"""Assemble les voix d'un épisode et écrit la timeline (début et fin de chaque réplique).

usage :
  python voix_timeline.py script.json                      # avec voix : voix.wav + timeline.json
  python voix_timeline.py script.json --sans-voix          # vidéo muette : timeline.json calculée sur le texte
  options : [--sortie dossier] [--silence -38] [--trou 0.25] [--debit 2.6]

script.json :
{
  "prises": {"nora": "audio/nora.mp3", "marc": "audio/marc.mp3"},   # une prise par personnage
  "lignes": [
    {"qui": "marc", "texte": "Ton augmentation ? On en reparlera."},
    {"qui": "nora", "texte": "Traduction : jamais.", "pause": 0.5},
    {"qui": "nora", "texte": "...", "fichier": "audio/ligne3.mp3"}   # ou un fichier par ligne
  ],
  "coupes": {"nora": [2.4, 5.1]}      # facultatif : instants exacts (en s, dans la prise) où couper
}

Avec voix : chaque prise contient toutes les répliques du personnage dans l'ordre, séparées par un
silence ([long pause] chez ElevenLabs, ou une respiration d'une seconde). Le script repère les zones de
parole, puis choisit les coupes qui donnent exactement autant de morceaux que de répliques : il préfère
les silences longs et des morceaux dont la durée colle à la longueur du texte. Un « Hmm », une
respiration ou un bruit de bouche reste donc collé à la réplique voisine au lieu de créer une réplique
de trop. Si une coupe tombe sur un silence très court, il le signale. "coupes" force les coupes à la main.

Sans voix (--sans-voix, ou "muet": true dans script.json, ou aucune prise ni fichier) : la durée de
chaque réplique est estimée sur son texte (syllabes, chiffres, ponctuation) au débit --debit (mots par
seconde, 2,6 par défaut). Une ligne peut imposer sa durée avec "duree": 2.5 (en s) et son silence
après elle avec "pause". Le montage se cale ensuite sur "L1", "L2"… comme avec une vraie voix.
"""
import argparse
import json
import os
import re
import subprocess
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import SR, ecrire_wav, ffmpeg_exe, lire_audio, volume_lufs  # noqa: E402

CIBLE_LUFS = -16.0


def silences(chemin, seuil_db, duree_min):
    out = subprocess.run([ffmpeg_exe(), "-hide_banner", "-i", chemin, "-af",
                          f"silencedetect=noise={seuil_db}dB:d={duree_min}", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    debuts = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", out)]
    fins = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", out)]
    return list(zip(debuts, fins + [None] * (len(debuts) - len(fins))))


def morceaux(chemin, duree_totale, seuil_db, duree_min, zone_min=0.12):
    """Zones de parole = tout ce qui n'est pas silence. Retourne [(début, fin)]."""
    zones, t = [], 0.0
    for a, b in silences(chemin, seuil_db, duree_min):
        if a - t > zone_min:
            zones.append((t, a))
        t = b if b is not None else duree_totale
    if duree_totale - t > zone_min:
        zones.append((t, duree_totale))
    return zones


def syllabes(texte):
    """Nombre de syllabes à peu près, pour estimer une durée de parole."""
    texte = re.sub(r"\[[^\]]*\]", " ", texte)  # balises de jeu [casual]
    n = 0.0
    for m in texte.split():
        chiffres = re.sub(r"\D", "", m)
        if chiffres:
            n += 1.6 * len(chiffres)
            continue
        v = re.findall(r"[aeiouyàâäéèêëîïôöùûü]+", m.lower())
        k = len(v)
        if k > 1 and re.search(r"[^aeiouy]e$|es$|ent$", m.lower()):
            k -= 1  # e muet final
        n += max(1, k)
    return n


def duree_estimee(texte, debit):
    """Durée de parole estimée (s) : syllabes au débit voulu + petites pauses de ponctuation."""
    vit = debit * 1.75  # ≈ syllabes par seconde
    pauses = len(re.findall(r"[,;:]", texte)) * 0.12 + len(re.findall(r"[.!?](?=\s+\S)", texte)) * 0.22
    return max(0.45, syllabes(texte) / vit + pauses)


def decouper(chemin, y, textes, seuil_db, debit=2.6, coupes=None):
    """Découpe une prise en autant de morceaux que de textes. Retourne [(début, fin)]."""
    duree = len(y) / SR
    attendu = len(textes)
    zones = morceaux(chemin, duree, seuil_db, 0.18, 0.04)  # un « À » court compte aussi
    if not zones:
        sys.exit(f"{os.path.basename(chemin)} : aucune parole trouvée (essayer --silence -45).")
    if coupes:
        bornes = [0.0] + sorted(float(c) for c in coupes) + [duree]
        if len(bornes) - 1 != attendu:
            sys.exit(f"{os.path.basename(chemin)} : {len(coupes)} coupes donnent {len(bornes) - 1} morceaux, "
                     f"{attendu} répliques attendues.")
        out = []
        for a, b in zip(bornes, bornes[1:]):
            dedans = [(max(a, z0), min(b, z1)) for z0, z1 in zones if z1 > a and z0 < b]
            out.append((dedans[0][0], dedans[-1][1]) if dedans else (a, b))
        return out
    K = len(zones)
    if K < attendu:
        # pas assez de silences : on cherche des silences plus courts et moins profonds
        for seuil2, d in ((seuil_db, 0.1), (seuil_db + 6, 0.12), (seuil_db + 10, 0.1)):
            z2 = morceaux(chemin, duree, seuil2, d, 0.04)
            if len(z2) >= attendu:
                zones, K = z2, len(z2)
                break
        else:
            sys.exit(f"{os.path.basename(chemin)} : {attendu} répliques attendues mais seulement {K} morceaux de parole.\n"
                     "Laisser un vrai silence entre les répliques, essayer --silence -32 (bruit de fond), "
                     "donner les instants de coupe (\"coupes\") ou un fichier par ligne (clé \"fichier\").")
    att = [duree_estimee(t, debit) for t in textes]
    parole = zones[-1][1] - zones[0][0]
    trous = sorted((zones[i + 1][0] - zones[i][1] for i in range(K - 1)), reverse=True)
    utile = parole - sum(trous[:attendu - 1])
    k = utile / (sum(att) or 1)
    att = [a * k for a in att]
    INF = float("inf")
    # f[j][i] : coût minimal pour placer les j premières répliques sur les i premières zones
    f = [[INF] * (K + 1) for _ in range(attendu + 1)]
    pred = [[0] * (K + 1) for _ in range(attendu + 1)]
    f[0][0] = 0.0
    for j in range(1, attendu + 1):
        for i in range(j, K - (attendu - j) + 1):
            for h in range(j - 1, i):
                if f[j - 1][h] == INF:
                    continue
                seg = zones[i - 1][1] - zones[h][0]
                c = ((seg - att[j - 1]) / (att[j - 1] + 0.6)) ** 2
                if h > 0:  # une coupe entre la zone h-1 et la zone h : on récompense les longs silences
                    c -= 2.0 * min(zones[h][0] - zones[h - 1][1], 1.5)
                if f[j - 1][h] + c < f[j][i]:
                    f[j][i], pred[j][i] = f[j - 1][h] + c, h
    out, i = [], K
    for j in range(attendu, 0, -1):
        h = pred[j][i]
        out.append((zones[h][0], zones[i - 1][1], h))
        i = h
    out.reverse()
    for j, (a, b, h) in enumerate(out[1:], start=2):
        trou = a - out[j - 2][1]
        if trou < 0.3:
            print(f"  attention : la coupe avant la réplique {j} tombe sur un silence de {trou:.2f} s, à vérifier à l'écoute "
                  f"(ou donner \"coupes\" dans script.json)")
    if K > attendu:
        print(f"  {os.path.basename(chemin)} : {K} morceaux de parole regroupés en {attendu} répliques")
    return [(a, b) for a, b, _ in out]


def fondu(seg, ms=12):
    n = min(int(SR * ms / 1000), len(seg) // 2)
    if n > 0:
        seg[:n] *= np.linspace(0, 1, n)
        seg[-n:] *= np.linspace(1, 0, n)
    return seg


def sans_voix(lignes, sortie, a):
    t, tl = a.debut, []
    for i, ln in enumerate(lignes, 1):
        d = float(ln.get("duree") or duree_estimee(ln.get("texte", ""), a.debit))
        tl.append({"n": i, "qui": ln.get("qui", ""), "texte": ln.get("texte", ""), "t0": round(t, 3), "t1": round(t + d, 3)})
        t += d + float(ln.get("pause", a.trou))
    json.dump({"duree": round(t, 3), "muet": True, "lignes": tl},
              open(os.path.join(sortie, "timeline.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for x in tl:
        print(f"L{x['n']:<3} {x['t0']:6.2f} → {x['t1']:6.2f}  {x['qui']:<10} {x['texte'][:60]}")
    print(f"Sans voix : durée estimée {t:.2f} s à {a.debit} mots/s → {os.path.join(sortie, 'timeline.json')}\n"
          "Lire la timeline : si une réplique doit rester plus longtemps à l'écran, lui donner \"duree\" dans script.json.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("script")
    ap.add_argument("--sortie", default=None, help="dossier de sortie (par défaut celui du script)")
    ap.add_argument("--silence", type=float, default=-38.0, help="seuil de silence en dB")
    ap.add_argument("--trou", type=float, default=0.25, help="silence ajouté après chaque réplique (s)")
    ap.add_argument("--debut", type=float, default=0.15, help="silence au tout début (s)")
    ap.add_argument("--sans-voix", action="store_true", help="vidéo muette : minutage estimé sur le texte")
    ap.add_argument("--debit", type=float, default=2.6, help="débit en mots par seconde (estimation)")
    a = ap.parse_args()

    base = os.path.dirname(os.path.abspath(a.script))
    sortie = a.sortie or base
    os.makedirs(sortie, exist_ok=True)
    sc = json.load(open(a.script, encoding="utf-8"))
    lignes = sc["lignes"]
    chemin = lambda p: p if os.path.isabs(p) else os.path.join(base, p)

    if a.sans_voix or sc.get("muet") or (not sc.get("prises") and not any("fichier" in ln for ln in lignes)):
        sans_voix(lignes, sortie, a)
        return

    # 1. volume de chaque source, gain pour viser la même intensité
    sources = {}
    for qui, f in sc.get("prises", {}).items():
        sources[qui] = chemin(f)
    for ln in lignes:
        if "fichier" in ln:
            sources["@" + ln["fichier"]] = chemin(ln["fichier"])
    gains, audio = {}, {}
    for cle, f in sources.items():
        if not os.path.exists(f):
            sys.exit(f"Fichier absent : {f}")
        audio[cle] = lire_audio(f)
        lufs = volume_lufs(f)
        gains[cle] = 1.0 if lufs is None or lufs < -70 else 10 ** ((CIBLE_LUFS - lufs) / 20)
        print(f"{os.path.basename(f)} : {lufs if lufs is not None else '?'} LUFS → gain {20 * np.log10(gains[cle]):+.1f} dB")

    # 2. découper chaque prise en répliques
    par_perso = {}
    for qui in sc.get("prises", {}):
        attendu = sum(1 for ln in lignes if ln["qui"] == qui and "fichier" not in ln)
        if attendu:
            textes = [ln.get("texte", "") for ln in lignes if ln["qui"] == qui and "fichier" not in ln]
            par_perso[qui] = decouper(sources[qui], audio[qui], textes, a.silence, a.debit, sc.get("coupes", {}).get(qui))
    rang = {qui: 0 for qui in par_perso}

    # 3. assembler
    out = [np.zeros(int(SR * a.debut), np.float32)]
    t = a.debut
    tl = []
    for i, ln in enumerate(lignes, 1):
        if "fichier" in ln:
            cle = "@" + ln["fichier"]
            y = audio[cle]
            z = morceaux(sources[cle], len(y) / SR, a.silence, 0.3)
            d0, d1 = (z[0][0], z[-1][1]) if z else (0, len(y) / SR)
        else:
            cle = ln["qui"]
            if cle not in par_perso:
                sys.exit(f"Ligne {i} : pas de prise pour « {cle} » dans \"prises\".")
            d0, d1 = par_perso[cle][rang[cle]]
            rang[cle] += 1
            y = audio[cle]
        d0, d1 = max(0.0, d0 - 0.04), min(len(y) / SR, d1 + 0.06)
        seg = fondu(y[int(d0 * SR):int(d1 * SR)].copy() * gains[cle])
        out.append(seg)
        tl.append({"n": i, "qui": ln["qui"], "texte": ln.get("texte", ""), "t0": round(t, 3), "t1": round(t + len(seg) / SR, 3)})
        t += len(seg) / SR
        pause = float(ln.get("pause", a.trou))
        out.append(np.zeros(int(SR * pause), np.float32))
        t += pause

    y = np.concatenate(out)
    crete = np.percentile(np.abs(y), 99.95) or 1.0
    y = np.tanh(y / crete * 0.9) * 0.89  # limiteur doux
    ecrire_wav(os.path.join(sortie, "voix.wav"), y)
    json.dump({"duree": round(t, 3), "lignes": tl}, open(os.path.join(sortie, "timeline.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    for x in tl:
        print(f"L{x['n']:<3} {x['t0']:6.2f} → {x['t1']:6.2f}  {x['qui']:<10} {x['texte'][:60]}")
    print(f"Durée totale : {t:.2f} s → {os.path.join(sortie, 'voix.wav')} et timeline.json")


if __name__ == "__main__":
    main()
