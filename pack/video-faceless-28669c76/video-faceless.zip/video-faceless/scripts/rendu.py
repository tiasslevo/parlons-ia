"""Moteur de montage animé en Python (Pillow + numpy + ffmpeg) : episode.json → vidéo verticale.

Marche partout où Python tourne : l'app Claude avec exécution de code, Claude Code, Cowork.
Pas de navigateur, pas de Node.

usage :
  python rendu.py episode.json --images auto            # 16 images de contrôle + planche.jpg (hors transitions)
  python rendu.py episode.json --images 1.5,L4,9.2 --zones   # instants choisis → planche-essai.jpg
  python rendu.py episode.json --verifier               # zones TikTok, hors écran, perso coupé, texte qui déborde
  python rendu.py episode.json --sortie video.mp4 [--qualite haute|normale|legere] [--cues cues.json] [--muet]
  python rendu.py episode.json --sortie essai.mp4 --de 0 --a 12   # un morceau seulement
  python rendu.py --catalogue                           # liste des clés disponibles

Tout ce qu'on peut écrire dans episode.json : references/bibliotheque.md.
Les temps s'écrivent en secondes (3.2) ou par réplique de la timeline :
  "L3" début de la réplique 3, "L3.fin" sa fin, "L3@0.5" son milieu, "L3+0.4" / "L3.fin-0.2" décalés,
  "L3#4" début du 4e mot de la réplique 3 (minutage mot à mot estimé, ou réel si la timeline le contient), "fin".
"""
import argparse
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import time as chrono

from PIL import Image, ImageDraw, ImageFilter, ImageOps

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import ffmpeg_exe  # noqa: E402
from dessin import (Couleurs, Polices, carte_autour, contour_blanc, degrade, dessiner_texte, grain,  # noqa: E402
                    halo, lumiere, motif, preparer_da, vignette)
from elements import TYPES, adoucir, creer  # noqa: E402

TRANSITIONS = {
    "coupe": 0.0, "gauche": 0.36, "droite": 0.36, "haut": 0.36, "bas": 0.36,
    "recouvre-gauche": 0.36, "recouvre-droite": 0.36, "recouvre-haut": 0.36, "recouvre-bas": 0.36,
    "zoom-avant": 0.4, "zoom-arriere": 0.4, "fondu": 0.4, "fondu-noir": 0.6, "flash": 0.24,
    "volet-gauche": 0.4, "volet-droite": 0.4, "volet-haut": 0.4, "volet-bas": 0.4,
    "bande": 0.5, "rond": 0.45, "flou": 0.4, "secousse": 0.0,
}
DIRS = {"gauche": (-1, 0), "droite": (1, 0), "haut": (0, -1), "bas": (0, 1)}


# ---------------------------------------------------------------- temps
class Temps:
    def __init__(self, timeline, duree):
        self.lignes = {x["n"]: x for x in timeline.get("lignes", [])} if timeline else {}
        self.duree = duree
        self._mots = {}

    def mots(self, n, texte=None):
        """[(mot, t0, t1)] d'une réplique. Minutage réel si la timeline a "mots", sinon estimé."""
        cle = (n, texte)
        if cle in self._mots:
            return self._mots[cle]
        ln = self.lignes[n]
        brut = texte if texte is not None else ln.get("texte", "")
        brut = re.sub(r"(?<!\[)\[[A-Za-zÀ-ÿ' -]+\](?!\])", " ", brut)  # balises de jeu [casual]…
        brut = brut.replace("\\n", " ")
        mots = [m for m in brut.split() if m]
        reels = ln.get("mots")
        if reels and texte is None and len(reels) == len(mots):
            out = [(m, float(r["t0"]), float(r["t1"])) for m, r in zip(mots, reels)]
        elif reels and texte is None:
            out = [(r.get("mot", r.get("m", "")), float(r["t0"]), float(r["t1"])) for r in reels]
        else:
            def poids(m):
                p = len(re.findall(r"[aeiouyàâéèêëîïôùûü]+", m.lower())) or 1
                return p + (0.8 if re.search(r"[.,;:!?]$", m) else 0) + (1.2 if re.search(r"\d", m) else 0)
            ps = [poids(m) for m in mots]
            tot = sum(ps) or 1
            a, b = ln["t0"] + 0.04, ln["t1"] - 0.04
            t, out = a, []
            for m, p in zip(mots, ps):
                d = (b - a) * p / tot
                out.append((m, t, t + d))
                t += d
        self._mots[cle] = out
        return out

    def __call__(self, v, defaut=None):
        if v is None:
            return defaut
        if isinstance(v, (int, float)):
            return float(v)
        s = str(v).replace(" ", "")
        if s == "fin":
            return self.duree
        m = re.fullmatch(r"L(\d+)(?:#(\d+))?(\.fin)?(?:@([\d.]+))?([+-][\d.]+)?", s)
        if not m:
            m2 = re.fullmatch(r"([\d.]+)([+-][\d.]+)?", s)
            if m2:
                return float(m2.group(1)) + float(m2.group(2) or 0)
            sys.exit(f"Temps illisible : {v!r} (attendu 3.2, \"L3\", \"L3.fin\", \"L3@0.5\", \"L3+0.4\", \"L3#2\")")
        n = int(m.group(1))
        if n not in self.lignes:
            sys.exit(f"La réplique L{n} n'existe pas dans timeline.json")
        ln = self.lignes[n]
        if m.group(2):
            mots = self.mots(n)
            i = min(len(mots), max(1, int(m.group(2)))) - 1
            t = mots[i][2] if m.group(3) else mots[i][1]
        else:
            t = ln["t1"] if m.group(3) else ln["t0"]
            if m.group(4):
                t = ln["t0"] + float(m.group(4)) * (ln["t1"] - ln["t0"])
        if m.group(5):
            t += float(m.group(5))
        return t


# ---------------------------------------------------------------- épisode
class Episode:
    def __init__(self, chemin):
        self.base = os.path.dirname(os.path.abspath(chemin))
        self.ep = json.load(open(chemin, encoding="utf-8"))
        self.W, self.H = self.ep.get("taille", [1080, 1920])
        self.fps = self.ep.get("fps", 30)
        self.da = preparer_da(self.ep.get("da", {}))
        self.c = Couleurs(self.da)
        self.polices = Polices(self.base, self.da)
        tl = None
        if self.ep.get("timeline"):
            tl = json.load(open(self.p(self.ep["timeline"]), encoding="utf-8"))
        self.duree = float(self.ep.get("duree") or (tl["duree"] + 0.6 if tl else 10))
        self.T = Temps(tl, self.duree)
        self.images, self.fonds, self.videos = {}, {}, {}
        self.scenes = []
        for sc in self.ep["scenes"]:
            t0 = self.T(sc.get("de"), 0.0)
            fs = self.fond_base(sc)
            self.scenes.append({"sc": sc, "t0": t0, "els": [creer(e, t0, self, fs) for e in sc.get("elements", [])]})
        for i, s in enumerate(self.scenes):
            s["t1"] = self.scenes[i + 1]["t0"] if i + 1 < len(self.scenes) else self.duree
            s["entree"] = s["sc"].get("entree", s["sc"].get("transition", "gauche" if i else "coupe"))
            if i == 0:
                s["entree"] = "coupe"
            if s["entree"] not in TRANSITIONS:
                sys.exit(f"Transition inconnue : {s['entree']!r}. Choix : {', '.join(TRANSITIONS)}")
            s["fond_base"] = self.fond_base(s["sc"])
            s["dt"] = float(s["sc"].get("duree_transition", TRANSITIONS[s["entree"]]))
        self.permanent = [creer(e, 0.0, self, self.da["fond"]) for e in self.ep.get("permanent", [])]
        self.punch = [self.T(x) for x in self.ep.get("punch", [])]
        self.flashs = [self.T(x) for x in self.ep.get("flash", [])]
        self.secousses = [el.t0 for s in self.scenes for el in s["els"] if el.type == "tampon"]
        self.secousses += [s["t0"] for s in self.scenes if s["entree"] == "secousse"]
        self.secousses += [self.T(x) for x in self.ep.get("secousses", [])]
        self.soustitres = [(self.T(x["de"]), self.T(x["a"]), x["texte"]) for x in self.ep.get("soustitres", [])]

    def p(self, rel):
        return rel if os.path.isabs(rel) else os.path.join(self.base, rel)

    # -------- images et médias
    def image(self, src, l, h=None, contour=0, miroir=False, coupe=None, bouche=None):
        """bouche : (image_de_bouche, x, y, l, rot), x/y/l en fractions de l'image source, posée avant recadrage."""
        cle = (src, int(l), h, contour, miroir, coupe, bouche)
        if cle not in self.images:
            f = self.p(src)
            if not os.path.isfile(f):
                sys.exit(f"Image absente : {f}")
            im = Image.open(f).convert("RGBA")
            if bouche:
                im = self.poser_bouche(im, *bouche)
            if coupe:
                bb = im.getbbox() or (0, 0, im.width, im.height)
                im = im.crop((0, bb[1], im.width, int(bb[1] + (bb[3] - bb[1]) * coupe)))
            if miroir:
                im = ImageOps.mirror(im)
            k = min(l / im.width, h / im.height) if h else l / im.width
            im = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))), Image.LANCZOS)
            if contour:
                im = contour_blanc(im, int(contour))
            self.images[cle] = im
        return self.images[cle]

    def poser_bouche(self, im, src, x, y, l, rot=0.0):
        """Colle une bouche détourée (sur sa pastille de peau) sur le visage, bords adoucis."""
        cle = ("bouche", src, im.width, l, rot)
        if cle not in self.images:
            f = self.p(src)
            if not os.path.isfile(f):
                sys.exit(f"Image de bouche absente : {f}")
            b = Image.open(f).convert("RGBA")
            bw = max(4, int(im.width * float(l)))
            b = b.resize((bw, max(2, int(b.height * bw / b.width))), Image.LANCZOS)
            r = max(1, bw // 40)
            b.putalpha(b.getchannel("A").filter(ImageFilter.MinFilter(2 * r + 1)).filter(ImageFilter.GaussianBlur(r)))
            if rot:
                b = b.rotate(-rot, Image.BICUBIC, expand=True)
            self.images[cle] = b
        b = self.images[cle]
        out = im.copy()
        out.alpha_composite(b, (int(im.width * float(x) - b.width / 2), int(im.height * float(y) - b.height / 2)))
        return out

    def enveloppe(self, src=None):
        """Volume de la voix image par image (0 à 1), pour la bouche qui bouge."""
        src = src or self.ep.get("audio") or self.ep.get("voix")
        if not src:
            sys.exit("bouche : pas de voix dans episode.json (clé \"voix\")")
        if not hasattr(self, "enveloppes"):
            self.enveloppes = {}
        if src not in self.enveloppes:
            import numpy as np
            from outils import lire_audio
            sr = 16000
            y = lire_audio(self.p(src), sr)
            n = int(sr / self.fps)
            k = len(y) // n
            rms = np.sqrt((y[:k * n].reshape(k, n) ** 2).mean(axis=1)) if k else np.zeros(1)
            actif = rms[rms > 1e-4]
            ref = float(np.percentile(actif, 90)) if len(actif) else 1.0
            env = np.clip(rms / max(ref, 1e-6), 0, 1)
            self.enveloppes[src] = np.convolve(env, [0.25, 0.5, 0.25], mode="same")  # évite le clignotement
        return self.enveloppes[src]

    def photo(self, src, w, h, zoom=1.0):
        cle = ("photo", src, w, h)
        if cle not in self.images:
            f = self.p(src)
            if not os.path.isfile(f):
                sys.exit(f"Média absent : {f}")
            self.images[cle] = ImageOps.fit(Image.open(f).convert("RGBA"), (int(w * 1.25), int(h * 1.25)), Image.LANCZOS)
        big = self.images[cle]
        if zoom == 1.0 and ("photo1", src, w, h) in self.images:
            return self.images[("photo1", src, w, h)]
        cw, ch = big.width / 1.25 / zoom * 1.0, big.height / 1.25 / zoom
        x0, y0 = (big.width - cw * 1.0) / 2, (big.height - ch) / 2
        im = big.resize((w, h), Image.LANCZOS, box=(x0, y0, x0 + cw, y0 + ch))
        if zoom == 1.0:
            self.images[("photo1", src, w, h)] = im
        return im

    def video_image(self, src, w, h, t, boucle=True):
        """Image de la vidéo à l'instant t (s), recadrée en w × h. Les images sont extraites une fois."""
        cle = (src, w, h)
        if cle not in self.videos:
            f = self.p(src)
            if not os.path.isfile(f):
                sys.exit(f"Vidéo absente : {f}")
            dossier = os.path.join(self.base, ".cache-media", hashlib.md5(f"{f}{w}{h}{self.fps}".encode()).hexdigest()[:10])
            if not os.path.isdir(dossier) or not os.listdir(dossier):
                os.makedirs(dossier, exist_ok=True)
                vf = f"fps={self.fps},scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}"
                r = subprocess.run([ffmpeg_exe(), "-v", "error", "-i", f, "-vf", vf, "-q:v", "3", os.path.join(dossier, "%05d.jpg")])
                if r.returncode != 0:
                    sys.exit(f"Lecture de la vidéo impossible : {f}")
            self.videos[cle] = (dossier, sorted(os.listdir(dossier)), {})
        dossier, fichiers, cache = self.videos[cle]
        i = int(t * self.fps)
        i = i % len(fichiers) if boucle else min(i, len(fichiers) - 1)
        if i not in cache:
            if len(cache) > 40:
                cache.clear()
            cache[i] = Image.open(os.path.join(dossier, fichiers[i])).convert("RGBA")
        return cache[i]

    # -------- fonds
    def spec_fond(self, sc):
        f = sc.get("fond", self.da["fond"])
        if isinstance(f, dict):
            spec = dict(f)
        else:
            spec = {"type": "motif" if sc.get("motif") else "uni", "couleur": f}
            if sc.get("motif"):
                spec.update(motif=sc["motif"], motif_couleur=sc.get("motif_couleur", "#00000014"), pas=sc.get("pas", 72))
        for k in ("grain", "vignette"):
            if k in sc:
                spec[k] = sc[k]
        return spec

    def fond_base(self, sc):
        """Couleur dominante du fond (pour choisir automatiquement encre ou clair pour le texte)."""
        s = self.spec_fond(sc)
        if s.get("type") in ("image", "photo", "video"):
            return "#000000" if s.get("assombrir", 0.35) > 0.2 else "#808080"
        return s.get("couleur") or s.get("de") or self.da["fond"]

    def fond(self, sc, t):
        s = self.spec_fond(sc)
        typ = s.get("type", "uni")
        defile = s.get("defile")
        cle = json.dumps(s, sort_keys=True)
        if typ in ("video",):
            im = self.video_image(s["src"], self.W, self.H, t, True).copy()
            return self._sur_media(im, s)
        if cle not in self.fonds:
            W, H = self.W, self.H
            c = self.c
            base = c(s.get("couleur", "fond"))
            if typ == "degrade":
                img = degrade(W, H, c(s.get("de", "fond")), c(s.get("vers", "accent")), s.get("angle", 90), s.get("radial", False),
                              s.get("x", 0.5), s.get("y", 0.4))
            elif typ == "faisceau":
                img = lumiere(W, H, c(s.get("couleur", "#141B33")), c(s.get("lumiere", "#FFF4D6")), s.get("x", 0.5),
                              s.get("ouverture", 24), s.get("force", 0.75), s.get("sol", 0.8))
            elif typ == "halo":
                img = halo(W, H, base, c(s.get("lumiere", "accent")), s.get("x", 0.5), s.get("y", 0.45), s.get("rayon", 0.5),
                           s.get("force", 0.6))
            elif typ in ("image", "photo"):
                img = ImageOps.fit(Image.open(self.p(s["src"])).convert("RGBA"), (W, H), Image.LANCZOS)
                img = self._sur_media(img, s)
            else:
                img = Image.new("RGBA", (W, H), base)
            if typ == "motif" or s.get("motif"):
                pas = int(s.get("pas", 72))
                cal = motif(W + (pas * 2 if defile else 0), H + (pas * 2 if defile else 0), s.get("motif", "quadrillage"),
                            c(s.get("motif_couleur", "#00000014")), pas, s.get("epaisseur"))
                if defile:
                    self.fonds[cle] = (img, cal, pas)
                else:
                    img.alpha_composite(cal)
            if s.get("grain"):
                img = grain(img, float(s["grain"]) * 0.12)
            if s.get("vignette"):
                img = vignette(img, float(s["vignette"]))
            if cle not in self.fonds:
                self.fonds[cle] = img
        f = self.fonds[cle]
        if isinstance(f, tuple):
            img, cal, pas = f
            vx, vy = defile
            ox, oy = int((t * vx) % pas), int((t * vy) % pas)
            img = img.copy()
            img.alpha_composite(cal.crop((pas - ox, pas - oy, pas - ox + self.W, pas - oy + self.H)))
            return img
        return f.copy()

    def _sur_media(self, im, s):
        if s.get("flou"):
            im = im.filter(ImageFilter.GaussianBlur(float(s["flou"])))
        a = float(s.get("assombrir", 0.35))
        if a:
            im = Image.alpha_composite(im, Image.new("RGBA", im.size, (0, 0, 0, int(255 * a))))
        return im

    # -------- composition
    def scene_img(self, s, t):
        img = self.fond(s["sc"], t)
        for el in s["els"]:
            el.dessiner(img, t)
        cam = s["sc"].get("camera")
        if cam:
            if cam == "lent":
                cam = {"zoom": [1.0, 1.05]}
            z0, z1 = cam.get("zoom", [1.0, 1.05])
            k = min(1.0, max(0.0, (t - s["t0"]) / max(0.1, s["t1"] - s["t0"])))
            z = z0 + (z1 - z0) * k
            if abs(z - 1) > 0.002:
                cx, cy = cam.get("x", self.W / 2), cam.get("y", self.H * 0.45)
                w, h = self.W / z, self.H / z
                x0 = min(max(0.0, cx - w / 2), self.W - w)
                y0 = min(max(0.0, cy - h / 2), self.H - h)
                img = img.resize((self.W, self.H), Image.BILINEAR, box=(x0, y0, x0 + w, y0 + h))
        return img

    def transition(self, prev, cur, typ, p, s):
        W, H = self.W, self.H
        p = max(0.0, min(1.0, p))
        e = adoucir(p)
        if typ in DIRS:
            vx, vy = DIRS[typ]
            img = Image.new("RGBA", (W, H))
            img.paste(prev, (int(vx * e * W), int(vy * e * H)))
            img.paste(cur, (int(-vx * (1 - e) * W), int(-vy * (1 - e) * H)))
            return img
        if typ.startswith("recouvre-"):
            vx, vy = DIRS[typ.split("-")[1]]
            img = prev.copy()
            img.paste(cur, (int(-vx * (1 - e) * W), int(-vy * (1 - e) * H)))
            return img
        if typ.startswith("volet-"):
            vx, vy = DIRS[typ.split("-")[1]]
            m = Image.new("L", (W, H), 0)
            g = ImageDraw.Draw(m)
            if vx:
                x = W * e
                g.rectangle([W - x, 0, W, H] if vx < 0 else [0, 0, x, H], fill=255)
            else:
                y = H * e
                g.rectangle([0, H - y, W, H] if vy < 0 else [0, 0, W, y], fill=255)
            return Image.composite(cur, prev, m)
        if typ == "bande":
            acc = Image.new("RGBA", (W, H), self.c(s["sc"].get("couleur_transition", "accent")))
            img = prev if p < 0.5 else cur
            k = adoucir(p * 2) if p < 0.5 else adoucir((p - 0.5) * 2)
            m = Image.new("L", (W, H), 0)
            g = ImageDraw.Draw(m)
            if p < 0.5:
                g.polygon([(0, 0), (W * 1.3 * k, 0), (W * 1.3 * k - 300, H), (0, H)], fill=255)
            else:
                g.polygon([(W * 1.3 * k, 0), (W + 400, 0), (W + 400, H), (W * 1.3 * k - 300, H)], fill=255)
            return Image.composite(acc, img, m)
        if typ == "rond":
            cx, cy = s["sc"].get("centre_transition", [W / 2, H * 0.45])
            R = math.hypot(max(cx, W - cx), max(cy, H - cy)) * e
            m = Image.new("L", (W, H), 0)
            ImageDraw.Draw(m).ellipse([cx - R, cy - R, cx + R, cy + R], fill=255)
            return Image.composite(cur, prev, m)
        if typ == "fondu":
            return Image.blend(prev, cur, e)
        if typ == "fondu-noir":
            noir = Image.new("RGBA", (W, H), (0, 0, 0, 255))
            return Image.blend(prev, noir, adoucir(p * 2)) if p < 0.5 else Image.blend(noir, cur, adoucir((p - 0.5) * 2))
        if typ == "flash":
            blanc = Image.new("RGBA", (W, H), self.c(s["sc"].get("couleur_transition", "#FFFFFF")))
            return Image.blend(prev, blanc, p * 2) if p < 0.5 else Image.blend(blanc, cur, (p - 0.5) * 2)
        if typ in ("zoom-avant", "zoom-arriere"):
            av = typ == "zoom-avant"
            z_prev = 1 + (0.35 if av else -0.25) * e
            z_cur = (0.8 if av else 1.3) + ((0.2 if av else -0.3) * e)
            fond = Image.new("RGBA", (W, H), self.c("encre"))

            def zoomer(im, z):
                w, h = int(W * z), int(H * z)
                g = im.resize((w, h), Image.BILINEAR)
                if z >= 1:
                    return g.crop(((w - W) // 2, (h - H) // 2, (w - W) // 2 + W, (h - H) // 2 + H))
                out = fond.copy()
                out.paste(g, ((W - w) // 2, (H - h) // 2))
                return out
            return Image.blend(zoomer(prev, z_prev), zoomer(cur, z_cur), adoucir(min(1.0, p * 1.4)))
        if typ == "flou":
            r = 28 * (1 - abs(p - 0.5) * 2)
            img = Image.blend(prev, cur, e)
            return img.filter(ImageFilter.GaussianBlur(r)) if r > 0.5 else img
        return cur

    def image_a(self, t):
        idx = 0
        for i, s in enumerate(self.scenes):
            if t >= s["t0"] - s["dt"] / 2:
                idx = i
        s = self.scenes[idx]
        typ = s["entree"]
        if idx > 0 and s["dt"] > 0 and t < s["t0"] + s["dt"] / 2:
            p = (t - (s["t0"] - s["dt"] / 2)) / s["dt"]
            prev = self.scene_img(self.scenes[idx - 1], t)
            cur = self.scene_img(s, max(t, s["t0"]))
            img = self.transition(prev, cur, typ, p, s)
        elif idx > 0 and t < s["t0"]:
            img = self.scene_img(self.scenes[idx - 1], t)
        else:
            img = self.scene_img(s, t)
        base = s["fond_base"] if t >= s["t0"] or idx == 0 else self.scenes[idx - 1]["fond_base"]
        for el in self.permanent:
            if not el.e.get("couleur"):
                el.fond_scene = base
            el.dessiner(img, t)
        z = 1.0
        for tp in self.punch:
            if 0 <= t - tp < 0.3:
                z = 1 + 0.045 * math.sin(math.pi * (t - tp) / 0.3)
        dx = dy = 0
        for ts in self.secousses:
            if 0.03 <= t - ts < 0.22:
                k = (0.22 - (t - ts)) / 0.19
                dx, dy = int(math.sin((t - ts) * 90) * 10 * k), int(math.cos((t - ts) * 70) * 7 * k)
        if z != 1.0 or dx or dy:
            zw, zh = int(self.W * z) + 24, int(self.H * z) + 24
            g = img.resize((zw, zh), Image.BILINEAR)
            img = g.crop(((zw - self.W) // 2 - dx, (zh - self.H) // 2 - dy, (zw - self.W) // 2 - dx + self.W, (zh - self.H) // 2 - dy + self.H))
        for ts in [el.t0 for s2 in self.scenes for el in s2["els"] if el.type == "tampon"] + self.flashs:
            if 0.03 <= t - ts < 0.03 + 2 / self.fps:
                img = Image.blend(img.convert("RGBA"), Image.new("RGBA", img.size, (255, 255, 255, 255)), 0.45)
        for a, b, txt in self.soustitres:
            if a <= t < b:
                self.sous_titre(img, txt)
        return img

    def sous_titre(self, img, txt):
        pol = self.polices.get(self.ep.get("soustitres_taille", 62), "texte")
        t_img = dessiner_texte(txt, pol, self.W - 300, self.c("encre"), self)
        t_img = carte_autour(t_img, "papier", self, marge=12, ombre="aucune")
        img.alpha_composite(t_img, (int(480 - t_img.width / 2), int(self.ep.get("soustitres_y", 1300))))

    # -------- repères son
    def cues(self):
        out = []
        son_transition = {"coupe": "coupe", "secousse": "impact", "flash": "impact", "fondu": None, "fondu-noir": None}
        for i, s in enumerate(self.scenes):
            if i:
                typ = son_transition.get(s["entree"], "whoosh")
                if typ:
                    out.append({"t": round(s["t0"] - s["dt"] / 2, 3), "type": typ})
            for el in s["els"] + (self.permanent if i == 0 else []):
                out += self.cues_element(el)
        for tp in self.punch:
            out.append({"t": round(tp, 3), "type": "impact"})
        out.sort(key=lambda c: c["t"])
        return out

    def cues_element(self, el):
        out = []
        ty, an = el.type, el.anim
        if ty == "tampon":
            out.append({"t": round(el.t0, 3), "type": "impact"})
        elif ty == "perso" and an == "monte":
            out.append({"t": round(el.t0, 3), "type": "glisse"})
        elif ty in ("liste",):
            out += [{"t": round(it["_a"], 3), "type": "pop"} for it in el.items]
            out += [{"t": round(it["_coche"], 3), "type": "pop"} for it in el.items if it["_coche"] is not None]
        elif ty == "etapes":
            out += [{"t": round(f, 3), "type": "pop"} for f in el.faits]
        elif ty in ("bouton",) and el.clic is not None:
            out.append({"t": round(el.clic, 3), "type": "clic"})
        elif ty in ("curseur",):
            out.append({"t": round(el.tps("clic", el.tps("fin", el.t0 + 0.6) + 0.1), 3), "type": "clic"})
        elif ty in ("notification",):
            out.append({"t": round(el.t0, 3), "type": "ding"})
        elif an not in ("aucune", "dessin", "fondu") and ty not in ("karaoke", "rubrique", "forme"):
            out.append({"t": round(el.t0, 3), "type": "pop"})
        return out

    # -------- vérification des zones et de la mise en page
    def verifier(self):
        """Rend chaque élément seul, à plusieurs moments, et signale : ce qui touche les zones masquées par
        TikTok, ce qui sort de l'écran (gauche, droite, haut), un personnage coupé en haut, un texte qui
        déborde de sa carte, de sa bulle, de sa notification ou de sa ligne de liste."""
        k = self.W / 1080
        zones = [("haut (y < 180)", (0, 0, self.W, 180 * k)), ("bas (y > 1450)", (0, 1450 * k, self.W, self.H)),
                 ("boutons à droite", (900 * k, 860 * k, self.W, 1450 * k))]
        self.alertes, self.mesurer = {}, True
        lignes = []
        for i, s in enumerate(self.scenes):
            for el in s["els"] + (self.permanent if i == 0 else []):
                if el.trace or el.type == "forme":  # traits et aplats décoratifs : libres de déborder
                    continue
                perm = el not in s["els"]
                fin = (self.duree if perm else s["t1"]) - 0.05
                if el.t1 is not None:
                    fin = min(fin, el.t1 - 0.01)
                debut = max(el.fin_entree(), el.t0 + 0.5)
                moments = sorted({round(min(debut, fin), 2), round((min(debut, fin) + fin) / 2, 2), round(fin, 2)})
                if el.type == "karaoke":
                    moments = sorted({round((g[0] + g[1]) / 2, 2) for g in el.groupes})
                quoi = str(el.e.get("texte") or el.e.get("src") or el.e.get("titre") or "")[:40]
                nom_el = f"scène {i + 1} ({s['t0']:.1f} s) · {el.type}" + (f" « {quoi} »" if quoi else "")
                vus = set()
                for t in moments:
                    img = Image.new("RGBA", (self.W, self.H))
                    el.dernier_cadre = el.mesure = None
                    el.dessiner(img, t)
                    bb = getattr(el, "mesure", None)
                    if not bb:
                        continue
                    msgs = []
                    if bb[0] < -6:
                        msgs.append(f"sort de l'écran à gauche de {int(-bb[0])} px")
                    if bb[2] > self.W + 6:
                        msgs.append(f"sort de l'écran à droite de {int(bb[2] - self.W)} px")
                    if bb[1] < -4:
                        msgs.append(("personnage coupé en haut" if el.type in ("perso", "medaillon") else "sort de l'écran en haut")
                                    + f" de {int(-bb[1])} px (réduire \"h\", ou augmenter \"y\" pour descendre)")
                    elif el.type == "perso" and bb[1] < 180 * k and el.e.get("cadrage", "pied") != "tete":
                        msgs.append(f"tête du personnage sous l'interface TikTok (haut à y = {int(bb[1])}) : réduire \"h\" ou augmenter \"y\"")
                    if bb[3] > self.H + 4 and el.type != "perso":
                        msgs.append(f"sort de l'écran en bas de {int(bb[3] - self.H)} px")
                    for nom, z in zones:
                        if el.type == "perso" and nom.startswith("bas"):
                            continue
                        if el.type == "perso" and nom.startswith("haut"):
                            continue  # déjà traité ci-dessus
                        ix = min(bb[2], z[2]) - max(bb[0], z[0])
                        iy = min(bb[3], z[3]) - max(bb[1], z[1])
                        if ix > 20 * k and iy > 20 * k:
                            msgs.append(f"déborde en zone {nom} de {int(ix)} × {int(iy)} px")
                    for m in msgs:
                        cle = m.split(" de ")[0]
                        if cle not in vus:
                            vus.add(cle)
                            lignes.append(f"  {nom_el} à {t:.1f} s : {m}")
                for _, msgs in [self.alertes.pop(id(el), (None, set()))]:
                    for m in sorted(msgs):
                        lignes.append(f"  {nom_el} : {m}")
        self.mesurer = False
        self.alertes = None
        for ln in lignes:
            print(ln)
        print("Aucun débordement." if not lignes else f"{len(lignes)} problème(s) de mise en page à corriger ou à assumer.")

    def temps_controle(self, n=16):
        """Instants des images de contrôle automatiques, déplacés hors des transitions."""
        out = []
        for i in range(n):
            t = self.duree * (i + 0.5) / n
            for j, s in enumerate(self.scenes[1:], start=1):
                a, b = s["t0"] - s["dt"] / 2 - 0.04, s["t0"] + s["dt"] / 2 + 0.04
                if a <= t <= b:
                    # après la transition, le temps que les éléments de la scène arrivent
                    t = b + min(0.45, max(0.06, (s["t1"] - b) / 2)) if b + 0.06 < self.duree else a - 0.06
            for ts in self.secousses + self.flashs:  # flash blanc et secousse des tampons : on attend qu'ils passent
                if ts <= t < ts + 0.28:
                    t = ts + 0.3
            t = round(min(max(0.0, t), self.duree - 0.02), 2)
            while out and t <= out[-1] + 0.05 and t + 0.25 < self.duree:
                t = round(t + 0.25, 2)
            out.append(t)
        return out


def zones_tiktok(img):
    W, H = img.size
    k = W / 1080
    calque = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(calque)
    rouge = (229, 72, 77, 70)
    d.rectangle([0, 0, W, 180 * k], fill=rouge)
    d.rectangle([0, 1450 * k, W, H], fill=rouge)
    d.rectangle([900 * k, 860 * k, W, 1450 * k], fill=rouge)
    img.alpha_composite(calque)
    return img


def catalogue():
    print("Éléments :", ", ".join(sorted(TYPES)))
    print("Transitions (clé \"entree\" d'une scène) :", ", ".join(TRANSITIONS))
    print("Animations d'entrée (\"anim\") : pop, zoom, monte, descend, glisse, glisse-gauche, glisse-droite, fondu, rebond, "
          "tourne, elastique, deplie, revele, aucune ; texte : \"mode\" = mots ou machine")
    print("Sorties (\"sortie\") : reduit, fondu, glisse-gauche, glisse-droite, monte, descend, coupe")
    print("Boucles (\"boucle\") : balance, flotte, respire, pulse, tremble (combinables : \"balance+flotte\")")
    print("Fonds (\"fond\": {\"type\": …}) : uni, degrade, motif, faisceau, halo, image, video ; options grain, vignette, defile")
    print("Motifs : quadrillage, points, lignes, colonnes, diagonales, losanges, croix, vagues, cercles, damier, rayons")
    print("Marques du mot clé : *mot* (selon la DA), ==surligné==, __souligné__, [[pastille]], ((encadré))")
    print("DA \"marque\" : couleur, surligneur, pastille, souligne, encadre · \"ombre\" : dure, douce, aucune")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("episode", nargs="?")
    ap.add_argument("--sortie", help="fichier mp4 à écrire (chemin relatif au dossier d'episode.json)")
    ap.add_argument("--images", help="'auto' ou liste de secondes : images de contrôle + planche.jpg")
    ap.add_argument("--planche", help="nom de la planche (défaut : planche.jpg avec auto, planche-essai.jpg sinon)")
    ap.add_argument("--zones", action="store_true", help="montre les zones masquées par TikTok sur les images de contrôle")
    ap.add_argument("--verifier", action="store_true", help="liste ce qui déborde : zones TikTok, bords de l'écran, cartes")
    ap.add_argument("--qualite", default="normale", choices=["haute", "normale", "legere"])
    ap.add_argument("--de", type=float, default=0.0)
    ap.add_argument("--a", type=float, default=None)
    ap.add_argument("--cues", help="écrit les repères son (cues.json) pour mix_son.py")
    ap.add_argument("--muet", action="store_true", help="ne pas ajouter la voix")
    ap.add_argument("--catalogue", action="store_true", help="affiche ce que le moteur sait faire")
    a = ap.parse_args()
    if a.catalogue or not a.episode:
        catalogue()
        return
    ep = Episode(a.episode)

    if a.verifier:
        ep.verifier()

    if a.cues:
        json.dump(ep.cues(), open(a.cues, "w", encoding="utf-8"), indent=1)
        print(f"Repères son : {a.cues}")

    if a.images:
        auto = a.images == "auto"
        temps = ep.temps_controle() if auto else [ep.T(x.strip()) for x in a.images.split(",")]
        dossier = os.path.join(ep.base, "controle")
        os.makedirs(dossier, exist_ok=True)
        vignettes = []
        for t in temps:
            img = ep.image_a(t)
            if a.zones:
                img = zones_tiktok(img)
            f = os.path.join(dossier, f"t{t:06.2f}.png")
            img.convert("RGB").save(f)
            vignettes.append((t, img.convert("RGB").resize((ep.W // 4, ep.H // 4), Image.LANCZOS)))
        cols = 4
        lignes = math.ceil(len(vignettes) / cols)
        vw, vh = ep.W // 4, ep.H // 4
        planche = Image.new("RGB", (cols * (vw + 12) + 12, lignes * (vh + 52) + 12), (40, 40, 44))
        dp = ImageDraw.Draw(planche)
        pol = ep.polices.get(30, "texte", 600)
        for i, (t, v) in enumerate(vignettes):
            x, y = 12 + (i % cols) * (vw + 12), 12 + (i // cols) * (vh + 52)
            planche.paste(v, (x, y))
            dp.text((x, y + vh + 8), f"{t:.2f} s", font=pol, fill=(230, 230, 230))
        nom_planche = a.planche or ("planche.jpg" if auto else "planche-essai.jpg")
        planche.save(os.path.join(dossier, nom_planche), quality=88)
        print(f"{len(temps)} images dans {dossier} + {nom_planche}")

    if a.sortie:
        fin = min(a.a if a.a is not None else ep.duree, ep.duree)
        n0, n1 = int(a.de * ep.fps), int(fin * ep.fps)
        W, H = ep.W, ep.H
        crf = {"haute": "17", "normale": "21", "legere": "25"}[a.qualite]
        echelle = ["-vf", "scale=720:1280:flags=lanczos"] if a.qualite == "legere" else []
        cmd = [ffmpeg_exe(), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(ep.fps), "-i", "-"]
        voix = ep.ep.get("audio") or ep.ep.get("voix")
        if voix and not a.muet:
            cmd += ["-ss", str(a.de), "-t", str(fin - a.de), "-i", ep.p(voix), "-map", "0:v", "-map", "1:a", "-c:a", "aac", "-b:a", "192k"]
        cmd += echelle + ["-c:v", "libx264", "-preset", "medium" if a.qualite != "haute" else "slow", "-crf", crf,
                          "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-t", str(fin - a.de), ep.p(a.sortie)]
        os.makedirs(os.path.dirname(ep.p(a.sortie)) or ".", exist_ok=True)
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        debut = chrono.time()
        for n in range(n0, n1):
            img = ep.image_a(n / ep.fps).convert("RGB")
            proc.stdin.write(img.tobytes())
            if (n - n0) % (ep.fps * 5) == 0:
                print(f"  {n / ep.fps:6.1f} s / {fin:.1f} s  ({chrono.time() - debut:.0f} s écoulées)", flush=True)
        proc.stdin.close()
        if proc.wait() != 0:
            sys.exit("ffmpeg a échoué")
        taille = os.path.getsize(ep.p(a.sortie)) / 1e6
        print(f"Vidéo : {ep.p(a.sortie)} ({taille:.1f} Mo, {chrono.time() - debut:.0f} s de calcul)")
        if taille > 30:
            print("Attention : plus de 30 Mo, trop lourd pour un téléchargement depuis l'app Claude. Relancer avec --qualite legere.")


if __name__ == "__main__":
    main()
