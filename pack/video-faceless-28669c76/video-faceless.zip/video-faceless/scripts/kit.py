"""Le kit de série : tout ce qui rend la série reconnaissable, rangé dans un seul ZIP.

usage :
  python kit.py creer ma-serie/ [--sortie kit-ma-serie.zip] [--max-px 1600]
  python kit.py lire kit-ma-serie.zip [--vers ma-serie/]      # ou un dossier (kit décompressé, fichiers d'un Projet)

creer lit le dossier de la série et fabrique kit-<serie>.zip :
  kit-<serie>/
    LISEZ-MOI.md          à quoi sert le kit et où le ranger (Projet Claude, conversation, Claude Code)
    serie.md              la fiche complète : DA, ton, règles du personnage, prompts de style
    da.json               le bloc "da" et les fonds, lisibles par le code
    persos/               la référence, les expressions, les bouches (png transparents)
    polices/              les polices de la DA, avec leur licence
    sons/                 la banque de sons personnelle, s'il y en a une
    apercu-da.jpg         trois écrans types rendus dans la DA
    apercu-persos.jpg     toutes les images du personnage sur une planche

lire décompresse le kit (dans --vers, par défaut un dossier au nom de la série), vérifie qu'il ne
manque rien et affiche le résumé à suivre pour la vidéo suivante.
"""
import argparse
import json
import math
import os
import re
import shutil
import sys
import tempfile
import zipfile

from PIL import Image, ImageDraw

ICI = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(ICI)
sys.path.insert(0, ICI)

IMAGES = (".png", ".jpg", ".jpeg", ".webp")
LIMITE_APP = 30e6


# ---------------------------------------------------------------- lecture de serie.md
def objet_json(texte, cle):
    """Trouve "cle": {...} dans un texte (bloc de code ou ligne) et renvoie l'objet."""
    m = re.search(r'"%s"\s*:\s*\{' % re.escape(cle), texte)
    if not m:
        return None
    i, prof = m.end() - 1, 0
    for j in range(i, len(texte)):
        if texte[j] == "{":
            prof += 1
        elif texte[j] == "}":
            prof -= 1
            if prof == 0:
                try:
                    return json.loads(texte[i:j + 1])
                except json.JSONDecodeError:
                    return None
    return None


def fond_ligne(texte, libelle):
    """Lit une ligne « - Fond de série : `{...}` » ou « `#hex` »."""
    m = re.search(r"%s[^:\n]*:\s*`([^`]+)`" % re.escape(libelle), texte, re.I)
    if not m:
        return None
    v = m.group(1).strip()
    try:
        return json.loads(v)
    except json.JSONDecodeError:
        return v if re.fullmatch(r"#[0-9A-Fa-f]{6,8}", v) else None


def lire_fiche(dossier):
    f = os.path.join(dossier, "serie.md")
    if not os.path.isfile(f):
        sys.exit(f"Pas de serie.md dans {dossier}")
    txt = open(f, encoding="utf-8").read()
    titre = re.search(r"^#\s+(.+)$", txt, re.M)
    titre = titre.group(1).strip() if titre else os.path.basename(os.path.abspath(dossier))
    titre = re.sub(r"\s*[—-]\s*fiche\s*$", "", titre)
    return txt, titre, objet_json(txt, "da"), fond_ligne(txt, "Fond de série"), fond_ligne(txt, "Fond de fin")


def slug(t):
    import unicodedata
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode()
    t = re.sub(r"[^a-zA-Z0-9]+", "-", t).strip("-").lower()
    return t[:40] or "serie"


# ---------------------------------------------------------------- images du personnage
def images_perso(dossier):
    d = os.path.join(dossier, "persos")
    if not os.path.isdir(d):
        return []
    out = []
    for racine, sous, fs in os.walk(d):
        sous[:] = [s for s in sous if s.lower() not in ("brut", "bruts", "raw", "cut-brut", "essais")]
        for f in sorted(fs):
            if f.lower().endswith(".png") and not f.lower().startswith("planche"):
                out.append(os.path.join(racine, f))
    return out


def planche(fichiers, sortie, fond="#2A2A2E", c=300):
    cols = min(4, max(1, len(fichiers)))
    rows = math.ceil(len(fichiers) / cols)
    pl = Image.new("RGB", (cols * (c + 16) + 16, rows * (c + 46) + 16), (40, 40, 44))
    d = ImageDraw.Draw(pl)
    try:
        from PIL import ImageFont
        pol = ImageFont.truetype(os.path.join(SKILL, "assets", "fonts", "Geist.ttf"), 20)
    except OSError:
        pol = None
    for i, f in enumerate(fichiers):
        x, y = 16 + (i % cols) * (c + 16), 16 + (i // cols) * (c + 46)
        case = Image.new("RGBA", (c, c), fond)
        im = Image.open(f).convert("RGBA")
        im.thumbnail((c - 16, c - 16))
        case.alpha_composite(im, ((c - im.width) // 2, (c - im.height) // 2))
        pl.paste(case.convert("RGB"), (x, y))
        d.text((x, y + c + 8), os.path.basename(f)[:30], font=pol, fill=(230, 230, 230))
    pl.save(sortie, quality=86)


# ---------------------------------------------------------------- aperçu de la DA
def apercu_da(dossier, da, fond_serie, fond_fin, persos, sortie):
    """Trois écrans types (ouverture, explication, fin) rendus par rendu.py dans la DA de la série."""
    from rendu import Episode
    ref = next((p for p in persos if os.path.basename(p).lower().startswith(("reference", "neutre"))), None)
    ref = ref or next((p for p in persos if "bouche" not in os.path.basename(p).lower()), None)
    fs = fond_serie or da.get("fond", "#FFFFFF")
    ff = fond_fin or "accent"
    perso = [{"type": "perso", "src": os.path.abspath(ref), "h": 760, "x": 480, "y": 1480, "anim": "aucune", "boucle": "aucune"}] if ref else []
    coin = [{"type": "perso", "src": os.path.abspath(ref), "h": 420, "x": 760, "y": 1440, "anim": "aucune", "boucle": "aucune"}] if ref else []
    ep = {
        "taille": [1080, 1920], "fps": 30, "duree": 3.0, "da": da,
        "scenes": [
            {"de": 0, "fond": fs, "elements": [
                {"type": "texte", "texte": "Le titre de ta vidéo\navec le *mot clé*", "taille": 92, "y": 420, "largeur": 860,
                 "anim": "aucune"},
                {"type": "pastille", "texte": "ta série", "y": 640, "anim": "aucune"}] + perso},
            {"de": 1.0, "fond": fs, "entree": "coupe", "elements": [
                {"type": "liste", "y": 300, "l": 800, "anim": "aucune", "pas": 0.0,
                 "elements": [{"texte": "Une étape claire", "a": 0}, {"texte": "La ligne *active*", "a": 0, "actif": 0},
                              {"texte": "Une étape cochée", "a": 0, "coche": 0}]},
                {"type": "notification", "app": "Message", "titre": "Une notification", "texte": "dans le style de la série",
                 "y": 1050, "anim": "aucune"}] + coin},
            {"de": 2.0, "fond": ff, "entree": "coupe", "elements": [
                {"type": "gros", "texte": "ABONNE-TOI", "y": 700, "anim": "aucune"},
                {"type": "bouton", "texte": "S'abonner", "fond": "encre", "y": 1000, "anim": "aucune"}]},
        ],
    }
    tmp = os.path.join(dossier, ".kit-apercu")
    os.makedirs(tmp, exist_ok=True)
    chemin = os.path.join(tmp, "episode.json")
    json.dump(ep, open(chemin, "w", encoding="utf-8"), ensure_ascii=False)
    try:
        e = Episode(chemin)
        vues = [e.image_a(t).convert("RGB").resize((360, 640), Image.LANCZOS) for t in (0.9, 1.9, 2.9)]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    pl = Image.new("RGB", (3 * 360 + 4 * 14, 640 + 28), (40, 40, 44))
    for i, v in enumerate(vues):
        pl.paste(v, (14 + i * 374, 14))
    pl.save(sortie, quality=88)


# ---------------------------------------------------------------- polices
def polices_da(dossier, da):
    """[(chemin, licence ou None)] des polices nommées dans la DA."""
    from dessin import Polices
    noms = {da.get("police_titre"), da.get("police_texte"), da.get("police_mono")} - {None}
    if da.get("police"):
        noms.add(da["police"])
    pol = Polices(dossier, da)
    out = []
    for n in sorted(noms):
        p = pol.chemin(n)
        if not p or os.path.basename(p) != os.path.basename(n):
            print(f"  attention : police « {n} » introuvable, à joindre au kit à la main")
            continue
        lic = None
        d = os.path.dirname(p)
        base = os.path.splitext(os.path.basename(p))[0].lower()
        for f in os.listdir(d):
            fl = f.lower()
            if (fl.startswith(("ofl", "licen")) and base[:6] in fl.replace("-", "")) or fl in (f"{base}-licence.txt", f"{base}-license.txt"):
                lic = os.path.join(d, f)
        out.append((p, lic))
    return out


LISEZ_MOI = """# Kit de la série « {titre} »

Ce kit contient tout ce qui fait que tes vidéos se ressemblent : ta direction artistique, ton personnage,
ses expressions, tes polices. Le skill vidéo faceless (installé une fois dans Claude) apporte la méthode et
les programmes ; ce kit apporte TA série. Garde-le précieusement et mets-le à jour quand ta DA change.

## Où le ranger

- **App Claude avec un Projet** (conseillé) : ajoute dans les fichiers du Projet `serie.md`,
  `apercu-da.jpg` et toutes les images de `persos/` (et tes polices si tu en as ajouté). Chaque nouvelle
  conversation du Projet les retrouve. Garde aussi le ZIP sur ton téléphone ou ton ordinateur.
- **Nouvelle conversation hors Projet** : joins ce ZIP dès le premier message et écris
  « Voici le kit de ma série, on fait une nouvelle vidéo ».
- **Claude Code** : laisse le contenu dans le dossier de ta série (`serie.md`, `persos/`, `polices/`).

## Contenu

- `serie.md` : la fiche de la série (DA, ton, règles du personnage, prompts de style pour les images)
- `da.json` : les réglages de la DA pour le montage
- `persos/` : {n_persos} image(s) du personnage
- `polices/` : {polices}
- `apercu-da.jpg`, `apercu-persos.jpg` : pour vérifier d'un coup d'œil que rien n'a dérivé

Créé par `kit.py` le {date}.
"""


def creer(a):
    dossier = os.path.abspath(a.dossier)
    txt, titre, da, fond_serie, fond_fin = lire_fiche(dossier)
    if not da:
        sys.exit("serie.md n'a pas de bloc \"da\" lisible (\"da\": {...} en JSON). Le compléter avant de faire le kit.")
    persos = images_perso(dossier)
    if not persos:
        print("  attention : aucune image dans persos/ ; le kit n'aura pas le personnage")
    nom = f"kit-{slug(titre)}"
    sortie = os.path.abspath(a.sortie or os.path.join(dossier, nom + ".zip"))
    tmp = tempfile.mkdtemp()
    racine = os.path.join(tmp, nom)
    os.makedirs(os.path.join(racine, "persos"))
    shutil.copy(os.path.join(dossier, "serie.md"), racine)
    json.dump({"serie": titre, "da": da, "fond_serie": fond_serie, "fond_fin": fond_fin},
              open(os.path.join(racine, "da.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    copies = []
    for p in persos:
        rel = os.path.relpath(p, os.path.join(dossier, "persos"))
        dst = os.path.join(racine, "persos", rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        im = Image.open(p)
        if max(im.size) > a.max_px:
            im = im.convert("RGBA")
            im.thumbnail((a.max_px, a.max_px), Image.LANCZOS)
            im.save(dst, optimize=True)
        else:
            shutil.copy(p, dst)
        copies.append(dst)
    pols = polices_da(dossier, da)
    if pols:
        os.makedirs(os.path.join(racine, "polices"))
        for p, lic in pols:
            shutil.copy(p, os.path.join(racine, "polices"))
            if lic:
                shutil.copy(lic, os.path.join(racine, "polices"))
    if os.path.isdir(os.path.join(dossier, "sons")):
        shutil.copytree(os.path.join(dossier, "sons"), os.path.join(racine, "sons"))
    if copies:
        planche(copies, os.path.join(racine, "apercu-persos.jpg"), fond=da.get("fond", "#2A2A2E"))
    apercu_da(dossier, da, fond_serie, fond_fin, persos, os.path.join(racine, "apercu-da.jpg"))
    import datetime
    open(os.path.join(racine, "LISEZ-MOI.md"), "w", encoding="utf-8").write(LISEZ_MOI.format(
        titre=titre, n_persos=len(copies), date=datetime.date.today().strftime("%d/%m/%Y"),
        polices=", ".join(os.path.basename(p) for p, _ in pols) or "aucune (polices du skill)"))
    if os.path.exists(sortie):
        os.remove(sortie)
    with zipfile.ZipFile(sortie, "w", zipfile.ZIP_DEFLATED) as z:
        for r, _, fs in os.walk(racine):
            for f in sorted(fs):
                p = os.path.join(r, f)
                z.write(p, os.path.relpath(p, tmp))
    shutil.copy(os.path.join(racine, "apercu-da.jpg"), os.path.join(os.path.dirname(sortie), "apercu-da.jpg"))
    shutil.rmtree(tmp)
    taille = os.path.getsize(sortie)
    print(f"Kit : {sortie} ({taille / 1e6:.1f} Mo) · {len(copies)} images du personnage · "
          f"{len(pols)} police(s) · aperçu de la DA : {os.path.join(os.path.dirname(sortie), 'apercu-da.jpg')}")
    if taille > LIMITE_APP:
        print("Attention : plus de 30 Mo, trop lourd pour l'app Claude. Relancer avec --max-px 1200.")


def lire(a):
    src = os.path.abspath(a.kit)
    tmp = None
    if os.path.isfile(src):
        tmp = tempfile.mkdtemp()
        with zipfile.ZipFile(src) as z:
            for n in z.namelist():
                cible = os.path.abspath(os.path.join(tmp, n))
                if not cible.startswith(tmp + os.sep):
                    sys.exit(f"Chemin refusé dans le ZIP : {n}")
            z.extractall(tmp)
        base = tmp
    else:
        base = src
    fiches = [r for r, _, fs in os.walk(base) if "serie.md" in fs]
    if not fiches:
        sys.exit("Pas de serie.md dans ce kit.")
    racine = min(fiches, key=len)
    txt, titre, da, fond_serie, fond_fin = lire_fiche(racine)
    dj = os.path.join(racine, "da.json")
    if os.path.isfile(dj):
        info = json.load(open(dj, encoding="utf-8"))
        da = da or info.get("da")
        fond_serie = fond_serie or info.get("fond_serie")
        fond_fin = fond_fin or info.get("fond_fin")
    vers = os.path.abspath(a.vers or (racine if tmp is None else os.path.join(os.getcwd(), slug(titre))))
    if vers != racine:
        os.makedirs(vers, exist_ok=True)
        for f in os.listdir(racine):
            s, d = os.path.join(racine, f), os.path.join(vers, f)
            if os.path.isdir(s):
                shutil.copytree(s, d, dirs_exist_ok=True)
            else:
                shutil.copy(s, d)
    if tmp:
        shutil.rmtree(tmp)
    # fichiers posés à plat (fichiers d'un Projet Claude, pièces jointes) : on les range
    for f in sorted(os.listdir(vers)):
        p = os.path.join(vers, f)
        if not os.path.isfile(p):
            continue
        if f.lower().endswith(".png") and not f.lower().startswith(("apercu", "planche")):
            os.makedirs(os.path.join(vers, "persos"), exist_ok=True)
            shutil.move(p, os.path.join(vers, "persos", f))
        elif f.lower().endswith((".ttf", ".otf")):
            os.makedirs(os.path.join(vers, "polices"), exist_ok=True)
            shutil.move(p, os.path.join(vers, "polices", f))
    persos = images_perso(vers)
    noms = [os.path.splitext(os.path.basename(p))[0] for p in persos]
    bouches = [n for n in noms if "bouche" in n.lower()]
    poses = [n for n in noms if n not in bouches]
    print(f"Série : {titre}")
    print(f"Dossier de la série : {vers}")
    for cle in ("Sujet", "Public", "Ton", "Ce qu'on ne fait pas", "Durée visée", "Fin de vidéo habituelle"):
        m = re.search(r"^-\s*%s\s*:\s*(.+)$" % re.escape(cle), txt, re.M)
        if m:
            print(f"  {cle} : {m.group(1).strip()}")
    print(f"  Poses du personnage ({len(poses)}) : {', '.join(poses) or 'aucune'}")
    if bouches:
        print(f"  Bouches : {', '.join(bouches)}")
    manque = []
    if not da:
        manque.append("le bloc \"da\" de serie.md")
    else:
        print('  Bloc "da" à recopier dans episode.json :\n    ' + json.dumps(da, ensure_ascii=False))
        from dessin import Polices
        pol = Polices(os.path.join(vers, "episodes", "x"), da)
        for n in {da.get("police_titre"), da.get("police_texte")} - {None}:
            p = pol.chemin(n)
            if not p or os.path.basename(p) != os.path.basename(n):
                manque.append(f"la police {n}")
    if fond_serie:
        print("  Fond de série : " + json.dumps(fond_serie, ensure_ascii=False))
    if not any(n.lower().startswith(("reference", "neutre")) for n in poses):
        manque.append("l'image de référence du personnage (persos/reference.png)")
    for f in ("apercu-da.jpg",):
        if not os.path.isfile(os.path.join(vers, f)):
            manque.append(f)
    if manque:
        print("À compléter : " + " ; ".join(manque))
    else:
        print("Kit complet : la vidéo suivante peut partir de là (episodes/<date-sujet>/ dans ce dossier).")


def main():
    ap = argparse.ArgumentParser(description="Créer ou relire le kit d'une série.")
    sp = ap.add_subparsers(dest="action", required=True)
    c = sp.add_parser("creer", help="fabrique kit-<serie>.zip depuis le dossier de la série")
    c.add_argument("dossier")
    c.add_argument("--sortie")
    c.add_argument("--max-px", type=int, default=1600, help="taille maximale des images du personnage dans le kit")
    lr = sp.add_parser("lire", help="décompresse et vérifie un kit")
    lr.add_argument("kit")
    lr.add_argument("--vers", help="dossier de la série où ranger le kit")
    a = ap.parse_args()
    creer(a) if a.action == "creer" else lire(a)


if __name__ == "__main__":
    main()
