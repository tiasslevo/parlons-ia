import React from 'react';
import {Composition} from 'remotion';
import {Episode, DUREE} from './Episode';
export const Root: React.FC = () => <Composition id="Main" component={Episode} durationInFrames={DUREE} fps={30} width={1080} height={1920} />;
