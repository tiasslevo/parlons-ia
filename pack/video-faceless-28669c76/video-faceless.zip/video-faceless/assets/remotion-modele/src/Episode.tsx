// EXEMPLE à réécrire pour chaque épisode : une scène par moment du script, chaque action calée sur une réplique.
// Cet exemple met en scène deux personnages qui se répondent ; ce n'est qu'une structure possible, pas un format à suivre.
// Zones sûres TikTok : contenu entre y 180 et y 1450, rien à droite de x 900 sous y 860.
import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import {FPS, THEME, DUREE_VOIX, L, Lfin, Lat, Scene, Stage, Fond, Perso, Bulle, Texte, Gros, Piece, Tampon, Compteur, Medaillon, Cercle, Hl, effets} from './kit';

export const DUREE = Math.round((DUREE_VOIX + 0.8) * FPS);
const JAUNE = '#FFE45C', NUIT = THEME.encre;

const SCENES: Scene[] = [
  {t0: 0, t1: L(2), render: (t) => <><Fond c={JAUNE} /><Perso t={t} t0={0} src="persos/adversaire-normal.png" />
    <Bulle t={t} n={1} texte="Ton augmentation ? On en reparlera." /></>},
  {t0: L(2), t1: L(3), render: (t) => <><Fond c={NUIT} /><Perso t={t} t0={L(2)} src="persos/heros-blase.png" x={480} l={820} />
    <Gros t={t} t0={L(2, 0.1)} y={420} sz={220} c="#fff">jamais.</Gros></>},
  {t0: L(3), t1: L(4), sortie: 'haut', render: (t) => <><Fond c={THEME.papier} motif="quadrillage" />
    <Piece t={t} t0={L(3)} src="pieces/fiche.png" x={480} y={760} l={640} />
    <Texte t={t} t0={Lat(3, 0.5)} y={260} sz={96}>une <Hl on={t > Lat(3, 0.6)}>date</Hl> et des critères</Texte>
    <Cercle t={t} t0={Lat(3, 0.7)} x={480} y={700} rx={260} ry={80} />
    <Medaillon t={t} t0={L(3, 0.3)} src="persos/heros-neutre.png" /></>},
  {t0: L(4), t1: L(5), entree: 'haut', render: (t) => <><Fond c={THEME.papier} motif="points" />
    <Compteur t={t} a={Lat(4, 0.3)} b={Lat(4, 0.8)} de={0} vers={15} suffixe=" mars" y={800} sz={200} c={THEME.vert} /></>},
  {t0: L(5), t1: DUREE_VOIX + 1, render: (t) => <><Fond c={JAUNE} /><Perso t={t} t0={L(5)} src="persos/adversaire-normal.png" changements={[[L(6), 'persos/heros-neutre.png']]} />
    <Bulle t={t} n={5} texte="On en reparlera." barre={L(6)} />
    <Tampon t={t} t0={L(6, 0.3)} x={480} y={760} texte="15 MARS" /></>},
];
const FX = effets([L(2), L(6, 0.3)]);

export const Episode: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  return (
    <AbsoluteFill style={{background: '#fff', overflow: 'hidden'}}>
      <Audio src={staticFile('voix.wav')} />
      <AbsoluteFill style={{transform: `translate(${FX.secousse(t)}px, ${FX.secousse(t + 0.03) * 0.6}px) scale(${FX.zoom(t)})`, transformOrigin: '480px 760px'}}>
        {SCENES.map((sc, i) => <Stage key={i} sc={sc} t={t} />)}
      </AbsoluteFill>
      <AbsoluteFill style={{background: '#fff', opacity: FX.flash(t), pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
