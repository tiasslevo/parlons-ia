// Kit de montage animé (Remotion) : décors, swipes, personnage, bulle, texte, pièce, tampon, compteur, médaillon, cercle.
// Tout se cale sur timeline.json (sortie de scripts/voix_timeline.py). Changer la DA dans THEME.
import React from 'react';
import {AbsoluteFill, Img, interpolate, spring, staticFile, Easing} from 'remotion';
import {loadFont} from '@remotion/fonts';
import timeline from './timeline.json';

export const THEME = {
  police: 'Geist', fichierPolice: 'Geist.ttf', graisse: 800,
  encre: '#14161A', accent: '#2F5BFF', surligneur: '#FFE45C', vert: '#2EC27E', rouge: '#E5484D', papier: '#FFFFFF',
  ombre: true, contour: 6, rayon: 28,
};
loadFont({family: THEME.police, url: staticFile(THEME.fichierPolice), weight: '100 900'});

export const FPS = 30;
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const pop = (t: number, t0: number, d = 12, k = 170) => spring({frame: Math.round((t - t0) * FPS), fps: FPS, config: {damping: d, stiffness: k}});
export const ease = (t: number, a: number, b: number, from = 0, to = 1) => interpolate(t, [a, b], [from, to], {...clamp, easing: Easing.out(Easing.cubic)});

// ---------- temps par réplique ----------
type Ligne = {n: number; qui: string; texte: string; t0: number; t1: number};
const LIGNES = (timeline as {duree: number; lignes: Ligne[]}).lignes;
export const DUREE_VOIX = (timeline as {duree: number}).duree;
const ligne = (n: number) => { const l = LIGNES.find((x) => x.n === n); if (!l) throw new Error(`Réplique L${n} absente de timeline.json`); return l; };
export const L = (n: number, plus = 0) => ligne(n).t0 + plus;          // début de la réplique n
export const Lfin = (n: number, plus = 0) => ligne(n).t1 + plus;       // fin de la réplique n
export const Lat = (n: number, frac: number) => ligne(n).t0 + frac * (ligne(n).t1 - ligne(n).t0);

// ---------- texte ----------
export const txt = (sz: number, c = THEME.encre): React.CSSProperties => ({fontFamily: THEME.police, fontWeight: THEME.graisse, letterSpacing: '-0.04em', fontSize: sz, lineHeight: 1.05, color: c});
export const Hl: React.FC<{on: boolean; c?: string; children: React.ReactNode}> = ({on, c = THEME.surligneur, children}) => <span style={{background: on ? c : 'transparent', padding: '0 12px', borderRadius: 10}}>{children}</span>;

// ---------- décors et scènes ----------
export const Fond: React.FC<{c: string; motif?: 'quadrillage' | 'points'}> = ({c, motif}) => (
  <AbsoluteFill style={{background: c, ...(motif === 'quadrillage' ? {backgroundImage: 'linear-gradient(#0000000F 2px, transparent 2px), linear-gradient(90deg, #0000000F 2px, transparent 2px)', backgroundSize: '72px 72px'} : motif === 'points' ? {backgroundImage: 'radial-gradient(#00000022 4px, transparent 5px)', backgroundSize: '72px 72px'} : {})}} />
);
export type Dir = 'haut' | 'bas' | 'gauche' | 'droite';
const V: Record<Dir, [number, number]> = {haut: [0, -1], bas: [0, 1], gauche: [-1, 0], droite: [1, 0]};
const SW = 0.36;
export type Scene = {t0: number; t1: number; entree?: Dir; sortie?: Dir; render: (t: number) => React.ReactNode};
// sans entree/sortie : coupe sèche. Avec : swipe étiré et flouté.
export const Stage: React.FC<{sc: Scene; t: number}> = ({sc, t}) => {
  if (t < sc.t0 - (sc.entree ? SW / 2 : 0) || t >= sc.t1 + (sc.sortie ? SW / 2 : 0)) return null;
  let dx = 0, dy = 0, et = 0;
  if (sc.entree && t < sc.t0 + SW / 2) { const p = ease(t, sc.t0 - SW / 2, sc.t0 + SW / 2); const [vx, vy] = V[sc.entree]; dx = -vx * (1 - p) * 1100; dy = -vy * (1 - p) * 1920; et = Math.sin(Math.PI * p) * 0.8; }
  if (sc.sortie && t > sc.t1 - SW / 2) { const p = interpolate(t, [sc.t1 - SW / 2, sc.t1 + SW / 2], [0, 1], {...clamp, easing: Easing.in(Easing.cubic)}); const [vx, vy] = V[sc.sortie]; dx = vx * p * 1100; dy = vy * p * 1920; et = Math.sin(Math.PI * p) * 0.8; }
  return <AbsoluteFill style={{transform: `translate(${dx}px, ${dy}px)`, filter: et > 0.05 ? `blur(${et * 7}px)` : undefined}}>{sc.render(Math.max(t, sc.t0))}</AbsoluteFill>;
};

// ---------- personnage : image fixe par expression, entre par le bas, se balance ----------
export const Perso: React.FC<{t: number; t0: number; src: string; x?: number; bas?: number; l?: number; changements?: [number, string][]}> = ({t, t0, src, x = 330, bas = 1500, l = 760, changements = []}) => {
  const p = pop(t, t0, 13, 160);
  const img = changements.filter(([a]) => t >= a).map(([, s]) => s).pop() ?? src;
  return <Img src={staticFile(img)} style={{position: 'absolute', left: x - l / 2, top: bas - l + (1 - p) * 800, width: l, height: l, objectFit: 'contain', objectPosition: 'bottom', transform: `rotate(${Math.sin(t * 1.3) * 1.2}deg)`, transformOrigin: '50% 100%'}} />;
};

// ---------- carte et bulle : les mots tombent pendant la réplique ----------
export const Carte: React.FC<{x: number; y: number; l: number; s?: number; r?: number; fond?: string; children: React.ReactNode}> = ({x, y, l, s = 1, r = 0, fond = THEME.papier, children}) => (
  <div style={{position: 'absolute', left: x - l / 2, top: y, width: l, transform: `scale(${s}) rotate(${r}deg)`, transformOrigin: '30% 100%', background: fond, border: `${THEME.contour}px solid ${THEME.encre}`, borderRadius: 40, boxShadow: THEME.ombre ? `9px 9px 0 ${THEME.encre}` : undefined, padding: '40px 46px', boxSizing: 'border-box'}}>{children}</div>
);
export const Bulle: React.FC<{t: number; texte: string; n: number; x?: number; y?: number; l?: number; sz?: number; queue?: boolean; barre?: number}> = ({t, texte, n, x = 480, y = 260, l = 840, sz = 76, queue = true, barre}) => {
  const a = L(n), b = Lfin(n);
  const mots = texte.split(' ');
  const k = barre !== undefined ? ease(t, barre, barre + 0.3) : 0;
  return <Carte x={x} y={y} l={l} s={pop(t, a - 0.05, 11, 200)} r={-1.5}>
    <div style={{...txt(sz), lineHeight: 1.12, display: 'flex', flexWrap: 'wrap', gap: '0 18px'}}>
      {mots.map((m, i) => { const ti = a + (i / mots.length) * (b - a) * 0.9; const q = ease(t, ti - 0.05, ti + 0.12); return <span key={i} style={{opacity: q, transform: `translateY(${(1 - q) * 26}px)`, display: 'inline-block'}}>{m}</span>; })}
    </div>
    {queue && <svg width="120" height="110" style={{position: 'absolute', left: 120, bottom: -104}}><path d="M10 6 L70 6 L24 100 Z" fill={THEME.papier} stroke={THEME.encre} strokeWidth={THEME.contour} strokeLinejoin="round" /><rect x="8" y="0" width="66" height="10" fill={THEME.papier} /></svg>}
    {k > 0 && <svg style={{position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible'}}><line x1="4%" y1="25%" x2={`${4 + 92 * k}%`} y2={`${25 + 50 * k}%`} stroke={THEME.rouge} strokeWidth="22" strokeLinecap="round" /></svg>}
  </Carte>;
};

// ---------- éléments qui arrivent ----------
export const Texte: React.FC<{t: number; t0: number; y: number; sz: number; c?: string; children: React.ReactNode}> = ({t, t0, y, sz, c, children}) =>
  t < t0 - 0.03 ? null : <div style={{position: 'absolute', left: 60, right: 180, top: y, textAlign: 'center', ...txt(sz, c), transform: `scale(${pop(t, t0, 10, 230)})`}}>{children}</div>;
export const Gros: React.FC<{t: number; t0: number; y: number; sz: number; c?: string; children: React.ReactNode}> = ({t, t0, y, sz, c, children}) => {
  if (t < t0 - 0.03) return null; const p = pop(t, t0, 9, 320);
  return <div style={{position: 'absolute', left: 50, right: 150, top: y, textAlign: 'center', ...txt(sz, c), lineHeight: 1, transform: `scale(${1 + 0.6 * (1 - p)})`, opacity: Math.min(1, p * 1.5)}}>{children}</div>;
};
export const Piece: React.FC<{t: number; t0: number; src: string; x: number; y: number; l: number; r?: number}> = ({t, t0, src, x, y, l, r = 0}) =>
  t < t0 - 0.05 ? null : <Img src={staticFile(src)} style={{position: 'absolute', left: x - l / 2, top: y - l / 2 + Math.sin((t - t0) * 2.2) * 8, width: l, height: l, objectFit: 'contain', transform: `scale(${pop(t, t0, 11, 210)}) rotate(${r + Math.sin((t - t0) * 1.7) * 2}deg)`}} />;
export const Tampon: React.FC<{t: number; t0: number; x: number; y: number; texte: string; c?: string; r?: number; sz?: number}> = ({t, t0, x, y, texte, c = THEME.rouge, r = -12, sz = 80}) => {
  if (t < t0) return null; const p = pop(t, t0, 9, 240);
  return <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${r}deg) scale(${2 - p})`, opacity: Math.min(1, p), border: `9px solid ${c}`, borderRadius: 18, padding: '8px 22px', ...txt(sz, c), background: 'rgba(255,255,255,.9)', whiteSpace: 'nowrap'}}>{texte}</div>;
};
export const Compteur: React.FC<{t: number; a: number; b: number; de: number; vers: number; y: number; sz: number; c?: string; suffixe?: string}> = ({t, a, b, de, vers, y, sz, c, suffixe = ''}) =>
  t < a - 0.05 ? null : <div style={{position: 'absolute', left: 60, right: 180, top: y, textAlign: 'center', ...txt(sz, c)}}>{Math.round(ease(t, a, b, de, vers)).toLocaleString('fr-FR')}{suffixe}</div>;
export const Medaillon: React.FC<{t: number; t0: number; src: string; x?: number; y?: number; d?: number; fond?: string}> = ({t, t0, src, x = 200, y = 1180, d = 300, fond = THEME.surligneur}) => {
  if (t < t0) return null;
  return <div style={{position: 'absolute', left: x - d / 2, top: y - d / 2, width: d, height: d, borderRadius: '50%', background: fond, border: `6px solid ${THEME.encre}`, boxShadow: `6px 6px 0 ${THEME.encre}`, overflow: 'hidden', transform: `scale(${pop(t, t0, 10, 220)}) rotate(${-4 + Math.sin(t * 2) * 2}deg)`}}>
    <Img src={staticFile(src)} style={{position: 'absolute', left: -d * 0.15, top: d * 0.04, width: d * 1.3, height: d * 1.3, objectFit: 'contain', objectPosition: 'top'}} />
  </div>;
};
export const Cercle: React.FC<{t: number; t0: number; x: number; y: number; rx: number; ry: number; c?: string}> = ({t, t0, x, y, rx, ry, c = THEME.rouge}) =>
  t < t0 ? null : <svg width={rx * 2 + 40} height={ry * 2 + 40} style={{position: 'absolute', left: x - rx - 20, top: y - ry - 20}}><ellipse cx={rx + 20} cy={ry + 20} rx={rx} ry={ry} fill="none" stroke={c} strokeWidth="11" strokeDasharray="4000" strokeDashoffset={4000 - 2 * Math.PI * Math.max(rx, ry) * 1.1 * ease(t, t0, t0 + 0.4)} strokeLinecap="round" /></svg>;

// ---------- temps forts : zoom, secousse, flash ----------
export const effets = (hits: number[]) => ({
  zoom: (t: number) => 1 + hits.reduce((a, p) => a + (t >= p ? 0.05 * Math.exp(-(t - p) * 7) : 0), 0),
  secousse: (t: number) => hits.reduce((a, p) => a + (t >= p && t < p + 0.15 ? Math.sin((t - p) * 120) * 7 * (1 - (t - p) / 0.15) : 0), 0),
  flash: (t: number) => hits.reduce((a, p) => Math.max(a, t >= p && t < p + 0.07 ? 0.35 : 0), 0),
});
