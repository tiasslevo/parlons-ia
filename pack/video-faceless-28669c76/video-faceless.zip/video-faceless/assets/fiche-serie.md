# [Nom de la série] — fiche

Ce fichier garde ce qui doit rester identique d'une vidéo à l'autre. Claude le relit avant chaque
vidéo. Il se remplit à la création de la série ; on le modifie seulement si la personne change un choix,
puis on refait le kit (`scripts/kit.py creer`).

## La série

- Compte : [nom du compte, plateforme]
- Sujet : [l'angle précis, une phrase]
- Public : [qui, quel âge, quel pays, ce qu'il cherche]
- Ton : [trois mots]
- Rythme : [posé / vif / très rapide] · Durée visée : [15 à 80 s]
- Ce qu'on ne fait pas : [sujets, mots, blagues exclus]
- Fin de vidéo habituelle : [abonne-toi, question en commentaire, lien en bio, rien]
- Voix : [ElevenLabs / sa propre voix / sans voix, texte à l'écran]

## Le personnage

- Qui : [la personne en avatar / personnage inventé : prénom, âge, rôle]
- Pourquoi on l'écoute : [ ]
- Caractère : [ ]
- Façon de parler : [tutoiement, expressions fréquentes, mots interdits]
- Style de dessin : [ ]
- Description exacte pour les prompts (recopier mot pour mot) :
  > [ ]
- Prompt de style du personnage (recopier mot pour mot) :
  > [ ]
- Image de référence : `persos/reference.png`
- Expressions disponibles : [neutre, explique, pointe, surpris, pensif, content…]
- Bouches : [non / `persos/bouche-1..3.png` et leurs positions par pose]
- Règles du personnage : [ce qu'il fait toujours, ce qu'il ne fait jamais : couleur de tenue fixe,
  accessoire signature, il ne crie pas, il n'apparaît jamais en entier sur les écrans de fin…]
- Mises en scène préférées : [en pied à gauche, buste en coin, médaillon carré, petit en coin…]

## Second personnage (facultatif)

- Qui, rôle : [ ]
- Description exacte pour les prompts :
  > [ ]
- Expressions : [ ]

## Voix

| Personnage | Source | Voix (nom et identifiant) | Balises de jeu habituelles |
|---|---|---|---|
| Principal | ElevenLabs / sa propre voix / aucune | [ ] | [ ] |

Modèle ElevenLabs utilisé : [ ] · Débit pour une vidéo sans voix : [2,6 mots/s]

## Direction artistique « [nom donné à la DA] »

- En une phrase : [ambiance, d'où elle vient]
- Bloc `"da"` à recopier dans chaque `episode.json` :
  ```json
  "da": { }
  ```
- Fond de série : `{ }`
- Fond des moments forts : `{ }` · Fond de fin : `{ }`
- Couleurs : fond [#], cartes [#], encre [#], accent [#] (à quoi il sert), surligneur [#]
- Polices : titres [fichier .ttf], texte [fichier .ttf] (licence : [OFL / autre])
- Marquage du mot clé : [couleur / surligneur / pastille / souligné / encadré]
- Texte à l'écran : [karaoké mot à mot / titres du mot clé / presque rien] · position : [haut, milieu]
- Rubrique fixe en haut : [oui : texte / non]
- Transitions préférées : [coupe + 1 ou 2 autres]
- Entrées préférées : [pop, monte, rebond…] · Boucles : [balance légère / aucune]
- Prompt de style des objets (recopier mot pour mot) :
  > [ ]
- Médias réels : [non / oui : lesquels]
- Sons : [banque du skill / sons personnels dans `sons/`]
