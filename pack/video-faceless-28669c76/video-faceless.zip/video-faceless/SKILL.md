---
name: video-faceless
description: Vidéos TikTok/Reels faceless où un personnage dessiné explique (voix IA ou la sienne) : personnage, DA, script, voix, images, montage animé, son, kit de série. Dès qu'on parle faceless ou avatar.
---

# Vidéos faceless avec un personnage

Ce skill fabrique des vidéos verticales (1080 × 1920) portées par un personnage dessiné : il parle,
réagit, et l'écran se construit au fil de sa voix (listes qui s'allument, étapes cochées, fenêtres qui
se tapent, chiffres qui montent, mots clés marqués). Chaque série a **sa propre DA**, décidée avec la
personne : aucun style ni format n'est imposé. Elle choisit, tu prépares, elle valide.

Toujours répondre en français simple, sans jargon : la personne n'est pas technique. Les fichiers de
`references/` se lisent au moment où l'étape en a besoin, pas tous d'un coup.

Deux choses à ne pas confondre (le dire à la personne si elle hésite) :
- **le skill** : installé une fois, il apporte la méthode et les programmes ; il est le même pour tous ;
- **le kit de série** (`kit-<serie>.zip`) : propre à la personne, il garde SA DA, SON personnage, SES
  polices. Il se fabrique à la fin de la première vidéo et se range dans son Projet Claude.

## 1. Au début de chaque conversation

**Où tu tournes :**

| Mode | Où | Montage | Comment le reconnaître |
|---|---|---|---|
| **App** | app Claude avec exécution de code | `scripts/rendu.py` dans le bac à sable | tu peux lancer Python, les fichiers disparaissent avec la conversation |
| **Studio** | Claude Code sur son ordinateur | `scripts/rendu.py` (ou Remotion, `assets/remotion-modele/`) | tu as un terminal et des fichiers locaux |
| **Sans code** | n'importe où | la personne monte dans CapCut avec ta feuille de montage | pas d'exécution de code |

```bash
python3 -c "import PIL, numpy; print('python ok')"
ffmpeg -version | head -1 || pip install imageio-ffmpeg
```

Si `pip install` échoue, passer en mode Sans code. Limites (30 Mo par fichier dans l'app) :
[references/environnements.md](references/environnements.md).

**Première vidéo ou série existante ?** Chercher un kit avant de poser des questions :
- un `serie.md` dans les fichiers du Projet, un `kit-*.zip` joint, ou un dossier de série (mode Studio) ;
- s'il existe : `python scripts/kit.py lire <kit.zip ou dossier> --vers ma-serie` range les fichiers
  et affiche le résumé (DA, poses, polices, ce qui manque). Passer directement à l'étape 4 ;
- sinon, c'est une nouvelle série : étape 3. Si la personne dit avoir déjà une série mais n'a rien
  joint, lui demander son kit plutôt que de tout recréer.

Détail des trois cas (Projet, conversation hors Projet, Claude Code) : [references/kit.md](references/kit.md).

## 2. Le dossier de la série

Ce qui doit rester identique d'une vidéo à l'autre va dans **`serie.md`**, rempli une fois depuis
[assets/fiche-serie.md](assets/fiche-serie.md). Pas de journal à tenir.

```
ma-serie/
  serie.md                 DA complète, ton, règles du personnage, prompts de style, voix
  persos/                  référence, expressions et bouches détourées (png transparents)
  polices/                 polices ajoutées par la personne (facultatif)
  sons/                    sons personnels (facultatif : le skill a sa banque)
  episodes/2026-10-20-sujet/
    script.json            répliques validées (format : assets/script-exemple.json)
    audio/  voix.wav  timeline.json
    pieces/  pieces/cut/   objets bruts puis détourés
    medias/                photos et vidéos réelles (facultatif)
    episode.json           le montage (format : assets/episode-exemple.json)
    controle/  sortie/
```

## 3. Première fois : créer la série

1. **L'entretien de départ** : [references/directions-artistiques.md](references/directions-artistiques.md).
   Quelques questions courtes, une à la fois : le sujet et le public de la série, le style du
   personnage, l'ambiance, la couleur, le genre d'écriture (typo), le rythme, le ton. Partir de ce que la
   personne aime (un compte, une marque, une image). **Donner des exemples seulement si elle ne sait
   pas.** Les DA de départ du fichier sont des pistes à adapter, pas un menu à imposer.
2. **Le personnage** : [references/personnage.md](references/personnage.md). Prompt de la référence,
   puis 6 à 8 expressions, et la planche de bouches si elle veut la bouche qui bouge.
3. **La DA en images** : écrire le bloc `"da"`, faire une planche d'essai rendue en code (la même scène
   dans 2 ou 3 variantes), la personne choisit sur l'image. Ajuster, puis tout noter dans `serie.md`.
4. **La voix** : [references/voix.md](references/voix.md). Voix IA (ElevenLabs), sa propre voix, ou
   **pas de voix du tout** (vidéo muette, texte à l'écran : minutage automatique).

## 4. Fabriquer une vidéo

1. **Script** : [references/script.md](references/script.md). 2 ou 3 angles, puis le script choisi en
   tableau (réplique, ce qu'on voit). Vérifier chaque fait chiffré ou juridique. **Attendre la
   validation** avant toute dépense.
2. **Voix et minutage** : prise(s) ElevenLabs ou enregistrement, `script.json`, puis
   `python scripts/voix_timeline.py episodes/<ep>/script.json` → `voix.wav` et `timeline.json`.
   Sans voix : `python scripts/voix_timeline.py episodes/<ep>/script.json --sans-voix` → `timeline.json`
   seule, durées estimées sur le texte (clé `"duree"` pour imposer une durée à une réplique).
3. **Images** : [references/images.md](references/images.md). Seulement le personnage et les objets du
   sujet ; les fonds se font en code. Prompts prêts à coller dans ChatGPT ou tout autre générateur
   d'images (Codex, Gemini, un outil relié à Claude…). Détourage
   `python scripts/detoure.py pieces pieces/cut`, regarder chaque image.
4. **Montage** : [references/montage.md](references/montage.md) pour la méthode,
   [references/bibliotheque.md](references/bibliotheque.md) pour piocher (fonds, transitions, animations,
   textes, composants qui se construisent, mises en scène du personnage). Contrôler :
   `python scripts/rendu.py episode.json --images auto --zones --verifier`, regarder
   `controle/planche.jpg` et corriger chaque ligne signalée (zone TikTok, texte hors écran, texte qui
   déborde de sa carte, personnage coupé). Puis rendre :
   `python scripts/rendu.py episode.json --sortie sortie/muette.mp4 --muet --cues cues.json`.
5. **Son** : [references/son.md](references/son.md). Une banque de bruitages est fournie :
   `python scripts/mix_son.py --voix voix.wav --cues cues.json --video sortie/muette.mp4 --sortie sortie/finale.mp4`
   (sans voix : enlever `--voix`).
6. **Livraison** : la vidéo en pièce jointe (moins de 30 Mo dans l'app : `--qualite legere` si besoin),
   avec la légende et 3 à 5 hashtags. Vérifier avant de dire qu'elle est prête : durée, quelques images,
   taille.
7. **Première vidéo seulement : le kit de série.** `python scripts/kit.py creer ma-serie` →
   `kit-<serie>.zip`, à donner en pièce jointe avec l'explication de [references/kit.md](references/kit.md)
   (où le ranger selon son outil). À refaire quand la DA ou le personnage change.

Varier d'une vidéo à l'autre en restant dans la DA : autre structure, autres composants, autres
transitions. Relire le script et la planche suffit à éviter de refaire la même vidéo.

En mode Sans code, remplacer 4 et 5 par la feuille de montage CapCut :
[references/capcut.md](references/capcut.md).

## Règles qui ne bougent pas

- **Pas de DA imposée** : la DA vient de l'entretien et des goûts de la personne. Une fois choisie, elle
  ne change plus sans son accord, et le kit est mis à jour.
- **Validation avant dépense** : pas de voix ni de lot d'images avant que la personne ait validé le
  script. Annoncer le coût estimé (voix : environ 1 crédit ElevenLabs par caractère).
- **Faits vérifiés** : jamais de chiffre, de loi ou d'étude inventés. Sans source, le dire et changer
  d'angle.
- **Zones sûres TikTok** : rien d'important en haut (y < 180), en bas (y > 1450), ni à droite dans la
  moitié basse (x > 900, 860 < y < 1450). `--zones` les montre, `--verifier` liste les débordements.
- **Lisible sur mobile** : texte de 64 px au moins, 2 à 4 mots par ligne de sous-titre, contraste net,
  une chose principale à regarder à la fois. `\n` dans un texte force le retour à la ligne.
- **Un changement visuel toutes les 1 à 2 s** : une ligne, une coche, un mot marqué, une expression, une
  scène. Une image posée ne porte jamais tout un propos.
- **Le personnage et la DA ne changent pas** d'une vidéo à l'autre. Toute nouvelle pose part de la
  référence ; le bloc `"da"` se recopie tel quel.
- **Pas de rendu réaliste** d'une vraie personne. Le personnage parle par ses expressions ; en option,
  une bouche dessinée qui bouge au volume de la voix : [references/bouche.md](references/bouche.md).
- **Droits** : pas de personnage, de marque, de musique, de voix ou de DA appartenant à quelqu'un
  d'autre. Polices fournies sous licence OFL, bruitages du skill synthétisés en code (libres), médias
  réels de la personne. Conseiller l'étiquette « contenu généré par IA » de TikTok avec une voix IA.
- **Honnêteté** : ne jamais dire qu'un fichier est envoyé, une voix générée ou une vidéo rendue sans
  l'avoir vérifié (ouvrir l'image, mesurer la durée, regarder la planche).
