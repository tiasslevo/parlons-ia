# La bouche qui bouge (option)

Par défaut, le personnage « parle » par ses changements d'expression (`changements` sur `perso`). En
option, `rendu.py` peut faire bouger sa bouche au volume de la voix : 2 ou 3 images de bouche alternent
selon le niveau sonore, image par image. Ce n'est pas une synchronisation labiale exacte (pas de
phonèmes) : c'est l'effet dessin animé, qui suffit pour un personnage 2D.

À garder pour les styles dessinés (trait, aplat, cartoon, kawaii). Jamais sur un rendu réaliste.

## Les images

1. **Une planche de bouches** générée en une seule image, depuis la référence du personnage :

   ```
   Même personnage que l'image jointe, même style. Planche de bouches pour l'animation : trois bouches
   isolées côte à côte, bien espacées, chacune dessinée sur une petite pastille ovale de la couleur de sa
   peau (sans contour autour de la pastille). Gauche : bouche entrouverte. Milieu : bouche ouverte qui
   parle. Droite : bouche grande ouverte en « O ». Même taille, vue de face, fond blanc pur, rien d'autre.
   ```

2. Détourer, puis découper la planche en fichiers séparés (`bouche-1.png`, `bouche-2.png`…, de la plus
   fermée à la plus ouverte) :

   ```bash
   python scripts/detoure.py pieces/brut/bouches.png pieces/cut/bouches.png
   python scripts/decoupe.py pieces/cut/bouches.png persos/bouche   # → persos/bouche-1.png, -2, -3
   ```

   La pastille de peau recouvre la bouche du dessin ; ses bords sont adoucis au montage.

3. Les poses : de préférence cadrées pareil (même taille de tête). La bouche du dessin reste visible
   pendant les silences, donc chaque expression garde sa bouche propre (sourire en coin, moue).

## Le réglage dans episode.json

```json
{"type": "perso", "src": "persos/malicieuse.png", "h": 1150, "x": 420, "y": 1560,
 "changements": [{"a": "L3", "src": "persos/mefiante.png"}],
 "bouche": {
   "images": ["persos/bouche-1.png", "persos/bouche-2.png", "persos/bouche-3.png"],
   "positions": {
     "persos/malicieuse.png": [0.505, 0.262, 0.085],
     "persos/mefiante.png":   [0.47, 0.255, 0.08, -6]
   },
   "seuils": [0.2, 0.45, 0.8]
 }}
```

| Clé | Rôle |
|---|---|
| `images` | les bouches, de la plus fermée à la plus ouverte (2 ou 3) |
| `positions` | pour chaque pose : `[x, y, l]` ou `[x, y, l, rot]`. `x`, `y` = centre de la bouche, `l` = largeur de la bouche, **en fractions de l'image de la pose** (0 à 1), rotation en degrés. Une pose absente garde sa bouche dessinée |
| `position` | réglage commun à toutes les poses (si elles sont cadrées pareil) |
| `seuils` | volume (0 à 1, 1 = voix forte) à partir duquel chaque bouche s'affiche. Sous le premier seuil : bouche du dessin. Défaut réparti entre 0,2 et 0,6 |
| `lignes` | facultatif : numéros des répliques du personnage (`[1, 3, 4]`). Avec deux personnages, chacun ne bouge la bouche que sur ses répliques |
| `voix` | facultatif : autre fichier audio que la voix de l'épisode (la prise d'un seul personnage) |

Trouver `x`, `y`, `l` : ouvrir la pose détourée, repérer le centre de la bouche en pixels, diviser par
la largeur et la hauteur de l'image. Puis contrôler avec `rendu.py --images` sur un instant où la voix
est forte : la pastille doit couvrir la bouche dessinée sans déborder sur le menton ou le nez.

## Pièges

- La pastille doit avoir **la couleur exacte de la peau** sous la bouche : sinon elle se voit. Si la
  couleur dérive, retoucher la teinte de la pastille plutôt que de régénérer.
- Les mains devant la bouche (doigt sur le nez, main au menton) : choisir une position qui ne recouvre
  pas la main, ou ne pas régler cette pose (elle garde sa bouche dessinée).
- Trop de mouvement fatigue : 2 bouches suffisent souvent ; monter les `seuils` si ça clignote.
- `cadrage` (`buste`, `tete`), `miroir` et `contour_blanc` sont pris en compte : la bouche est posée sur
  l'image d'origine avant recadrage.
