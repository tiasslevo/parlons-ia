# Où le skill tourne, et ce qu'il faut installer

Vérifié le 19 et le 20/10/2026 sur la documentation officielle de Claude. Les limites bougent : en cas de doute,
tester plutôt que promettre.

## Mode Studio : Claude Code sur l'ordinateur (recommandé)

C'est le seul mode où toute la chaîne tourne sans bricolage : fichiers qui restent sur le disque,
calcul sans limite de durée, téléchargement direct des voix, Remotion possible.

Prérequis :
- un abonnement Claude qui inclut Claude Code (Pro ou plus) ;
- **Python 3.10+** avec `pip install pillow numpy` (et `scipy`, facultatif, pour un détourage plus rapide) ;
- **ffmpeg** : Windows `winget install ffmpeg`, Mac `brew install ffmpeg`, Linux `sudo apt install ffmpeg`.
  À défaut : `pip install imageio-ffmpeg` (ffmpeg embarqué, les scripts le trouvent seuls) ;
- pour Remotion (facultatif) : **Node.js 18+** ; Remotion télécharge son propre navigateur au premier rendu
  (environ 100 Mo) ;
- le connecteur ElevenLabs activé dans Claude si la voix est générée par IA.

Ordinateur : un PC de bureau ordinaire suffit. Compter 1 à 2 minutes de calcul pour 1 minute de vidéo avec
`rendu.py`, à peu près pareil avec Remotion.

Installer le skill : copier le dossier `video-faceless/` dans `~/.claude/skills/` (pour tous les projets)
ou dans `.claude/skills/` du dossier de la série. Taper `/video-faceless` ou simplement décrire la vidéo.

## Mode App : app Claude avec exécution de code

L'app Claude (web, ordinateur, téléphone) peut lancer du Python dans un bac à sable si l'option
**« Exécution de code et création de fichiers »** est active (dans les paramètres, rubrique Fonctionnalités
ou Capacités selon la version de l'app).

Ce qui marche :
- tout le travail d'écriture : série, personnage, script, prompts d'images, feuille de montage ;
- la voix par le connecteur ElevenLabs (relié dans Paramètres → Connecteurs) ;
- `detoure.py`, `voix_timeline.py`, `rendu.py`, `mix_son.py` : ils n'ont besoin que de Python, Pillow, numpy
  et ffmpeg. Si ffmpeg manque, `pip install imageio-ffmpeg` le fournit (paquet PyPI, source autorisée par défaut).

Limites à connaître (documentation officielle) :
- **30 Mo maximum par fichier**, en envoi comme en téléchargement. Une vidéo de 60 à 80 s en `--qualite normale`
  pèse en général 5 à 20 Mo avec des aplats ; si elle dépasse, relancer avec `--qualite legere` (720 × 1280).
- **Durée de calcul limitée** par tâche, sans chiffre publié. Rendre par morceaux si besoin
  (`--de 0 --a 30`, puis `--de 30`) et les recoller avec ffmpeg (`-f concat`).
- **Réseau restreint** : par défaut, le bac à sable atteint surtout les gestionnaires de paquets (PyPI, npm…).
  Les fichiers audio d'ElevenLabs et les images de ChatGPT ne se téléchargent donc pas toujours depuis le
  code : demander à la personne de les télécharger puis de les joindre à la conversation.
- **Rien ne reste** après la conversation : travailler dans un Projet Claude, garder `serie.md` et les images
  du personnage dans les fichiers du projet, télécharger les livrables.
- Offres Team et Enterprise : l'administrateur peut avoir coupé le réseau ou l'exécution de code.
- Les skills personnalisés s'ajoutent dans **Customize → Skills** (en français : Personnaliser → Skills) :
  bouton « + », « Create skill », « Upload a skill », puis le fichier `video-faceless.zip` (qui contient
  le dossier `video-faceless/`). L'exécution de code doit être active (Paramètres → Capacités →
  « Exécution de code et création de fichiers »). Vérifié sur l'aide officielle le 20/10/2026.
- Les fichiers d'un Projet sont lisibles depuis le bac à sable selon l'aide officielle ; le dossier exact
  n'est pas documenté. Si `kit.py lire` ne les trouve pas, demander de joindre le ZIP du kit.

Pas de Remotion dans ce mode : il lui faut un navigateur Chrome téléchargé hors des sources autorisées et
beaucoup plus de calcul. `rendu.py` a été écrit pour ce cas.

Sur téléphone : tout marche de la même façon, mais il faut pouvoir joindre des fichiers (audio, images) et
télécharger la vidéo. Préférer l'ordinateur pour la première série.

## Cowork (application Claude pour ordinateur)

Cowork exécute du code dans un environnement isolé et suit les mêmes réglages réseau que l'app. Les scripts
Python devraient y tourner comme en mode App. Non testé pour ce skill : le dire à la personne si elle choisit
ce mode, et faire un essai court (`rendu.py --images auto`) avant de promettre un rendu complet.

## Mode Sans code

Aucune exécution de code, ou un rendu qui échoue. Tu livres quand même tout le reste : script validé, texte
pour la voix, prompts d'images, et une **feuille de montage minutée** à suivre dans CapCut
([capcut.md](capcut.md)). La personne génère la voix sur le site d'ElevenLabs ou s'enregistre.

## Comptes et coûts côté personne

| Outil | Pour quoi | Ce qu'il faut savoir |
|---|---|---|
| Claude | tout | exécution de code requise pour le mode App ; Claude Code pour le mode Studio |
| ElevenLabs | voix IA | offre gratuite limitée (environ 10 000 crédits par mois) et réservée à un usage personnel avec mention d'ElevenLabs ; usage commercial à partir de l'offre payante la moins chère. Vérifier les tarifs du moment sur elevenlabs.io |
| ChatGPT (ou Codex, Gemini, tout générateur relié) | images | génération d'images incluse dans ChatGPT, avec des limites plus basses en gratuit. Garder une seule conversation par personnage |
| CapCut | montage sans code | gratuit pour l'essentiel |
| Remotion | montage en mode Studio | gratuit pour une personne seule ou une entreprise de 3 salariés au plus ; licence payante au-delà |
