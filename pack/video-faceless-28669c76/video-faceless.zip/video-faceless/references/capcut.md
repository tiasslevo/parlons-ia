# Mode Sans code : la feuille de montage CapCut

Quand le code ne peut pas tourner, tu prépares tout et la personne monte dans CapCut (gratuit, téléphone ou
ordinateur). Le résultat est un peu moins vif qu'un montage en code, mais la méthode reste la même : la DA
de la série, des éléments qui évoluent au fil de la voix, un changement toutes les 1 à 2 s.

## Ce que tu livres

1. Le script validé et le texte exact de chaque prise de voix (avec balises si ElevenLabs).
2. Les prompts d'images ([images.md](images.md)), en demandant à ChatGPT un **fond transparent** pour les
   personnages et les pièces. Sinon, la fonction « Supprimer l'arrière-plan » de CapCut fait le détourage.
3. La **feuille de montage** ci-dessous, une ligne par événement, minutée.
4. La légende et les hashtags.

## Préparer CapCut (une fois)

- Nouveau projet, format **9:16**.
- Importer les polices de la DA (fichiers `.ttf` de `assets/fonts/`) : Texte → Police → Importer (sur
  ordinateur), sinon choisir une police grasse proche.
- Fonds : CapCut fait les aplats (Toile → Couleur). Pour un dégradé, un motif ou un faisceau, tu peux les
  produire en image avec le code si l'exécution de code marche même un peu (`rendu.py --images 0.5` sur une
  scène vide), sinon un aplat de la couleur de série suffit.
- Garder un projet « modèle » avec les fonds et les styles de texte : le dupliquer à chaque épisode.

## Monter

1. Importer la voix (un fichier par personnage, ou la voix assemblée) sur la piste audio principale.
2. Couper la voix aux répliques et noter le temps de début de chacune : c'est la timeline de la feuille.
3. Fond : le fond de série, et un aplat d'accent pour les mots forts et la fin.
4. Personnages et pièces en **incrustation** (Superposition), placés selon la feuille. Animation d'entrée
   « Rebond » ou « Zoom avant », 0,3 s. Pour le balancement : animation en boucle « Balancement », intensité
   faible.
5. Textes : un ou trois mots, gros, animation « Pop » ou « Rebond ». Pour du mot à mot : un texte par mot,
   ou l'animation « Machine à écrire ». Sous-titres karaoké : Texte → Sous-titres auto, style avec mot
   surligné à la couleur d'accent. Une liste qui se construit : un texte par ligne, chacun démarre sur
   son mot.
6. Tampons : texte dans un cadre, animation d'entrée « Zoom arrière » rapide + effet « Secousse » 0,2 s.
7. Transitions : coupe nette la plupart du temps ; « Glisser », « Balayage », « Zoom » ou « Fondu au noir »
   pour quelques changements de partie (voir la liste des transitions de [bibliotheque.md](bibliotheque.md)).
8. Bruitages : Audio → Effets sonores (whoosh, pop, impact), à faible volume. Voir [son.md](son.md).
9. Exporter en 1080p, 30 i/s.

Respecter les zones sûres : rien d'important dans le haut, le bas et la colonne de droite (voir
[montage.md](montage.md)).

## Modèle de feuille de montage

| Temps | Durée | Fond | Personnage | À l'écran | Animation | Son |
|---|---|---|---|---|---|---|
| 0,0 | 2,2 s | crème quadrillé | `neutre`, en pied, à gauche | « La plupart des gens ont **deux choix.** », mots un par un, « deux choix » en pastille verte | perso monte du bas, mots pop | glisse |
| 2,2 | 2,3 s | idem | médaillon carré en bas à gauche | deux cartes « Démissionner », « Serrer les dents », une croix sur chacune | glisser à gauche, cartes pop | whoosh, pop |
| 4,5 | 2,2 s | crème | `content`, médaillon | étapes 1-2-3 qui se cochent, photo réelle en polaroid | rond, photo glisse | whoosh |
| … | | | | | | |

Remplir une ligne par changement visible. Si une ligne dure plus de 1,5 s sans rien de nouveau, la couper
en deux et ajouter un événement (un mot qui se surligne, une expression qui change, un cercle).
