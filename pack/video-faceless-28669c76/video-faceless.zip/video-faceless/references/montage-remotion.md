# Variante Remotion (mode Studio)

Remotion monte la vidéo en React : mêmes principes que `rendu.py`, avec des ressorts plus fins, du flou de
vitesse sur les swipes et la liberté d'inventer des composants sur mesure (fiche de paie qui se remplit,
calendrier qui se colore). Le kit fourni est plus petit que la bibliothèque de `rendu.py` : il couvre les
bases (fond, scène, personnage, bulle, carte, texte, tampon, compteur, médaillon, cercle, surligneur) ; le
reste se code à la demande en reprenant la logique de [bibliotheque.md](bibliotheque.md). À choisir
seulement si la personne veut un composant que `rendu.py` n'a pas. À réserver au mode Studio : il faut Node.js et un navigateur que
Remotion télécharge seul. Testé sous Linux avec Remotion 4.0.536.

Licence : gratuit pour une personne seule ou une entreprise de 3 salariés au plus. Au-delà, licence payante
(remotion.pro).

## Mise en place (une fois par épisode)

```bash
cp -r <skill>/assets/remotion-modele episodes/<ep>/remotion
cd episodes/<ep>/remotion
npm install                                  # 1 à 2 minutes la première fois
cp ../timeline.json src/
mkdir -p public/persos public/pieces
cp ../voix.wav public/                       # ou ../mix.wav après l'étape son
cp ../../../persos/*/*.png public/persos/    # adapter les noms
cp ../pieces/cut/*.png public/pieces/
```

Tout fichier appelé par `staticFile()` doit exister dans `public/`, sinon le rendu échoue.

## Écrire l'épisode

`src/kit.tsx` contient les composants : `Fond`, `Stage` (scène avec swipe), `Perso`, `Bulle`, `Carte`,
`Texte`, `Gros`, `Piece`, `Tampon`, `Compteur`, `Medaillon`, `Cercle`, `Hl` (surligneur), `effets`
(zoom, secousse, flash). Les temps se lisent dans `timeline.json` : `L(3)` début de la réplique 3,
`Lfin(3)` sa fin, `Lat(3, 0.5)` son milieu, `L(3, 0.4)` décalé.

La DA se change en haut de `kit.tsx` (`THEME` : police, couleurs, ombres). `src/Episode.tsx` est un exemple
complet à réécrire : une entrée par scène dans `SCENES`, les temps forts dans `effets([...])`.

Règles React : pas de hook (`useState`, `useEffect`) dans les scènes, tout se calcule à partir de `t` ;
les animations passent par `pop(t, t0)` et `ease(t, a, b)`. Pas d'émoji (pas de police émoji dans le
navigateur de rendu) ; dessiner les flèches et signes spéciaux en SVG.

## Contrôler et rendre

```bash
npx remotion still src/index.ts Main controle/f0300.png --frame=300    # une image (30 images = 1 s)
npx remotion studio src/index.ts                                       # aperçu interactif dans le navigateur
npx remotion render src/index.ts Main ../sortie/video.mp4 --codec h264 --crf 17
```

Faire 12 à 20 images de contrôle avant le rendu complet, les regarder en planche
(`python <skill>/scripts/planche.py controle`), corriger, puis rendre. Compter 1 à 2 minutes pour 1 minute
de vidéo. Pour poser les bruitages après coup : rendre avec `--muted`, puis `mix_son.py` avec un
`cues.json` écrit à la main depuis les temps de `SCENES` et des tampons.

Windows avec WSL : lancer Node côté Windows ou côté Linux, pas un mélange des deux (un `node_modules`
installé sous Linux ne marche pas avec le Node de Windows).
