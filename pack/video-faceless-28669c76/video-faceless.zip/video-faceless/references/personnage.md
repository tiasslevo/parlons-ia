# Créer le personnage et le garder identique

Le personnage est ce qui rend la série reconnaissable : on doit le reconnaître en une demi-seconde, sans
présentation. Il peut être la personne elle-même en avatar, une mascotte, un animal, un objet qui parle.
Un seul personnage suffit. Un second (complice, contradicteur, client) est une option, pas une règle.

## 1. Les questions à poser

Une par une, avec une réponse par défaut si la personne hésite :

1. Qui est-il ? Elle-même en avatar, ou un personnage inventé (prénom court, âge, rôle, d'où il parle).
2. Pourquoi on l'écoute ? Ce qu'il sait que le spectateur ne sait pas.
3. Son caractère en trois mots. Le ton de la voix et des phrases en découle.
4. Sa façon de parler : tutoiement ou vouvoiement, mots qu'il dit souvent, mots qu'il ne dit jamais.
5. Le style de dessin (tableau ci-dessous) et la tenue fixe : une couleur dominante, un détail signature
   (lunettes rondes, casque orange, foulard, tasse…).
6. Un autre personnage récurrent ? Seulement si le sujet s'y prête.

Tout va dans `serie.md` (modèle : [../assets/fiche-serie.md](../assets/fiche-serie.md)).

## 2. Les styles d'avatar

Montrer ce tableau, proposer deux ou trois styles qui collent au sujet et à la DA.

| Style | Rendu | Bon pour |
|---|---|---|
| Bitmoji / 3D doux | rendu lisse, grands yeux, ombrage léger, épais liseré blanc d'autocollant | se représenter soi-même, business, conseils |
| Trait minimaliste | trait noir épais, intérieur blanc, presque pas de couleur | récit, humour, animaux, sujets légers |
| 3D film d'animation | personnage 3D stylisé, matières douces, éclairage studio | carrière, argent, tutos « sérieux mais sympas » |
| Mascotte kawaii | formes rondes, grosse tête, couleurs vives, souvent petite | produits, apps, tech, enfants |
| Trait + aplat | contour net, couleurs à plat, aucune ombre | explications, chiffres, droit |
| Chibi | grosse tête, petit corps, pastel | santé, parentalité, études |
| Papier découpé | formes découpées, texture papier, ombre courte | actu, histoire, contes |
| Croquis au feutre | trait irrégulier façon carnet, quelques aplats | école, langues, sciences |
| Pâte à modeler | volumes ronds, matière visible | cuisine, enfants, DIY |

Éviter : le réaliste (vallée de l'étrange, confusion avec une vraie personne), un personnage existant ou
« à la manière de » un studio ou un artiste nommé. La bouche qui bouge est une option du montage
(planche de bouches + réglage, voir [bouche.md](bouche.md)), pas une génération vidéo.

## 3. Le prompt de référence (à coller dans ChatGPT ou un autre générateur d'images)

Une seule image de référence, en pied, de face, bras le long du corps, expression neutre, **sur fond
blanc uni**. Toutes les autres poses partent d'elle. Base commune :

```
Personnage de série de vidéos, [STYLE]. [Apparence : âge, peau, cheveux, coiffure, signes distinctifs].
Tenue fixe : [vêtements, couleur dominante], [détail signature]. Vue de face, en pied, bras le long du
corps, expression neutre et sympathique. Fond blanc pur uni, aucun décor, aucun texte, aucune ombre au
sol. Format portrait 2:3.
```

Remplacer `[STYLE]` par :

- **Bitmoji / 3D doux** : « avatar 3D doux façon autocollant de messagerie, grands yeux expressifs,
  proportions un peu cartoon, rendu lisse et brillant, ombrage léger, fin contour sombre puis épais
  contour blanc autour de la silhouette »
- **Trait minimaliste** : « dessin au trait noir épais et régulier, intérieur blanc, aucune couleur sauf
  [une touche de couleur], aucune ombre, expression simple faite de points et de traits »
- **3D film d'animation** : « personnage 3D stylisé de film d'animation familial, proportions
  légèrement exagérées, grands yeux, matières douces, éclairage studio doux »
- **Mascotte kawaii** : « mascotte kawaii toute ronde, très grosse tête, petit corps, grands yeux
  brillants, joues roses, couleurs vives à plat, contour brun foncé »
- **Trait + aplat** : « illustration vectorielle plate, contour encre noire net et régulier, couleurs à
  plat, aucune ombre, aucun dégradé »
- **Chibi** : « personnage chibi, tête très grosse, petit corps, couleurs pastel à plat, contour épais
  doux »
- **Papier découpé** : « personnage en papier découpé, formes aux bords nets, légère texture de papier,
  petite ombre portée nette »
- **Croquis au feutre** : « dessin au feutre fin, trait légèrement irrégulier façon carnet de croquis,
  quelques aplats de couleur au feutre »
- **Pâte à modeler** : « figurine en pâte à modeler, volumes ronds, traces de doigts légères, éclairage
  doux »

Pour un avatar de la personne elle-même : elle joint une photo d'elle à ChatGPT et ajoute « Inspire-toi
de la photo jointe pour le visage, la coiffure et la barbe, en restant dans le style demandé ». Jamais
la photo de quelqu'un d'autre sans son accord.

Faire 3 ou 4 propositions, la personne choisit. Noter dans `serie.md` la description exacte qui a produit
l'image retenue : elle se recopie mot pour mot ensuite. Penser à la diversité réelle du public (peau,
coiffure, tenue cohérentes avec le pays de la série).

## 4. Poses et expressions

Dans **la même conversation ChatGPT**, en joignant la référence à chaque fois :

```
Même personnage exactement, même style, même tenue, mêmes couleurs, mêmes proportions que l'image
jointe. Seule la pose change : [pose ou expression]. En pied, fond blanc pur uni, aucun texte.
```

Jeu de départ (6 à 8 images), à adapter au sujet :
- `neutre` : regarde le spectateur, léger sourire ;
- `explique` : une main ouverte vers le côté ;
- `pointe` : montre quelque chose du doigt (vers le haut ou le côté) ;
- `surpris` : yeux ronds, mains sur les joues ;
- `pensif` : main au menton ;
- `bras-croises` : doute, refus ;
- `content` : grand sourire, pouce levé ;
- une ou deux poses du sujet : ordinateur, téléphone, billets, loupe, caméra…

Plus tard, ajouter des poses au fil des besoins, toujours depuis la référence. Pour une tête seule
(réactions en médaillon) : « même personnage, cadré sur la tête et les épaules, [expression] ».

Vérifier chaque image : même tenue, coiffure, couleurs, proportions, épaisseur de trait, fond blanc.
Une image qui dérive se refait, elle ne se rattrape pas au montage.

Détourer : `python scripts/detoure.py persos/brut persos --contour 14 --carre`.
`--contour` ajoute le liseré blanc d'autocollant, `--carre` met toutes les poses au même format ancré en
bas : elles se remplacent sans saut à l'écran. Sans liseré au détourage, `"contour_blanc": 12` dans
`episode.json` l'ajoute au montage. Une image déjà transparente (exportée sans fond par le générateur)
est gardée et son halo flou est nettoyé.

Taille réelle avec `--carre` : le carré a pour côté la plus grande dimension du dessin. Pour une pose
plus haute que large (le cas courant), le personnage occupe toute la hauteur : `"h": 1000` donne un
personnage de 1000 px. Pour une pose plus large que haute (bras écartés, accessoire tenu loin), il
occupe moins : `detoure.py` affiche pour chaque fichier « dessin réel 900×700, soit 70 % de la
hauteur ». Dans ce cas, augmenter `h` d'autant pour garder la même taille de tête, ou détourer cette
pose sans `--carre`.

## 5. Les mises en scène

Le même personnage peut apparaître de plusieurs façons dans une vidéo (détails dans
[bibliotheque.md](bibliotheque.md), section 8) :

- **en pied**, grand, quand il parle sans illustration ;
- **en buste** ou **tête seule** pour une réaction courte ;
- **en médaillon** rond ou carré dans un coin pendant qu'un schéma occupe l'écran ;
- **petit en coin avec un accessoire** (loupe, drapeau, ordinateur) posé à côté de lui ;
- **retourné** (`miroir`) pour regarder vers le texte.

Une règle simple : une seule chose principale à regarder à la fois. Quand l'illustration arrive, le
personnage rapetisse, passe en coin ou en médaillon, ou sort.

## 6. La cohérence d'une vidéo à l'autre

- Ne jamais régénérer le personnage de zéro : toute nouvelle pose part de la référence.
- Garder des noms de fichiers stables (`persos/neutre.png`, `persos/surpris.png`…).
- Même voix, mêmes réglages, même façon de parler.
- Même DA : le bloc `"da"` de `serie.md` se recopie tel quel.
