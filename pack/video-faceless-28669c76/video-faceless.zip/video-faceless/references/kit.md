# Le kit de série

Le skill est le même pour tout le monde : la méthode et les programmes. Le **kit de série** est propre à
la personne : il garde ce qui rend SA série reconnaissable, pour que la vidéo 12 ressemble à la vidéo 1
même dans une conversation neuve.

## Ce qu'il contient

`python scripts/kit.py creer ma-serie` fabrique `kit-<serie>.zip` :

| Fichier | Contenu |
|---|---|
| `serie.md` | la DA complète (couleurs, polices, marquage du mot clé, fonds, transitions et entrées préférées, rythme), le ton, les règles du personnage, les prompts de style pour les images, la voix |
| `da.json` | le bloc `"da"` et les fonds, pour le code |
| `persos/` | la référence, les expressions, les bouches (png transparents, réduits à 1600 px au plus) |
| `polices/` | les polices de la DA et leur licence |
| `sons/` | la banque personnelle, s'il y en a une |
| `apercu-da.jpg` | trois écrans types (ouverture, explication, fin) rendus dans la DA |
| `apercu-persos.jpg` | toutes les images du personnage |
| `LISEZ-MOI.md` | où ranger le kit, en trois lignes |

Avant de le fabriquer, vérifier que `serie.md` est complet (modèle : [../assets/fiche-serie.md](../assets/fiche-serie.md)) :
le bloc `"da"` en JSON valide, le fond de série, les prompts de style recopiés mot pour mot, les règles
du personnage. Le script refuse une fiche sans bloc `"da"`, et prévient s'il manque une police ou les
images du personnage. Il prévient aussi si le ZIP dépasse 30 Mo (limite de l'app) : relancer avec
`--max-px 1200`.

## Quand le fabriquer

- **À la fin de la première vidéo**, quand la personne a validé la vidéo : le personnage et la DA sont
  alors éprouvés. Le donner en pièce jointe avec l'explication ci-dessous.
- **À chaque évolution de la DA** (nouvelle couleur, nouvelle police, nouvelles expressions) : refaire
  le kit, le redonner, et rappeler de remplacer l'ancien partout (fichiers du Projet, téléphone).
  Un seul kit valable à la fois.

## Les vidéos suivantes : trois cas

Expliquer à la personne le cas qui la concerne, avec ces mots ou presque.

**a. App Claude avec un Projet (le plus simple au quotidien)**
« Ouvre ton Projet, va dans ses fichiers et ajoute `serie.md`, `apercu-da.jpg` et les images du
dossier `persos/` (décompresse le ZIP sur ton téléphone ou ton ordinateur pour les voir). Si tu as ajouté
tes propres polices, ajoute aussi les fichiers `.ttf`. Ensuite, chaque nouvelle conversation dans ce
Projet connaît ta série : dis seulement “nouvelle vidéo sur…”. »
Au début d'une conversation du Projet : lire `serie.md` dans le contexte, puis chercher les fichiers dans
le bac à sable (dossier des fichiers du Projet ou des pièces jointes) et lancer
`python scripts/kit.py lire <ce dossier> --vers ma-serie` pour les ranger. Si les images du Projet ne
sont pas lisibles par le code, demander de joindre le ZIP du kit à la conversation.

**b. Nouvelle conversation hors Projet**
« Joins `kit-<serie>.zip` dès ton premier message et écris : “Voici le kit de ma série, on fait une
nouvelle vidéo sur…”. » Puis `python scripts/kit.py lire kit-<serie>.zip --vers ma-serie`.

**c. Claude Code (mode Studio)**
« Le kit reste dans le dossier de ta série : `serie.md`, `persos/`, `polices/`. Lance Claude Code dans
ce dossier et demande une nouvelle vidéo. » Le ZIP sert de sauvegarde, ou pour passer à l'app.

Dans les trois cas, après `kit.py lire` : recopier le bloc `"da"` tel quel dans `episode.json`,
reprendre les poses par leur nom, relire les règles du personnage et les transitions préférées.
Ne rien réinventer : si la personne veut changer la DA, le faire avec elle, puis refaire le kit.
