# La bibliothèque du montage

Tout ce que `scripts/rendu.py` sait dessiner, avec la clé à écrire dans `episode.json` et le moment où
l'employer. Rien n'est obligatoire : pioche ce qui sert l'idée de la phrase. `python scripts/rendu.py
--catalogue` affiche la liste courte.

Sommaire : [structure du fichier](#1-structure-dun-episodejson) · [temps](#2-les-temps) ·
[clés communes](#3-clés-communes-à-tous-les-éléments) · [fonds](#4-fonds) · [transitions](#5-transitions) ·
[animations](#6-animations) · [texte](#7-le-texte) · [personnages et images](#8-personnages-images-médias) ·
[composants qui se construisent](#9-composants-qui-se-construisent) · [traits et petits éléments](#10-traits-icônes-et-décor) ·
[effets globaux](#11-effets-sur-toute-limage) · [recettes](#12-recettes)

## 1. Structure d'un episode.json

```json
{
  "taille": [1080, 1920], "fps": 30,
  "timeline": "timeline.json", "voix": "voix.wav",
  "da": { ... voir directions-artistiques.md ... },
  "permanent": [ ...éléments affichés par-dessus toutes les scènes... ],
  "scenes": [
    {"de": "L1", "fond": {...}, "entree": "coupe", "elements": [ ... ]},
    {"de": "L2", "fond": "#FFFFFF", "entree": "gauche", "elements": [ ... ]}
  ],
  "punch": ["L2@0.5"], "flash": [], "secousses": [], "soustitres": []
}
```

- `duree` (facultatif) : durée totale de la vidéo en secondes. Par défaut, la durée de `timeline.json`
  + 0,6 s (avec ou sans voix). La mettre pour rallonger la fin ou couper plus tôt. Sans `timeline` ni
  `duree`, la vidéo fait 10 s.
- `timeline` : le minutage des répliques, sorti de `voix_timeline.py` (avec voix, ou `--sans-voix`).
  `voix` : le fichier audio ajouté au rendu (absent pour une vidéo muette).
- Une scène dure jusqu'au début de la suivante. La première commence toujours net.
- Les éléments se dessinent dans l'ordre de la liste : le dernier passe devant.
- `permanent` : ce qui reste quand les scènes changent (rubrique en haut, médaillon dans un coin,
  sous-titres karaoké). Temps absolus (`a`, `jusqua`). Leur couleur de texte s'adapte au fond de la scène.
- Chemins d'images relatifs à `episode.json`. Coordonnées en pixels sur 1080 × 1920.
- Couleurs : `"#RRGGBB"`, `"#RRGGBBAA"` (transparence), ou un mot de la DA : `"accent"`, `"encre"`,
  `"clair"`, `"papier"`, `"fond"`, `"surligneur"`, `"gain"`, `"perte"`. Utiliser ces mots plutôt que des
  codes : changer la DA change alors tout l'épisode.
- Les anciens fichiers (`"police"`, `"graisse"`, `"ombre": true`, `"fond": "#hex"` + `"motif"`) marchent
  toujours.

## 2. Les temps

| Écriture | Sens |
|---|---|
| `3.2` | 3,2 s |
| `"L3"` / `"L3.fin"` | début / fin de la réplique 3 de `timeline.json` |
| `"L3@0.5"` | à 50 % de la réplique 3 |
| `"L3+0.4"`, `"L3.fin-0.2"` | décalés |
| `"L3#4"` / `"L3#4.fin"` | début / fin du 4e mot de la réplique 3 |
| `"fin"` | fin de la vidéo |

Le minutage mot à mot (`#`) est estimé à partir des syllabes. S'il existe un vrai minutage (Whisper,
ElevenLabs avec horodatage), l'ajouter dans `timeline.json` sur la ligne :
`"mots": [{"mot": "Il", "t0": 0.21, "t1": 0.33}, ...]` ; le karaoké et les `#` l'utilisent alors.

## 3. Clés communes à tous les éléments

| Clé | Rôle |
|---|---|
| `type` | le type d'élément (sections 7 à 10) |
| `a` / `jusqua` | apparition / disparition (défaut : début de la scène / jusqu'à la fin de la scène) |
| `x`, `y` | position du centre (sauf `perso` : `y` = bas ; `liste` et `rubrique` : `y` = haut) |
| `ancre` | `centre`, `bas`, `haut`, `gauche` pour changer le point d'accroche |
| `anim` | animation d'entrée (section 6) |
| `sortie` | animation de sortie au moment `jusqua` |
| `boucle` | mouvement permanent léger |
| `rot`, `echelle`, `opacite` | rotation en degrés, taille, transparence (0 à 1) |
| `mouvements` | déplacements au fil du temps : `[{"a": "L4", "fin": "L4+0.4", "x": 300, "y": 900, "echelle": 0.6}]` |
| `police` | `"titre"`, `"texte"`, `"mono"` ou un fichier `.ttf` |
| `casse` | `"majuscules"` ou `"normale"` |

`mouvements` sert quand une même pièce reste et se déplace pour laisser de la place (la liste remonte,
le personnage rapetisse dans un coin).

## 4. Fonds

Tous les fonds sont faits en code. Pas de décor à générer.

```json
"fond": "#F6F0E4"
"fond": "accent"
"fond": {"type": "degrade", "de": "#FF8A1F", "vers": "#D62E6A", "angle": 90}
"fond": {"type": "degrade", "de": "#FFE3D3", "vers": "#FFF6EC", "radial": true, "x": 0.5, "y": 0.4}
"fond": {"type": "motif", "couleur": "#FBF8F1", "motif": "quadrillage", "motif_couleur": "#15171C10", "pas": 60}
"fond": {"type": "faisceau", "couleur": "#14203D", "lumiere": "#F4E7B8", "x": 0.5, "ouverture": 30, "force": 0.7, "sol": 0.78}
"fond": {"type": "halo", "couleur": "#18181B", "lumiere": "#3C3C44", "x": 0.5, "y": 0.55, "rayon": 0.6}
"fond": {"type": "image", "src": "medias/bureau.jpg", "flou": 8, "assombrir": 0.45}
"fond": {"type": "video", "src": "medias/rue.mp4", "assombrir": 0.3}
```

| Type | Quand |
|---|---|
| uni (`"#hex"` ou mot de DA) | le fond de série, ou l'aplat plein couleur d'un mot fort, d'une fin |
| `degrade` | carte de fin, moment fort, ambiance (linéaire ou `radial`) |
| `motif` | fond de série vivant : `quadrillage`, `points`, `lignes`, `colonnes`, `diagonales`, `losanges`, `croix`, `vagues`, `cercles`, `damier`, `rayons` ; `epaisseur` en option |
| `faisceau` | scène de nuit, moment intime ou dramatique : un projecteur tombe sur le personnage |
| `halo` | gros plan doux, fond sombre qui ne fait pas plat |
| `image` / `video` | médias réels de la personne en fond, floutés et assombris pour garder le texte lisible |

Options pour tous : `"grain": 0.4` (texture papier ou film), `"vignette": 0.3` (bords assombris),
`"defile": [20, 0]` (le motif glisse de 20 px/s, effet discret de mouvement).
Dans la scène : `"camera": "lent"` (zoom très lent de 1 à 1,05) ou `"camera": {"zoom": [1, 1.1], "x": 480, "y": 700}`.

## 5. Transitions

Clé `entree` de la scène, durée réglable avec `duree_transition` (en s).

| Clé | Effet | Quand |
|---|---|---|
| `coupe` | coupe franche | par défaut pour la majorité des changements, réplique sèche |
| `gauche`, `droite`, `haut`, `bas` | l'ancienne scène est poussée | passer à la suite d'une explication |
| `recouvre-gauche` (… `-droite`, `-haut`, `-bas`) | la nouvelle glisse par-dessus | une carte qui arrive sur la précédente |
| `volet-gauche` (… `-droite`, `-haut`, `-bas`) | rideau net | changement de chapitre |
| `bande` | une bande de couleur balaie l'écran (`couleur_transition`) | rubrique, « numéro 2 » |
| `rond` | la scène s'ouvre en cercle (`centre_transition: [x, y]`) | révélation, zoom sur un détail |
| `zoom-avant`, `zoom-arriere` | on plonge dans l'image ou on recule | entrer dans le détail, prendre du recul |
| `fondu` | fondu enchaîné | passage de temps, douceur |
| `fondu-noir` | passage par le noir | ellipse (« le lendemain »), fin d'un récit |
| `flash` | éclair blanc (`couleur_transition`) | chiffre choc, carte de fin |
| `flou` | flou puis net | rêve, souvenir, « imagine » |
| `secousse` | coupe + secousse | impact, mauvaise nouvelle |

Varier sans en abuser : deux ou trois transitions différentes par vidéo, coupe le reste du temps.

## 6. Animations

**Entrée** (`anim`) :

| Clé | Effet | Défaut pour |
|---|---|---|
| `pop` | grossit avec un petit rebond | la plupart des éléments |
| `zoom` | grossit sans rebond | `forme` |
| `monte` / `descend` | arrive du bas / du haut (`distance` en px) | `monte` : `perso` ; `descend` : `notification` |
| `glisse-gauche`, `glisse-droite` (`glisse` = droite) | arrive du côté | cartes, médias |
| `fondu` | apparaît en douceur | ambiance, personnage dans le noir |
| `rebond` | tombe d'en haut et rebondit | objet qui « tombe », mascotte |
| `tourne` | pop avec rotation | pastille, médaillon, objet drôle |
| `elastique` | s'étire puis se pose | mot fort, titre |
| `deplie` | se déplie de haut en bas | fenêtre, carte, liste |
| `revele` | se dévoile de gauche à droite | phrase, ligne de texte |
| `aucune` | posé net | élément déjà vu dans la scène d'avant (continuité) |

Les tampons ont leur propre entrée (écrasement + secousse + flash). Les traits (`barre`, `cercle`,
`fleche`) se dessinent.

**Sortie** (`sortie`, à `jusqua`) : `reduit` (défaut), `fondu`, `glisse-gauche`, `glisse-droite`, `monte`,
`descend`, `coupe`.

**Boucle** (`boucle`) : `balance` (défaut des personnages), `flotte` (objets), `respire`, `pulse`,
`tremble`, combinables (`"balance+flotte"`), ou `"aucune"`. À garder légères : le spectateur doit sentir
que c'est vivant, pas que ça bouge.

## 7. Le texte

### Marquer le mot clé

Dans n'importe quel texte :

| Écriture | Rendu |
|---|---|
| `*mot*` | le mot clé, marqué selon la DA (`"marque"` : couleur, surligneur, pastille, souligne, encadre) |
| `==mot==` | surligneur (la couleur `surligneur` de la DA) |
| `__mot__` | souligné à la couleur d'accent, tracé au fil du temps |
| `[[deux choix]]` | pastille pleine (plusieurs mots possibles) |
| `((pas))` | encadré |

Une même série garde une seule façon de marquer, sauf exception voulue. Les marques se dessinent
juste après le texte (surligneur qui s'étire, soulignement qui se trace) ; `marque_a` fixe le moment.
Si l'accent se confond avec le fond (texte sur aplat d'accent), le moteur passe à l'encre ou au blanc.

### Retour à la ligne

`\n` dans un texte force un retour à la ligne à cet endroit : `"texte": "Le loyer est payé.\nToi, jamais."`.
Marche dans `texte`, `gros`, `rubrique`, `bulle`, `pastille`, `carte`, `liste`, `notification` et
`tampon`. Sinon le texte revient à la ligne tout seul selon `largeur`.

### Types de texte

| Type | Clés | Quand |
|---|---|---|
| `texte` | `texte`, `taille`, `largeur`, `aligne`, `couleur`, `fond` (carte derrière), `contour`, `interligne`, `mode`, `fin`, `vitesse`, `marque` | phrase courte ou titre. `mode` : `bloc` (d'un coup), `mots` (mot par mot jusqu'à `fin`), `machine` (lettre par lettre, `vitesse` en lettres/s, curseur) |
| `gros` | `texte`, `taille` (max), `largeur`, `mode` | mot géant plein écran qui s'ajuste seul à la largeur : « L'ASTUCE », « 59 % », « À QUI ÉCRIRE ? » |
| `rubrique` | `texte`, `taille` (76), `y` (205 = haut du texte) | titre fixe de la vidéo ou du chapitre, à mettre dans `permanent` |
| `karaoke` | `lignes` (`"toutes"`, `"L2-L5"`, `["L1","L4"]`), `groupe` (mots par écran, 3), `style_mot` (couleur, surligneur, pastille, souligne, encadre, aucun), `progressif`, `textes` (`{"L3": "texte affiché"}`), `taille`, `y`, `fond`, `rebond` | sous-titres calés sur la voix, mot dit marqué. À mettre dans `permanent` |
| `bulle` | `texte`, `l`, `taille`, `mots` (fin du mot à mot), `queue` (`bas-gauche`, `bas-droite`, `null`), `etiquette`, `fond` | parole d'un personnage, citation, message reçu |
| `pastille` | `texte`, `taille`, `fond`, `couleur`, `forme` (icône) | étiquette pleine : « 1 COMMANDE », « Abonne-toi » |
| `etiquette` | idem, petit, contour fin | « exemple », « lien en bio », « source » |
| `compteur` | `de`, `vers`, `fin`, `prefixe`, `suffixe`, `decimales`, `taille`, `fond` | chiffre qui roule |
| `tampon` | `texte` (`\n` pour deux lignes), `couleur`, `taille`, `rot`, `style` (`plein`) | verdict : « REFUSÉ », « VALIDÉ », « FAUX » |

`soustitres` (liste globale, ancien format) reste disponible pour un sous-titre simple en carte.

Règles de lisibilité : 2 à 4 mots par ligne de sous-titre, 6 à 8 mots au plus pour une phrase à l'écran,
taille 64 au minimum pour un texte à lire, jamais deux textes qui disent la même chose en même temps.

## 8. Personnages, images, médias

| Type | Clés | Quand |
|---|---|---|
| `perso` | `src`, `h` (hauteur, conseillé) ou `l`, `cadrage`, `changements`, `miroir`, `contour_blanc`, `accessoire`(s), `coupe`, `bouche` | le personnage. `changements` : `[{"a": "L4", "src": "persos/surpris.png"}]` change l'expression sans réanimer |
| `image` (ou `objet`) | `src`, `l`, `h`, `changements`, `miroir`, `contour_blanc` | objet ou illustration du sujet |
| `media` (ou `photo`, `video`) | `src` (jpg, png, mp4, mov, webm), `l`, `h`, `cadre`, `zoom_lent`, `duree_zoom`, `debut`, `vitesse`, `boucle_video` | photo ou vidéo réelle (b-roll). `cadre` : `carte` (style DA), `polaroid`, `arrondi`, `rond`, `aucun`. `zoom_lent: [1, 1.12]` = lent effet Ken Burns. Le son de la vidéo n'est pas repris |
| `medaillon` | `src`, `d`, `forme` (`rond`, `carre`), `fond`, `zoom`, `haut`, `changements`, `rayon`, `couleur_contour` | réaction du personnage dans un rond ou un carré arrondi, présence discrète pendant un schéma |

**Mises en scène du personnage** (`cadrage`) :

| Cadrage | Rendu | Réglages de départ |
|---|---|---|
| `pied` (défaut) | en pied, ancré en bas, `y` = 1500 | `h` 900 à 1100, `x` 330 (à gauche) ou 480 |
| `buste` | coupé à 62 % de sa hauteur (`coupe`) | `h` 440 à 700, en coin (`x` 740, `y` 1450) ou centré |
| `tete` | tête seule (36 %) | `h` 380 à 450 : réaction courte |
| `coin` | petit en bas à gauche | `h` 320, avec un `accessoire` |
| (médaillon) | utiliser `medaillon` | `d` 200 à 300, `x` 180, `y` 1280 |

`bouche` (option) : bouche dessinée qui s'ouvre au volume de la voix, 2 ou 3 images de bouche et leur
position par pose, voir [bouche.md](bouche.md).

`accessoire` : `{"src": "objets/loupe.png", "dx": 200, "dy": -150, "l": 200, "rot": -15, "devant": true}`
(`dx`, `dy` = position du centre par rapport au bas-centre du personnage). Plusieurs : `accessoires: [...]`.
`contour_blanc: 12` ajoute le liseré d'autocollant si l'image n'en a pas (sinon `detoure.py --contour`).
`miroir: true` retourne l'image (le regarder tourné vers le texte).

## 9. Composants qui se construisent

Ils restent à l'écran et évoluent au fil de la voix : c'est ce qui donne « un changement toutes les
1 à 2 s » sans changer de plan. Tous suivent la DA (contour, ombre, rayon, polices, accent).

| Type | Clés | Ce qui évolue |
|---|---|---|
| `liste` | `elements` : `[{"texte", "sous", "a", "actif", "fin_actif", "coche", "barre", "croix", "forme", "image", "numero"}]` ou de simples textes + `pas` ; `style` (`cartes`, `puces`, `numeros`, `cases`, `simple`), `marqueur`, `actif_style` (`rempli`, `surligneur`, `couleur`, `contour`), `un_actif` (true), `l`, `taille`, `espace` | les lignes arrivent une à une (`a`), la ligne dont on parle s'allume (`actif` ; avec `un_actif` le surlignage descend), se coche, se barre, prend une croix |
| `etapes` | `n` ou `labels`, `legendes`, `faits` (un temps par étape), `d`, `espace`, `courant` | 1-2-3 reliés : chaque étape se coche, le trait se remplit, l'étape en cours est entourée |
| `progression` | `de`, `vers`, `depart`, `fin`, `etiquette`, `pourcent`, `max`, `l`, `h`, `couleur` | barre qui se remplit avec son pourcentage |
| `fenetre` | `style` (`navigateur`, `terminal`, `code`, `app`, `mail`), `url`, `titre`, `lignes` (textes ou `{"texte", "a", "couleur", "cle", "tape"}`), `vitesse`, `tape`, `curseur`, `l`, `h`, `taille` | les lignes se tapent ; `"~"` = ligne grise de remplissage ; `"$ ..."` = commande dans un terminal ; `"cle": true` = ligne surlignée |
| `notification` | `app`, `titre`, `texte`, `heure`, `forme` ou `image`, `couleur`, `fond`, `taille`, `l`, `h` | glisse depuis le haut (message reçu, paiement, alerte). La hauteur s'adapte au texte ; un `h` trop petit est signalé par `--verifier` |
| `barres` (ou `graphique`) | `valeurs`, `etiquettes`, `accent` (indice ou liste des barres mises en avant, défaut la plus haute), `couleur_accent` (couleur de ces barres, défaut `"accent"`), `couleur` (couleur des autres, défaut `"papier"`), `unite`, `prefixe`, `depart`, `fin`, `decale`, `afficher`, `max`, `l`, `h` | les barres montent l'une après l'autre avec leur valeur |
| `grille` | `n`, `colonnes`, `d`, `espace`, `forme` (`carre`, `rond`, `bonhomme`), `remplis`, `depart`, `fin`, `couleur`, `vide`, `depuis` | les cases se remplissent : « 1 personne sur 10 », parts d'une entreprise |
| `carte` | `titre`, `texte`, `image` / `forme` / `numero`, `etiquette`, `actif`, `coche`, `l`, `taille`, `fond` | carte d'info qui peut s'allumer ou recevoir une coche |
| `compteur` | voir section 7 | le chiffre roule |
| `bouton` | `texte`, `texte_apres`, `fond`, `fond_apres`, `forme`, `clic` | se presse au `clic` et change (« S'abonner » devient « Abonné ») |
| `curseur` | `de_xy`, `vers_xy`, `a`, `fin`, `clic`, `taille` | pointeur qui se déplace puis clique (onde) |

## 10. Traits, icônes et décor

| Type | Clés | Quand |
|---|---|---|
| `fleche` | `x1`, `y1`, `x2`, `y2` (ou `de_xy`, `vers_xy`), `courbe` (px, signe = côté), `style` (`pointilles`), `couleur`, `epaisseur`, `duree`, `pointe` | relier deux idées, désigner un détail |
| `cercle` | `x`, `y`, `rx`, `ry`, `couleur`, `epaisseur`, `duree` | entourer un détail à la main |
| `barre` (ou `trait`) | `x1`, `y1`, `x2`, `y2`, `couleur`, `epaisseur` | barrer une phrase fausse, souligner à la main |
| `icone` | `forme` (`coche`, `croix`, `coeur`, `etoile`, `eclair`, `plus`, `moins`, `point`, `cloche`, `question`, `exclamation`, `fleche`), `d`, `couleur`, `fond` (rond derrière) | petit signe dessiné en code, sans émoji |
| `forme` | `forme` (`rond`, `rect`, `blob`), `l`, `h`, `couleur`, `rayon` | aplat de couleur derrière un personnage ou un chiffre |

## 11. Effets sur toute l'image

- `punch` : liste de temps, petit coup de zoom (temps fort).
- `flash` : liste de temps, éclair blanc de deux images.
- `secousses` : liste de temps (les tampons et la transition `secousse` secouent déjà).

## 12. Recettes

Exemples de combinaisons, à adapter. Aucune n'est un format imposé.

- **Le mot qui claque** : scène `coupe`, `gros` avec `*mot*`, personnage `tete` ou rien. 1 s.
- **La liste qui s'allume** : `rubrique` en `permanent`, `liste` style `cartes` dont chaque ligne arrive sur
  son mot (`"a": "L3#2"`) puis s'allume (`actif`), personnage `buste` en coin.
- **Le tuto en étapes** : `etapes` en haut (cochées au fil des répliques), une `carte` ou une `fenetre` par
  étape au centre, transition `gauche` entre les étapes.
- **Le récit d'ambiance** : fond `faisceau` ou `halo`, personnage en `fondu`, `texte` en `machine`
  (heure, date), `karaoke` en `permanent`, transitions `fondu-noir`.
- **La démo** : `fenetre` navigateur ou terminal qui se tape, `curseur` qui clique un `bouton`,
  `notification` qui tombe.
- **Le chiffre qui pèse** : `compteur` ou `barres`, puis `tampon`, fond `aplat` d'accent.
- **La preuve réelle** : `media` en `polaroid` avec `zoom_lent`, `fleche` vers le détail, médaillon carré
  du personnage qui réagit.
- **La fin** : scène sur fond `accent` ou `degrade`, `gros` « ABONNE-TOI », `bouton` + `curseur`.
