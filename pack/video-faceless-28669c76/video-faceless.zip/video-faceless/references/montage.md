# Le montage animé

Le montage s'écrit dans un fichier `episode.json` : des scènes, chacune avec un fond et des éléments,
chaque apparition calée sur une réplique (ou un mot) de `timeline.json`. `scripts/rendu.py` en fait une
vidéo. La liste de tout ce qu'on peut poser, avec les clés : [bibliotheque.md](bibliotheque.md).

## Ce qui ne bouge pas

- **Un changement visible toutes les 1 à 2 s** : une ligne qui s'ajoute, un mot qui se surligne, une
  coche, un chiffre qui roule, une expression qui change, une nouvelle scène. Le plus souvent, on fait
  évoluer ce qui est déjà à l'écran plutôt que de changer de plan.
- **Lisible sur un téléphone** : texte de 64 px minimum, 2 à 4 mots par ligne de sous-titre, 6 à 8 mots
  au plus pour une phrase à l'écran, contraste net (texte foncé sur clair, clair sur foncé).
- **Une chose principale à regarder** : le personnage, ou le schéma. Quand le schéma arrive, le
  personnage rapetisse, passe en coin, en médaillon, ou sort.
- **Jamais deux textes qui disent la même chose** au même moment (sous-titre + titre identiques).
- **Zones sûres** (ci-dessous).
- **Une DA par série** : fond, accent, polices, marquage et cartes ne changent pas d'un épisode à l'autre.

Tout le reste est libre : densité, place du texte, transitions, façon d'animer, présence ou non de
sous-titres, médias réels ou non.

## Choisir les éléments

Pour chaque réplique du tableau validé, se demander : qu'est-ce qui montre le mieux cette phrase ?

| La phrase contient | À l'écran |
|---|---|
| un chiffre | `compteur`, `gros`, `barres` ou `grille` ; tout chiffre s'écrit en gros |
| une liste, des options | `liste` qui se construit ligne par ligne, la ligne dite s'allume |
| des étapes | `etapes` 1-2-3 en haut, qui se cochent |
| un outil, un site, une app | `fenetre` (navigateur, terminal, app) qui se tape, `notification`, `curseur` + `bouton` |
| un verdict | `tampon`, croix ou coche dans la liste, `barre` sur la phrase fausse |
| une émotion, une réaction | changement d'expression du personnage, `tete` ou `medaillon` |
| un objet concret | `image` de l'objet (générée dans ChatGPT ou autre), qui entre avec `rebond` ou `tourne` |
| une preuve réelle | `media` (photo, vidéo de la personne) dans un cadre |
| un mot fort | `gros` plein écran, ou mot clé marqué dans un `texte` |
| une liaison (« donc », « mais ») | le personnage seul, avec le sous-titre : c'est la respiration |

Pour le texte, trois façons de faire, à choisir par série (et à ne pas cumuler sur le même écran) :
- **sous-titre karaoké** (`karaoke` en `permanent`) : 2 à 4 mots, le mot dit marqué ;
- **titres** : le mot clé de la phrase, en gros, qui remplace le sous-titre quand un concept tombe ;
- **presque rien** : les libellés des schémas suffisent, le personnage porte le reste.

## Zones sûres (1080 × 1920)

L'interface de TikTok recouvre le haut (y < 180), le bas (y > 1450, légende et pseudo) et la colonne de
droite (x > 900 entre y = 860 et y = 1450, boutons). Centrer le contenu vers **x = 480** plutôt que 540.
Les personnages en pied sont ancrés en bas (`"y": 1500`) : le corps peut descendre dans la zone basse,
pas le visage.

`rendu.py --images auto --zones` colore ces zones en rouge sur les images de contrôle.
`rendu.py --verifier` rend chaque élément seul à plusieurs moments et liste :
- ce qui déborde dans les zones TikTok (le corps d'un personnage en bas est toléré) ;
- ce qui **sort de l'écran** à gauche, à droite, en haut ou en bas ;
- un **personnage coupé en haut**, ou dont la tête passe sous l'interface du haut ;
- un **texte qui déborde de sa carte, de sa notification, de sa ligne de liste ou de sa fenêtre**, et
  un mot trop long pour la largeur prévue.
Chaque ligne dit quoi changer. Corriger, ou assumer en connaissance de cause (un aplat décoratif qui
dépasse est normal ; les `forme` ne sont pas vérifiées).

## Déroulé

1. `timeline.json` existe (sortie de `voix_timeline.py`, avec voix ou `--sans-voix`). Le relire :
   quelle réplique dure combien.
2. Écrire `episode.json` en partant de [../assets/episode-exemple.json](../assets/episode-exemple.json) et du
   bloc `"da"` de `serie.md` : une scène par moment fort, plusieurs scènes pendant une longue explication.
3. Contrôler : `python scripts/rendu.py episode.json --images auto --zones --verifier`, puis **regarder
   `controle/planche.jpg`** : textes coupés, mot seul sur une ligne, chevauchements, éléments dans les
   zones rouges, image trop petite, écran figé plus de 2 s, accent illisible sur le fond.
   Les 16 images automatiques évitent les transitions et les flashs des tampons. Pour des moments
   précis : `--images 1.2,L4,L6.fin` ; elles vont dans `controle/planche-essai.jpg` sans écraser la
   planche complète (`--planche nom.jpg` pour choisir le nom).
4. Corriger, refaire les images de contrôle. Deux ou trois tours suffisent en général.
5. Rendre : `python scripts/rendu.py episode.json --sortie sortie/muette.mp4 --muet --cues cues.json`
   (vidéo sans son pour l'étape son), ou directement avec la voix : `--sortie sortie/video.mp4`.
   Le chemin de sortie est relatif au dossier d'`episode.json`. Compter environ 1 s de calcul par seconde
   de vidéo sur un ordinateur ordinaire. Pour tester une partie : `--de 20 --a 35`.
6. Vérifier la vidéo avant de la donner : durée, quelques images extraites, taille du fichier.

## Repères de taille (1080 × 1920)

- Personnage en pied : `h` 900 à 1100, `x` 330 (à gauche) ou 480, `y` 1500.
- Personnage en buste dans un coin : `cadrage: "buste"`, `h` 440 à 520, `x` 740, `y` 1450.
- Médaillon : `d` 200 à 300, `x` 180, `y` 1280.
- Rubrique : `taille` 70 à 92, `y` 205.
- Sous-titre karaoké : `taille` 60 à 72, `y` 300 à 480.
- Mot géant : `gros` s'ajuste seul (`taille` = maximum).
- Pièce centrale (image, fenêtre, liste) : `l` 620 à 840, `x` 480, `y` 500 à 900.
- Chiffre plein écran : `taille` 220 à 320.

## Pièges

- Une image manquante arrête le rendu : vérifier les noms de fichiers.
- Deux éléments qui arrivent au même instant se mangent : décaler de 0,2 à 0,3 s.
- Les polices n'ont pas d'émojis ni de signes rares (flèches, ≠) : utiliser `icone` et `fleche`.
- Une couleur d'accent sur un fond de la même couleur disparaît : le moteur bascule le mot en encre ou
  en blanc, mais mieux vaut choisir une autre marque pour cette scène.
- Une vidéo réelle est découpée en images au premier rendu (dossier `.cache-media/`, à supprimer après).
