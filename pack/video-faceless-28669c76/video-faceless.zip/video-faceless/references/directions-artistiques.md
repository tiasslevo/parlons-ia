# La direction artistique (DA) de la série

Chaque série a sa propre DA, décidée avec la personne à la première vidéo puis gardée. On la reconnaît
en une seconde : c'est elle, avec le personnage, qui fait qu'on sait que c'est « sa » vidéo. **Tu
n'imposes pas de DA.** Tu poses des questions, tu proposes à partir de ses réponses, elle choisit sur
image.

## 1. L'entretien de départ

Une question à la fois, en mots simples. Commencer par ce qu'elle aime : un compte qu'elle admire, une
marque, une image, une affiche, les couleurs de son activité. **Donner des exemples seulement si elle
répond « je ne sais pas »**, et alors deux ou trois, pas une liste.

1. **Le sujet de la série et le public** : de quoi, pour qui, dans quel pays. (Exemple si besoin :
   « l'argent au quotidien pour les jeunes salariés d'Abidjan ».)
2. **Le style du personnage** : elle-même en avatar, une mascotte, un animal, un objet qui parle ; dessin
   au trait, couleurs à plat, 3D douce, pâte à modeler… (tableau des styles : [personnage.md](personnage.md)).
3. **L'ambiance** : sérieuse, chaleureuse, drôle, mystérieuse, énergique, calme. Plutôt clair ou plutôt
   sombre ?
4. **La couleur** : une couleur qui la représente (ou celle de sa marque). On en garde une seule vive,
   l'accent, plus une couleur de fond et une couleur de cartes.
5. **L'écriture (typo)** : grosses lettres serrées qui claquent, lettres rondes et douces, écriture à la
   main, style journal, style machine à écrire. Montrer les polices fournies sur une image si elle
   hésite.
6. **Le rythme** : posé (on a le temps de lire) ou très rapide (un changement par seconde, coupes
   franches).
7. **Le ton** : tutoiement ou vouvoiement, humour ou pas, phrases sèches ou chaleureuses.

Puis la façon de faire ressortir le mot clé (couleur, surligneur, pastille, souligné, encadré) et le
style des cartes (contour, ombre, coins) : les proposer toi-même d'après les réponses, elle valide sur
l'image.

## 2. De l'entretien à l'image

1. Traduire les réponses en un bloc `"da"` (clés ci-dessous) et un fond de série. Si une des pistes de
   départ est proche, partir d'elle et l'adapter (couleur, police, fond) : ce sont des points de départ,
   pas des modèles.
2. Faire une **planche d'essai** : la même scène rendue en 2 ou 3 variantes (personnage provisoire ou
   formes simples s'il n'existe pas encore), avec `rendu.py --images 1.5,3`. Elle choisit sur l'image,
   pas sur une description.
3. Ajuster (accent, police, fond), refaire une image, puis tout écrire dans `serie.md` : le bloc `"da"`
   exact, les fonds, les transitions et entrées préférées, le rythme, le ton, le prompt de style des
   objets. C'est ce que le kit de série emportera ([kit.md](kit.md)).

Une DA tient en six choix :

1. **le style du personnage** ;
2. **le fond de série** : uni clair, uni foncé, motif léger, dégradé (tout est fait en code) ;
3. **une seule couleur d'accent**, plus l'encre (texte, contours) et le blanc ;
4. **une ou deux polices** : une pour les titres, une pour le texte courant ;
5. **la façon de marquer le mot clé** : couleur, surligneur, pastille, soulignement, encadré ;
6. **le style des cartes** : contour (épaisseur), ombre (dure, douce, aucune), coins (rayon).

Ces réglages passent dans tous les composants : une liste, une fenêtre, une pastille ou un graphique
prennent automatiquement les contours, ombres, rayons, polices et l'accent de la DA.

Ne pas recopier telle quelle la DA d'un créateur connu : garder l'idée, changer au moins l'accent,
le fond ou la police.

## Huit pistes de départ (si elle ne sait pas)

À montrer seulement quand la personne n'a pas d'idée, ou pour illustrer une de ses réponses. Toujours
les adapter à elle.

| Piste | En un mot | Bon pour | Personnage qui va bien | Polices |
|---|---|---|---|---|
| 1 · Nuit orange | fond anthracite, capitales condensées, accent orange | business, productivité, IA, prospection | Bitmoji / 3D doux, liseré blanc | Anton + Geist |
| 2 · Carnet crème | crème à points, surligneur jaune, peu de texte | récit, humour, vie quotidienne, animaux | trait minimaliste | Bricolage |
| 3 · Tuto vert | crème quadrillé, cartes à ombre dure, pastille verte | tutos, argent, carrière, méthodes | 3D style film d'animation | Archivo Black + Geist |
| 4 · Kawaii blanc | blanc, rond, accent orange vif | produits, apps, astuces tech | mascotte kawaii | Fredoka |
| 5 · Pop bleu | blanc quadrillé, contours épais, bleu + jaune | droit, argent, débunk | trait + aplat | Geist |
| 6 · Journal choc | papier journal ligné, rouge et noir, capitales | actu, arnaques, histoire | papier découpé | Anton + DM Serif Display |
| 7 · Pastel doux | crème chaud, corail, coins très ronds, ombres douces | santé, parentalité, études, bien-être | chibi | Fredoka |
| 8 · Tableau craie | vert tableau, écriture manuscrite, jaune craie | école, langues, sciences, culture | croquis au feutre | Caveat + Geist |

Les polices sont dans `assets/fonts/` (licence libre OFL, utilisables dans des vidéos commerciales) :
Geist, Anton, Archivo Black, Bricolage Grotesque, Fredoka, Caveat, DM Serif Display, JetBrains Mono
(terminaux et code).

### 1 · Nuit orange

```json
"da": {"police_titre": "Anton.ttf", "police_texte": "Geist.ttf", "graisse_texte": 700,
       "encre": "#141416", "clair": "#FFFFFF", "accent": "#FF7A1A", "papier": "#2B2B30", "fond": "#1C1C1F",
       "ombre": "aucune", "contour": 0, "rayon": 14, "marque": "couleur", "casse": "majuscules"}
```
Fond de série : `{"type": "halo", "couleur": "#18181B", "lumiere": "#3C3C44", "y": 0.55, "rayon": 0.6}`.
Fin : `{"type": "degrade", "de": "#FF8A1F", "vers": "#D62E6A"}`. Cartes gris foncé, texte blanc.

### 2 · Carnet crème

```json
"da": {"police_titre": "Bricolage.ttf", "graisse_titre": 800, "police_texte": "Bricolage.ttf", "graisse_texte": 700,
       "encre": "#1B1B1B", "accent": "#FFD43B", "papier": "#FFFFFF", "fond": "#F6F0E4",
       "ombre": "aucune", "contour": 5, "rayon": 22, "marque": "surligneur"}
```
Fond : `{"type": "motif", "couleur": "#F6F0E4", "motif": "points", "motif_couleur": "#1B1B1B26", "pas": 56}`.
Scène de nuit : `{"type": "faisceau", "couleur": "#14203D", "lumiere": "#F4E7B8"}`. Karaoké en haut,
mot dit surligné.

### 3 · Tuto vert

```json
"da": {"police_titre": "ArchivoBlack.ttf", "police_texte": "Geist.ttf", "graisse_texte": 700,
       "encre": "#15171C", "accent": "#22C55E", "papier": "#FFFFFF", "fond": "#FBF8F1",
       "ombre": "dure", "decalage": 7, "contour": 5, "rayon": 18, "marque": "pastille"}
```
Fond : `{"type": "motif", "couleur": "#FBF8F1", "motif": "quadrillage", "motif_couleur": "#15171C10", "pas": 60}`.
Médaillon carré du personnage en bas à gauche, photos réelles en cartes.

### 4 · Kawaii blanc

```json
"da": {"police_titre": "Fredoka.ttf", "graisse_titre": 700, "police_texte": "Fredoka.ttf", "graisse_texte": 600,
       "encre": "#2A2238", "accent": "#FF7A2F", "papier": "#FFFFFF", "fond": "#FFFFFF",
       "ombre": "douce", "contour": 0, "rayon": 36, "marque": "couleur"}
```
Fond blanc uni, ponctuellement `{"type": "motif", "couleur": "#FFF1EA", "motif": "points", "motif_couleur": "#FF7A2F30"}`.
Fin sur `"accent"` plein. Mascotte petite, en coin, avec accessoires. Karaoké en haut.

### 5 · Pop bleu

```json
"da": {"police_titre": "Geist.ttf", "graisse_titre": 800, "police_texte": "Geist.ttf", "graisse_texte": 650,
       "encre": "#14161A", "accent": "#2F5BFF", "surligneur": "#FFE45C", "papier": "#FFFFFF", "fond": "#FFFFFF",
       "ombre": "dure", "contour": 6, "rayon": 28, "marque": "couleur"}
```
Fond : `{"type": "motif", "couleur": "#FFFFFF", "motif": "quadrillage", "motif_couleur": "#ECEEF2"}`.
Aplats jaune `#FFE45C` ou encre pour les mots forts.

### 6 · Journal choc

```json
"da": {"police_titre": "Anton.ttf", "police_texte": "DMSerifDisplay.ttf", "encre": "#111111",
       "accent": "#E10600", "surligneur": "#FFD600", "papier": "#FFFDF7", "fond": "#F4F1EA",
       "ombre": "dure", "decalage": 6, "contour": 4, "rayon": 4, "marque": "souligne", "casse": "majuscules"}
```
Fond : `{"type": "motif", "couleur": "#F4F1EA", "motif": "lignes", "motif_couleur": "#11111118", "grain": 0.5}`.
Citations en bulles sans queue, tampons rouges, aplat rouge pour les mots forts.

### 7 · Pastel doux

```json
"da": {"police_titre": "Fredoka.ttf", "graisse_titre": 650, "police_texte": "Fredoka.ttf", "graisse_texte": 500,
       "encre": "#3B2F2F", "accent": "#FF7A6B", "surligneur": "#FFE7A0", "papier": "#FFFFFF", "fond": "#FFF6EC",
       "ombre": "douce", "contour": 4, "rayon": 44, "marque": "souligne"}
```
Fond : `{"type": "degrade", "de": "#FFE3D3", "vers": "#FFF6EC", "radial": true}` ou crème à vagues.

### 8 · Tableau craie

```json
"da": {"police_titre": "Caveat.ttf", "graisse_titre": 700, "police_texte": "Geist.ttf", "graisse_texte": 600,
       "encre": "#1F2A26", "clair": "#F7F3E8", "accent": "#FFE066", "papier": "#F7F3E8", "fond": "#1F3A33",
       "ombre": "aucune", "contour": 0, "rayon": 12, "marque": "souligne"}
```
Fond : `{"type": "uni", "couleur": "#1F3A33", "grain": 0.6, "vignette": 0.35}`. Titres manuscrits, cartes
papier clair posées sur le tableau, flèches et cercles à la craie (`"couleur": "clair"`).

## Les clés du bloc "da"

Ce que l'entretien fixe, clé par clé :

- `fond` : la couleur de série (claire ou foncée) ; `papier` : la couleur des cartes ;
- `encre` : très foncée (texte sur clair, contours) ; `clair` : le blanc du texte sur fond foncé ;
- `accent` : une seule couleur vive. Vérifier qu'elle se lit sur le fond (un jaune ne se lit pas en
  couleur de mot sur du blanc : le mettre en surligneur ou en pastille) ;
- `surligneur` : facultatif, sinon l'accent sert de surligneur ;
- `gain` et `perte` : vert et rouge, seulement pour ce qui se gagne ou se perd ;
- `police_titre` et `police_texte` : une police grasse avec les accents français pour les titres, une
  police très lisible pour le texte. Une seule police pour les deux marche aussi. Pour une police
  personnelle, déposer le `.ttf` à côté d'`episode.json` et vérifier sa licence (usage commercial) ;
- `graisse_titre`, `graisse_texte` : 400 à 900 pour les polices variables (Geist, Bricolage, Fredoka,
  Caveat, JetBrains Mono) ;
- `marque` : `couleur`, `surligneur`, `pastille`, `souligne` ou `encadre` ;
- `ombre` : `dure` (décalée, nette ; `decalage` en px), `douce` (floue), `aucune` ;
- `contour` (0 à 8 px) et `rayon` (0 = coins carrés, 40 = très ronds) ;
- `casse` : `majuscules` pour des titres en capitales, sinon `normale`.

Lisibilité à contrôler sur la planche : texte foncé sur clair, clair sur foncé, accent jamais seul sur un
fond de luminosité proche. Quand aucune couleur n'est imposée, le moteur choisit tout seul l'encre ou le
blanc selon le fond de chaque scène.

## Le style des objets et illustrations

Une fois le personnage choisi, écrire un **suffixe de style** pour les objets, accordé au personnage
(même rendu, même épaisseur de trait, même palette), et le noter dans `serie.md`. Exemples :

- Bitmoji / 3D doux : « objet en rendu 3D doux et brillant façon émoji, contour noir fin puis épais
  contour blanc d'autocollant, couleurs franches, ombrage léger, fond blanc pur » ;
- trait minimaliste : « dessin au trait noir épais et régulier, intérieur blanc, au plus une touche de
  [accent], aucune ombre, fond blanc pur » ;
- 3D film d'animation : « objet en 3D stylisé façon film d'animation, matières douces, éclairage studio
  doux, couleurs saturées, fond blanc pur » ;
- kawaii : « objet mignon aux formes rondes, contour brun foncé, couleurs pastel à plat, petits reflets,
  fond blanc pur » ;
- papier découpé : « collage en papier découpé, bords nets, légère texture papier, ombre portée courte,
  palette [couleurs], fond blanc pur ».
