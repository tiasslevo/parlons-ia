# La voix

Trois choix : une voix IA (ElevenLabs), la voix de la personne, ou pas de voix du tout (vidéo muette,
le texte à l'écran porte le propos). S'il y a plusieurs personnages, on peut mélanger : la personne fait
le sien, l'IA fait l'autre.

## Règle de dépense

La voix coûte des crédits (environ 1 crédit par caractère du texte, soit 1 000 à 1 700 crédits pour un
épisode de 70 s à deux voix). Ne générer qu'**après validation du script**, annoncer le nombre de caractères
avant de lancer, et faire **une prise par personnage et par épisode**.

## Choisir une voix IA (une fois par série)

Avec le connecteur ElevenLabs relié à Claude :

1. `creative_get_model_guide` sur le modèle de parole le plus expressif disponible (eleven_v4 au moment
   d'écrire ce skill) : il dit quelles balises de jeu il comprend. Le relire si le modèle change.
2. **Bibliothèque d'abord** : `creative_list_voices`, retenir 3 ou 4 voix qui collent à la fiche (âge, genre,
   accent, énergie). Leurs extraits de démonstration s'écoutent gratuitement : donner les liens à la
   personne.
3. Si rien ne va, **voix sur mesure** (Voice Design, payant) : `creative_design_voice` avec une description
   et une phrase test tirée du script, en français. Décrire la façon de parler, pas le matériel :
   - bien : « femme de 30 ans, accent d'Abidjan léger, voix chaude et rapide, ton complice et un peu
     moqueur, son clair, pleine bande » ;
   - à éviter : « au téléphone », « dans un micro », « enregistrement » : la voix sort alors comme à la radio.
   La personne écoute les propositions, puis `creative_save_designed_voice` sur celle qu'elle choisit.
4. Noter le nom, l'identifiant de la voix et le modèle dans `serie.md`. On n'en change plus.

S'il y a un second personnage, chercher un vrai contraste avec le premier (âge, débit, timbre) : on doit
savoir qui parle les yeux fermés.

## Générer les prises d'un épisode

Un flow ElevenLabs par épisode (`creative_create_flow`, nom « [série] — [sujet] »), puis
`creative_generate_speech` une fois par personnage :

- tout le texte du personnage, **dans l'ordre du script**, chaque réplique séparée par `[long pause]` ;
- une balise de jeu juste avant les mots qu'elle colore ; elle vaut jusqu'à la suivante. Base `[casual]`,
  puis selon le moment `[sarcastic]`, `[deadpan]`, `[smug]`, `[dismissive]`, `[sighs]`, `[laughs]`,
  `[chuckles]`, `[whispers]`, `[warmly]`, `[curious]`, `[nervous]`. Éviter `[excited]` en ouverture
  (trop appuyé). Doser : une balise toutes les deux ou trois répliques suffit ;
- un mot en MAJUSCULES pour l'appuyer, rarement ;
- aucun point de suspension (soupir parasite) ;
- demander à la personne combien de variantes elle veut : chaque variante coûte des crédits.

Exemple (6 répliques, une seule voix) :

```
[casual] Tu comptes les jours jusqu'au vendredi ? [long pause] La plupart des gens ont deux choix.
[long pause] [deadpan] Démissionner, ou serrer les dents. [long pause] [smug] Moi, j'ai pris une
troisième option. [long pause] Résultat : trois mois de revenus en plus. [long pause] [warmly] Abonne-toi,
je te montre comment demain.
```

Suivre la génération avec `creative_get_flow_run_status`, puis récupérer les fichiers :
- **mode Studio** : télécharger tout de suite (les liens expirent au bout de quelques heures) dans
  `episodes/<ep>/audio/<personnage>.mp3` ;
- **mode App** : le bac à sable n'a souvent pas accès aux serveurs d'ElevenLabs. Donner le lien du flow à la
  personne, elle télécharge les mp3 et les joint à la conversation.

Écouter avant d'aller plus loin : la personne valide le jeu. Une réplique ratée se régénère seule (un
fichier par ligne, clé `"fichier"` dans `script.json`), pas toute la prise.

## Sa propre voix

- Pièce calme avec des tissus (rideaux, lit, placard plein), téléphone à 20 cm de la bouche, application
  dictaphone, mode avion.
- Le plus simple : **un fichier par réplique** (`l01.m4a`, `l02.m4a`…). Une erreur ? On refait le fichier.
  Dans `script.json`, chaque ligne reçoit `"fichier": "audio/l01.m4a"`.
- Ou une prise par personnage, avec une vraie respiration d'une seconde entre les répliques et sans
  recommencer une phrase au milieu.
- Nettoyage léger si la pièce résonne ou souffle :
  `ffmpeg -i brut.m4a -af "highpass=f=80,afftdn=nf=-25,loudnorm=I=-16" -ar 48000 voix-propre.wav`
- Pour rester anonyme tout en jouant soi-même : la fonction « changeur de voix » (speech to speech) du site
  ElevenLabs garde le jeu et change le timbre. À faire sur le site si le connecteur ne la propose pas.

## Assembler et minuter

```bash
python scripts/voix_timeline.py episodes/<ep>/script.json
```

Le script repère les zones de parole de chaque prise, puis choisit les coupes qui donnent **exactement
autant de morceaux que de répliques dans `script.json`** : il préfère les silences longs et des morceaux
dont la durée colle à la longueur du texte. Un « Hmm », une respiration, un rire ou un bruit de bouche
reste collé à la réplique voisine au lieu de créer une réplique de trop (et si le « Hmm » est une
réplique du script, il devient bien sa propre réplique). Le nombre de répliques est donc toujours celui
du script. Ensuite il **aligne le volume** des personnages (deux voix ElevenLabs peuvent sortir avec
20 dB d'écart), ajoute un petit silence entre les répliques (`"pause"` par ligne pour un temps plus
long), et écrit `voix.wav` et `timeline.json` (début et fin de chaque réplique).

Relire le tableau qu'il affiche : chaque réplique doit tomber sur le bon texte, avec une durée qui
ressemble à sa longueur. S'il écrit « attention : la coupe avant la réplique 4 tombe sur un silence de
0,12 s », vérifier ce passage à l'écoute ou sur une image de contrôle.

Si une coupe est fausse :
- imposer les coupes à la main dans `script.json`, en secondes dans la prise d'origine :
  `"coupes": {"nora": [2.4, 3.3, 5.3]}` (autant de coupes que de répliques moins une) ;
- ou changer le seuil : `--silence -32` (prise avec bruit de fond), `--silence -45` (prise très propre) ;
- ou passer à un fichier par réplique (clé `"fichier"`).

## Sans voix : le minutage automatique

Pour une vidéo muette (le texte à l'écran porte tout, musique ou bruitages seulement), écrire quand même
`script.json` avec une ligne par réplique, puis :

```bash
python scripts/voix_timeline.py episodes/<ep>/script.json --sans-voix [--debit 2.6]
```

Le mode sans voix se lance aussi tout seul si `script.json` contient `"muet": true` ou n'a ni prise ni
fichier. La durée de chaque réplique est estimée sur son texte (syllabes, chiffres, ponctuation) au débit
`--debit` (mots par seconde : 2,6 par défaut, 2,2 pour laisser lire, 3 pour un rythme rapide). Une ligne
peut imposer sa durée avec `"duree": 2.5` et le silence qui la suit avec `"pause": 0.4`. Le fichier
`timeline.json` obtenu s'utilise exactement comme avec une voix : `"L3"`, `"L3.fin"`, `"L3#2"`.
Le montage se rend avec `--muet`, le son avec `mix_son.py` sans `--voix`.

Le karaoké et les repères `"L3#4"` (4e mot de la réplique 3) utilisent un minutage mot à mot **estimé**
à partir des syllabes : assez juste pour des groupes de 2 à 4 mots. Pour un calage parfait en mode Studio,
transcrire `voix.wav` avec faster-whisper (`pip install faster-whisper`, `word_timestamps=True`) et ajouter
à chaque ligne de `timeline.json` : `"mots": [{"mot": "Tu", "t0": 0.21, "t1": 0.30}, ...]`.
