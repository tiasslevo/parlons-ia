# Écrire le script

Un script faceless se lit à voix haute, vite, par un personnage qui a un avis. Il doit tenir l'attention
seconde par seconde : chaque phrase apporte une info, une image ou un retournement.

## Avant d'écrire

1. Relire `serie.md` : le personnage, le ton, ce qu'on ne fait pas.
2. Si la personne envoie des vidéos qui marchent dans sa niche : les regarder ou les transcrire, noter le
   hook mot pour mot, la structure, ce qui accroche. **On s'en inspire, on ne recopie jamais.**
3. Vérifier chaque fait chiffré, juridique, médical ou financier sur une source officielle ou reconnue
   (site du gouvernement, texte de loi, organisme public, étude publiée). La source va dans le document de
   validation, pas à l'écran. Sans source solide : changer d'angle.
4. Proposer 2 ou 3 angles en une ligne chacun (hook + idée). La personne choisit.

## Le hook (les 2 premières secondes)

Une phrase et un texte à l'écran dès la première image. Quelques familles, à varier :

- **la promesse précise** : « Voici comment trouver tes clients de A à Z. »
- **le constat qui pique** : « Tu comptes les jours jusqu'au vendredi ? »
- **la phrase fausse qu'on entend partout**, qu'on démonte ensuite ;
- **le chiffre** : « 59 appels par jour. »
- **la scène** : « Il est 2 h 44. Kenza ne dort toujours pas. »
- **le résultat d'abord** : « Cette vidéo a été montée en trois minutes. »

Pas de présentation du personnage, pas d'introduction (« aujourd'hui on va parler de »).

## Des structures pour s'inspirer

Aucune n'est obligatoire. Choisir celle qui sert le sujet, la mélanger, ou en inventer une.

| Structure | Déroulé | Bon pour |
|---|---|---|
| Tuto en étapes | promesse → étape 1, 2, 3 (chacune une action concrète) → récap → appel | méthodes, outils, démarches |
| Liste d'options | « la plupart des gens font A ou B » → la 3e option → preuve | carrière, argent, choix de vie |
| Récit court | une scène, un problème, un retournement, la leçon | humour, vécu, animaux, sujets sensibles |
| Avant / après | la galère → ce qui a changé → le résultat chiffré | produit, habitude, outil |
| Le calcul | une petite chose qui devient énorme, le chiffre grossit à chaque phrase | frais, épargne, temps perdu |
| Idée reçue | la phrase qu'on entend → pourquoi c'est faux → ce qu'il faut faire | santé, droit, argent |
| Démo | « regarde » → l'outil en action à l'écran → ce que ça change | apps, IA, logiciels |
| Dictionnaire | phrase entendue → traduction honnête, 4 ou 5 entrées | travail, relations, séries courtes |
| Réponse à un commentaire | le commentaire à l'écran (avec accord ou anonymisé) → la réponse | communauté |
| Contradicteur récurrent | un second personnage dit une chose fausse, le personnage principal la démonte | débunk, conseils (si la personne aime ce format) |

Fin : un appel concret et unique (s'abonner, commenter un mot, envoyer la vidéo à quelqu'un de précis,
lien en bio), parfois un récap en une image juste avant.

Durée : 120 à 200 mots pour 45 à 80 s. Plus long seulement si chaque phrase apporte une info nouvelle.

## Écrire comme on parle

- Phrases courtes. Une idée par phrase.
- Registre oral du personnage : « du coup », « bah », « franchement », « t'as », négation sans « ne » si
  ça lui ressemble. Adapter au pays du public : expressions, monnaie, exemples locaux.
- Des chiffres précis plutôt que des adjectifs : « 6 jours », pas « plein de jours ».
- Pas de formule creuse, pas d'opposition « ce n'est pas X, c'est Y », pas de liste de trois adjectifs,
  pas de « dans un monde où ».
- **Aucun point de suspension** dans le texte destiné à la voix IA : certains modèles le jouent comme un
  soupir. Points et virgules seulement.
- Les nombres : écrire comme ils se disent si la voix bute (« deux mille cinq cents ») ; garder les
  chiffres pour l'écran.

## Le format de validation

Présenter le script en tableau, avec ce qu'on voit à l'écran. C'est ce document que la personne valide.
La colonne « Qui » ne sert que s'il y a plusieurs voix.

| # | Réplique (texte exact de la voix) | À l'écran |
|---|---|---|
| 1 | Tu comptes les jours jusqu'au vendredi ? | Titre en haut, « vendredi » en pastille, la semaine en cases qui se barrent |
| 2 | La plupart des gens ont deux choix. | Deux cartes arrivent une à une |
| 3 | Démissionner, ou serrer les dents. | Chaque carte reçoit une croix sur son mot |
| 4 | Moi, j'ai pris une troisième option. | Coupe, étapes 1-2-3, « 3e option » en pastille, photo réelle |
| 5 | Résultat : trois mois de revenus en plus. | Graphique à barres qui monte, tampon « + 7 300 € » |
| 6 | Abonne-toi, je te montre comment demain. | Aplat de couleur, « ABONNE-TOI », bouton cliqué |

Sources : [liste, hors écran]. Durée estimée : [mots ÷ 2,6 ≈ secondes].

Après validation, le transformer en `script.json` (voir [../assets/script-exemple.json](../assets/script-exemple.json)) :
une entrée par réplique, dans l'ordre, avec la voix qui la dit.

## Légende et publication

- Légende : une phrase qui reprend le hook ou pose la question, puis 3 à 5 hashtags précis de la niche.
- Couverture : l'image du hook, lisible en petit.
- Première heure : répondre aux commentaires, épingler le meilleur.
