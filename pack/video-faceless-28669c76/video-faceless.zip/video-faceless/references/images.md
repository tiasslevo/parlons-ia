# Les images : personnage, objets, médias réels

Trois familles d'images :
- **le personnage** (référence + poses), fait une fois pour la série : voir [personnage.md](personnage.md) ;
- **les objets et illustrations** du sujet (une loupe, des billets, un téléphone qui vibre, un bâtiment),
  neufs à chaque épisode, toujours dans le style du personnage ;
- **les médias réels**, en option : photos ou courtes vidéos de la personne (son bureau, son écran, ses
  mains, sa rue), posés dans un cadre ou en fond flouté.

Ce qui ne se génère pas :
- **les fonds et décors** : uni, dégradé, motif, faisceau de lumière, halo, aplat de fin sont faits en code
  ([bibliotheque.md](bibliotheque.md), section 4) ;
- **les textes, chiffres, listes, fenêtres, graphiques, boutons, notifications** : le montage les dessine
  en code, nets et justes (les générateurs d'images écrivent mal le français).

## Qui génère ?

L'outil d'images est au choix de la personne : ChatGPT (le plus courant), Codex, Gemini, Midjourney,
ou tout générateur relié à Claude. Les prompts ci-dessous marchent partout ; seuls les mots « dans
ChatGPT » changent.

1. **Un outil d'image est relié à Claude** (connecteur ou outil intégré) : tu génères toi-même, une image
   par appel, après accord sur la liste. Annoncer le coût si l'outil consomme des crédits.
2. **Cas le plus courant : la personne utilise un générateur à côté** (ChatGPT en général). Tu prépares
   les prompts, elle les colle, télécharge les images et te les renvoie. Déroulé ci-dessous.

## Déroulé avec ChatGPT

1. Tu lis le script validé et listes **4 à 8 objets** : un par idée forte, pas un par phrase. Beaucoup de
   phrases se montrent mieux avec un composant codé (liste, chiffre, fenêtre) qu'avec une image.
2. Tu écris un **message de départ** à coller une seule fois dans une conversation ChatGPT dédiée à la série
   (« Objets — [série] »), avec deux objets déjà validés joints en référence de style (au premier épisode :
   la référence du personnage).
3. Puis **un prompt par image**, numéroté, avec le nom de fichier à donner. La personne colle, télécharge
   et te renvoie les fichiers (pièces jointes, ou dossier `pieces/` en mode Studio).
4. Tu ouvres chaque image et vérifies : fond blanc uni, objet entier, aucun texte lisible, style conforme.
   Une image ratée : un seul nouvel essai avec une consigne précise, sinon changer d'objet.
5. Détourer et contrôler (une image déjà sur fond transparent est gardée, et son halo flou ou gris
   est nettoyé ; `--garder-alpha` pour ne pas y toucher) :
   ```bash
   python scripts/detoure.py pieces pieces/cut --contour 10       # --contour : liseré blanc, si la DA en a
   python scripts/planche.py pieces/cut                    # damier : un fond mal détouré saute aux yeux
   python scripts/planche.py pieces/cut --fond "#1C1C1F"   # sur la couleur du fond de série
   ```

Option bouche qui bouge : une image de plus, la planche de 3 bouches du personnage, découpée avec
`scripts/decoupe.py` ([bouche.md](bouche.md)).

## Message de départ (à coller une fois)

```
Tu vas me dessiner des objets pour une série de vidéos. Je t'enverrai une demande par image.
Pour TOUTES les images, respecte exactement ce style, identique aux images jointes :
[suffixe de style des objets, recopié depuis serie.md]
Règles fixes : un objet seul, centré, entier, sur fond blanc pur uni. Aucun texte, aucune lettre, aucun
chiffre lisible, aucun logo de marque, aucun cadre, aucun décor. Format carré 1024 × 1024. Objets
expressifs et un peu drôles. Réponds seulement par l'image.
```

## Prompt d'un objet

```
Image [n] — [nom-de-fichier].png : [l'objet], [son état ou sa situation qui raconte l'idée],
[un détail drôle ou parlant]. Même style que les précédentes, fond blanc pur.
```

Exemples :
- `telephone-frais.png` : un téléphone posé à plat d'où s'échappent des pièces de monnaie par une petite
  fissure, trois petits traits de mouvement.
- `sablier-calendrier.png` : un grand sablier dont le sable coule, un petit calendrier accroché dessus dont
  les pages s'envolent, sans chiffres.
- `boutique.png` : une petite boutique avec un store orange, vue de face, porte ouverte.
- `loupe.png` : une loupe au manche en bois, reflet sur le verre (accessoire à poser à côté du personnage).

Ce qui raconte le mieux : un objet du quotidien **dans un état exagéré** (qui déborde, fond, se fissure,
s'envole). Éviter les concepts abstraits (« la confiance ») : choisir l'objet qui les montre.

## Les médias réels (facultatif)

Quand la personne veut montrer du vrai (son écran, ses mains, un lieu, un produit) :
- photos `jpg`/`png` ou courtes vidéos `mp4`/`mov` filmées au téléphone, 2 à 6 s chacune, sans visage
  si la série est faceless ;
- les déposer dans `medias/` (ou les joindre à la conversation) ;
- au montage : `media` dans un cadre (`carte`, `polaroid`, `arrondi`, `rond`) avec `zoom_lent`, ou en fond
  (`"fond": {"type": "video", ...}`) flouté et assombri. Le son des vidéos n'est pas repris ;
- droits : uniquement ses propres médias, ou des médias libres de droits avec la source notée. Pas de
  visage d'une autre personne sans son accord.

## Si la personne n'a pas de générateur d'images

Le montage tient très bien sans objets : gros mots, compteurs, listes, fenêtres, graphiques, icônes,
tampons et traits sont dessinés en code. Prévoir alors 2 ou 3 objets seulement, ou des pictogrammes
libres de droits (chercher « CC0 » ou « domaine public » et noter la source dans `serie.md`).
