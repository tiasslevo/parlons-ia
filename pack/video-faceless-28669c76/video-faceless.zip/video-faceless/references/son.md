# Le son

Une vidéo sans bruitages paraît vide, une vidéo trop bruitée paraît amateur. On pose des sons discrets
sur ce qui bouge : coupes, swipes, tampons, apparitions, notifications. La voix reste devant.

## La banque fournie

Le skill a sa propre banque dans `assets/sons/` : 21 bruitages **fabriqués en code** par
`scripts/sons.py` (aucun enregistrement extérieur), donc libres de droits, utilisables dans des vidéos
commerciales sans mention. Trois variantes par type :

| Type | Son | Posé sur |
|---|---|---|
| `whoosh` | souffle qui passe | transitions qui bougent (glissement, volet, zoom, bande) |
| `glisse` | swipe léger | entrée d'un personnage |
| `pop` | petit pop rond | apparitions, lignes de liste, coches, étapes |
| `impact` | coup sourd | tampons, flash, secousse, `punch` |
| `coupe` | clic sec de coupe | changements de scène en coupe franche |
| `clic` | clic de souris | bouton, curseur |
| `ding` | petite clochette | notification |

`mix_son.py` les utilise par défaut, rien à installer. Si une banque disparaît :
`python scripts/sons.py` la refait.

La personne peut préférer des sons réels : elle les range dans `sons/<type>/` (wav ou mp3, libres de
droits, par exemple les packs CC0 de Kenney ou les sons « Creative Commons 0 » de Freesound) et passe
`--sons sons/`. Chaque type présent remplace celui du skill, les autres restent. Noter la source dans
`serie.md`. Pas de sons « mème » reconnaissables ni d'extraits de films ou de musiques connues.

## Poser les sons

`rendu.py --cues cues.json` écrit les repères depuis `episode.json` (whoosh aux transitions qui bougent,
coupe sur les coupes franches, impact aux tampons, flash, secousse et `punch`, pop aux apparitions,
clic aux boutons et curseurs, glisse à l'entrée d'un personnage, ding aux notifications ; rien sur les
fondus). Puis :

```bash
python scripts/mix_son.py --voix voix.wav --cues cues.json --video sortie/muette.mp4 --sortie sortie/finale.mp4
python scripts/mix_son.py --cues cues.json --video sortie/muette.mp4 --sortie sortie/finale.mp4   # vidéo sans voix
```

Le script espace les sons (pas deux impacts à moins de 2,5 s, pas deux pops à moins de 0,35 s), règle
chaque type à un niveau fixe sous la voix, puis sort le mix à −14 LUFS, le niveau attendu par TikTok et
Reels. Sans voix ni musique, il garde le niveau des bruitages (une normalisation les ferait hurler).
Retoucher `cues.json` à la main si besoin : enlever un son, ajouter `"gain": -12` pour monter un impact,
ou `"fichier": "sons/impact/tampon.wav"` pour un son précis.

Moins, c'est mieux : si la personne trouve ça chargé, garder seulement les whoosh et les impacts
(enlever les autres lignes de `cues.json`).

## La musique (facultative)

Une musique libre de droits, calme, sans paroles : `--musique musique.mp3`. Elle baisse toute seule quand
quelqu'un parle et s'éteint en fondu à la fin. Niveau par défaut −24 dB (`--musique-db -28` pour plus
discret). Sur TikTok, on peut aussi ajouter un son de la bibliothèque de l'application au moment de publier,
à très bas volume : c'est souvent mieux pour la portée.

## Vérifier

Tu n'entends pas le son : demande à la personne d'écouter avec des écouteurs et de répondre à trois
questions. La voix est-elle toujours claire ? Un son est-il trop fort ou en retard ? Manque-t-il quelque chose
sur un tampon ? Deux tours de correction au plus, ensuite on publie.
