# Mon style

## En une phrase
<!-- ex. Vidéos face caméra sur l'IA pour les entrepreneurs, ton direct, illustrations flat vertes. -->

## Façon de monter
<!-- alternance (défaut) / face caméra pur / écran séparé / illustration complète -->
Rythme : <!-- naturel / dynamique / très serré -->

## Illustrations
Matière : <!-- flat / papier découpé -->
Phrase de style (recopiée dans chaque prompt) :
```
<!-- ex. flat vector illustration, simple geometric shapes, flat solid colors, front view, not isometric, no outlines, no gradients, no texture -->
```
Palette stricte : <!-- ex. crème #F6F0E4, encre #1D1B18, accent #25A35A, doré #D9A94A -->
Générateur : <!-- ChatGPT / outil relié à Claude -->

## Titres
Ligne principale : <!-- police, couleur sur caméra, couleur sur illustration -->
Ligne fine : <!-- police, couleur (la même toute la vidéo) -->
Sous-titres : <!-- police, taille, couleur du mot dit, où (buste) -->

## Bloc "da" (recopié tel quel dans episode.json)
```json
{"police_titre": "Anton.ttf", "police_texte": "Manrope.ttf", "graisse_texte": 700,
 "encre": "#1D1B18", "accent": "#25A35A", "papier": "#FFFFFF", "fond": "#F1EADF",
 "surligneur": "#D9A94A", "ombre": "douce", "contour": 0, "rayon": 26, "marque": "couleur"}
```
Fond des scènes illustrées : <!-- ex. papier clair (fond.py --papier "#F1EADF") -->
Fond derrière la personne : <!-- décor filmé / remplacé par images/pretes/fond.png (prompt utilisé) -->

## Son cadre habituel
<!-- Plan (cadrage.py) et réglage choisi : garder / un peu / serré, zoom et centre. -->

## Outils sur cet ordinateur
<!-- chemins ou commandes qui ont marché (ffmpeg, modèle de détourage, Whisper). -->

## Retours
<!-- ce qu'elle a aimé, ce qu'elle a corrigé, vidéo par vidéo. -->
