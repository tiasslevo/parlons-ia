# Couper le rush

Le but : une parole nette, sans blanc ni reprise, qui garde la façon de parler
de la personne. Cette parole montée devient la référence de temps de tout le
reste.

## 1. Inspecter et transcrire

```bash
ffmpeg -hide_banner -i source/rush.mov        # durée, taille, rotation, pistes
python3 scripts/transcrire.py source/rush.mov --sortie analysis/mots.json
```

Lis `analysis/mots.txt` puis les mots horodatés. Passe à `--modele medium` si
les noms propres sont mal entendus. Une dictée ou un texte fourni n'a pas
besoin de transcription.

## 2. Choisir ce qu'on garde

Repère dans la transcription :

- les **blancs** avant la première phrase, entre les phrases, après la fin ;
- les **hésitations** qui gênent (« euh », « donc… », mot répété) ;
- les **faux départs et reprises** : quand une phrase est dite plusieurs fois,
  garde en général la dernière prise complète. Vérifie au contenu ;
- les **phrases en trop** pour la durée voulue (TikTok : 20 à 60 s le plus
  souvent). Propose ces coupes de fond, ne les impose pas.

Autour d'un raccord douteux, retranscris une courte fenêtre :
`python3 scripts/transcrire.py source/rush.mov --debut 12 --fin 18.5`.
`scripts/detecter_silences.py` propose une première liste de blancs.

Garde les attaques de syllabes, les fins de mots et les respirations utiles.
Coupe 30 à 60 ms avant le premier mot et après le dernier. Commence sur la
première phrase utile.

## 3. Écrire l'EDL et assembler

`edit/edl.json` liste les morceaux gardés (temps du rush, fin exclusive) :

```json
{"source": "../source/rush.mov", "fps": 30, "segments": [
  {"debut": 1.47, "fin": 10.77, "raison": "accroche, « Alors » retiré"},
  {"debut": 11.03, "fin": 15.27, "raison": "2e prise gardée"}]}
```

```bash
python3 scripts/appliquer_edl.py edit/edl.json --video edit/dialogue.mp4 \
  --wav edit/voix.wav --vertical 1080x1920
```

Le script remet la vidéo à l'endroit, recadre en vertical, cale image et son à
la frame près et pose un micro-fondu à chaque raccord. Il écrit
`edit/edl-resolue.json` : la place de chaque morceau dans la vidéo montée (les
débuts servent de `--coupes` au détourage).

## 4. Traiter la voix, vérifier, retranscrire

```bash
python3 scripts/voix.py edit/voix.wav edit/voix-traitee.wav   # voir son.md
python3 scripts/transcrire.py edit/voix-traitee.wav --sortie analysis/mots-montes.json
python3 scripts/timeline.py analysis/mots-montes.json --sortie timeline.json
```

Relis la liste : chaque phrase complète, aucun mot mangé aux raccords, aucune
reprise oubliée. Si un raccord accroche, corrige l'EDL et refais l'assemblage.

`timeline.json` découpe la parole en lignes L1, L2… avec le temps de chaque
mot. `--max 1.6` donne des lignes plus courtes. Les apparitions se calent
ensuite sur `"L3#4"` (4e mot de la ligne 3).

## Rythme

Demande-le au départ si elle a une préférence :

- **naturel** : pauses de 0,25 à 0,4 s gardées entre les phrases ;
- **dynamique** (par défaut) : pauses de 0,1 à 0,2 s, phrases enchaînées ;
- **très serré** : presque aucune pause. Attention aux phrases qui se collent.

Ne change pas la vitesse de la voix. Si un résultat a besoin d'être lu, crée
le temps au montage (courte pause gardée ou image tenue).
