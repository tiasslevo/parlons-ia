# Les quatre façons de monter

La personne choisit une façon pour la vidéo. Sans choix, prends l'alternance.
La structure vient de ce qu'elle dit, pas d'un minutage fixe.

## 1. Face caméra pur

On la voit tout le temps. L'écran travaille autour d'elle :

- coupes nettes, zoom lent discret, un recadrage sec plus serré sur la phrase
  forte (une fois par passage environ) ;
- titres courts au-dessus de sa tête ;
- éléments qui montent de derrière son dos jusqu'au-dessus de sa tête quand
  elle cite un outil, un chiffre, un objet ;
- sous-titres vers le buste quand ils aident à suivre.

Détail : [plein-face.md](plein-face.md).

## 2. Écran séparé

Le format par défaut de ce mode :

- un **fond papier clair** sur tout l'écran (texture faite en code) ;
- **en haut** (de y = 240 à 900 environ) une carte ou une illustration : titre,
  images, bulles, liste qui se construit ;
- **en bas** un **cadre arrondi à bordure blanche** (environ 900 × 620, à
  y = 1080) qui contient la caméra, avec le fond remplacé à l'intérieur ;
- **sa tête dépasse** légèrement le haut du cadre, comme si elle était devant
  (grâce au détourage). Le haut des cheveux sort de 60 à 120 px.

Cadre le visage entier dans le cadre, front près du bord haut. Pas de
sous-titres sur sa bouche : les textes de l'illustration et sa voix suffisent.

Bon pour : une démonstration, une liste, un exemple qu'on suit pendant qu'elle
commente.

## 3. Illustration complète

L'écran entier est illustré sur sa voix, comme une vidéo sans visage. Tout le
moteur du catalogue sert ici : fonds, transitions, listes, fenêtres,
notifications, compteurs, images. Méthode : [illustrer.md](illustrer.md).

Bon pour : une explication en plusieurs étapes, un chiffre, une conséquence.

## 4. Alternance (par défaut)

Les trois se succèdent au fil du propos :

- **caméra** pour l'accroche, une annonce, un avis, une émotion, une
  respiration ;
- **écran séparé** quand elle commente ce qu'on voit ;
- **illustration complète** dès que l'explication se développe.

Lis d'abord la construction du texte : ouverture, parties, exemples,
conclusion. Choisis une logique et applique-la partout : si une partie commence
sur la caméra, les parties comparables aussi. Pas de quota, pas d'alternance
automatique toutes les X secondes. Un passage dure le temps de son idée ;
deux scènes de suite du même mode restent possibles.

Raccords : coupe franche le plus souvent ; un fondu, un flou ou un zoom quand
le propos change vraiment (deux ou trois transitions différentes au plus).

## Le plan à montrer avant de fabriquer

Avant de demander des images, montre le plan en quelques lignes et attends
son accord :

```
0,0-7,3   caméra   « 10 000 abonnés… » — téléphone, bulles, groupe montent derrière la tête
7,3-9,4   illustration — « Débordé », notifications qui s'empilent
9,4-13,5  caméra   titre « Mon propre agent », zoom sec, robot derrière la tête
13,5-18,4 séparé   l'agent répond dans le groupe ; elle en bas dans son cadre
18,4-24,4 illustration — la boutique, l'agent, trois actions qui se cochent
```
