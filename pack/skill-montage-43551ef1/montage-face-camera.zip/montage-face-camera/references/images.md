# Les images

## Qui génère

1. **Un générateur est relié à Claude** (outil d'images, connecteur, Codex) :
   tu génères toi-même, une image par appel, après accord sur la liste.
   Annonce le coût s'il consomme des crédits.
2. **Sinon (cas courant)** : elle génère dans ChatGPT avec tes prompts et te
   renvoie les fichiers dans `images/recues/`.

## La liste

Après validation du plan, liste 4 à 8 objets : un par idée forte, plus le
décor si elle remplace son fond ([fond.md](fond.md)). Donne-les
en **un seul lot**, numérotés, avec le nom du fichier à garder. Elle passe du
temps à générer : pas de demandes au compte-gouttes.

## Message de départ (à coller une fois dans ChatGPT)

```
Tu vas me dessiner des objets pour mes vidéos. Une demande par image.
Style pour TOUTES les images : [phrase de style de mon-style/style.md].
Palette stricte : [couleurs]. Un objet seul, centré, entier, sur fond
blanc pur uni (ou transparent). Aucun texte, aucune lettre, aucun chiffre,
aucun logo de marque, pas de sol, pas de décor. Carré 1024 x 1024.
Réponds seulement par l'image.
```

Joins deux images déjà validées comme référence dès qu'elles existent.

## Phrases de style (à adapter à sa palette)

- **Flat** : `flat vector illustration, simple geometric shapes, flat solid
  colors, front view, not isometric, no outlines, no gradients, no texture,
  soft rounded corners`
- **Papier découpé** : `layered cut paper illustration, stacked paper
  layers with small soft shadows, slightly irregular edges, subtle paper
  grain, no outlines`

## Prompt d'une image

```
Image [n] — [nom].png : [l'objet], [son état qui raconte l'idée],
[un détail parlant]. Même style que les précédentes.
```

Exemple : `robot-agent.png` : un petit robot assistant souriant, la main
levée, une bulle de discussion verte dans l'autre main.

Choisis des objets concrets dans un état parlant (qui déborde, répond,
s'empile). Évite les idées abstraites : trouve l'objet qui les montre.

## Logos

Pour un outil cité, demande le logo officiel (site de la marque) ou cherche-le.
Garde sa forme exacte. Tu peux en faire une version dans son style en joignant
l'original au générateur. Ne remplace jamais un logo par un autre.

## Recevoir et préparer

1. Ouvre chaque image : objet entier, aucun texte, style conforme.
2. Une image ratée : un seul nouvel essai avec une consigne précise, sinon
   un autre objet.
3. Détoure et vérifie sur damier :

```bash
python3 scripts/detoure.py images/recues images/pretes
python3 scripts/planche.py images/pretes
```

Une image déjà transparente est gardée et son halo nettoyé.
`scripts/decoupe.py` sépare plusieurs objets générés sur une même image.

## Droits

Ses propres médias, des images générées, des logos utilisés pour nommer
l'outil dont elle parle. Pas de personnage ou d'illustration d'un autre
créateur.
