# Vérifier et livrer

## Pendant la fabrication

Une fois par scène, quelques images clés avec `--zones --verifier` :

- **zones TikTok** libres : haut (y < 180), bas (y > 1450), droite
  (x > 900 entre y = 860 et 1450) ;
- visage jamais couvert, tête jamais coupée en haut ;
- titres et sous-titres lisibles à la taille d'un téléphone ;
- un titre, un sous-titre et une image ne disent pas la même chose ;
- rien ne se chevauche sans intention ;
- chaque élément a fini d'entrer au moins 0,7 s avant la fin de sa scène
  (`--verifier` le signale) ;
- le fond remplacé : bords des cheveux propres, rien ne sort de sa tête ;
- un écran ne reste pas figé plus de 2 s pendant une explication.

Pas de rendus de vérification en boucle : corrige ce que tu vois, revérifie
seulement ce qui a changé.

## Le son

Voix traitée d'abord, bruitages 14 dB dessous : [son.md](son.md).

## Sur le vrai export

```bash
ffmpeg -hide_banner -i sortie/video.mp4      # durée, 1080x1920, 30 fps, son
ffmpeg -ss 5 -i sortie/video.mp4 -frames:v 1 controle/export-5s.jpg
```

Extrais 8 à 10 images réparties sur toute la vidéo, dont une par passage, et
regarde-les. Vérifie la durée, la taille du fichier, la fin (dernière phrase
entière). Mesure le volume :
`ffmpeg -i sortie/video.mp4 -af ebur128=peak=true -f null -`.

Dis exactement ce que tu as contrôlé. Tu n'entends pas la vidéo : demande-lui
de la regarder sur son téléphone, son allumé, avant de publier.

## Remettre

- Le fichier est sur son ordinateur : donne le chemin complet de
  `sortie/video.mp4` et propose d'ouvrir le dossier.
- Pour le téléphone : AirDrop, Google Drive, WhatsApp à soi-même, ou câble.
- Propose une légende courte et 3 à 5 hashtags, dans son ton.

## Après la vidéo

Note ses retours dans `mon-style/style.md` (ce qu'elle a aimé, ce qu'elle a
corrigé). La vidéo suivante part de là. Supprime `.cache-media/` pour
libérer de la place.
