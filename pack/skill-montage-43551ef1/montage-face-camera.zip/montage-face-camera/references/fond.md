# Remplacer le fond derrière la personne

Une salle de bain, un mur chargé ou une pièce en désordre se voient tout de
suite. Propose toujours de remplacer le fond : la personne est détourée, et un
nouveau décor est posé derrière elle. Garde le décor filmé seulement s'il est
beau et qu'elle le veut.

## La question (dans l'entretien de style)

« On garde le décor de ta vidéo, ou je le remplace ? Trois choix :
1. un fond simple fait par moi (papier clair, couleur unie, dégradé doux) ;
2. un décor que tu génères dans ChatGPT avec le prompt que je te donne ;
3. une photo de ton choix (ton bureau rangé, ta boutique). »

Note la réponse dans `mon-style/style.md` : le même fond revient à chaque vidéo.

## Le prompt du décor (choix 2)

Adapte la pièce et la palette à son style, puis donne-le en un bloc :

```
Image verticale 1024 x 1536, pleine page, sans transparence.
[phrase de style de mon-style/style.md]
Le mur du fond d'une pièce claire et calme, vue de face, derrière une
personne qui parle à la caméra : [bureau lumineux / salon / boutique].
Couleurs : [palette]. À gauche, [une fenêtre, une plante] ; à droite,
[une étagère, une lampe]. Tout le centre de l'image, du quart haut jusqu'en
bas, reste un mur uni sans aucun objet : la personne sera placée là.
Contraste doux, ambiance lumineuse. Aucun texte, aucune personne.
```

Elle te renvoie l'image dans `images/recues/fond.png`.

## Préparer et vérifier

```bash
python3 scripts/fond.py images/recues/fond.png images/pretes/fond.png \
  --apercu edit/dialogue.mp4 edit/masque.mp4 --t 3
python3 scripts/fond.py --papier "#F1EADF" images/pretes/papier.png   # fond fait en code
```

`--flou 3` adoucit un décor trop présent, `--eclaircir 0.1` l'éclaircit.
Ouvre `controle/apercu-fond.jpg` et vérifie :

- la tête et les épaules tombent sur la zone unie, rien ne sort de sa tête ;
- les bords des cheveux sont propres (sinon refais le détourage avec
  `--reduction 0.4`) ;
- la lumière du décor va avec celle du visage (décor clair pour une vidéo
  filmée de jour) ;
- le décor laisse la place aux titres au-dessus de la tête.

## Au montage

Le décor devient le fond des scènes caméra, et la personne détourée passe
devant. Les éléments qui montent de derrière elle se placent entre les deux.
Dans l'écran séparé, le même décor remplit le cadre. Clés : [moteur.md](moteur.md).

Le décor reste fixe pendant les zooms sur la personne : c'est normal. Pour un
recadrage sec très serré, un léger flou du décor (`--flou 4`) aide.
