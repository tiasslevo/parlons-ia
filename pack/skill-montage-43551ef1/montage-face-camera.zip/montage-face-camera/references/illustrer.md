# Illustrer ce qu'elle dit

Pour l'écran séparé et l'illustration complète, et pour les éléments posés
autour d'elle.

## Découper le propos

Regroupe les phrases en étapes de sens. Pour chacune, note :

- ce que l'écran doit faire comprendre ;
- ce qui apparaît, sur quel mot, et ce qui change ensuite ;
- le titre utile, s'il y en a un ;
- les sous-titres gardés ou retirés ;
- le raccord avec la suite.

Une idée nouvelle appelle une réponse visuelle. Une même étape peut évoluer
sur plusieurs phrases : on ajoute, on coche, on déplace, plutôt que de changer
de plan sans arrêt.

## Images ou code

- **Images générées** : les objets concrets du sujet (téléphone, boutique,
  robot, livres, personnages). Une image par idée forte, 4 à 8 par vidéo.
  Prompts : [images.md](images.md).
- **Code** : tout ce qui contient du texte ou change d'état (titres, listes
  qui se cochent, bulles de discussion, notifications, fenêtres d'app,
  compteurs, flèches, graphiques). Le moteur les dessine nets, en français
  juste. Catalogue : [../catalogue/bibliotheque.md](../catalogue/bibliotheque.md).
- **Vrais médias** : captures, enregistrements d'écran, photos. Ils prouvent ;
  on ne les redessine pas.

## Un seul langage visuel

Les éléments codés suivent la matière choisie : mêmes couleurs, mêmes ombres,
mêmes coins arrondis que les images. Si une forme codée détonne à côté des
images, génère plutôt l'image. Ce qui doit être lu reste de face.

## Composer

- L'idée en cours est grande et nette. Ce qui a fini de servir sort, ou passe
  en retrait (plus petit, sur le côté) si c'est le contexte de la suite.
- Une construction riche reste lisible par révélations successives.
- Pas de petites étiquettes qui répètent les mots prononcés, pas de badges de
  commentaire autour de la personne.
- Centre le contenu vers x = 480 plutôt que 540 (boutons TikTok à droite).

## Le mouvement

- Un objet arrive au début du mot qui le nomme ; son entrée se développe
  pendant que le mot est dit.
- Un trajet vers une nouvelle place part franchement et freine à l'arrivée.
- Un résultat reste visible en grand 0,4 à 0,7 s avant l'idée suivante.
- Les objets posés restent vivants (léger flottement), sans s'agiter.

## Transitions

Coupe franche le plus souvent. Deux ou trois transitions différentes par
vidéo, au plus : zoom, flou, volet, fondu. Liste dans le catalogue, section 5.

## Texte

Elle parle, le spectateur écoute. Quand elle parle en général, illustre en
images ; un texte éventuel reste court et proche de ses mots. Quand elle donne
un exemple concret, montre le texte utile de cet exemple, succinct (une bulle
de discussion, une ligne de liste).
