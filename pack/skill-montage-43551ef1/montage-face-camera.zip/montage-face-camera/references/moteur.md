# Le moteur de montage

`scripts/rendu.py` lit `episode.json` et fabrique la vidéo. C'est le moteur
du catalogue ([../catalogue/bibliotheque.md](../catalogue/bibliotheque.md) :
fonds, transitions, animations, textes, listes, bulles, notifications,
compteurs, images), avec trois éléments en plus pour la personne filmée.

## Les éléments de la caméra

**`camera`** : la vidéo montée. L'image affichée à l'instant t est celle de
`dialogue.mp4` à t : vidéo, voix et `timeline.json` restent calées.

```json
{"type": "camera", "src": "edit/dialogue.mp4", "zoom_lent": [1.0, 1.05],
 "centre": [520, 900], "zooms": [{"a": "L6#12", "zoom": 1.25, "jusqua": "L7"}]}
```

- `cadre: [x, y, l, h]` : rectangle occupé (défaut : plein écran). Écran
  séparé : `[0, 960, 1080, 960]` avec `centre` sur le visage.
- `centre` : point de la vidéo gardé au centre ; `zoom`, `zoom_lent`, `zooms`
  (recadrages secs, chacun avec son `centre` possible).
- `masque` + `"decoupe": true` : seule la personne détourée est dessinée.

**`dos`** : une image qui monte de derrière le buste, floue puis nette, et se
pose à `x`, `y`. Clés : `src`, `l` ou `h`, `a`, `duree` (0,6), `flou` (14),
`depart_y`, `mouvements` (pour se décaler quand une autre arrive).

**`ecran`** : l'écran séparé. La caméra dans un cadre arrondi à bordure
blanche, la tête qui dépasse du haut.

```json
{"type": "ecran", "src": "edit/dialogue.mp4", "masque": "edit/masque.mp4",
 "fond_cadre": "images/pretes/fond.png", "cadre": [90, 1080, 900, 620],
 "depasse": 150, "centre": [520, 935], "arrondi": 44, "bordure": 12}
```

`cadre` = intérieur du cadre ; `depasse` = hauteur au-dessus où la tête peut
sortir ; `centre` = point de la vidéo au centre de cadre + dépassement.
Règle `centre` pour que le haut des cheveux sorte de 60 à 120 px.

**`titre`** : `haut`, `bas` (facultatif), `taille`, `y`, `police_haut`,
`police_bas`, `couleur_haut`, `couleur_bas`, `ombre` (false sur fond clair).
Taille conseillée : 150 à 170 (le titre se réduit seul s'il est trop large).

## Les fonds

- Décor remplacé : `"fond": {"type": "image", "src": "images/pretes/fond.png", "assombrir": 0}`,
  et la `camera` seule avec `"decoupe": true` (plus de caméra pleine dessous).
- Papier clair : `"fond": {"type": "papier", "couleur": "fond"}`, ou l'image
  faite par `fond.py --papier` (plus rapide au rendu).

## L'ordre fait la profondeur

Les éléments se dessinent dans l'ordre de la liste. Pour passer derrière la
personne :

```json
"elements": [
  {"type": "dos", "src": "images/pretes/robot.png", "l": 300, "x": 840, "y": 560, "a": "L6#14"},
  {"type": "camera", "src": "edit/dialogue.mp4", "masque": "edit/masque.mp4", "decoupe": true},
  {"type": "titre", "haut": "Mon propre agent", "bas": "personnel", "y": 330, "couleur_haut": "#FFFFFF", "a": "L6#12"}
]
```

(fond de la scène = le décor remplacé). Avec le décor filmé, mets d'abord une
`camera` pleine, puis la découpée : les deux portent exactement les mêmes
`centre`, `zoom`, `zoom_lent` et `zooms`, sinon la découpe se décale.

## Une scène par passage

Chaque passage du plan devient une scène (`"de": "L5-0.06"`, `"entree"`,
`"fond"`, `"elements"`). Les sous-titres vont
dans `permanent`, un `karaoke` par plage voulue, borné par `a` et `jusqua`.

Point de départ complet : [../modeles/episode-alternance.json](../modeles/episode-alternance.json).

Temps : `"L3"`, `"L3.fin"`, `"L3#4"` (4e mot), `"L3#4+0.2"`.

## Contrôler puis rendre

```bash
python3 scripts/rendu.py episode.json --images 1.5,L4#2,9.8 --zones --verifier
```

Regarde `controle/planche-essai.jpg` et corrige chaque ligne signalée
(zones TikTok, texte qui déborde, élément encore en train d'entrer en fin de
scène). Puis :

```bash
python3 scripts/rendu.py episode.json --sortie sortie/muette.mp4 --muet \
  --cues analysis/cues.json --qualite haute
python3 scripts/mix_son.py --voix edit/voix-traitee.wav --cues analysis/cues.json \
  --video sortie/muette.mp4 --sortie sortie/video.mp4
```

Environ 3 s de calcul par seconde de vidéo ; `--de 10 --a 16` rend un morceau.

## Pièges

- Deux éléments au même instant se mangent : décale de 0,2 s.
- L'ordre compte aussi pour les titres : placé avant une image, il passe dessous.
