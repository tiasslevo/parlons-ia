# Installer les outils

À faire une fois, au premier lancement. Tu lances les commandes toi-même dans
Claude Code et tu expliques en une ligne ce que tu installes. La personne n'a
qu'à accepter les autorisations.

## Vérifier

```bash
python3 --version          # 3.10 ou plus (sous Windows : python)
ffmpeg -version | head -1
python3 -c "import PIL, numpy, onnxruntime, faster_whisper; print('ok')"
```

## Installer ce qui manque

**ffmpeg** (lecture et écriture des vidéos) :

- Windows : `winget install Gyan.FFmpeg`, puis fermer et rouvrir le terminal.
- Mac : `brew install ffmpeg` (si `brew` manque, l'installer depuis brew.sh).
- Linux : `sudo apt install ffmpeg`.
- Si rien ne marche : `pip install imageio-ffmpeg` ; le moteur le trouve seul,
  et pour les autres scripts passe `--ffmpeg` avec le chemin donné par
  `python3 -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"`.

**Python et ses paquets** :

```bash
pip install pillow numpy onnxruntime faster-whisper
```

Si Python manque : python.org (Windows : cocher « Add to PATH ») ou
`brew install python`.

**Le modèle de détourage** (Robust Video Matting, environ 15 Mo), rangé dans
un dossier `outils/` à côté des vidéos :

```bash
mkdir -p outils
curl -L -o outils/rvm_mobilenetv3_fp32.onnx \
  https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx
```

**Whisper** télécharge son modèle au premier usage (`small` : environ 500 Mo).

## Temps de calcul (ordinateur ordinaire, sans carte graphique)

| Étape | Pour 30 s de vidéo |
|---|---|
| Transcription `small` | 1 à 2 min |
| Détourage de la personne | 2 à 6 min |
| Rendu final | 1 à 2 min |

Lance ces étapes en arrière-plan et annonce leur durée.

## Si ça bloque

- `pip` refusé : `python3 -m pip install --user ...`, ou un environnement
  virtuel (`python3 -m venv .venv`, puis activer).
- Mémoire insuffisante au détourage : `--reduction 0.25`.
- Mac M1 à M4 : tout fonctionne, en restant sur le processeur.
- Note dans `mon-style/style.md` ce qui a marché (chemins, commandes) : la
  prochaine vidéo partira de là.
