# Le son : la voix d'abord

La voix est ce qu'on écoute. Traite-la toujours avant de poser le moindre
bruitage, juste après l'assemblage de l'EDL.

## 1. Traiter la voix

```bash
python3 scripts/voix.py edit/voix.wav edit/voix-traitee.wav
```

Chaîne légère, la voix reste la sienne : passe-haut 80 Hz, réduction de bruit
douce, un peu moins de grave sourd, un peu plus de clarté, compression douce,
niveau **-14 LUFS intégrés**, crêtes **≤ -1 dBTP**. La durée ne change pas.

- Souffle ou bruit de pièce fort : `--bruit 12`. Voix qui sonne « en boîte » :
  `--bruit 4`.
- Utilise ensuite `edit/voix-traitee.wav` partout (`"voix"` dans
  `episode.json`, `mix_son.py --voix`).

## 2. Les bruitages sous la voix

```bash
python3 scripts/mix_son.py --voix edit/voix-traitee.wav --cues analysis/cues.json \
  --video sortie/muette.mp4 --sortie sortie/video.mp4
```

- Les bruitages se règlent sur la voix mesurée : **14 dB plus bas** par défaut
  (`--ecart`, entre 12 et 18), et encore **6 dB de moins quand elle parle**
  (`--attenuation`).
- Musique : `--musique fichier.mp3`, 20 dB sous la voix, baissée sous la parole.
  Seulement une musique qu'elle a le droit d'utiliser.
- Peu de bruitages sur la caméra : un son à l'arrivée d'un élément suffit.
  Retire des lignes de `cues.json` si ça fait trop.

Sons fournis : `assets/sons/`, fabriqués en code par `sons.py`, libres de
droits. Elle peut ajouter les siens avec `--sons`.

## 3. Vérifier en chiffres

`mix_son.py` affiche la voix, les bruitages, leur écart et le mix final.
`rendu.py episode.json --verifier` mesure aussi la voix et le bus
`edit/bruitages.wav`, et signale :

- une voix hors de -15,5 à -12,5 LUFS ;
- une crête au-dessus de -1 dBTP ;
- des bruitages à moins de 12 dB sous la voix.

Mesure enfin le vrai export :
`ffmpeg -i sortie/video.mp4 -af ebur128=peak=true -f null -`.
Tu n'entends pas le son : demande-lui d'écouter sur son téléphone.
