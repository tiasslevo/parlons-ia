# Le style de la personne

À la première vidéo, tu fixes avec elle un style qu'elle gardera. Pars de sa
vision. Si elle n'en a pas, propose deux ou trois choix sur image, pas une
liste.

## L'entretien (une question à la fois)

1. **Sa vision** : un compte qu'elle aime, une marque, une ambiance. Son sujet
   et son public.
2. **La matière des illustrations** (deux choix) :
   - **flat** : formes simples en aplats, sans contour ni dégradé, lisible et
     moderne ;
   - **papier découpé** : couches de papier, petites ombres douces, bords
     légèrement irréguliers, chaleureux.
   Images d'exemple : `styles/flat.jpg`, `styles/papier-decoupe.jpg`. Un autre
   style seulement si elle le demande elle-même.
3. **Les couleurs** : celles de sa marque, sinon tu proposes une palette courte :
   un fond clair, une encre, **une** couleur d'accent, éventuellement une
   couleur de mise en valeur (doré, jaune). Elle reste la même toute la vidéo.
4. **Les titres** : une police forte pour la ligne principale, une police fine
   pour la ligne dessous, une couleur pour cette ligne fine.
5. **Le fond** derrière elle : garder le décor filmé ou le remplacer
   ([fond.md](fond.md)).
6. **Le rythme** : naturel, dynamique ou très serré.

## Polices fournies (licence libre OFL)

| Rôle | Polices |
|---|---|
| Ligne principale | Anton, Bebas Neue, Archivo Black, Bricolage Grotesque |
| Ligne fine | Instrument Serif (et italique), DM Serif Display, Caveat (manuscrite) |
| Sous-titres et textes | Manrope, Geist, Fredoka (ronde) |

Associations qui marchent :

- **Anton + Instrument Serif italique** : net et élégant (par défaut) ;
- **Bebas Neue + Caveat** : énergique, plus personnel ;
- **Archivo Black + DM Serif Display** : massif, éditorial ;
- **Bricolage + Fredoka** : doux, accessible.

Elle peut ajouter ses polices (`.ttf`) dans `mon-style/polices/`.

## Montrer avant de valider

Fais une image d'essai : une scène caméra avec un titre et une scène
illustrée, dans deux variantes (couleurs ou polices). Rendu :
`python3 scripts/rendu.py essai.json --images 1.0,3.0`. Elle choisit sur
l'image.

## Ce que tu notes dans `mon-style/style.md`

Modèle : [../modeles/style.md](../modeles/style.md). La matière, la phrase de
style à recopier dans chaque prompt d'image, le bloc `"da"` (couleurs, polices),
les polices et couleurs des titres, le fond, la façon de monter préférée, le rythme, la
position de sa tête dans son cadre habituel, les retours qu'elle a donnés.

Ne recopie pas le style d'un créateur connu : garde l'idée, change au moins
l'accent, la police ou la matière.
