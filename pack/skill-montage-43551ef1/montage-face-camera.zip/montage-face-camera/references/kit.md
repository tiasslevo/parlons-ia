# Le kit de style

Le skill est le même pour tout le monde. Le **kit de style** est à elle : il
garde ce qui rend ses vidéos reconnaissables, pour que la vidéo 12 ressemble
à la vidéo 1.

## Ce qu'il contient

```
mon-style/
  style.md        matière, phrase de style des images, palette, bloc "da",
                  polices et couleurs des titres, façon de monter, rythme,
                  position habituelle de sa tête, retours
  references/     2 à 4 images validées, à joindre au générateur d'images
  pieces/         images qui reviennent (son logo, sa mascotte, ses outils)
  polices/        ses polices ajoutées, avec leur licence
  apercu.jpg      une scène caméra et une scène illustrée dans son style
```

Modèle de fiche : [../modeles/style.md](../modeles/style.md).

## Quand le fabriquer

À la fin de la première vidéo, quand elle l'a validée. Mets à jour
`style.md` à chaque vidéo (retours) et refais l'aperçu quand le style
change. Un seul kit valable à la fois.

Pour une sauvegarde ou un autre ordinateur :

```bash
python3 -m zipfile -c kit-style.zip mon-style/
```

## Où le ranger

Explique-lui le cas qui la concerne, avec ces mots ou presque.

**Claude Code (le cas normal)**
« Ton kit est le dossier `mon-style/`. Garde-le à côté de tes vidéos et lance
Claude Code dans ce dossier parent : je le retrouve à chaque nouvelle vidéo. »

**Projet Claude**
« Dans ton Projet, ajoute `style.md` et `apercu.jpg` aux fichiers du Projet.
Les conversations du Projet connaissent alors ton style, même pour préparer
un plan ou des prompts depuis ton téléphone. Le montage, lui, se fait dans
Claude Code. »

## Au début d'une vidéo

Lis `style.md`, recopie le bloc `"da"` tel quel dans `episode.json`, reprends
les polices, couleurs et la phrase de style mot pour mot. Ne réinvente rien.
Si elle veut changer, fais-le avec elle, puis mets le kit à jour.
