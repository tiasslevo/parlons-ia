# La personne à l'écran

Pour les passages caméra et l'écran séparé. Les clés du moteur sont dans
[moteur.md](moteur.md).

## Détourer et repérer la tête

Le détourage permet de passer des éléments derrière elle :

```bash
python3 scripts/detourer.py edit/dialogue.mp4 edit/masque.mp4 \
  --modele outils/rvm_mobilenetv3_fp32.onnx --coupes 279,406,551
```

`--coupes` : les débuts des morceaux de l'EDL (en frames, dans
`edl-resolue.json`). Teste d'abord `--max-frames 60` et regarde une image du
masque : cheveux, mains, micro.

Le même masque sert à remplacer le fond derrière elle : [fond.md](fond.md).

## Cadrage : partir de sa façon de filmer

Assise, debout, plan large ou serré : mesure d'abord le cadre de départ.

```bash
python3 scripts/cadrage.py edit/masque.mp4 --json analysis/cadrage.json
```

Le script donne le plan (très serré à large) et trois réglages `zoom` +
`centre`, pour la caméra et pour l'écran séparé : **garder** tel quel,
**un peu** plus serré, **serré** (tête et épaules grandes). Montre-lui une
image de contrôle de chaque réglage et laisse-la choisir ; « garder tel
quel » est un bon choix quand c'est déjà bien. Note son choix dans
`mon-style/style.md`. Le zoom lent et le recadrage sec s'ajoutent ensuite.

Place titres et éléments d'après ces mesures (haut de la tête, côtés,
bouche), gestes compris, pas au hasard.

## Les éléments qui montent de derrière elle

C'est la signature de ce montage. Quand elle cite un outil, une plateforme,
un chiffre ou un objet :

- l'élément part de derrière son buste au **début du mot** qui le nomme ;
- il monte franchement, freine en arrivant, passe du flou au net ;
- il se pose au-dessus ou à côté de sa tête, grand, en partie caché par les
  cheveux, jamais sur le visage ;
- s'il en vient un deuxième, le premier se décale et rapetisse pour lui faire
  place ; on finit sur une composition équilibrée autour de la tête ;
- posés, ils flottent légèrement jusqu'à leur sortie.

Un logo garde sa forme reconnaissable. Utilise le logo officiel fourni par la
personne, ou une version dessinée dans son style d'après l'original.

## Titres

- Un titre a une raison d'être : le concept, le chiffre, le constat à retenir.
  Lus à la suite, les titres résument la vidéo.
- Court, avec les mots précis de la personne.
- Ligne principale en haut (police forte), ligne fine dessous, légèrement
  chevauchée. Une ligne suffit souvent.
- Ligne principale contrastée avec le fond : à l'encre sur un décor clair ou
  le papier, claire avec une ombre sur un décor sombre. Taille 150 à 170.
  La couleur de la ligne fine reste la même toute la vidéo.
- Placé entre y = 240 et le haut de la tête, sans toucher les éléments.

Polices et couleurs : celles du kit ([style.md](style.md)).

## Zooms

- **Zoom lent** discret (1 à 1,06) pendant un passage caméra, qui repart à
  chaque coupe.
- **Recadrage sec** plus serré (1,2 à 1,3) sur un mot fort, un jugement, une
  réplique ; retour au large à la phrase ou à la scène suivante. Environ une
  fois par passage.
- Le zoom s'applique à la vidéo et à son masque avec les mêmes réglages. Les
  titres et sous-titres ne bougent pas.

## Sous-titres

Groupes de 2 à 4 mots vers le buste, bouche dégagée, mot prononcé mis en
couleur. Les mots réellement dits. Retire-les quand le titre ou l'élément dit
déjà la même chose, reprends-les dès que la voix apporte autre chose.

## Contrôle

Une image par élément posé et une pendant une course : visage dégagé, bords
propres, titre lisible, zones TikTok libres.
