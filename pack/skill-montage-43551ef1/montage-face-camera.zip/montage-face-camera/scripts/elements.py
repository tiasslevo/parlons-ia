"""Les éléments posables dans une scène d'episode.json (la bibliothèque du moteur rendu.py).

Chaque type d'élément est une classe enregistrée dans TYPES sous sa clé JSON ("perso", "liste"…).
La liste complète, avec leurs clés et quand les employer : catalogue/bibliotheque.md (et references/moteur.md pour camera, dos, titre).
"""
import hashlib
import json
import math
import re

from PIL import Image, ImageDraw

from dessin import (carte, carte_autour, compter_mots, dessiner_texte, icone, jetons,
                    melange, avec_alpha)

TYPES = {}


def element(nom, *alias):
    def deco(cls):
        for n in (nom,) + alias:
            TYPES[n] = cls
        cls.nom = nom
        return cls
    return deco


# ---------------------------------------------------------------- courbes
def ressort(dt, amorti=9.0, freq=16.0):
    if dt <= 0:
        return 0.0
    if dt > 1.2:
        return 1.0
    return 1 - math.exp(-dt * amorti) * math.cos(dt * freq)


def adoucir(x):
    x = min(1.0, max(0.0, x))
    return 1 - (1 - x) ** 3


def rebondir(p):
    """Courbe de chute avec rebonds (0 → 1)."""
    p = min(1.0, max(0.0, p))
    n, d = 7.5625, 2.75
    if p < 1 / d:
        return n * p * p
    if p < 2 / d:
        p -= 1.5 / d
        return n * p * p + 0.75
    if p < 2.5 / d:
        p -= 2.25 / d
        return n * p * p + 0.9375
    p -= 2.625 / d
    return n * p * p + 0.984375


def q(v, pas=0.04):
    return round(v / pas) * pas


# ---------------------------------------------------------------- collage d'un sprite sur l'image
def coller(fond, sp, x, y, sx, sy, r, o, ancre, cache, cle_sp, clip=1.0):
    if sx <= 0.01 or sy <= 0.01 or o <= 0.01 or clip <= 0.005:
        return
    sxq, syq, rq, oq, cq = round(sx, 2), round(sy, 2), round(r * 4) / 4, round(o, 2), round(clip, 2)
    cle = ("t", cle_sp, sxq, syq, rq, oq, cq)
    im = cache.get(cle)
    if im is None:
        if len(cache) > 500:
            for k in [k for k in cache if k[0] == "t"][:250]:
                del cache[k]
        im = sp
        if cq < 1:
            im = im.crop((0, 0, max(1, int(im.width * cq)), im.height))
            pad = Image.new("RGBA", sp.size, (0, 0, 0, 0))
            pad.paste(im, (0, 0))
            im = pad
        if sxq != 1.0 or syq != 1.0:
            im = im.resize((max(1, int(im.width * sxq)), max(1, int(im.height * syq))), Image.BICUBIC)
        if rq:
            im = im.rotate(-rq, Image.BICUBIC, expand=True)
        if oq < 0.99:
            a = im.getchannel("A").point(lambda v: int(v * oq))
            im = im.copy()
            im.putalpha(a)
        cache[cle] = im
    if ancre == "bas":
        px, py = int(x - im.width / 2), int(y - im.height)
    elif ancre == "haut":
        px, py = int(x - im.width / 2), int(y)
    elif ancre == "gauche":
        px, py = int(x), int(y - im.height / 2)
    else:
        px, py = int(x - im.width / 2), int(y - im.height / 2)
    if px >= fond.width or py >= fond.height or px + im.width <= 0 or py + im.height <= 0:
        return (px, py, px + im.width, py + im.height, im)  # hors de l'image : rien à dessiner
    fond.alpha_composite(im, (max(0, px), max(0, py)), (max(0, -px), max(0, -py)))
    return (px, py, px + im.width, py + im.height, im)


# ---------------------------------------------------------------- élément de base
class Element:
    anim_defaut = "pop"
    boucle_defaut = ""
    ancre_defaut = "centre"
    x_defaut, y_defaut = 480, 760
    police_defaut = "titre"
    trace = False  # True : dessiné directement sur l'image (flèche, cercle…)

    def __init__(self, e, sc_t0, ep, fond_scene=None):
        self.e, self.ep, self.T, self.da, self.c = e, ep, ep.T, ep.da, ep.c
        self.type = e.get("type", "image")
        self.t0 = self.T(e.get("a"), sc_t0)
        self.t1 = self.T(e.get("jusqua"), None)
        self.fond_scene = fond_scene or ep.da["fond"]
        self.cache = {}
        self.uid = hashlib.md5(json.dumps(e, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:8]
        self.phase = int(self.uid, 16) % 628 / 100
        self.anim = e.get("anim", e.get("entree", self.anim_defaut))
        self.sortie = e.get("sortie", "reduit")
        b = e.get("boucle", None)
        if b is None and "balance" in e:  # ancien format
            b = self.boucle_defaut if e["balance"] else ""
        if b is None:
            b = self.boucle_defaut
        self.boucles = [x for x in (b if isinstance(b, list) else str(b).split("+")) if x and x != "aucune"]
        self.dernier_cadre = None
        self.preparer()

    # -- à surcharger
    def preparer(self):
        pass

    def etat(self, t):
        return 0

    def construire(self, t):
        return None

    def fin_entree(self):
        """Moment où l'élément est complet (pour la vérification des zones)."""
        return self.t0 + 0.6

    # -- outils communs
    def alerte(self, msg):
        """Note un défaut de mise en page (texte qui déborde de sa carte…), affiché par --verifier."""
        al = getattr(self.ep, "alertes", None)
        if al is not None:
            al.setdefault(id(self), (self, set()))[1].add(msg)

    def verif_texte(self, img, quoi="le texte"):
        if getattr(img, "trop_large", False):
            self.alerte(f"{quoi} a un mot trop long pour sa largeur : réduire la taille ou couper le mot")

    def tps(self, cle, defaut=None):
        return self.T(self.e.get(cle), defaut)

    def coul_texte(self, cle="couleur"):
        if self.e.get(cle):
            return self.c(self.e[cle])
        return self.c.sur(self.fond_scene)

    def accent_lisible(self):
        """L'accent, sauf s'il se confond avec le fond de la scène : alors encre ou clair."""
        from dessin import luminance as lum
        acc, fond = self.c("accent"), self.c(self.fond_scene)
        if abs(lum(acc) - lum(fond)) < 0.12 and sum(abs(a - b) for a, b in zip(acc[:3], fond[:3])) < 150:
            return self.c.sur(self.fond_scene)
        return None

    def police(self, taille, defaut=None):
        return self.ep.polices.get(taille, self.e.get("police", defaut or self.police_defaut), self.e.get("graisse"))

    def casse(self, defaut=None):
        c = self.e.get("casse")
        if c:
            return c
        if (self.e.get("police", defaut or self.police_defaut)) == "titre":
            return self.da.get("casse", "normale")
        return "normale"

    def sprite(self, t):
        k = (self.etat(t), str(self.fond_scene))
        if k not in self.cache:
            if len(self.cache) > 260:
                for kk in [kk for kk in self.cache if not (isinstance(kk, tuple) and kk and kk[0] == "t")][:130]:
                    del self.cache[kk]
            self.cache[k] = self.construire(t)
        return self.cache[k], k

    def visible(self, t):
        return t >= self.t0 - 0.01 and (self.t1 is None or t < self.t1 + (0.0 if self.sortie == "coupe" else 0.3))

    def position(self, t):
        e = self.e
        x, y = float(e.get("x", self.x_defaut)), float(e.get("y", self.y_defaut))
        s = float(e.get("echelle", 1.0))
        for m in e.get("mouvements", []):
            a = self.T(m.get("a"), self.t0)
            b = self.T(m.get("fin"), a + 0.4)
            if t < a:
                break
            k = adoucir((t - a) / max(0.01, b - a))
            x += (float(m.get("x", x)) - x) * k
            y += (float(m.get("y", y)) - y) * k
            s += (float(m.get("echelle", s)) - s) * k
        return x, y, s

    def transformation(self, t):
        """Entrée, sortie et boucle → (sx, sy, dx, dy, rot, opacité, clip)."""
        e, dt = self.e, t - self.t0
        sx = sy = 1.0
        dx = dy = r = 0.0
        o, clip = 1.0, 1.0
        a = self.anim
        d = float(e.get("distance", 900 if self.type == "perso" else 260))
        if a == "pop":
            sx = sy = ressort(dt)
        elif a == "zoom":
            sx = sy = adoucir(dt / 0.3)
        elif a == "monte":
            dy = (1 - ressort(dt, 10, 9)) * d
            if self.type != "perso":
                o = adoucir(dt / 0.15)
        elif a == "descend":
            dy = -(1 - ressort(dt, 10, 9)) * d
            o = adoucir(dt / 0.15)
        elif a in ("glisse", "glisse-droite"):
            dx = (1 - ressort(dt, 10, 9)) * 1100
        elif a == "glisse-gauche":
            dx = -(1 - ressort(dt, 10, 9)) * 1100
        elif a == "fondu":
            o = adoucir(dt / 0.3)
        elif a == "rebond":
            dy = -(1 - rebondir(dt / 0.6)) * 700
        elif a == "tourne":
            sx = sy = ressort(dt)
            r = -(1 - adoucir(dt / 0.45)) * 140
        elif a == "elastique":
            sx, sy = ressort(dt, 6, 22), ressort(dt, 8, 14)
        elif a == "deplie":
            sy = adoucir(dt / 0.28)
        elif a == "revele":
            clip = adoucir(dt / 0.45)
        if self.t1 is not None and t > self.t1:
            u = t - self.t1
            so = self.sortie
            if so == "coupe":
                return None
            if so == "fondu":
                o *= 1 - adoucir(u / 0.22)
            elif so == "glisse-gauche":
                dx -= adoucir(u / 0.25) * 1200
            elif so == "glisse-droite":
                dx += adoucir(u / 0.25) * 1200
            elif so == "monte":
                dy -= adoucir(u / 0.25) * 1300
                o *= 1 - adoucir(u / 0.25)
            elif so == "descend":
                dy += adoucir(u / 0.25) * 1300
            else:
                k = 1 - adoucir(u / 0.18)
                sx, sy = sx * k, sy * k
            if o <= 0.02 or sx <= 0.02:
                return None
        for b in self.boucles:
            ph = self.phase
            if b == "balance":
                r += math.sin(t * 1.3 + ph) * float(e.get("balance_deg", 1.2))
            elif b == "flotte":
                dy += math.sin(t * 2.2 + ph) * 7
            elif b == "respire":
                k = 1 + 0.012 * math.sin(t * 2.4 + ph)
                sx, sy = sx * (2 - k) ** 0.3, sy * k
            elif b == "pulse":
                k = 1 + 0.035 * max(0.0, math.sin(t * 6 + ph))
                sx, sy = sx * k, sy * k
            elif b == "tremble":
                dx += math.sin(t * 47 + ph) * 2.5
                dy += math.cos(t * 39 + ph) * 2
        r += float(e.get("rot", 0))
        return sx, sy, dx, dy, r, o * float(e.get("opacite", 1.0)), clip

    def dessiner(self, img, t):
        if not self.visible(t):
            return
        if self.trace:
            self.tracer(img, t)
            return
        tr = self.transformation(t)
        if tr is None:
            return
        sp, k = self.sprite(t)
        if sp is None or sp.width == 0:
            return
        sx, sy, dx, dy, r, o, clip = tr
        x, y, s = self.position(t)
        ancre = self.e.get("ancre", self.ancre_defaut)
        cadre = coller(img, sp, x + dx, y + dy, sx * s, sy * s, r, o, ancre, self.cache, (k, id(sp)), clip)
        if cadre and getattr(self.ep, "mesurer", False):
            # boîte du dessin réel (sans les marges transparentes), en coordonnées de l'écran, même hors champ
            bb = cadre[4].getchannel("A").point(lambda v: 255 if v > 60 else 0).getbbox()
            self.mesure = (cadre[0] + bb[0], cadre[1] + bb[1], cadre[0] + bb[2], cadre[1] + bb[3]) if bb else None
        if cadre and t >= self.fin_entree():
            self.dernier_cadre = cadre[:4]


# ---------------------------------------------------------------- personnages et images
@element("perso")
class Perso(Element):
    anim_defaut = "monte"
    boucle_defaut = "balance"
    ancre_defaut = "bas"
    x_defaut, y_defaut = 480, 1500

    def preparer(self):
        cad = self.e.get("cadrage", "pied")
        if cad == "coin":
            self.x_defaut, self.y_defaut = 190, 1440
        self.cadrage = cad

    def src(self, t):
        src = self.e["src"]
        for ch in self.e.get("changements", []):
            if t >= self.T(ch["a"]):
                src = ch["src"]
        return src

    # -- bouche qui bouge (option du moteur faceless)
    def bouche(self, t):
        """(image, x, y, l, rot) de la bouche à poser à l'instant t, ou None (on garde la bouche du dessin)."""
        b = self.e.get("bouche")
        if not b:
            return None
        pos = b.get("positions", {}).get(self.src(t), b.get("position"))
        if not pos:
            return None  # pose sans réglage : bouche du dessin
        if b.get("lignes"):  # ne parler que sur ses répliques (plusieurs personnages)
            if not any(self.T(f"L{n}") <= t <= self.T(f"L{n}.fin") for n in b["lignes"]):
                return None
        env = self.ep.enveloppe(b.get("voix"))
        i = int(t * self.ep.fps)
        v = float(env[i]) if 0 <= i < len(env) else 0.0
        images = b["images"]
        seuils = b.get("seuils") or [0.2 + 0.4 * k / max(1, len(images) - 1) for k in range(len(images))]
        niveau = sum(1 for s in seuils if v >= s)
        if niveau == 0:
            return None
        return (images[min(niveau, len(images)) - 1], float(pos[0]), float(pos[1]), float(pos[2]),
                float(pos[3]) if len(pos) > 3 else 0.0)

    def etat(self, t):
        return (self.src(t), self.bouche(t))

    def construire(self, t):
        e = self.e
        h = e.get("h")
        l = e.get("l")
        if h is None and l is None:
            h = {"coin": 320, "pied": 1000, "buste": 640, "tete": 420}.get(self.cadrage, 1000)
        if l is None:
            l = 4000
        coupe = e.get("coupe", {"buste": 0.62, "tete": 0.36}.get(self.cadrage))
        im = self.ep.image(self.src(t), l, h, e.get("contour_blanc", 0), e.get("miroir", False), coupe, self.bouche(t))
        acc = e.get("accessoires", [e["accessoire"]] if e.get("accessoire") else [])
        if not acc:
            return im
        pieces = []
        for a in acc:
            ai = self.ep.image(a["src"], a.get("l", 220), None, a.get("contour_blanc", 0), a.get("miroir", False))
            if a.get("rot"):
                ai = ai.rotate(-a["rot"], Image.BICUBIC, expand=True)
            # dx, dy : centre de l'accessoire par rapport au bas-centre du personnage
            pieces.append((ai, im.width / 2 + a.get("dx", 0) - ai.width / 2, im.height + a.get("dy", -im.height / 2) - ai.height / 2,
                           a.get("devant", True)))
        x0 = min([0] + [p[1] for p in pieces])
        y0 = min([0] + [p[2] for p in pieces])
        x1 = max([im.width] + [p[1] + p[0].width for p in pieces])
        # le bas reste celui du personnage (ancrage au sol)
        W, H = int(max(x1 - x0, 2 * max(im.width / 2 - x0, x1 - im.width / 2))), int(im.height - y0)
        cx = W / 2 - im.width / 2
        out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        for ai, px, py, devant in pieces:
            if not devant:
                out.alpha_composite(ai, (int(px + cx), int(py - y0)))
        out.alpha_composite(im, (int(cx), int(-y0)))
        for ai, px, py, devant in pieces:
            if devant:
                out.alpha_composite(ai, (int(px + cx), int(py - y0)))
        return out


@element("image", "objet")
class Img(Element):
    boucle_defaut = "balance+flotte"

    def etat(self, t):
        src = self.e["src"]
        for ch in self.e.get("changements", []):
            if t >= self.T(ch["a"]):
                src = ch["src"]
        return src

    def construire(self, t):
        e = self.e
        return self.ep.image(self.etat(t), e.get("l", 600), e.get("h"), e.get("contour_blanc", 0), e.get("miroir", False))


@element("media", "photo", "video")
class Media(Element):
    """Photo ou vidéo réelle dans un cadre (b-roll). Le son de la vidéo n'est pas repris."""

    def preparer(self):
        e = self.e
        self.w, self.h = int(e.get("l", 760)), int(e.get("h", e.get("l", 760) * 0.62))
        self.est_video = e["src"].lower().endswith((".mp4", ".mov", ".webm", ".m4v", ".mkv"))

    def etat(self, t):
        e = self.e
        if self.est_video:
            tl = max(0.0, t - self.t0) * float(e.get("vitesse", 1.0)) + float(e.get("debut", 0))
            return ("v", int(tl * self.ep.fps))
        z = e.get("zoom_lent")
        if z:
            z0, z1 = (z if isinstance(z, list) else (1.0, 1.08))
            k = min(1.0, max(0.0, (t - self.t0) / float(e.get("duree_zoom", 5))))
            return ("z", round(z0 + (z1 - z0) * k, 3))
        return ("f",)

    def construire(self, t):
        e, ep = self.e, self.ep
        k = self.etat(t)
        if k[0] == "v":
            im = ep.video_image(e["src"], self.w, self.h, k[1] / ep.fps, e.get("boucle_video", True))
        else:
            z = k[1] if k[0] == "z" else 1.0
            im = ep.photo(e["src"], self.w, self.h, z)
        cadre = e.get("cadre", "carte")
        if cadre in ("rond", "arrondi"):
            m = Image.new("L", im.size, 0)
            g = ImageDraw.Draw(m)
            if cadre == "rond":
                g.ellipse([0, 0, im.width - 1, im.height - 1], fill=255)
            else:
                g.rounded_rectangle([0, 0, im.width - 1, im.height - 1], radius=int(self.da.get("rayon", 28)), fill=255)
            out = Image.new("RGBA", im.size, (0, 0, 0, 0))
            out.paste(im, (0, 0), m)
            if cadre == "rond" and self.da.get("contour"):
                ImageDraw.Draw(out).ellipse([0, 0, im.width - 1, im.height - 1], outline=self.c("encre"), width=int(self.da["contour"]))
            return out
        if cadre == "polaroid":
            b = int(self.w * 0.045)
            fond, m = carte(self.w + 2 * b, self.h + 4 * b, ep, fond="#FFFFFF", rayon=6)
            fond.paste(im.convert("RGB"), (m + b, m + b))
            return fond
        if cadre == "aucun":
            return im
        fond, m = carte(self.w, self.h, ep, fond="papier")
        msk = Image.new("L", im.size, 0)
        r = max(0, int(self.da.get("rayon", 28)) - int(self.da.get("contour", 6)) // 2)
        ImageDraw.Draw(msk).rounded_rectangle([0, 0, im.width - 1, im.height - 1], radius=r, fill=255)
        fond.paste(im.convert("RGB"), (m, m), msk)
        if self.da.get("contour"):
            ImageDraw.Draw(fond).rounded_rectangle([m, m, m + self.w, m + self.h], radius=int(self.da.get("rayon", 28)),
                                                   outline=self.c("encre"), width=int(self.da["contour"]))
        return fond


@element("medaillon")
class Medaillon(Element):
    boucle_defaut = "balance"
    x_defaut, y_defaut = 200, 1220

    def etat(self, t):
        src = self.e["src"]
        for ch in self.e.get("changements", []):
            if t >= self.T(ch["a"]):
                src = ch["src"]
        return src

    def construire(self, t):
        e, da, ep = self.e, self.da, self.ep
        dmt = int(e.get("d", 300))
        forme = e.get("forme", "rond")
        bord = int(e.get("contour", da.get("contour", 6)))
        rayon = int(e.get("rayon", max(18, da.get("rayon", 28))))
        fond_c = self.c(e.get("fond", "surligneur"))
        inner = Image.new("RGBA", (dmt, dmt), fond_c)
        perso = ep.image(self.etat(t), int(dmt * e.get("zoom", 1.3)))
        inner.alpha_composite(perso, ((dmt - perso.width) // 2, int(dmt * e.get("haut", 0.04))))
        masque = Image.new("L", (dmt, dmt), 0)
        g = ImageDraw.Draw(masque)
        if forme == "carre":
            g.rounded_rectangle([0, 0, dmt - 1, dmt - 1], radius=rayon, fill=255)
        else:
            g.ellipse([0, 0, dmt - 1, dmt - 1], fill=255)
        o = da.get("ombre", "dure")
        dec = int(da.get("decalage", 9)) if o == "dure" else 0
        img = Image.new("RGBA", (dmt + dec + 4, dmt + dec + 4), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        if dec:
            if forme == "carre":
                d.rounded_rectangle([dec, dec, dmt + dec - 1, dmt + dec - 1], radius=rayon, fill=self.c("encre"))
            else:
                d.ellipse([dec, dec, dmt + dec - 1, dmt + dec - 1], fill=self.c("encre"))
        img.paste(inner, (0, 0), masque)
        cb = self.c(e.get("couleur_contour", "encre"))
        if bord:
            if forme == "carre":
                d.rounded_rectangle([0, 0, dmt - 1, dmt - 1], radius=rayon, outline=cb, width=bord)
            else:
                d.ellipse([0, 0, dmt - 1, dmt - 1], outline=cb, width=bord)
        return img


# ---------------------------------------------------------------- texte
@element("texte", "titre")
class Texte(Element):
    """Texte libre. mode : bloc (d'un coup), mots (mot par mot), machine (lettre par lettre)."""

    def preparer(self):
        e = self.e
        self.taille = e.get("taille", 110 if self.type == "titre" else 96)
        if "police" not in e:
            self.police_defaut = "titre" if self.taille >= 90 or self.type == "titre" else "texte"
        self.mode = e.get("mode", "bloc")
        n = compter_mots(e["texte"])
        self.n_mots = n
        self.n_car = len(re.sub(r"\*|==|__|\[\[|\]\]|\(\(|\)\)", "", e["texte"]))
        if self.mode == "mots":
            self.fin = self.tps("fin", self.t0 + 0.26 * n)
        elif self.mode == "machine":
            self.fin = self.tps("fin", self.t0 + self.n_car / float(e.get("vitesse", 22)))
        else:
            self.fin = self.t0
        self.marque_a = self.tps("marque_a", self.fin + 0.08)

    def fin_entree(self):
        return max(self.fin, self.marque_a) + 0.45

    def etat(self, t):
        nm = nc = None
        cur = False
        if self.mode == "mots" and t < self.fin:
            nm = max(1, min(self.n_mots, int((t - self.t0) / max(0.05, self.fin - self.t0) * self.n_mots) + 1))
        elif self.mode == "machine" and t < self.fin + 0.6:
            nc = int(max(0.0, t - self.t0) / max(0.05, self.fin - self.t0) * self.n_car)
            cur = (int(t * 3) % 2 == 0) or t < self.fin
        prog = q(adoucir((t - self.marque_a) / 0.35), 0.05)
        return (nm, nc, prog, cur)

    def construire(self, t):
        e = self.e
        nm, nc, prog, cur = self.etat(t)
        img = dessiner_texte(e["texte"], self.police(self.taille), e.get("largeur", self.ep.W - 200), self.coul_texte(), self.ep,
                             e.get("aligne", "centre"), e.get("interligne", 1.05), nb_mots=nm, nb_car=nc,
                             contour=e.get("contour", 0), marque=e.get("marque"), prog=prog, casse=self.casse(), curseur=cur,
                             accent=self.accent_lisible())
        self.verif_texte(img)
        if e.get("fond"):
            if "bb" not in self.cache:  # cadre calculé sur le texte complet : la carte ne saute pas
                plein = dessiner_texte(e["texte"], self.police(self.taille), e.get("largeur", self.ep.W - 200), self.coul_texte(),
                                       self.ep, e.get("aligne", "centre"), e.get("interligne", 1.05), casse=self.casse())
                self.cache["bb"] = plein.getbbox() or (0, 0, plein.width, plein.height)
            bb = self.cache["bb"]
            img = img.crop((max(0, bb[0] - 6), 0, bb[2] + 6, img.height))
            img = carte_autour(img, e["fond"], self.ep, marge=e.get("marge", 26), rogner=False)
        return img


@element("gros", "mot-geant")
class Gros(Texte):
    """Mot ou courte phrase en géant, ajusté à la largeur (« L'ASTUCE », « 59 % »)."""
    y_defaut = 820

    def preparer(self):
        super().preparer()
        e = self.e
        larg = e.get("largeur", 900)
        t = int(e.get("taille", 300))
        txt = e["texte"].upper() if self.casse() == "majuscules" else e["texte"]
        mots = [m for m, _ in jetons(txt)]
        while t > 60:
            pol = self.police(t)
            if max(pol.getlength(m) for m in mots) <= larg * 0.98:
                img = dessiner_texte(txt, pol, larg, (0, 0, 0, 255), self.ep, interligne=0.95)
                if img.height <= e.get("hauteur_max", 820):
                    break
            t -= 8
        self.taille = t
        e.setdefault("interligne", 0.95)
        e.setdefault("largeur", larg)


@element("rubrique")
class Rubrique(Texte):
    """Titre fixe en haut de l'écran (titre de la vidéo ou du chapitre)."""
    anim_defaut = "aucune"
    ancre_defaut = "haut"
    y_defaut = 205

    def preparer(self):
        self.e.setdefault("police", "titre")
        self.e.setdefault("taille", 76)
        self.e.setdefault("largeur", 840)
        super().preparer()


@element("karaoke", "soustitre-mots")
class Karaoke(Element):
    """Sous-titre calé sur la voix, par groupes de 2 à 4 mots, le mot dit marqué."""
    anim_defaut = "aucune"
    police_defaut = "texte"
    y_defaut = 470

    def preparer(self):
        e, T = self.e, self.T
        sel = e.get("lignes", "toutes")
        nums = sorted(T.lignes)
        if sel == "toutes":
            choix = nums
        elif isinstance(sel, str) and "-" in sel:
            a, b = [int(x.strip("L")) for x in sel.split("-")]
            choix = [n for n in nums if a <= n <= b]
        else:
            choix = [int(str(x).strip("L")) for x in (sel if isinstance(sel, list) else [sel])]
        textes = e.get("textes", {})
        g = int(e.get("groupe", 3))
        self.groupes = []  # (t0, t1, texte, [(t0 mot)])
        for n in choix:
            mots = T.mots(n, textes.get(f"L{n}"))
            if not mots:
                continue
            cur = []
            for i, (m, a, b) in enumerate(mots):
                cur.append((m, a, b))
                coupe = len(cur) >= g or re.search(r"[.?!,:;]$", m)
                if coupe or i == len(mots) - 1:
                    self.groupes.append([cur[0][1], cur[-1][2], cur])
                    cur = []
            fin_ligne = T.lignes[n]["t1"]
            if self.groupes:
                self.groupes[-1][1] = fin_ligne + 0.15
        for i in range(len(self.groupes) - 1):
            self.groupes[i][1] = max(self.groupes[i][1], min(self.groupes[i + 1][0], self.groupes[i][1] + 0.35))
        if self.groupes:
            self.t0 = min(self.t0, self.groupes[0][0]) if "a" not in e else self.t0

    def actuel(self, t):
        for gi, (a, b, mots) in enumerate(self.groupes):
            if a - 0.03 <= t < b:
                k = 0
                for j, (m, ma, mb) in enumerate(mots):
                    if t >= ma - 0.03:
                        k = j
                return gi, k
        return None, None

    def visible(self, t):
        return super().visible(t) and self.actuel(t)[0] is not None

    def etat(self, t):
        return self.actuel(t)

    def transformation(self, t):
        tr = super().transformation(t)
        gi, _ = self.actuel(t)
        if tr is None or gi is None:
            return tr
        dt = t - self.groupes[gi][0]
        k = 0.9 + 0.1 * ressort(dt + 0.02, 12, 18) if self.e.get("rebond", True) else 1.0
        return (tr[0] * k, tr[1] * k) + tr[2:]

    def construire(self, t):
        e = self.e
        gi, k = self.actuel(t)
        mots = self.groupes[gi][2]
        txt = " ".join(m for m, _, _ in mots)
        style = e.get("style_mot", self.da.get("marque", "couleur"))
        if self.e.get("progressif"):
            nm = k + 1
        else:
            nm = None
        img = dessiner_texte(txt, self.police(e.get("taille", 66)), e.get("largeur", 860), self.coul_texte(), self.ep,
                             e.get("aligne", "centre"), 1.1, nb_mots=nm, forcer={k: style} if style != "aucun" else None,
                             casse=self.casse("texte"), contour=e.get("contour", 0), accent=self.accent_lisible())
        self.verif_texte(img, "le sous-titre")
        if e.get("fond"):
            img = carte_autour(img, e["fond"], self.ep, marge=e.get("marge", 18), ombre=e.get("ombre"))
        return img


@element("bulle")
class Bulle(Element):
    police_defaut = "texte"

    def preparer(self):
        self.mots = compter_mots(self.e["texte"])

    def etat(self, t):
        if self.e.get("mots"):
            fin = self.T(self.e["mots"])
            n = max(1, min(self.mots, int((t - self.t0) / max(0.2, fin - self.t0) * self.mots) + 1)) if t >= self.t0 else 0
            return None if n >= self.mots else n
        return None

    def construire(self, t):
        e, ep, da = self.e, self.ep, self.da
        nb = self.etat(t)
        pol = self.police(e.get("taille", 78))
        l = int(e.get("l", ep.W - 240))
        marge = 44
        coul = self.c(e.get("couleur", "encre")) if e.get("couleur") else self.c.sur(e.get("fond", "papier"))
        txt = dessiner_texte(e["texte"], pol, l - 2 * marge - 40, coul, ep, e.get("aligne", "gauche"), 1.12,
                             casse=self.casse("texte"))
        part = txt if nb is None else dessiner_texte(e["texte"], pol, l - 2 * marge - 40, coul, ep, e.get("aligne", "gauche"),
                                                     1.12, nb_mots=nb, casse=self.casse("texte"))
        self.verif_texte(txt, "le texte de la bulle")
        besoin = txt.height + 2 * marge + (30 if e.get("etiquette") else 0)
        h = max(int(e.get("h", 0)), besoin)
        bord, encre = int(da.get("contour", 6)), self.c("encre")
        o = da.get("ombre", "dure")
        om = int(da.get("decalage", 9)) if o == "dure" else 0
        queue = e.get("queue", "bas-gauche")
        hq = 110 if queue else 0
        img = Image.new("RGBA", (l + om + bord, h + hq + om + bord), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        fond = self.c(e.get("fond", "papier"))
        rr = int(e.get("rayon", max(12, da.get("rayon", 28) * 1.4)))
        if queue:
            qx = 130 if queue == "bas-gauche" else l - 230
            pts = [(qx, h - 20), (qx + 90, h - 20), (qx + (10 if queue == "bas-gauche" else 140), h + hq - 10)]
        if om:
            d.rounded_rectangle([om, om, l + om, h + om], radius=rr, fill=encre)
            if queue:
                d.polygon([(px + om, py + om) for px, py in pts], fill=encre)
        d.rounded_rectangle([0, 0, l, h], radius=rr, fill=fond, outline=encre if bord else None, width=bord)
        if queue:
            d.polygon(pts, fill=fond)
            if bord:
                d.line([pts[0], pts[2], pts[1]], fill=encre, width=bord, joint="curve")
            d.line([(pts[0][0] + bord, h - bord / 2 - 1), (pts[1][0] - bord, h - bord / 2 - 1)], fill=fond, width=bord + 2)
        if e.get("etiquette"):
            pe = self.ep.polices.get(32, "texte", 700)
            d.text((marge, 26), e["etiquette"].upper(), font=pe, fill=self.c("accent"))
        ty = (h - txt.height) // 2 + (16 if e.get("etiquette") else 0)
        img.alpha_composite(part, (marge, max(0, ty)))
        return img


@element("pastille", "etiquette")
class Pastille(Element):
    """Étiquette arrondie : « 1 COMMANDE », « Abonne-toi », « exemple »."""

    def construire(self, t):
        e = self.e
        petit = self.type == "etiquette"
        taille = int(e.get("taille", 30 if petit else 54))
        fond = e.get("fond", "papier" if petit else "accent")
        coul = self.c(e["couleur"]) if e.get("couleur") else self.c.sur(fond)
        casse = e.get("casse", "majuscules" if petit else self.casse())
        txt = dessiner_texte(e["texte"], self.police(taille), 2000, coul, self.ep, casse=casse)
        bb = txt.getbbox() or (0, 0, 10, 10)
        txt = txt.crop((bb[0], 0, bb[2], txt.height))
        ic = None
        if e.get("forme"):
            ic = icone(e["forme"], taille * 1.05, coul)
        px, py = int(taille * 0.55), int(taille * 0.28)
        w = txt.width + 2 * px + (ic.width + taille * 0.3 if ic else 0)
        h = txt.height + 2 * py - int(taille * 0.35)
        rayon = e.get("rayon", min(h // 2, int(self.da.get("rayon", 28) * 1.5)))
        bord = e.get("contour", max(2, int(self.da.get("contour", 6) * (0.6 if petit else 1))) if self.da.get("contour") else 0)
        img, m = carte(w, h, self.ep, fond=fond, rayon=rayon, contour=bord, ombre=e.get("ombre", "aucune" if petit else None))
        x = m + px
        if ic:
            img.alpha_composite(ic, (int(x), int(m + (h - ic.height) / 2)))
            x += ic.width + taille * 0.3
        img.alpha_composite(txt, (int(x), int(m + (h - txt.height) / 2)))
        return img


@element("tampon")
class Tampon(Element):
    anim_defaut = "tampon"

    def transformation(self, t):
        tr = super().transformation(t)
        if tr is None:
            return None
        dt = t - self.t0
        if self.anim == "tampon":
            p = ressort(dt, 12, 22)
            s = 2.2 - 1.2 * p
            tr = (tr[0] * s, tr[1] * s) + tr[2:5] + (min(1.0, dt / 0.08) * tr[5], tr[6])
        r = tr[4] + (-12 if "rot" not in self.e else 0)
        return tr[:4] + (r,) + tr[5:]

    def construire(self, t):
        e = self.e
        c = self.c(e.get("couleur", "perte"))
        taille = e.get("taille", 90)
        pol = self.police(taille)
        txt = e["texte"].replace("\\n", "\n")
        txt = txt.upper() if e.get("casse", "majuscules") == "majuscules" else txt
        lignes = txt.split("\n")
        tw = max(pol.getlength(x) for x in lignes)
        asc, desc = pol.getmetrics()
        hl = int((asc + desc) * 0.95)
        b = max(6, int(taille / 9))
        img = Image.new("RGBA", (int(tw) + 80 + b * 2, hl * (len(lignes) - 1) + asc + desc + 50 + b * 2), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        r = int(e.get("rayon", min(26, self.da.get("rayon", 28) * 0.7)))
        plein = e.get("style") == "plein"
        d.rounded_rectangle([b, b, img.width - b, img.height - b], radius=r,
                            fill=c if plein else (255, 255, 255, 235), outline=c, width=b)
        y0 = img.height / 2 - hl * (len(lignes) - 1) / 2 + desc * 0.15
        for i, ligne in enumerate(lignes):
            d.text((img.width / 2, y0 + i * hl), ligne, font=pol, fill=(255, 255, 255, 255) if plein else c, anchor="mm")
        return img


@element("compteur")
class Compteur(Element):
    def valeur(self, t):
        e = self.e
        a, b = self.t0, self.tps("fin", self.t0 + 1.0)
        v = e.get("de", 0) + (e.get("vers", 0) - e.get("de", 0)) * adoucir((t - a) / max(0.05, b - a))
        dec = int(e.get("decimales", 0))
        s = f"{v:,.{dec}f}".replace(",", " ").replace(".", ",") if dec else f"{round(v):,}".replace(",", " ")
        return f"{e.get('prefixe', '')}{s}{e.get('suffixe', '')}"

    def fin_entree(self):
        return self.tps("fin", self.t0 + 1.0) + 0.1

    def etat(self, t):
        return self.valeur(t)

    def construire(self, t):
        e = self.e
        img = dessiner_texte(self.valeur(t), self.police(e.get("taille", 220)), self.ep.W, self.coul_texte(), self.ep,
                             contour=e.get("contour", 0))
        if e.get("fond"):
            img = carte_autour(img, e["fond"], self.ep, marge=e.get("marge", 20))
        return img


# ---------------------------------------------------------------- composants qui se construisent
def ligne_items(e, T, t0):
    out = []
    pas = float(e.get("pas", 0.7))
    for i, it in enumerate(e.get("elements", e.get("items", []))):
        if isinstance(it, str):
            it = {"texte": it}
        it = dict(it)
        it["_a"] = T(it.get("a"), t0 + i * pas)
        for k in ("actif", "coche", "barre", "croix", "fin_actif"):
            it["_" + k] = T(it.get(k), None)
        out.append(it)
    return out


@element("liste")
class Liste(Element):
    """Liste qui se construit ligne par ligne ; une ligne peut s'allumer, se cocher, se barrer."""
    anim_defaut = "aucune"
    ancre_defaut = "haut"
    y_defaut = 420
    police_defaut = "texte"

    def preparer(self):
        e = self.e
        self.items = ligne_items(e, self.T, self.t0)
        if e.get("un_actif", True):
            actifs = sorted([it["_actif"] for it in self.items if it["_actif"] is not None])
            for it in self.items:
                if it["_actif"] is not None and it["_fin_actif"] is None:
                    suiv = [a for a in actifs if a > it["_actif"]]
                    it["_fin_actif"] = suiv[0] if suiv else None

    def fin_entree(self):
        return max(it["_a"] for it in self.items) + 0.4

    def etat_item(self, it, t):
        if t < it["_a"]:
            return None
        ent = q(min(1.0, (t - it["_a"]) / 0.3), 0.1)
        act = it["_actif"] is not None and t >= it["_actif"] and (it["_fin_actif"] is None or t < it["_fin_actif"])
        pa = q(adoucir((t - it["_actif"]) / 0.3), 0.1) if act else 0
        ch = it["_coche"] is not None and t >= it["_coche"]
        pb = q(adoucir((t - it["_barre"]) / 0.3), 0.1) if it["_barre"] is not None and t >= it["_barre"] else 0
        cr = it["_croix"] is not None and t >= it["_croix"]
        return (ent, act, pa, ch, pb, cr)

    def etat(self, t):
        return tuple(self.etat_item(it, t) for it in self.items)

    def construire(self, t):
        e, ep, C = self.e, self.ep, self.c
        style = e.get("style", "cartes")
        l = int(e.get("l", 820))
        taille = int(e.get("taille", 52))
        gap = int(e.get("espace", 22))
        pol = self.police(taille)
        pol_s = ep.polices.get(int(taille * 0.62), "texte")
        hrow = int(taille * (2.0 if style == "cartes" else 1.55)) + (int(taille * 0.75) if any(it.get("sous") for it in self.items) else 0)
        n = len(self.items)
        dec = int(self.da.get("decalage", 9)) + 40
        H = n * hrow + (n - 1) * gap + dec
        W = l + dec + 90
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        acc, encre = C("accent"), C("encre")
        act_style = e.get("actif_style", "rempli")
        coul_base = self.coul_texte()
        for i, (it, st) in enumerate(zip(self.items, self.etat(t))):
            if st is None:
                continue
            ent, act, pa, ch, pb, cr = st
            y = i * (hrow + gap)
            off = int((1 - adoucir(ent)) * -70)
            row = Image.new("RGBA", (W, hrow + dec), (0, 0, 0, 0))
            fond = "papier"
            coul = coul_base if style != "cartes" else C.sur("papier")
            if act and act_style == "rempli":
                fond = "accent"
                coul = C.sur("accent")
            mx = 0
            if style == "cartes":
                c_img, m = carte(l, hrow, ep, fond=fond, contour=None if not (act and act_style == "contour") else self.da.get("contour", 6) * 2,
                                 couleur_contour="accent" if act and act_style == "contour" else "encre")
                row.alpha_composite(c_img, (0, 0))
                mx = m
            elif act and act_style == "rempli":
                c_img, m = carte(l, hrow, ep, fond="accent", ombre="aucune", contour=0)
                row.alpha_composite(c_img, (0, 0))
                mx = m
            elif act and act_style == "surligneur":
                ImageDraw.Draw(row).rounded_rectangle([0, hrow * 0.12, l * max(0.05, pa), hrow * 0.88], radius=int(self.da.get("rayon", 20) * 0.5),
                                                      fill=C("surligneur"))
                coul = C.sur("surligneur") if pa > 0.5 else coul
            d = ImageDraw.Draw(row)
            if act and act_style == "couleur":
                coul = acc
            x = mx + int(taille * 0.45)
            cy = mx + hrow / 2
            dm = int(taille * 1.15)
            marq = e.get("marqueur", {"cartes": "numeros", "puces": "puces", "numeros": "numeros", "cases": "cases"}.get(style, "aucun"))
            if marq == "numeros":
                fc = encre if (act and act_style == "rempli") else acc
                d.rounded_rectangle([x, cy - dm / 2, x + dm, cy + dm / 2], radius=int(min(dm / 2, self.da.get("rayon", 20) * 0.6)), fill=fc)
                d.text((x + dm / 2, cy), str(it.get("numero", i + 1)), font=ep.polices.get(int(taille * 0.8), "titre"),
                       fill=C.sur(fc), anchor="mm")
                x += dm + int(taille * 0.4)
            elif marq == "puces":
                r = taille * 0.2
                d.ellipse([x, cy - r, x + 2 * r, cy + r], fill=acc if not act else coul)
                x += int(2 * r + taille * 0.5)
            elif marq == "cases":
                d.rounded_rectangle([x, cy - dm / 2, x + dm, cy + dm / 2], radius=int(dm * 0.2), fill=acc if ch else C("papier"),
                                    outline=encre, width=max(3, int(self.da.get("contour", 6) * 0.7) or 3))
                if ch:
                    row.alpha_composite(icone("coche", dm, C.sur("accent")), (int(x), int(cy - dm / 2)))
                x += dm + int(taille * 0.45)
            elif it.get("forme"):
                row.alpha_composite(icone(it["forme"], dm, acc), (int(x), int(cy - dm / 2)))
                x += dm + int(taille * 0.4)
            if it.get("image"):
                ic = ep.image(it["image"], dm, dm)
                row.alpha_composite(ic, (int(x), int(cy - ic.height / 2)))
                x += ic.width + int(taille * 0.35)
            larg = mx + l - x - int(taille * (1.6 if (ch and marq != "cases") or cr else 0.5))
            ti = dessiner_texte(it["texte"], pol, larg, coul, ep, "gauche", 1.0, casse=e.get("casse"))
            self.verif_texte(ti, f"la ligne « {it['texte'][:30]} »")
            bb = ti.getbbox() or (0, 0, 1, 1)
            hs = 0
            ts = None
            if it.get("sous"):
                ts = dessiner_texte(it["sous"], pol_s, larg, melange(coul, C(fond), 0.35), ep, "gauche", 1.0)
                hs = (ts.getbbox() or (0, 0, 0, 0))[3]
            ht = bb[3] - bb[1]
            hs_vrai = ((ts.getbbox() or (0, 0, 0, 0))[3] - (ts.getbbox() or (0, 0, 0, 0))[1]) if ts is not None else 0
            if ht + hs_vrai + 2 > hrow - taille * 0.1:
                self.alerte(f"la ligne « {it['texte'][:30]} » déborde de sa case (texte sur {getattr(ti, 'nb_lignes', 2)} lignes) : "
                            "raccourcir, élargir \"l\" ou baisser \"taille\"")
            ytxt = cy - (ht + hs) / 2 - bb[1]
            row.alpha_composite(ti, (int(x - pol.size * 0.2 - 10), int(ytxt)))
            if ts is not None:
                row.alpha_composite(ts, (int(x - pol_s.size * 0.2 - 10), int(ytxt + bb[3] + 2)))
            if pb:
                wtx = bb[2] - bb[0]
                d.line([(x, cy), (x + wtx * pb, cy)], fill=C("perte"), width=max(6, int(taille * 0.12)))
            if (ch and marq != "cases") or cr:
                dd = int(taille * 1.1)
                row.alpha_composite(icone("croix" if cr else "coche", dd, (255, 255, 255, 255), fond=C("perte") if cr else C("gain")),
                                    (int(mx + l - dd - taille * 0.35), int(cy - dd / 2)))
            if ent < 1:
                a = row.getchannel("A").point(lambda v: int(v * min(1.0, ent * 1.6)))
                row.putalpha(a)
            img.alpha_composite(row, (max(0, off + 40), y))
        return img


@element("etapes")
class Etapes(Element):
    """Étapes 1-2-3 reliées, qui se cochent au fil de la voix."""
    y_defaut = 330

    def preparer(self):
        e = self.e
        self.labels = e.get("labels") or [str(i + 1) for i in range(int(e.get("n", 3)))]
        self.faits = [self.T(x) for x in e.get("faits", [])]

    def etat(self, t):
        return tuple(q(adoucir((t - f) / 0.25), 0.2) if t >= f else 0 for f in self.faits) + \
            (0,) * (len(self.labels) - len(self.faits))

    def construire(self, t):
        e, C, ep = self.e, self.c, self.ep
        n = len(self.labels)
        dm = int(e.get("d", 92))
        gap = int(e.get("espace", 90))
        W = n * dm + (n - 1) * gap + 30
        avec_lab = bool(e.get("legendes"))
        H = dm + 30 + (int(dm * 0.9) if avec_lab else 0)
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        st = self.etat(t)
        acc, encre, pap = C("accent"), C("encre"), C("papier")
        bord = max(4, int(self.da.get("contour", 6)))
        trait = C.sur(self.fond_scene)
        cy = 15 + dm / 2
        for i in range(n - 1):
            x0 = 15 + i * (dm + gap) + dm
            d.line([(x0, cy), (x0 + gap, cy)], fill=avec_alpha(trait, 0.35), width=max(4, bord))
            if st[i]:
                d.line([(x0, cy), (x0 + gap * st[i], cy)], fill=acc, width=max(4, bord))
        cur = next((i for i in range(n) if not st[i]), None)
        pol = ep.polices.get(int(dm * 0.5), "titre")
        for i in range(n):
            x = 15 + i * (dm + gap)
            fait = st[i] > 0
            if fait:
                d.ellipse([x, 15, x + dm, 15 + dm], fill=acc, outline=encre if self.da.get("contour") else None, width=bord)
                img.alpha_composite(icone("coche", int(dm * 0.8 * (0.6 + 0.4 * st[i])), C.sur("accent")),
                                    (int(x + dm * 0.1 + dm * 0.4 * (1 - (0.6 + 0.4 * st[i]))), int(15 + dm * 0.1 + dm * 0.4 * (1 - (0.6 + 0.4 * st[i])))))
            else:
                ec = acc if i == cur and e.get("courant", True) else encre
                d.ellipse([x, 15, x + dm, 15 + dm], fill=pap, outline=ec, width=bord + (3 if i == cur else 0))
                d.text((x + dm / 2, 15 + dm / 2), self.labels[i] if len(self.labels[i]) <= 2 else str(i + 1), font=pol,
                       fill=ec, anchor="mm")
            if avec_lab:
                pl = ep.polices.get(int(dm * 0.32), "texte")
                d.text((x + dm / 2, 15 + dm + dm * 0.45), e["legendes"][i], font=pl, fill=trait, anchor="mm")
        return img


@element("progression")
class Progression(Element):
    def valeur(self, t):
        e = self.e
        a = self.T(e.get("depart"), self.t0 + 0.15)
        b = self.tps("fin", a + 1.2)
        return e.get("de", 0) + (e.get("vers", 100) - e.get("de", 0)) * adoucir((t - a) / max(0.05, b - a))

    def etat(self, t):
        v = self.valeur(t)
        return float(self.e.get("vers", 100)) if abs(v - self.e.get("vers", 100)) < 0.3 else round(v, 1)

    def construire(self, t):
        e, ep = self.e, self.ep
        l, h = int(e.get("l", 760)), int(e.get("h", 58))
        v = self.valeur(t)
        top = 0
        lab = None
        if e.get("etiquette") or e.get("pourcent", True):
            pol = ep.polices.get(int(h * 0.75), "texte")
            lab = (pol, e.get("etiquette", ""), f"{round(v)} %" if e.get("pourcent", True) else "")
            top = int(h * 1.25)
        r = int(min(h / 2, self.da.get("rayon", 28)))
        base, m = carte(l, h, ep, fond="papier", rayon=r)
        img = Image.new("RGBA", (base.width, base.height + top), (0, 0, 0, 0))
        img.alpha_composite(base, (0, top))
        d = ImageDraw.Draw(img)
        bord = int(self.da.get("contour", 6))
        frac = max(0.0, min(1.0, v / float(e.get("max", 100))))
        if frac > 0.01:
            d.rounded_rectangle([m + bord, top + m + bord, m + bord + (l - 2 * bord) * frac, top + m + h - bord],
                                radius=max(0, r - bord), fill=self.c(e.get("couleur", "accent")))
        if lab:
            coul = self.coul_texte()
            d.text((m, top - 8), lab[1], font=lab[0], fill=coul, anchor="ls")
            d.text((m + l, top - 8), lab[2], font=lab[0], fill=coul, anchor="rs")
        return img


@element("fenetre")
class Fenetre(Element):
    """Fausse fenêtre : navigateur, terminal, code, app, mail. Les lignes se tapent au fil de la voix."""

    def preparer(self):
        e = self.e
        style = e.get("style", "navigateur")
        self.style = style
        self.lignes = []
        t = self.t0 + 0.25
        vit = float(e.get("vitesse", 30))
        for ln in e.get("lignes", []):
            if isinstance(ln, str):
                ln = {"texte": ln}
            a = self.T(ln.get("a"), t)
            n = len(ln["texte"])
            instant = ln["texte"].startswith("~") or e.get("tape", True) is False or ln.get("tape") is False
            b = a if instant else a + n / vit
            self.lignes.append((ln, a, b))
            t = b + 0.15
        self.fin = t

    def fin_entree(self):
        return self.fin + 0.2

    def etat(self, t):
        out = []
        for ln, a, b in self.lignes:
            if t < a:
                out.append(-1)
            elif t >= b:
                out.append(len(ln["texte"]))
            else:
                out.append(int((t - a) / max(0.01, b - a) * len(ln["texte"])))
        cur = int(t * 2.5) % 2 == 0
        return tuple(out) + (cur,)

    def construire(self, t):
        e, C, ep, da = self.e, self.c, self.ep, self.da
        st = self.etat(t)
        cur = st[-1]
        sombre = self.style in ("terminal", "code")
        l = int(e.get("l", 860))
        taille = int(e.get("taille", 38 if sombre else 42))
        pol = ep.polices.get(taille, "mono" if sombre else "texte", None if sombre else 600)
        hl = int(taille * 1.5)
        barre = int(taille * 1.9)
        h = int(e.get("h", barre + max(3, len(self.lignes)) * hl + taille * 1.6))
        fond = e.get("fond", "#16181D" if sombre else "papier")
        img, m = carte(l, h, ep, fond=fond)
        d = ImageDraw.Draw(img)
        bord = int(da.get("contour", 6))
        encre = C("encre")
        tc = C("#E8E8E8") if sombre else C.sur(fond)
        # barre du haut
        y0 = m + bord
        if self.style in ("navigateur", "terminal", "code", "app"):
            for i, cc in enumerate(("#FF5F57", "#FEBC2E", "#28C840") if da.get("ombre") != "dure" else ("perte", "surligneur", "gain")):
                r = taille * 0.27
                d.ellipse([m + 24 + i * r * 3.1, y0 + barre / 2 - r, m + 24 + i * r * 3.1 + 2 * r, y0 + barre / 2 + r], fill=C(cc))
            if self.style == "navigateur":
                ux = m + 24 + taille * 3
                d.rounded_rectangle([ux, y0 + barre * 0.2, m + l - 24, y0 + barre * 0.8], radius=int(barre * 0.3),
                                    fill=melange(C("papier"), encre, 0.08))
                d.text((ux + 18, y0 + barre / 2), e.get("url", "www.exemple.com"), font=ep.polices.get(int(taille * 0.7), "texte", 500),
                       fill=melange(encre, C("papier"), 0.35), anchor="lm")
            elif e.get("titre"):
                d.text((m + l / 2, y0 + barre / 2), e["titre"], font=ep.polices.get(int(taille * 0.75), "texte", 600),
                       fill=melange(tc, C(fond), 0.35), anchor="mm")
            d.line([(m, y0 + barre), (m + l, y0 + barre)], fill=encre if not sombre else melange(C(fond), "#FFFFFF", 0.15),
                   width=max(2, bord // 2))
        elif self.style == "mail":
            d.text((m + 30, y0 + barre / 2), e.get("titre", "Nouveau message"), font=ep.polices.get(int(taille * 0.85), "texte", 700),
                   fill=tc, anchor="lm")
            d.line([(m, y0 + barre), (m + l, y0 + barre)], fill=encre, width=max(2, bord // 2))
        y = y0 + barre + taille * 0.6
        for i, ((ln, a, b), n) in enumerate(zip(self.lignes, st[:-1])):
            if n < 0:
                break
            x = m + 30
            if self.style == "code":
                d.text((x, y), f"{i + 1:>2}", font=pol, fill=melange(tc, C(fond), 0.6))
                x += pol.getlength("00 ")
            txt = ln["texte"]
            if txt.startswith("~"):
                w = (l - 80) * (0.45 + 0.4 * ((i * 37) % 10) / 10)
                d.rounded_rectangle([x, y + hl * 0.2, x + w, y + hl * 0.6], radius=int(hl * 0.2), fill=melange(tc, C(fond), 0.75))
            else:
                coul = self.c(ln["couleur"]) if ln.get("couleur") else tc
                vis = txt[:n]
                if self.style == "terminal" and vis.startswith("$"):
                    d.text((x, y), "$", font=pol, fill=C("accent"))
                    d.text((x + pol.getlength("$ "), y), vis[1:].lstrip(), font=pol, fill=coul)
                else:
                    if ln.get("cle"):
                        d.rounded_rectangle([x - 8, y - 2, x + pol.getlength(vis) + 8, y + hl * 0.8], radius=8, fill=C("surligneur"))
                        coul = C.sur("surligneur")
                    d.text((x, y), vis, font=pol, fill=coul)
                if n < len(txt) or (i == len(self.lignes) - 1 or st[i + 1] < 0):
                    if cur and e.get("curseur", True):
                        xc = x + pol.getlength(vis if not (self.style == "terminal" and vis.startswith("$")) else "$ " + vis[1:].lstrip()) + 4
                        d.rectangle([xc, y + 4, xc + taille * 0.5, y + taille * 1.05], fill=C("accent") if sombre else encre)
                if pol.getlength(txt) > l - (x - m) - 30:
                    self.alerte(f"la ligne « {txt[:30]} » sort de la fenêtre : raccourcir, élargir \"l\" ou baisser \"taille\"")
            y += hl
            if y > m + h - hl * 0.6:
                if i + 1 < len(self.lignes) and st[i + 1] >= 0:
                    self.alerte("la fenêtre est trop basse pour toutes ses lignes : augmenter \"h\" ou enlever des lignes")
                break
        return img


@element("notification")
class Notification(Element):
    anim_defaut = "descend"
    y_defaut = 330
    police_defaut = "texte"

    def construire(self, t):
        e, C, ep = self.e, self.c, self.ep
        l = int(e.get("l", 860))
        taille = int(e.get("taille", 40))
        ic = int(taille * 2.3)
        tc = C.sur(e.get("fond", "papier"))
        larg = l - 28 - ic - 26 - 28
        tt = dessiner_texte(e.get("titre", ""), ep.polices.get(taille, "texte", 750), larg, tc, ep, "gauche", 1.0)
        tb = None
        if e.get("texte"):
            tb = dessiner_texte(e["texte"], ep.polices.get(int(taille * 0.85), "texte", 450), larg, tc, ep, "gauche", 1.0)
        self.verif_texte(tt, "le titre de la notification")
        if tb is not None:
            self.verif_texte(tb, "le texte de la notification")
        bas_tt = (tt.getbbox() or (0, 0, 0, 0))[3]
        bas = (taille * 1.2 + (tb.getbbox() or (0, 0, 0, 0))[3]) if tb is not None else bas_tt
        if tb is not None and bas_tt > taille * 1.25:  # titre sur deux lignes : le texte descend
            bas += bas_tt - taille * 1.2
        besoin = int(taille * 4.6 * 0.3 + bas + taille * 0.5)
        h = int(e.get("h", max(taille * 4.6, besoin)))
        if h < besoin - 6:
            self.alerte(f"le texte déborde de la notification (h {h} pour {besoin} nécessaires) : enlever \"h\" ou raccourcir")
        img, m = carte(l, h, ep, fond=e.get("fond", "papier"), rayon=e.get("rayon", max(22, int(self.da.get("rayon", 28) * 1.2))),
                       ombre=e.get("ombre", "douce" if self.da.get("ombre") != "dure" else "dure"))
        d = ImageDraw.Draw(img)
        x, y = m + 28, m + (h - ic) / 2
        if e.get("image"):
            im = ep.image(e["image"], ic, ic)
            img.alpha_composite(im, (int(x), int(y)))
        else:
            d.rounded_rectangle([x, y, x + ic, y + ic], radius=int(ic * 0.25), fill=self.c(e.get("couleur", "accent")))
            if e.get("forme"):
                img.alpha_composite(icone(e["forme"], int(ic * 0.7), C.sur(e.get("couleur", "accent"))), (int(x + ic * 0.15), int(y + ic * 0.15)))
            else:
                d.text((x + ic / 2, y + ic / 2), (e.get("app", "A") or "A")[0].upper(), font=ep.polices.get(int(ic * 0.55), "titre"),
                       fill=C.sur(e.get("couleur", "accent")), anchor="mm")
        tx = x + ic + 26
        gris = melange(tc, C(e.get("fond", "papier")), 0.45)
        pa = ep.polices.get(int(taille * 0.7), "texte", 600)
        y_haut = m + taille * 4.6 * 0.2
        d.text((tx, y_haut), (e.get("app", "") or "").upper(), font=pa, fill=gris, anchor="lm")
        d.text((m + l - 28, y_haut), e.get("heure", "maintenant"), font=pa, fill=gris, anchor="rm")
        y_tt = m + taille * 4.6 * 0.3
        img.alpha_composite(tt, (int(tx - taille * 0.2 - 10), int(y_tt)))
        if tb is not None:
            dec = max(0, bas_tt - taille * 1.2) if bas_tt > taille * 1.25 else 0
            img.alpha_composite(tb, (int(tx - taille * 0.17 - 10), int(y_tt + taille * 1.2 + dec)))
        return img


@element("barres", "graphique")
class Barres(Element):
    """Graphique à barres qui montent l'une après l'autre."""

    def preparer(self):
        self.vals = [float(v) for v in self.e["valeurs"]]
        self.depart = self.T(self.e.get("depart"), self.t0 + 0.2)
        self.fin = self.tps("fin", self.depart + 0.5 + 0.22 * len(self.vals))

    def fin_entree(self):
        return self.fin + 0.1

    def progres(self, t, i):
        n = len(self.vals)
        dec = float(self.e.get("decale", 0.22))
        a = self.depart + i * dec
        b = max(a + 0.2, self.fin - (n - 1 - i) * dec)
        return adoucir((t - a) / (b - a))

    def etat(self, t):
        return tuple(1.0 if p > 0.985 else q(p, 0.03) for p in (self.progres(t, i) for i in range(len(self.vals))))

    def construire(self, t):
        e, C, ep = self.e, self.c, self.ep
        l, h = int(e.get("l", 760)), int(e.get("h", 560))
        n = len(self.vals)
        mx = float(e.get("max", max(self.vals) or 1))
        st = self.etat(t)
        bord = int(self.da.get("contour", 6))
        acc = e.get("accent", [max(range(n), key=lambda i: self.vals[i])])
        acc = acc if isinstance(acc, list) else [acc]
        haut_lab = int(h * 0.12)
        bas_lab = int(h * 0.12) if e.get("etiquettes") else 10
        img = Image.new("RGBA", (l + 40, h + 40), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        tc = self.coul_texte()
        zone = h - haut_lab - bas_lab
        bw = l / (n * 1.45)
        gap = (l - n * bw) / (n + 1)
        base_y = 20 + haut_lab + zone
        d.line([(10, base_y), (l + 30, base_y)], fill=tc, width=max(3, bord))
        pv = ep.polices.get(int(min(bw * 0.42, haut_lab * 0.8)), "titre")
        pe = ep.polices.get(int(min(bw * 0.3, bas_lab * 0.65)) or 20, "texte")
        dec = int(self.da.get("decalage", 9)) if self.da.get("ombre") == "dure" else 0
        r = int(min(bw / 3, self.da.get("rayon", 28) * 0.5))
        for i, v in enumerate(self.vals):
            x = 20 + gap + i * (bw + gap)
            hh = zone * (v / mx) * st[i]
            fc = C(e.get("couleur_accent", "accent")) if i in acc else C(e.get("couleur", "papier"))
            if hh > 2:
                if dec:
                    d.rounded_rectangle([x + dec, base_y - hh + dec, x + bw + dec, base_y], radius=r, fill=C("encre"))
                d.rounded_rectangle([x, base_y - hh, x + bw, base_y], radius=r, fill=fc, outline=C("encre") if bord else None, width=bord)
            if e.get("afficher", True) and st[i] > 0.05:
                txt = f"{e.get('prefixe', '')}{round(v * st[i]) if v >= 10 else round(v * st[i], 1)}{e.get('unite', '')}".replace(".", ",")
                d.text((x + bw / 2, base_y - hh - 14), txt, font=pv, fill=tc, anchor="mb")
            if e.get("etiquettes"):
                d.text((x + bw / 2, base_y + 16), e["etiquettes"][i], font=pe, fill=tc, anchor="mt")
        return img


@element("grille")
class Grille(Element):
    """Grille de cases, ronds ou bonshommes qui se remplissent (« 1 sur 10 », parts, places)."""

    def preparer(self):
        self.depart = self.T(self.e.get("depart"), self.t0 + 0.3)
        self.fin = self.tps("fin", self.depart + 1.0)

    def fin_entree(self):
        return self.fin + 0.1

    def etat(self, t):
        k = adoucir((t - self.depart) / max(0.05, self.fin - self.depart))
        return int(round(int(self.e.get("remplis", 1)) * k))

    def construire(self, t):
        e, C = self.e, self.c
        n, cols = int(e.get("n", 50)), int(e.get("colonnes", 10))
        dm, gap = int(e.get("d", 64)), int(e.get("espace", 14))
        rows = math.ceil(n / cols)
        img = Image.new("RGBA", (cols * (dm + gap) + 10, rows * (dm + gap) + 10), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        k = self.etat(t)
        vide = self.c(e["vide"]) if e.get("vide") else melange(C.sur(self.fond_scene), self.c(self.fond_scene), 0.78)
        plein = self.c(e.get("couleur", "accent"))
        forme = e.get("forme", "carre")
        ordre = list(range(n))
        if e.get("depuis") == "fin":
            ordre = ordre[::-1]
        remplis = set(ordre[:k])
        for i in range(n):
            x, y = 5 + (i % cols) * (dm + gap), 5 + (i // cols) * (dm + gap)
            c = plein if i in remplis else vide
            if forme == "rond":
                d.ellipse([x, y, x + dm, y + dm], fill=c)
            elif forme == "bonhomme":
                d.ellipse([x + dm * 0.3, y, x + dm * 0.7, y + dm * 0.4], fill=c)
                d.rounded_rectangle([x + dm * 0.12, y + dm * 0.46, x + dm * 0.88, y + dm], radius=int(dm * 0.3), fill=c)
            else:
                d.rounded_rectangle([x, y, x + dm, y + dm], radius=int(min(dm * 0.3, self.da.get("rayon", 28) * 0.4)), fill=c)
        return img


@element("carte")
class Carte(Element):
    """Carte d'info : icône ou image à gauche, titre, sous-titre ; peut s'allumer ou se cocher."""
    police_defaut = "texte"

    def preparer(self):
        self.actif = self.tps("actif")
        self.coche = self.tps("coche")

    def etat(self, t):
        return (self.actif is not None and t >= self.actif, self.coche is not None and t >= self.coche)

    def construire(self, t):
        e, C, ep = self.e, self.c, self.ep
        act, ch = self.etat(t)
        l = int(e.get("l", 760))
        taille = int(e.get("taille", 50))
        dm = int(taille * 1.7)
        fond = "accent" if act else e.get("fond", "papier")
        tc = C.sur(fond)
        titre = dessiner_texte(e.get("titre", ""), ep.polices.get(taille, e.get("police", "texte"), 750), l - dm - 140, tc, ep, "gauche", 1.0,
                               casse=e.get("casse"))
        bt = titre.getbbox() or (0, 0, 1, 1)
        sous = None
        if e.get("texte"):
            sous = dessiner_texte(e["texte"], ep.polices.get(int(taille * 0.62), "texte", 450), l - dm - 140,
                                  melange(tc, C(fond), 0.3), ep, "gauche", 1.0)
        hs = (sous.getbbox() or (0, 0, 0, 0))[3] if sous else 0
        self.verif_texte(titre, "le titre de la carte")
        if sous is not None:
            self.verif_texte(sous, "le texte de la carte")
        besoin = int(max(dm + taille * 0.9, (bt[3] - bt[1]) + hs + taille * 1.1))
        h = int(e.get("h", besoin))
        if h < besoin - taille * 0.5:
            self.alerte(f"le texte déborde de la carte (h {h} pour {besoin} nécessaires) : enlever \"h\" ou raccourcir")
        img, m = carte(l, h, ep, fond=fond)
        d = ImageDraw.Draw(img)
        x = m + int(taille * 0.5)
        cy = m + h / 2
        if e.get("image"):
            im = ep.image(e["image"], dm, dm)
            img.alpha_composite(im, (int(x), int(cy - im.height / 2)))
            x += dm + int(taille * 0.4)
        elif e.get("forme"):
            img.alpha_composite(icone(e["forme"], dm, C.sur("accent"), fond=C("accent") if not act else C("encre")), (int(x), int(cy - dm / 2)))
            x += dm + int(taille * 0.4)
        elif e.get("numero") is not None:
            fc = C("encre") if act else C("accent")
            d.rounded_rectangle([x, cy - dm / 2, x + dm, cy + dm / 2], radius=int(min(dm / 2, self.da.get("rayon", 28) * 0.6)), fill=fc)
            d.text((x + dm / 2, cy), str(e["numero"]), font=ep.polices.get(int(dm * 0.6), "titre"), fill=C.sur(fc), anchor="mm")
            x += dm + int(taille * 0.4)
        y = cy - ((bt[3] - bt[1]) + hs) / 2 - bt[1]
        img.alpha_composite(titre, (int(x - taille * 0.2 - 10), int(y)))
        if sous:
            img.alpha_composite(sous, (int(x - taille * 0.12 - 10), int(y + bt[3] + 4)))
        if ch:
            dd = int(taille * 1.2)
            img.alpha_composite(icone("coche", dd, (255, 255, 255, 255), fond=C("gain")), (int(m + l - dd - 24), int(cy - dd / 2)))
        if e.get("etiquette"):
            pe = ep.polices.get(24, "texte", 700)
            tw = pe.getlength(e["etiquette"].upper())
            d.rounded_rectangle([m + l - tw - 50, m - 16, m + l - 14, m + 20], radius=10, fill=C("papier"), outline=C("encre"), width=3)
            d.text((m + l - 32 - tw / 2, m + 2), e["etiquette"].upper(), font=pe, fill=C("encre"), anchor="mm")
        return img


@element("bouton")
class Bouton(Element):
    def preparer(self):
        self.clic = self.tps("clic")

    def etat(self, t):
        return self.clic is not None and t >= self.clic + 0.12

    def transformation(self, t):
        tr = super().transformation(t)
        if tr and self.clic is not None and 0 <= t - self.clic < 0.24:
            k = 1 - 0.09 * math.sin(math.pi * (t - self.clic) / 0.24)
            tr = (tr[0] * k, tr[1] * k) + tr[2:]
        return tr

    def construire(self, t):
        e, C = self.e, self.c
        apres = self.etat(t)
        fond = e.get("fond_apres", "encre") if apres else e.get("fond", "accent")
        txt = e.get("texte_apres", e["texte"]) if apres else e["texte"]
        taille = int(e.get("taille", 58))
        pol = self.police(taille)
        txt = txt.upper() if self.casse() == "majuscules" else txt
        tw = pol.getlength(txt)
        w, h = int(tw + taille * 1.6 + (taille * 1.2 if e.get("forme") else 0)), int(taille * 1.9)
        img, m = carte(w, h, self.ep, fond=fond, rayon=e.get("rayon", min(h // 2, int(self.da.get("rayon", 28) * 1.3))),
                       ombre="aucune" if apres else None)
        d = ImageDraw.Draw(img)
        x = m + taille * 0.8
        if e.get("forme"):
            img.alpha_composite(icone(e["forme"], taille, C.sur(fond)), (int(x), int(m + (h - taille) / 2)))
            x += taille * 1.2
        d.text((x, m + h / 2), txt, font=pol, fill=C.sur(fond), anchor="lm")
        if apres and self.da.get("ombre") == "dure":
            dec = int(self.da.get("decalage", 9))
            out = Image.new("RGBA", img.size, (0, 0, 0, 0))
            out.alpha_composite(img.crop((0, 0, img.width - dec, img.height - dec)), (dec // 2, dec // 2))
            return out
        return img


@element("icone")
class Icone(Element):
    def construire(self, t):
        e = self.e
        fond = self.c(e["fond"]) if e.get("fond") else None
        return icone(e.get("forme", "coche"), e.get("d", 140), self.c(e.get("couleur", "accent" if fond is None else "clair")), fond=fond)


@element("forme")
class Forme(Element):
    """Aplat décoratif derrière un élément : rond, rectangle, tache (blob)."""
    anim_defaut = "zoom"

    def construire(self, t):
        e = self.e
        l, h = int(e.get("l", 600)), int(e.get("h", e.get("l", 600)))
        img = Image.new("RGBA", (l + 4, h + 4), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        c = self.c(e.get("couleur", "accent"))
        f = e.get("forme", "rond")
        if f == "rect":
            d.rounded_rectangle([0, 0, l, h], radius=int(e.get("rayon", self.da.get("rayon", 28))), fill=c)
        elif f == "blob":
            pts = []
            for i in range(90):
                a = i / 90 * 2 * math.pi
                k = 1 + 0.07 * math.sin(3 * a + self.phase) + 0.05 * math.cos(5 * a + 1.3 * self.phase)
                pts.append((l / 2 + l / 2 * 0.92 * k * math.cos(a), h / 2 + h / 2 * 0.92 * k * math.sin(a)))
            d.polygon(pts, fill=c)
        else:
            d.ellipse([0, 0, l, h], fill=c)
        return img


# ---------------------------------------------------------------- traits dessinés à la main
class Trace(Element):
    anim_defaut = "dessin"
    trace = True

    def avance(self, t):
        return adoucir((t - self.t0) / float(self.e.get("duree", 0.4)))

    def opacite(self, t):
        if self.t1 is not None and t > self.t1:
            return max(0.0, 1 - (t - self.t1) / 0.2)
        return 1.0


@element("barre", "trait")
class Barre(Trace):
    def tracer(self, img, t):
        e = self.e
        p = self.avance(t)
        if p <= 0:
            return
        o = self.opacite(t)
        c = avec_alpha(self.c(e.get("couleur", "perte")), o)
        ep_t = int(e.get("epaisseur", 18))
        x1, y1, x2, y2 = (e["de_xy"] + e["vers_xy"]) if "de_xy" in e else (e["x1"], e["y1"], e["x2"], e["y2"])
        calque = Image.new("RGBA", img.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(calque)
        xe, ye = x1 + (x2 - x1) * p, y1 + (y2 - y1) * p
        d.line([(x1, y1), (xe, ye)], fill=c, width=ep_t)
        for (px, py) in ((x1, y1), (xe, ye)):
            d.ellipse([px - ep_t / 2, py - ep_t / 2, px + ep_t / 2, py + ep_t / 2], fill=c)
        img.alpha_composite(calque)


@element("cercle")
class Cercle(Trace):
    def avance(self, t):
        return adoucir((t - self.t0) / float(self.e.get("duree", 0.45)))

    def tracer(self, img, t):
        e = self.e
        p = self.avance(t)
        if p <= 0:
            return
        c = avec_alpha(self.c(e.get("couleur", "perte")), self.opacite(t))
        ep_t = int(e.get("epaisseur", 12))
        x, y, rx, ry = e["x"], e["y"], e.get("rx", 200), e.get("ry", 90)
        n = 80
        pts = []
        for i in range(int(n * 1.12 * p) + 1):
            a = -2.4 + i / n * 2 * math.pi
            k = 1 + 0.04 * math.sin(i / n * 9) + 0.05 * i / n
            pts.append((x + rx * k * math.cos(a), y + ry * k * math.sin(a)))
        if len(pts) > 1:
            calque = Image.new("RGBA", img.size, (0, 0, 0, 0))
            ImageDraw.Draw(calque).line(pts, fill=c, width=ep_t, joint="curve")
            img.alpha_composite(calque)


@element("fleche")
class Fleche(Trace):
    """Flèche dessinée à la main, droite ou courbe (courbe = décalage en px du milieu)."""

    def tracer(self, img, t):
        e = self.e
        p = self.avance(t)
        if p <= 0:
            return
        c = avec_alpha(self.c(e.get("couleur", "encre") if e.get("couleur") else self.c.sur(self.fond_scene)), self.opacite(t))
        ep_t = int(e.get("epaisseur", 12))
        x1, y1, x2, y2 = (e["de_xy"] + e["vers_xy"]) if "de_xy" in e else (e["x1"], e["y1"], e["x2"], e["y2"])
        k = float(e.get("courbe", 120))
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        L = math.hypot(x2 - x1, y2 - y1) or 1
        cx, cy = mx - (y2 - y1) / L * k, my + (x2 - x1) / L * k

        def B(u):
            return ((1 - u) ** 2 * x1 + 2 * (1 - u) * u * cx + u * u * x2, (1 - u) ** 2 * y1 + 2 * (1 - u) * u * cy + u * u * y2)
        n = 60
        pts = [B(i / n * p) for i in range(n + 1)]
        calque = Image.new("RGBA", img.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(calque)
        if e.get("style") == "pointilles":
            for i in range(0, n, 4):
                d.line(pts[i:i + 3], fill=c, width=ep_t)
        else:
            d.line(pts, fill=c, width=ep_t, joint="curve")
        if p > 0.85 and e.get("pointe", True):
            (ax, ay), (bx, by) = pts[-4], pts[-1]
            ang = math.atan2(by - ay, bx - ax)
            s = ep_t * 3.2 * min(1.0, (p - 0.85) / 0.15)
            for da_ in (2.5, -2.5):
                d.line([(bx, by), (bx + s * math.cos(ang + da_), by + s * math.sin(ang + da_))], fill=c, width=ep_t)
            d.ellipse([bx - ep_t / 2, by - ep_t / 2, bx + ep_t / 2, by + ep_t / 2], fill=c)
        img.alpha_composite(calque)


@element("curseur")
class Curseur(Trace):
    """Pointeur de souris qui se déplace puis clique (avec onde)."""

    def tracer(self, img, t):
        e = self.e
        x1, y1 = e.get("de_xy", [e.get("x", 600) + 200, e.get("y", 900) + 300])
        x2, y2 = e.get("vers_xy", [e.get("x", 600), e.get("y", 900)])
        b = self.tps("fin", self.t0 + 0.6)
        k = adoucir((t - self.t0) / max(0.05, b - self.t0))
        x, y = x1 + (x2 - x1) * k, y1 + (y2 - y1) * k
        clic = self.tps("clic", b + 0.1)
        s = float(e.get("taille", 1.0))
        d = ImageDraw.Draw(img)
        if t >= clic:
            u = t - clic
            if u < 0.45:
                r = 20 + 90 * adoucir(u / 0.45)
                d.ellipse([x - r, y - r, x + r, y + r], outline=avec_alpha(self.c("accent"), 1 - u / 0.45), width=8)
            if u < 0.15:
                s *= 0.85
        pts = [(0, 0), (0, 58), (15, 45), (26, 70), (37, 65), (26, 41), (46, 41)]
        poly = [(x + px * s * 1.3, y + py * s * 1.3) for px, py in pts]
        d.polygon(poly, fill=(255, 255, 255, 255), outline=self.c("encre"))
        d.line(poly + [poly[0]], fill=self.c("encre"), width=5, joint="curve")


def creer(e, sc_t0, ep, fond_scene=None):
    typ = e.get("type", "image")
    if typ not in TYPES:
        raise SystemExit(f"Type d'élément inconnu : {typ!r}. Types disponibles : {', '.join(sorted(TYPES))}")
    return TYPES[typ](e, sc_t0, ep, fond_scene)
