#!/usr/bin/env python3
"""Prépare le fond qui remplace le décor filmé derrière la personne, et montre un aperçu.

usage :
  python fond.py images/recues/fond.png images/pretes/fond.png
  python fond.py images/recues/fond.png images/pretes/fond.png --flou 3 \
      --apercu edit/dialogue.mp4 edit/masque.mp4 --t 2.5     # → controle/apercu-fond.jpg
  python fond.py --papier "#F3EDE2" images/pretes/fond.png   # fond papier clair fait en code

Le fond est recadré en 1080 × 1920 (centre gardé). --flou adoucit un fond trop chargé
(2 à 6 px), --eclaircir 0.1 l'éclaircit pour que la personne reste le sujet.
L'aperçu pose la personne détourée (frame à --t secondes) devant le fond.
"""
import argparse
import os
import subprocess
import sys

from PIL import Image, ImageEnhance, ImageFilter, ImageOps

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import ffmpeg_exe  # noqa: E402


def frame(video, t, gris=False):
    r = subprocess.run([ffmpeg_exe(), "-v", "error", "-ss", str(t), "-i", video, "-frames:v", "1",
                        "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True)
    if r.returncode or not r.stdout:
        sys.exit(f"Lecture impossible : {video}")
    import io
    return Image.open(io.BytesIO(r.stdout)).convert("L" if gris else "RGB")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("entree", nargs="?")
    p.add_argument("sortie")
    p.add_argument("--papier", help="couleur : fabrique un fond papier en code au lieu d'une image")
    p.add_argument("--taille", default="1080x1920")
    p.add_argument("--flou", type=float, default=0)
    p.add_argument("--eclaircir", type=float, default=0)
    p.add_argument("--apercu", nargs=2, metavar=("DIALOGUE", "MASQUE"))
    p.add_argument("--t", type=float, default=2.0)
    a = p.parse_args()
    W, H = [int(v) for v in a.taille.split("x")]
    if a.papier:
        from camera import papier
        from dessin import couleur
        im = papier(W, H, couleur(a.papier)).convert("RGB")
    else:
        if not a.entree:
            sys.exit("Donner l'image du fond, ou --papier COULEUR")
        im = ImageOps.fit(Image.open(a.entree).convert("RGB"), (W, H), Image.LANCZOS)
    if a.flou:
        im = im.filter(ImageFilter.GaussianBlur(a.flou))
    if a.eclaircir:
        im = ImageEnhance.Brightness(im).enhance(1 + a.eclaircir)
    os.makedirs(os.path.dirname(a.sortie) or ".", exist_ok=True)
    im.save(a.sortie)
    print(f"Fond : {a.sortie} ({W}×{H})")
    if a.apercu:
        cou = frame(a.apercu[0], a.t).resize((W, H))
        m = frame(a.apercu[1], a.t, True).resize((W, H))
        out = im.copy()
        out.paste(cou, (0, 0), m)
        os.makedirs("controle", exist_ok=True)
        out.save("controle/apercu-fond.jpg", quality=88)
        print("Aperçu : controle/apercu-fond.jpg (regarder les bords des cheveux et des épaules)")


if __name__ == "__main__":
    main()
