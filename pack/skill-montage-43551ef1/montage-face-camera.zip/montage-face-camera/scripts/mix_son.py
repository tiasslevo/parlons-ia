"""Pose les bruitages et la musique sous la voix, puis colle le son sur la vidéo.

usage :
  python mix_son.py --voix voix.wav --cues cues.json [--sons sons/] [--musique musique.mp3] \
                    [--video muette.mp4 --sortie finale.mp4]
  python mix_son.py --cues cues.json --video muette.mp4 --sortie finale.mp4 --duree 12   # vidéo sans voix

- cues.json vient de rendu.py --cues (ou s'écrit à la main) : [{"t": 3.16, "type": "pop"}, ...]
  On peut ajouter "fichier": "sons/impact/coup.wav" ou "gain": -12 sur une ligne.
- Sans --sons, la banque du skill (assets/sons/, sons synthétisés en code par sons.py, libres de droits)
  sert pour tout. Avec --sons, chaque sous-dossier présent (whoosh/, pop/, impact/, glisse/, coupe/, clic/,
  ding/ ; wav ou mp3) remplace le type correspondant ; les types absents gardent la banque du skill.
  --sans-banque n'utilise que --sons. Voir references/controle.md.
- La musique, si présente, baisse toute seule quand quelqu'un parle.
- Les bruitages se calent sur le niveau de la voix (--ecart dB dessous, 15 par défaut) et baissent encore
  quand elle parle (--attenuation). La voix doit être traitée avant (voix.py, -14 LUFS).
- Sortie : mix.wav (crêtes limitées), bruitages.wav (pour la mesure), et la vidéo finale si --video est donné.
"""
import argparse
import json
import os
import random
import subprocess
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import SR, ecrire_wav, ffmpeg_exe, lire_audio, normaliser  # noqa: E402

# niveau de chaque type par rapport à l'écart de base sous la voix (dB) : l'impact un peu plus présent
DECALAGE = {"impact": 3.0, "whoosh": 0.0, "coupe": -2.0, "pop": -1.0, "glisse": -2.0, "clic": 0.0, "ding": -1.0}
ECART_MIN = {"impact": 2.5, "pop": 0.35, "whoosh": 0.3, "glisse": 0.5, "coupe": 0.3, "clic": 0.2, "ding": 1.0}
BANQUE_SKILL = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "sons")


def lire_banque(dossier):
    banque = {}
    if dossier and os.path.isdir(dossier):
        for typ in os.listdir(dossier):
            d = os.path.join(dossier, typ)
            if os.path.isdir(d):
                fs = sorted(os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith((".wav", ".mp3", ".ogg", ".flac")))
                if fs:
                    banque[typ] = fs
    return banque


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--voix", help="voix.wav (absent pour une vidéo sans voix : donner --duree ou --video)")
    ap.add_argument("--cues", required=True)
    ap.add_argument("--sons", help="banque personnelle (facultatif)")
    ap.add_argument("--sans-banque", action="store_true", help="ne pas compléter avec les sons du skill")
    ap.add_argument("--duree", type=float, help="durée du son sans voix (s)")
    ap.add_argument("--musique")
    ap.add_argument("--ecart", type=float, default=14.0, help="bruitages sous la voix, en dB intégrés (12 à 18)")
    ap.add_argument("--ecart-musique", type=float, default=20.0, help="musique sous la voix, en dB")
    ap.add_argument("--attenuation", type=float, default=6.0, help="baisse en plus des bruitages pendant la parole (dB)")
    ap.add_argument("--video")
    ap.add_argument("--sortie")
    ap.add_argument("--graine", type=int, default=7)
    a = ap.parse_args()
    random.seed(a.graine)

    if a.voix:
        voix = lire_audio(a.voix)
    else:
        d = a.duree
        if d is None and a.video:
            import re
            err = subprocess.run([ffmpeg_exe(), "-i", a.video], capture_output=True, text=True).stderr
            m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", err)
            d = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else None
        if d is None:
            sys.exit("Sans voix, donner --duree ou --video.")
        voix = np.zeros(int(d * SR), np.float32)
    cues = json.load(open(a.cues, encoding="utf-8"))
    def rms_actif(y):
        n = int(0.05 * SR)
        k = len(y) // n
        if k == 0:
            return float(np.sqrt((y ** 2).mean()) or 1e-6)
        r = np.sqrt((y[:k * n].reshape(k, n) ** 2).mean(axis=1))
        r = r[r > r.max() * 0.1] if r.max() > 0 else r
        return float(np.sqrt((r ** 2).mean()) or 1e-6)
    v_db = 20 * np.log10(rms_actif(voix)) if a.voix else -20.0
    if a.voix:
        from outils import niveau
        vi, vtp = niveau(a.voix)
        if vi is not None and abs(vi + 14) > 2:
            print(f"Attention : la voix est à {vi:.1f} LUFS. La traiter d'abord : python scripts/voix.py {a.voix} edit/voix-traitee.wav")
    duree = len(voix) / SR + (1.0 if a.voix else 0.0)
    mix = np.zeros(int(duree * SR), np.float32)

    banque = {} if a.sans_banque else lire_banque(BANQUE_SKILL)
    perso = lire_banque(a.sons)
    banque.update(perso)
    print("Banque :", {k: (len(v), "perso" if k in perso else "skill") for k, v in banque.items()})
    cache, dernier, poses = {}, {}, 0
    for c in cues:
        typ, t = c.get("type", "pop"), float(c["t"])
        f = c.get("fichier")
        if not f:
            if typ not in banque:
                continue
            if t - dernier.get(typ, -99) < ECART_MIN.get(typ, 0.3):
                continue
            f = random.choice(banque[typ])
        dernier[typ] = t
        if not os.path.exists(f):
            f = os.path.join(os.path.dirname(os.path.abspath(a.cues)), f)
        if f not in cache:
            y = lire_audio(f)
            cache[f] = y / rms_actif(y)  # chaque son ramené au même niveau moyen
        g = v_db - a.ecart + DECALAGE.get(typ, 0.0) + float(c.get("gain", 0.0))
        y = cache[f][: int(SR * 2.5)] * 10 ** (g / 20)
        # l'attaque d'un whoosh doit finir sur la coupe : on le pose un peu avant
        i0 = int(max(0.0, t - (0.12 if typ == "whoosh" else 0.0)) * SR)
        if i0 >= len(mix):
            continue  # repère après la fin du son
        i1 = min(len(mix), i0 + len(y))
        mix[i0:i1] += y[: i1 - i0]
        poses += 1
    print(f"{poses} bruitages posés")

    # enveloppe de la voix : 1 quand elle parle, 0 dans les silences
    fen = int(0.3 * SR)
    absv = np.abs(np.pad(voix, (0, len(mix) - len(voix)))).astype(np.float64)
    cs = np.concatenate([[0.0], np.cumsum(absv)])
    i = np.arange(len(mix))
    lo, hi = np.clip(i - fen // 2, 0, len(mix)), np.clip(i + fen // 2, 0, len(mix))
    env = (cs[hi] - cs[lo]) / fen
    parle = np.clip(env / (np.percentile(env[env > 0], 60) if np.any(env > 0) else 1), 0, 1).astype(np.float32)
    mix *= 1 - parle * (1 - 10 ** (-a.attenuation / 20))  # bruitages baissés quand elle parle

    if a.musique:
        m = lire_audio(a.musique)
        if len(m) < len(mix):
            m = np.tile(m, int(len(mix) / max(1, len(m))) + 1)
        m = m[:len(mix)] / rms_actif(m) * 10 ** ((v_db - a.ecart_musique) / 20)
        m *= 1 - parle * (1 - 10 ** (-9 / 20))
        fin = int(1.0 * SR)
        m[-fin:] *= np.linspace(1, 0, fin)
        mix += m

    dossier = os.path.dirname(os.path.abspath(a.voix or a.cues))
    bus = os.path.join(dossier, "bruitages.wav")
    ecrire_wav(bus, mix)
    from outils import niveau
    if a.voix and np.abs(mix).max() > 0:
        # réglage final mesuré : le bus des bruitages (et musique) exactement --ecart dB sous la voix
        bi0, _ = niveau(bus)
        if bi0 is not None and bi0 > -70:
            mix *= 10 ** (((vi - a.ecart) - bi0) / 20)
            ecrire_wav(bus, mix)
    total = mix.copy()
    total[:len(voix)] += voix
    brut = os.path.join(dossier, "mix-brut.wav")
    sortie_wav = os.path.join(dossier, "mix.wav")
    ecrire_wav(brut, total)
    subprocess.run([ffmpeg_exe(), "-v", "error", "-y", "-i", brut, "-af", "alimiter=limit=0.82:attack=3:release=60:level=false",
                    "-ar", str(SR), sortie_wav], check=True)
    os.remove(brut)
    bi, _ = niveau(bus)
    mi, mtp = niveau(sortie_wav)
    if a.voix:
        print(f"Niveaux : voix {vi:.1f} LUFS · bruitages {bi:.1f} LUFS (écart {vi - bi:.1f} dB) · mix {mi:.1f} LUFS, crête {mtp:.1f} dBTP")
    print(f"Mix : {sortie_wav} ; bus des bruitages : {bus}")
    if a.video:
        sortie = a.sortie or os.path.splitext(a.video)[0] + "-son.mp4"
        subprocess.run([ffmpeg_exe(), "-v", "error", "-y", "-i", a.video, "-i", sortie_wav, "-map", "0:v", "-map", "1:a",
                        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", sortie], check=True)
        print(f"Vidéo finale : {sortie} ({os.path.getsize(sortie) / 1e6:.1f} Mo)")


if __name__ == "__main__":
    main()
