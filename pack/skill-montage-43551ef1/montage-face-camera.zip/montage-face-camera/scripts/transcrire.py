#!/usr/bin/env python3
"""Transcrit une voix avec horodatage de chaque mot (faster-whisper).

Installation (une fois) :
  pip install faster-whisper

Usage :
  python transcrire.py edit/voix.wav --sortie analysis/mots.json
  python transcrire.py source/rush.mp4 --modele small --langue fr
  python transcrire.py edit/voix.wav --debut 12.0 --fin 18.5   # fenêtre courte

Modèles : "small" va vite sur un ordinateur ordinaire ; "medium" ou
"large-v3" sont plus justes sur les noms propres, plus lents sans carte
graphique. Le premier lancement télécharge le modèle (quelques centaines de Mo).

Sorties : un JSON (mots avec début/fin en secondes, phrases) et un .txt lisible.
Avec --debut/--fin, les temps restent exprimés dans le fichier d'origine.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
from pathlib import Path


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("media", type=Path)
    p.add_argument("--sortie", type=Path, default=Path("analysis/mots.json"))
    p.add_argument("--modele", default="small")
    p.add_argument("--langue", default="fr")
    p.add_argument("--debut", type=float, help="début d'une fenêtre à transcrire, en s")
    p.add_argument("--fin", type=float, help="fin de la fenêtre, en s")
    p.add_argument("--appareil", default="auto", help="auto, cpu ou cuda")
    p.add_argument("--ffmpeg", default="ffmpeg")
    a = p.parse_args()

    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise SystemExit("faster-whisper manque : pip install faster-whisper")

    decalage = a.debut or 0.0
    with tempfile.TemporaryDirectory() as tmp:
        wav = Path(tmp) / "asr.wav"
        cmd = [a.ffmpeg, "-hide_banner", "-loglevel", "error", "-y"]
        if a.debut is not None:
            cmd += ["-ss", f"{a.debut}"]
        if a.fin is not None:
            cmd += ["-to", f"{a.fin}"] if a.debut is None else ["-t", f"{a.fin - decalage}"]
        cmd += ["-i", str(a.media), "-vn", "-ac", "1", "-ar", "16000",
                "-c:a", "pcm_s16le", str(wav)]
        subprocess.run(cmd, check=True)

        calcul = "int8" if a.appareil in ("auto", "cpu") else "float16"
        modele = WhisperModel(a.modele, device=a.appareil, compute_type=calcul)
        segments, info = modele.transcribe(
            str(wav), language=a.langue, word_timestamps=True,
            vad_filter=False,  # garder hésitations et reprises visibles
            condition_on_previous_text=False,
        )
        phrases, mots = [], []
        for seg in segments:
            phrases.append({"debut": round(seg.start + decalage, 3),
                            "fin": round(seg.end + decalage, 3),
                            "texte": seg.text.strip()})
            for w in seg.words or []:
                mots.append({"mot": w.word.strip(),
                             "debut": round(w.start + decalage, 3),
                             "fin": round(w.end + decalage, 3),
                             "confiance": round(w.probability, 3)})

    a.sortie.parent.mkdir(parents=True, exist_ok=True)
    a.sortie.write_text(json.dumps({
        "media": str(a.media), "modele": a.modele, "langue": info.language,
        "fenetre": [a.debut, a.fin], "phrases": phrases, "mots": mots,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    lignes = [f"[{ph['debut']:7.2f} - {ph['fin']:7.2f}] {ph['texte']}" for ph in phrases]
    a.sortie.with_suffix(".txt").write_text("\n".join(lignes) + "\n", encoding="utf-8")
    print(f"{len(mots)} mots, {len(phrases)} phrases -> {a.sortie}")


if __name__ == "__main__":
    main()
