#!/usr/bin/env python3
"""Détoure la personne d'une vidéo montée (Robust Video Matting, ONNX).

Sert aux éléments qui passent derrière la personne (plein face) et à l'écran
séparé. Sortie conseillée : masque.mp4, une vidéo en niveaux de gris (blanc =
la personne) de même durée que la vidéo montée, lue par rendu.py (type
"camera", clé "masque"). Une sortie .webm donne un VP9 avec transparence
(pour Remotion ou CapCut).

Installation (une fois) :
  pip install onnxruntime numpy
  Télécharger le modèle (≈15 Mo) :
  https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx

Usage :
  python detourer.py edit/dialogue.mp4 edit/masque.mp4 --modele outils/rvm_mobilenetv3_fp32.onnx
  python detourer.py edit/dialogue.mp4 edit/test.webm --modele ... --max-frames 90   # essai court
  python detourer.py edit/dialogue.mp4 edit/personne.webm --modele ... --coupes 0,112,240

--coupes : numéros de frames (dans la vidéo montée) où une coupe franche a lieu ;
le modèle repart à zéro à ces endroits pour ne pas traîner l'image précédente.
La vidéo d'entrée doit être à cadence constante (c'est le cas après appliquer_edl.py).
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

try:
    import numpy as np
    import onnxruntime as ort
except ImportError:
    raise SystemExit("Dépendances manquantes : pip install onnxruntime numpy")


def sonder(ffmpeg: str, chemin: Path) -> tuple[int, int, str]:
    log = subprocess.run([ffmpeg, "-hide_banner", "-i", str(chemin)],
                         capture_output=True, text=True).stderr
    m = re.search(r"Video:.*?(\d{2,5})x(\d{2,5})", log)
    f = re.search(r"(\d+(?:\.\d+)?) fps", log)
    if not m or not f:
        sys.exit("Impossible de lire dimensions ou cadence de la vidéo.")
    return int(m.group(1)), int(m.group(2)), f.group(1)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("entree", type=Path)
    p.add_argument("sortie", type=Path)
    p.add_argument("--modele", type=Path, required=True)
    p.add_argument("--reduction", type=float, default=0.4,
                   help="downsample_ratio de RVM : 0.25 à 0.5 pour du 1080p (défaut 0.4)")
    p.add_argument("--coupes", default="", help="frames de coupe franche, séparées par des virgules")
    p.add_argument("--max-frames", type=int, help="essai court seulement")
    p.add_argument("--ffmpeg", default="ffmpeg")
    a = p.parse_args()

    if a.sortie.exists():
        sys.exit(f"{a.sortie} existe déjà : choisir un nouveau nom.")
    w, h, fps = sonder(a.ffmpeg, a.entree)
    if w % 2 or h % 2:
        sys.exit("Dimensions impaires : redimensionner la vidéo avant le détourage.")
    coupes = {int(x) for x in a.coupes.split(",") if x.strip().isdigit()}

    session = ort.InferenceSession(str(a.modele), providers=ort.get_available_providers())
    lecture = subprocess.Popen(
        [a.ffmpeg, "-hide_banner", "-loglevel", "error", "-i", str(a.entree),
         "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    a.sortie.parent.mkdir(parents=True, exist_ok=True)
    masque_seul = a.sortie.suffix.lower() == ".mp4"
    if masque_seul:
        sortie_cmd = ["-f", "rawvideo", "-pix_fmt", "gray", "-s", f"{w}x{h}", "-r", fps, "-i", "-",
                      "-c:v", "libx264", "-crf", "14", "-pix_fmt", "yuv420p", str(a.sortie)]
    else:
        sortie_cmd = ["-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{w}x{h}", "-r", fps, "-i", "-",
                      "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-auto-alt-ref", "0",
                      "-b:v", "0", "-crf", "24", "-row-mt", "1", str(a.sortie)]
    ecriture = subprocess.Popen([a.ffmpeg, "-hide_banner", "-loglevel", "error", "-y"] + sortie_cmd,
                                stdin=subprocess.PIPE)

    taille = w * h * 3
    ratio = np.array([a.reduction], dtype=np.float32)

    def etats_neufs():
        return [np.zeros((1, 1, 1, 1), dtype=np.float32) for _ in range(4)]

    rec = etats_neufs()
    n = 0
    alphas_moyens = []
    while True:
        brut = lecture.stdout.read(taille)
        if len(brut) < taille:
            break
        if n in coupes:
            rec = etats_neufs()
        image = np.frombuffer(brut, dtype=np.uint8).reshape(h, w, 3)
        src = image.astype(np.float32).transpose(2, 0, 1)[None] / 255.0
        # Amorce : à la première frame et après une coupe, on répète l'image
        # pour que le modèle stabilise ses états avant d'écrire.
        passes = 3 if (n == 0 or n in coupes) else 1
        for _ in range(passes):
            fgr, pha, *rec = session.run(None, {
                "src": src, "r1i": rec[0], "r2i": rec[1], "r3i": rec[2],
                "r4i": rec[3], "downsample_ratio": ratio})
        alpha = (np.clip(pha[0, 0], 0, 1) * 255).astype(np.uint8)
        ecriture.stdin.write(alpha.tobytes() if masque_seul else np.dstack([image, alpha]).tobytes())
        alphas_moyens.append(float(alpha.mean()) / 255)
        n += 1
        if n % 150 == 0:
            print(f"{n} frames détourées…", flush=True)
        if a.max_frames and n >= a.max_frames:
            break

    lecture.stdout.close()
    lecture.terminate()
    ecriture.stdin.close()
    ecriture.wait()

    rapport = {"entree": str(a.entree), "sortie": str(a.sortie), "frames": n,
               "dimensions": [w, h], "fps": fps, "reduction": a.reduction,
               "coupes": sorted(coupes),
               "part_opaque_moyenne": round(sum(alphas_moyens) / max(1, n), 3)}
    a.sortie.with_suffix(".json").write_text(json.dumps(rapport, indent=2), encoding="utf-8")
    print(f"{n} frames -> {a.sortie}")


if __name__ == "__main__":
    main()
