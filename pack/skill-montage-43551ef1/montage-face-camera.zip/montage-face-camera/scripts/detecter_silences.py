#!/usr/bin/env python3
"""Repère les silences d'un rush et propose une première liste de segments à garder.

Usage :
  python detecter_silences.py RUSH.mp4 --sortie analysis/silences.json
  python detecter_silences.py RUSH.mp4 --seuil -35 --min-silence 0.45 --marge 0.12

La proposition sert de point de départ. Les hésitations, faux départs et reprises
se repèrent ensuite avec la transcription : ce script ne les voit pas.
Nécessite ffmpeg dans le PATH (ou --ffmpeg CHEMIN).
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path


def duree_media(ffmpeg: str, chemin: Path) -> float:
    sortie = subprocess.run(
        [ffmpeg, "-hide_banner", "-i", str(chemin)],
        capture_output=True, text=True,
    ).stderr
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", sortie)
    if not m:
        sys.exit("Durée introuvable : le fichier est-il lisible par ffmpeg ?")
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


def silences(ffmpeg: str, chemin: Path, seuil_db: float, min_silence: float,
             piste: int) -> list[tuple[float, float]]:
    cmd = [
        ffmpeg, "-hide_banner", "-nostats", "-i", str(chemin),
        "-map", f"0:a:{piste}",
        "-af", f"silencedetect=noise={seuil_db}dB:d={min_silence}",
        "-f", "null", "-",
    ]
    log = subprocess.run(cmd, capture_output=True, text=True).stderr
    debuts = [float(x) for x in re.findall(r"silence_start:\s*(-?[\d.]+)", log)]
    fins = [float(x) for x in re.findall(r"silence_end:\s*([\d.]+)", log)]
    paires = []
    for i, debut in enumerate(debuts):
        fin = fins[i] if i < len(fins) else None
        paires.append((max(0.0, debut), fin))
    return paires


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("rush", type=Path)
    p.add_argument("--sortie", type=Path, help="fichier JSON à écrire")
    p.add_argument("--seuil", type=float, default=-35.0,
                   help="niveau sous lequel on parle de silence, en dB (défaut -35)")
    p.add_argument("--min-silence", type=float, default=0.45,
                   help="durée minimale d'un silence à resserrer, en s (défaut 0.45)")
    p.add_argument("--marge", type=float, default=0.12,
                   help="air gardé avant et après la parole, en s (défaut 0.12)")
    p.add_argument("--piste", type=int, default=0, help="index de la piste audio")
    p.add_argument("--ffmpeg", default="ffmpeg")
    a = p.parse_args()

    total = duree_media(a.ffmpeg, a.rush)
    trous = silences(a.ffmpeg, a.rush, a.seuil, a.min_silence, a.piste)

    # Segments de parole = complément des silences, avec une marge de chaque côté.
    garder = []
    curseur = 0.0
    for debut, fin in trous:
        fin = total if fin is None else fin
        if debut > curseur:
            garder.append([curseur, debut])
        curseur = fin
    if curseur < total:
        garder.append([curseur, total])

    segments = []
    for debut, fin in garder:
        d = max(0.0, debut - a.marge)
        f = min(total, fin + a.marge)
        if segments and d <= segments[-1]["fin"]:
            segments[-1]["fin"] = round(f, 3)
        else:
            segments.append({"debut": round(d, 3), "fin": round(f, 3)})
    segments = [s for s in segments if s["fin"] - s["debut"] >= 0.15]

    garde = sum(s["fin"] - s["debut"] for s in segments)
    resultat = {
        "source": str(a.rush),
        "duree_source_s": round(total, 3),
        "reglages": {"seuil_db": a.seuil, "min_silence_s": a.min_silence,
                     "marge_s": a.marge},
        "silences": [{"debut": round(d, 3), "fin": round(f if f is not None else total, 3)}
                     for d, f in trous],
        "segments_proposes": segments,
        "duree_gardee_s": round(garde, 3),
        "note": "Proposition brute. Retirer ensuite faux départs, reprises et "
                "hésitations repérés dans la transcription, puis écouter les raccords.",
    }
    texte = json.dumps(resultat, ensure_ascii=False, indent=2)
    if a.sortie:
        a.sortie.parent.mkdir(parents=True, exist_ok=True)
        a.sortie.write_text(texte, encoding="utf-8")
    print(texte if not a.sortie else
          f"{len(segments)} segments, {garde:.1f} s gardées sur {total:.1f} s -> {a.sortie}")


if __name__ == "__main__":
    main()
