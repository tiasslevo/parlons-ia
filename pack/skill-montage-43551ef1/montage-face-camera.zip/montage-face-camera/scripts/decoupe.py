"""Découpe une planche détourée (plusieurs dessins séparés par du vide) en un fichier par dessin.

usage :
  python decoupe.py planche.png sortie/bouche          # → sortie/bouche-1.png, bouche-2.png… (de gauche à droite)
  python decoupe.py planche.png sortie/objet --min 2000 --marge 6

Sert pour objets générés sur une image.
La planche doit déjà être détourée (scripts/detoure.py).
"""
import argparse
import os
import sys

from PIL import Image


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("planche")
    ap.add_argument("prefixe", help="chemin et début du nom des fichiers à écrire")
    ap.add_argument("--min", type=int, default=1500, help="surface minimale d'un dessin en pixels (ignore les miettes)")
    ap.add_argument("--marge", type=int, default=4)
    a = ap.parse_args()
    import numpy as np
    im = Image.open(a.planche).convert("RGBA")
    alpha = np.array(im.getchannel("A")) > 40
    boites = []
    try:
        from scipy import ndimage
        # on relie les traits proches d'un même dessin avant de compter les morceaux
        lab, n = ndimage.label(ndimage.binary_dilation(alpha, iterations=8))
        for i, sl in enumerate(ndimage.find_objects(lab), start=1):
            if sl is None:
                continue
            if int((alpha[sl] & (lab[sl] == i)).sum()) >= a.min:
                boites.append((sl[1].start, sl[0].start, sl[1].stop, sl[0].stop))
    except ImportError:  # sans scipy : dessins séparés par des colonnes vides (planche en ligne)
        cols = alpha.any(axis=0)
        x = 0
        while x < len(cols):
            if cols[x]:
                x0 = x
                while x < len(cols) and cols[x]:
                    x += 1
                rows = np.where(alpha[:, x0:x].any(axis=1))[0]
                if alpha[:, x0:x].sum() >= a.min:
                    boites.append((x0, int(rows[0]), x, int(rows[-1]) + 1))
            x += 1
    boites.sort(key=lambda b: (b[0], b[1]))
    if not boites:
        sys.exit("Aucun dessin trouvé : la planche est-elle bien détourée ?")
    os.makedirs(os.path.dirname(os.path.abspath(a.prefixe)), exist_ok=True)
    for k, (x0, y0, x1, y1) in enumerate(boites, start=1):
        m = a.marge
        piece = im.crop((max(0, x0 - m), max(0, y0 - m), min(im.width, x1 + m), min(im.height, y1 + m)))
        f = f"{a.prefixe}-{k}.png"
        piece.save(f)
        print(f"{f}  {piece.width} × {piece.height}")


if __name__ == "__main__":
    main()
