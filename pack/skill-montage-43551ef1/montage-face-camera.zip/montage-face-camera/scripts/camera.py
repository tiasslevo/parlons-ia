"""Éléments propres au montage face caméra, ajoutés au moteur rendu.py.

- "camera" : la vidéo montée de la personne (plein écran, cadre de l'écran séparé, zooms).
  Avec "masque" et "decoupe": true, seule la personne détourée est dessinée : ce qui est
  placé avant elle dans la liste passe DERRIÈRE elle.
- "dos" : une image qui monte de derrière le dos jusqu'au-dessus de la tête, floue puis nette.
- "titre" : le titre à deux niveaux (ligne principale + ligne fine dessous, légèrement chevauchée).

La vidéo montée et la timeline partagent le même temps : l'image affichée à t est la frame t.
Clés et exemples : references/moteur.md.
"""
import hashlib
import math
import os
import subprocess

from PIL import Image, ImageDraw, ImageFilter

from elements import Element, Img, adoucir, coller, element
from outils import ffmpeg_exe


class Frames:
    """Images d'une vidéo extraites une fois (jpg) dans .cache-media/, à la taille d'origine."""

    def __init__(self, ep, src, gris=False):
        f = ep.p(src)
        if not os.path.isfile(f):
            raise SystemExit(f"Vidéo absente : {f}")
        self.dossier = os.path.join(ep.base, ".cache-media", "cam-" + hashlib.md5(f"{f}{ep.fps}{gris}".encode()).hexdigest()[:10])
        if not os.path.isdir(self.dossier) or not os.listdir(self.dossier):
            os.makedirs(self.dossier, exist_ok=True)
            vf = f"fps={ep.fps}" + (",format=gray" if gris else "")
            r = subprocess.run([ffmpeg_exe(), "-v", "error", "-i", f, "-vf", vf, "-q:v", "2",
                                os.path.join(self.dossier, "%05d.jpg")])
            if r.returncode != 0:
                raise SystemExit(f"Lecture de la vidéo impossible : {f}")
        self.fichiers = sorted(os.listdir(self.dossier))
        self.gris, self.fps, self.cache = gris, ep.fps, {}

    def __call__(self, t):
        i = min(max(0, int(round(t * self.fps))), len(self.fichiers) - 1)
        if i not in self.cache:
            if len(self.cache) > 6:
                self.cache.clear()
            im = Image.open(os.path.join(self.dossier, self.fichiers[i]))
            self.cache[i] = im.convert("L" if self.gris else "RGB")
        return self.cache[i]


def _frames(ep, src, gris=False):
    if not hasattr(ep, "_frames_cam"):
        ep._frames_cam = {}
    cle = (src, gris)
    if cle not in ep._frames_cam:
        ep._frames_cam[cle] = Frames(ep, src, gris)
    return ep._frames_cam[cle]


@element("camera", "personne")
class Camera(Element):
    """La personne filmée. "cadre": [x, y, l, h] = rectangle occupé à l'écran (défaut : plein écran).
    "centre": [x, y] point du rush gardé au centre (pixels de la vidéo montée).
    "zoom": 1.0 ; "zoom_lent": [1.0, 1.06] sur la durée de la scène ;
    "zooms": [{"a": "L3#2", "zoom": 1.3, "centre": [540, 800], "jusqua": "L4"}] recadrages secs.
    "masque" + "decoupe": true → personne seule (fond transparent)."""
    anim_defaut = "aucune"

    def preparer(self):
        e, ep = self.e, self.ep
        self.cadre = e.get("cadre", [0, 0, ep.W, ep.H])
        self.zooms = [(self.T(z.get("a")), self.T(z.get("jusqua"), None), z) for z in e.get("zooms", [])]
        self.fin_scene = None

    def boite(self, t, W, H):
        e = self.e
        x, y, l, h = self.cadre
        z = float(e.get("zoom", 1.0))
        c = list(e.get("centre", [W / 2, H / 2]))
        zl = e.get("zoom_lent")
        if zl:
            fin = self.t1 or self.fin_scene or (self.t0 + 6)
            k = min(1.0, max(0.0, (t - self.t0) / max(0.1, fin - self.t0)))
            z *= zl[0] + (zl[1] - zl[0]) * k
        for a, b, zz in self.zooms:
            if t >= a and (b is None or t < b):
                z *= float(zz.get("zoom", 1.25))
                c = list(zz.get("centre", c))
        s0 = max(l / W, h / H) * z
        bw, bh = l / s0, h / s0
        x0 = min(max(0.0, c[0] - bw / 2), W - bw)
        y0 = min(max(0.0, c[1] - bh / 2), H - bh)
        return (x0, y0, x0 + bw, y0 + bh), (int(x), int(y), int(l), int(h))

    def dessiner(self, img, t):
        if not self.visible(t):
            return
        e = self.e
        cou = _frames(self.ep, e["src"])(t)
        box, (x, y, l, h) = self.boite(t, cou.width, cou.height)
        im = cou.resize((l, h), Image.BILINEAR, box=box).convert("RGBA")
        if e.get("decoupe"):
            if not e.get("masque"):
                raise SystemExit("camera avec \"decoupe\": true demande \"masque\" (sortie de detourer.py)")
            m = _frames(self.ep, e["masque"], True)(t).resize((l, h), Image.BILINEAR, box=box)
            im.putalpha(m)
        elif e.get("arrondi"):
            m = Image.new("L", (l, h), 0)
            ImageDraw.Draw(m).rounded_rectangle([0, 0, l - 1, h - 1], radius=int(e["arrondi"]), fill=255)
            im.putalpha(m)
        o = float(e.get("opacite", 1.0))
        if o < 0.99:
            im.putalpha(im.getchannel("A").point(lambda v: int(v * o)))
        img.alpha_composite(im, (x, y))


@element("dos")
class Dos(Img):
    """Image qui part de derrière le buste ("depart_y", défaut y + 900) et monte à sa place
    (x, y), floue puis nette, en freinant à l'arrivée. "duree" (0,6 s), "flou" (14 px).
    À placer AVANT la camera découpée dans la liste des éléments."""
    boucle_defaut = "flotte"

    def dessiner(self, img, t):
        if not self.visible(t):
            return
        e = self.e
        anim, self.anim = self.anim, "aucune"
        tr = self.transformation(t)
        self.anim = anim
        if tr is None:
            return
        sx, sy, dx, dy, r, o, clip = tr
        x, y, s = self.position(t)
        duree = float(e.get("duree", 0.6))
        p = min(1.0, max(0.0, (t - self.t0) / duree))
        k = 1 - (1 - p) ** 3.2  # part franchement, freine à l'arrivée
        y0 = float(e.get("depart_y", y + 900))
        yy = y0 + (y - y0) * k
        flou = round(float(e.get("flou", 14)) * (1 - adoucir(p * 1.15)))
        sp = self.construire(t)
        if flou >= 1:
            cle = ("flou", flou)
            if cle not in self.cache:
                self.cache[cle] = sp.filter(ImageFilter.GaussianBlur(flou))
            sp = self.cache[cle]
        coller(img, sp, x + dx, yy + dy, sx * s, sy * s, r, o, "centre", self.cache, ("dos", flou), clip)


@element("titre")
class Titre(Element):
    """Titre à deux niveaux. "haut" (ligne principale), "bas" (facultatif, ligne fine dessous).
    "police_haut" (Anton.ttf), "police_bas" (InstrumentItalic.ttf), "couleur_haut", "couleur_bas",
    "taille" (hauteur de la ligne principale, 150), "largeur" (900), "contour_bas" (auto)."""
    anim_defaut = "elastique"
    x_defaut, y_defaut = 540, 360

    def construire(self, t):
        e, c = self.e, self.c
        larg = float(e.get("largeur", 900))
        haut = str(e.get("haut", "")).upper() if e.get("casse", "majuscules") == "majuscules" else str(e.get("haut", ""))
        taille = int(e.get("taille", 150))
        ph = self.ep.polices.get(taille, e.get("police_haut", "Anton.ttf"))
        while ph.getlength(haut) > larg and taille > 40:
            taille -= 4
            ph = self.ep.polices.get(taille, e.get("police_haut", "Anton.ttf"))
        ch = c(e.get("couleur_haut", "encre"))
        bas = e.get("bas")
        tb = int(taille * float(e.get("rapport_bas", 0.78)))
        pb = self.ep.polices.get(tb, e.get("police_bas", "InstrumentItalic.ttf"), 400)
        while bas and pb.getlength(bas) > larg and tb > 30:
            tb -= 4
            pb = self.ep.polices.get(tb, e.get("police_bas", "InstrumentItalic.ttf"), 400)
        cb = c(e.get("couleur_bas", "accent"))
        lum = (0.2126 * cb[0] + 0.7152 * cb[1] + 0.0722 * cb[2]) / 255
        cont_b = c(e.get("contour_bas_couleur", "#1D1B18" if lum > 0.55 else "#FFFFFF"))
        sh = c(e.get("ombre", "#00000080")) if e.get("ombre", True) else None
        marge = 30
        bb_h = ph.getbbox(haut)
        wh, hh = bb_h[2] - bb_h[0], bb_h[3] - bb_h[1]
        wb = hb = 0
        if bas:
            bb_b = pb.getbbox(bas)
            wb, hb = bb_b[2] - bb_b[0], bb_b[3] - bb_b[1]
        chev = int(hb * float(e.get("chevauchement", 0.1))) if bas else 0
        W = int(max(wh, wb) + 2 * marge)
        H = int(hh + (hb - chev if bas else 0) + 2 * marge + 10)
        im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        xh, yh = (W - wh) / 2 - bb_h[0], marge - bb_h[1]
        if sh:
            d.text((xh + 5, yh + 6), haut, font=ph, fill=sh)
        d.text((xh, yh), haut, font=ph, fill=ch)
        if bas:
            xb, yb = (W - wb) / 2 - bb_b[0], marge + hh - chev - bb_b[1]
            d.text((xb, yb), bas, font=pb, fill=cb, stroke_width=max(2, tb // 22), stroke_fill=cont_b)
        return im


@element("ecran", "cadre-camera")
class Ecran(Camera):
    """Écran séparé : la personne dans un cadre arrondi à bordure, sa tête dépasse du haut du cadre.
    "cadre": [x, y, l, h] (intérieur du cadre), "masque" (obligatoire pour dépasser),
    "fond_cadre": image placée derrière elle dans le cadre (sinon le décor filmé),
    "depasse": hauteur en px au-dessus du cadre où la tête peut sortir (130),
    "arrondi" (44), "bordure" (12), "couleur_bordure" ("#FFFFFF"), "ombre" (true),
    "centre", "zoom", "zoom_lent", "zooms" comme camera."""

    def preparer(self):
        super().preparer()
        self.cadre = self.e.get("cadre", [90, 1010, 900, 760])

    def dessiner(self, img, t):
        if not self.visible(t):
            return
        e, ep = self.e, self.ep
        x, y, l, h = [int(v) for v in self.cadre]
        dep = int(e.get("depasse", 130))
        r = int(e.get("arrondi", 44))
        b = int(e.get("bordure", 12))
        cou = _frames(ep, e["src"])(t)
        # la vidéo couvre le cadre agrandi vers le haut : la tête peut sortir du cadre
        self.cadre = [x, y - dep, l, h + dep]
        box, _ = self.boite(t, cou.width, cou.height)
        self.cadre = [x, y, l, h]
        grand = cou.resize((l, h + dep), Image.BILINEAR, box=box).convert("RGBA")
        m = None
        if e.get("masque"):
            m = _frames(ep, e["masque"], True)(t).resize((l, h + dep), Image.BILINEAR, box=box)
        interieur = grand.crop((0, dep, l, h + dep))
        if e.get("fond_cadre") and m is not None:
            cle = ("fond_cadre", e["fond_cadre"], l, h)
            if cle not in self.cache:
                from PIL import ImageOps
                self.cache[cle] = ImageOps.fit(Image.open(ep.p(e["fond_cadre"])).convert("RGBA"), (l, h), Image.LANCZOS)
            fond = self.cache[cle].copy()
            pers = interieur.copy()
            pers.putalpha(m.crop((0, dep, l, h + dep)))
            fond.alpha_composite(pers)
            interieur = fond
        coins = Image.new("L", (l, h), 0)
        ImageDraw.Draw(coins).rounded_rectangle([0, 0, l - 1, h - 1], radius=r, fill=255)
        interieur.putalpha(coins)
        if e.get("ombre", True):
            om = Image.new("RGBA", (l + 2 * b + 60, h + 2 * b + 60), (0, 0, 0, 0))
            ImageDraw.Draw(om).rounded_rectangle([30, 40, 30 + l + 2 * b, 40 + h + 2 * b], radius=r + b, fill=(40, 30, 20, 60))
            om = om.filter(ImageFilter.GaussianBlur(18))
            img.alpha_composite(om, (x - b - 30, y - b - 30))
        bord = Image.new("RGBA", (l + 2 * b, h + 2 * b), (0, 0, 0, 0))
        ImageDraw.Draw(bord).rounded_rectangle([0, 0, l + 2 * b - 1, h + 2 * b - 1], radius=r + b,
                                               fill=self.c(e.get("couleur_bordure", "#FFFFFF")))
        img.alpha_composite(bord, (x - b, y - b))
        img.alpha_composite(interieur, (x, y))
        if m is not None and dep > 0:
            # la partie de la personne au-dessus du cadre (et sur la bordure du haut) passe devant
            haut = dep + b + 2
            tete = grand.crop((0, 0, l, haut))
            mm = m.crop((0, 0, l, haut))
            # fondu sur les 6 dernières lignes pour éviter une marque nette
            import numpy as np
            a = np.array(mm, dtype=np.float32)
            k = np.ones(haut, dtype=np.float32)
            k[-6:] = np.linspace(1, 0, 6)
            tete.putalpha(Image.fromarray((a * k[:, None]).astype("uint8")))
            img.alpha_composite(tete, (x, y - dep))


def papier(W, H, base, force=1.0, graine=7):
    """Fond papier froissé clair, fait en code : facettes douces, plis fins, grain."""
    import numpy as np
    rng = np.random.default_rng(graine)

    def bruit(n, flou):
        petit = Image.fromarray((rng.random((max(2, H // n), max(2, W // n))) * 255).astype("uint8"))
        return np.array(petit.resize((W, H), Image.BICUBIC).filter(ImageFilter.GaussianBlur(flou)), dtype=np.float32) / 255 - 0.5
    relief = bruit(260, 60) * 8 + bruit(90, 22) * 7
    plis = Image.new("L", (W, H), 128)
    d = ImageDraw.Draw(plis)
    for _ in range(26):
        x0, y0 = rng.random() * W, rng.random() * H
        ang = rng.random() * math.pi
        lg = 250 + rng.random() * 700
        x1, y1 = x0 + math.cos(ang) * lg, y0 + math.sin(ang) * lg
        nx, ny = -math.sin(ang) * 2, math.cos(ang) * 2
        k = 0.5 + rng.random()
        d.line([x0, y0, x1, y1], fill=int(128 - 26 * k), width=2)
        d.line([x0 + nx, y0 + ny, x1 + nx, y1 + ny], fill=int(128 + 20 * k), width=2)
    plis = np.array(plis.filter(ImageFilter.GaussianBlur(1.6)), dtype=np.float32) - 128
    # facettes : un côté de chaque grand pli un peu plus sombre
    fac = np.zeros((H, W), dtype=np.float32)
    yy, xx = np.mgrid[0:H, 0:W]
    for _ in range(7):
        ang = rng.random() * math.pi
        c = rng.random() * (W + H) * 0.8
        cote = (xx * math.cos(ang) + yy * math.sin(ang)) > c
        fac += np.where(cote, -1.0, 1.0) * (1.5 + rng.random() * 2)
    fac = np.array(Image.fromarray(np.clip(fac * 8 + 128, 0, 255).astype("uint8")).filter(ImageFilter.GaussianBlur(3)),
                   dtype=np.float32) / 8 - 16
    grain_ = rng.normal(0, 2.2, (H, W)).astype(np.float32)
    fac -= fac.mean()
    v = (relief + plis * 0.7 + fac * 0.4 + grain_) * force
    arr = np.clip(np.array(base[:3], dtype=np.float32)[None, None, :] + v[:, :, None], 0, 255).astype("uint8")
    return Image.fromarray(arr, "RGB").convert("RGBA")
