"""Briques de dessin du moteur rendu.py : couleurs, polices, texte enrichi, cartes, icônes, fonds.

Tout est dessiné en code avec Pillow (et numpy pour les dégradés et la lumière).
La DA (dict "da" d'episode.json) pilote les contours, les ombres, les rayons, les polices et la façon
de marquer le mot clé. Voir catalogue/bibliotheque.md (et references/moteur.md pour camera, dos, titre) pour la liste des clés.
"""
import math
import os
import re

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

DOSSIER_SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DA_DEFAUT = {
    "police_titre": "Geist.ttf", "graisse_titre": 800,
    "police_texte": None, "graisse_texte": 650,
    "encre": "#14161A", "clair": "#FFFFFF", "accent": "#2F5BFF", "surligneur": None,
    "papier": "#FFFFFF", "fond": "#FFFFFF", "gain": "#2EC27E", "perte": "#E5484D",
    "ombre": "dure", "decalage": 9, "contour": 6, "rayon": 28,
    "marque": "couleur", "casse": "normale",
}


def preparer_da(brut):
    """Complète la DA et accepte l'ancien format (police / graisse / ombre true-false)."""
    da = dict(DA_DEFAUT)
    brut = dict(brut or {})
    if "police" in brut:
        brut.setdefault("police_titre", brut["police"])
        brut.setdefault("police_texte", brut["police"])
    if "graisse" in brut:
        brut.setdefault("graisse_titre", brut["graisse"])
        brut.setdefault("graisse_texte", brut["graisse"])
    da.update(brut)
    if da["police_texte"] is None:
        da["police_texte"] = da["police_titre"]
    if da.get("ombre") is True:
        da["ombre"] = "dure"
    elif da.get("ombre") in (False, None):
        da["ombre"] = "aucune"
    if not da.get("surligneur"):
        da["surligneur"] = da["accent"]
    return da


# ---------------------------------------------------------------- couleurs
def couleur(c, defaut="#000000"):
    if isinstance(c, (tuple, list)):
        return tuple(c) + ((255,) if len(c) == 3 else ())
    c = (c or defaut).lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    v = tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
    return v + ((int(c[6:8], 16),) if len(c) == 8 else (255,))


def luminance(c):
    r, g, b = [x / 255 for x in couleur(c)[:3]]
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def avec_alpha(c, a):
    c = couleur(c)
    return c[:3] + (int(c[3] * a),)


def melange(c1, c2, k):
    a, b = couleur(c1), couleur(c2)
    return tuple(int(a[i] + (b[i] - a[i]) * k) for i in range(4))


class Couleurs:
    """Traduit les mots clés de la DA ("accent", "encre", "papier", "fond", "clair", "gain", "perte")."""

    def __init__(self, da):
        self.da = da

    def __call__(self, c, defaut="encre"):
        if c is None:
            c = defaut
        if isinstance(c, str) and c in ("accent", "encre", "papier", "fond", "clair", "gain", "perte", "surligneur"):
            c = self.da[c]
        return couleur(c)

    def sur(self, fond):
        """Couleur de texte lisible sur ce fond : encre sur clair, clair sur foncé."""
        return couleur(self.da["encre"]) if luminance(self(fond)) > 0.45 else couleur(self.da["clair"])


# ---------------------------------------------------------------- polices
class Polices:
    def __init__(self, base, da):
        self.base, self.da, self.cache = base, da, {}

    def chemin(self, nom):
        """Cherche la police : à côté d'episode.json, dans polices/ de ce dossier ou des deux dossiers
        au-dessus (dossier de la série, kit relu par kit.py), puis dans les polices du skill."""
        if nom:
            cands = [nom]
            d = self.base
            for _ in range(3):
                cands += [os.path.join(d, nom), os.path.join(d, "polices", nom)]
                d = os.path.dirname(d)
            cands += [os.path.join(DOSSIER_SKILL, nom), os.path.join(DOSSIER_SKILL, "assets", "fonts", nom)]
            for p in cands:
                if os.path.isfile(p):
                    return p
        for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/Library/Fonts/Arial Bold.ttf",
                  "C:/Windows/Fonts/arialbd.ttf"):
            if os.path.isfile(p):
                return p
        return None

    def get(self, taille, police="titre", graisse=None):
        """police = "titre", "texte", "mono" ou un nom de fichier .ttf."""
        if police in (None, "titre"):
            nom, g = self.da["police_titre"], self.da["graisse_titre"]
        elif police == "texte":
            nom, g = self.da["police_texte"], self.da["graisse_texte"]
        elif police == "mono":
            nom, g = self.da.get("police_mono", "JetBrainsMono.ttf"), 600
        else:
            nom, g = police, 700
        g = graisse or g
        cle = (nom, int(taille), g)
        if cle not in self.cache:
            p = self.chemin(nom)
            if p is None:
                f = ImageFont.load_default(int(taille))
            else:
                f = ImageFont.truetype(p, int(taille))
                try:
                    vals = []
                    for ax in f.get_variation_axes():
                        n = ax["name"].decode() if isinstance(ax["name"], bytes) else ax["name"]
                        v = ax["default"]
                        if n.lower() == "weight":
                            v = max(ax["minimum"], min(ax["maximum"], g))
                        vals.append(v)
                    f.set_variation_by_axes(vals)
                except Exception:
                    pass
            self.cache[cle] = f
        return self.cache[cle]


# ---------------------------------------------------------------- texte enrichi
# *mot*  = mot clé, marqué selon la DA ("marque")    ==mot== = surligneur    __mot__ = souligné
# [[mot]] = pastille                                  ((mot)) = encadré
BALISES = {"*": "cle", "==": "surligneur", "__": "souligne", "[[": "pastille", "]]": "pastille",
           "((": "encadre", "))": "encadre"}


def jetons(texte):
    """Découpe un texte enrichi en mots stylés. Un retour à la ligne (vrai saut, ou « \\n » écrit tel
    quel) donne au mot suivant le style "saut" : il commencera une nouvelle ligne."""
    texte = texte.replace("\\n", "\n")
    out, actifs = [], set()
    fin_espace = True
    saut = False
    for brut in re.split(r"(\*|==|__|\[\[|\]\]|\(\(|\)\)|\n)", texte):
        if brut == "\n":
            saut = True
            fin_espace = True
            continue
        if brut in BALISES:
            st = BALISES[brut]
            if brut in ("[[", "(("):
                actifs.add(st)
            elif brut in ("]]", "))"):
                actifs.discard(st)
            else:
                actifs.symmetric_difference_update({st})
            continue
        if not brut:
            continue
        for j, mot in enumerate(re.split(r"\s+", brut)):
            if not mot:
                continue
            if re.fullmatch(r"[?!:;»%]+", mot) and out:
                out[-1] = (out[-1][0] + "\u00a0" + mot, out[-1][1])
            elif out and out[-1][0] == "«":
                out[-1] = ("«\u00a0" + mot, set(actifs) | (out[-1][1] & {"saut"}))
            elif j == 0 and out and not fin_espace and not saut:
                out.append((mot, set(actifs) | {"colle"}))  # L'*astuce* : pas d'espace entre L' et astuce
            else:
                out.append((mot, set(actifs) | ({"saut"} if saut and out else set())))
            saut = False
        fin_espace = brut[-1].isspace()
    return out


def texte_brut(texte):
    out = ""
    for m, st in jetons(texte):
        out += ("" if not out else "\n" if "saut" in st else "" if "colle" in st else " ") + m
    return out


def style_effectif(st, da, marque=None):
    """Remplace "cle" par la marque de la DA. Renvoie l'ensemble des styles à dessiner."""
    st = set(st)
    if "cle" in st:
        st.discard("cle")
        st.add(marque or da.get("marque", "couleur"))
    return st


BOITES = ("surligneur", "pastille", "encadre")


def dessiner_texte(texte, police, largeur, coul, ep, aligne="centre", interligne=1.1, nb_mots=None,
                   nb_car=None, contour=0, marque=None, prog=1.0, forcer=None, casse=None, curseur=False, accent=None):
    """Rend un texte enrichi dans une image transparente.

    nb_mots / nb_car : limite les mots ou caractères visibles (mise en page finale conservée).
    prog : avancement 0..1 du dessin des marques (surligneur qui s'étire, soulignement qui se trace).
    forcer : {indice_de_mot: style} pour le karaoké (le mot dit reçoit ce style).
    """
    da, C = ep.da, ep.c
    if casse == "majuscules":
        texte = texte.upper()
    mots = jetons(texte)
    if forcer:
        mots = [(m, (st | {forcer[i]}) if i in forcer else st) for i, (m, st) in enumerate(mots)]
    taille = police.size
    pad = int(taille * 0.2)
    esp = police.getlength(" ")
    lignes, cur, w = [], [], 0.0
    sts = [style_effectif(st, da, marque) for _, st in mots]
    for i, (mot, _) in enumerate(mots):
        st = sts[i]
        extra = 0
        for b in ("pastille", "encadre"):
            if b in st:
                avant = i > 0 and b in sts[i - 1]
                apres = i + 1 < len(mots) and b in sts[i + 1]
                extra = (0 if avant else pad) + (0 if apres else pad)
                g = 0 if avant else pad
                break
        else:
            g = 0
        lw = police.getlength(mot) + extra
        sep = 0 if "colle" in st else esp
        if cur and (("saut" in st) or (w + sep + lw > largeur and sep)):
            lignes.append((cur, w))
            cur, w = [], 0.0
        cur.append((mot, st, lw, g))
        w += (sep if len(cur) > 1 else 0) + lw
    if cur:
        lignes.append((cur, w))
    asc, desc = police.getmetrics()
    hl = int((asc + desc) * interligne)
    larg_img = int(max([largeur] + [lw for _, lw in lignes])) + 2 * pad + 20
    img = Image.new("RGBA", (larg_img, hl * max(1, len(lignes)) + pad + 20), (0, 0, 0, 0))
    img.trop_large = max([0] + [lw for _, lw in lignes]) > largeur + 2  # un mot seul plus large que la place
    img.nb_lignes = len(lignes)
    d = ImageDraw.Draw(img)
    acc, encre = (accent or C("accent")), C("encre")
    surl = C("surligneur") if accent is None or C("surligneur") != C("accent") else acc
    k, car = 0, 0
    places = []  # (ligne, x, y, mot, st, mw, extra, visible_chars)
    for i, (ln, lw) in enumerate(lignes):
        x = pad + 10 + {"centre": (larg_img - 2 * pad - 20 - lw) / 2, "gauche": 0, "droite": larg_img - 2 * pad - 20 - lw}[aligne]
        y = pad // 2 + 10 + i * hl
        for mot, st, mw, extra in ln:
            if nb_mots is not None and k >= nb_mots:
                break
            vis = len(mot)
            if nb_car is not None:
                if car >= nb_car:
                    break
                vis = min(len(mot), nb_car - car)
            if "colle" in st and places and places[-1][0] == i:
                x -= esp
            places.append((i, x, y, mot, st, mw, extra, vis))
            car += len(mot) + 1
            x += mw + esp
            k += 1
    # 1. boîtes (fusionnées quand deux mots voisins ont la même)
    boites = []
    for (i, x, y, mot, st, mw, extra, vis) in places:
        for b in BOITES:
            if b in st:
                if boites and boites[-1][0] == b and boites[-1][1] == i and abs(boites[-1][3] + esp - x) < 2:
                    boites[-1][3] = x + mw
                else:
                    boites.append([b, i, x, x + mw, y])
    for b, i, x0, x1, y in boites:
        if b == "surligneur":
            x0b, x1b = x0 - pad * 0.6, x1 + pad * 0.6
            x1b = x0b + (x1b - x0b) * max(0.0, min(1.0, prog))
            if x1b > x0b + 2:
                d.rounded_rectangle([x0b, y + asc * 0.08, x1b, y + asc + desc * 0.55], radius=int(taille * 0.12), fill=surl)
        elif b == "pastille":
            fond = acc
            r = [x0, y + asc * 0.02, x1, y + asc + desc * 0.75]
            s = 0.6 + 0.4 * max(0.0, min(1.0, prog)) if prog > 0 else 0.0
            if s < 1:
                cx, cy = (r[0] + r[2]) / 2, (r[1] + r[3]) / 2
                r = [cx + (r[0] - cx) * s, cy + (r[1] - cy) * s, cx + (r[2] - cx) * s, cy + (r[3] - cy) * s]
            if r[2] - r[0] > 4:
                bord = max(0, int(da.get("contour", 0)) // 2)
                rr = min(int(da.get("rayon", 20) * 0.7), int((r[3] - r[1]) / 2))
                d.rounded_rectangle(r, radius=rr, fill=fond, outline=encre if bord else None, width=bord)
        elif b == "encadre":
            r = [x0, y + asc * 0.02, x1, y + asc + desc * 0.75]
            d.rounded_rectangle(r, radius=int(da.get("rayon", 20) * 0.6), outline=acc, width=max(4, int(taille * 0.07)))
    # 2. mots
    clair = C("clair")
    for (i, x, y, mot, st, mw, extra, vis) in places:
        fill = coul
        if "couleur" in st:
            fill = acc
        if "surligneur" in st:
            fill = encre if luminance(surl) > 0.5 else clair
        if "pastille" in st and prog >= 0.5:
            fill = encre if luminance(acc) > 0.6 else clair
        txt = mot[:vis]
        d.text((x + extra, y), txt, font=police, fill=fill, stroke_width=contour,
               stroke_fill=encre if contour else None)
        if "souligne" in st:
            ep_s = max(5, int(taille * 0.09))
            yl = y + asc + desc * 0.15
            xe = x + (mw) * max(0.0, min(1.0, prog))
            d.line([(x, yl), (xe, yl)], fill=acc, width=ep_s)
    if curseur and places:
        i, x, y, mot, st, mw, extra, vis = places[-1]
        xc = x + extra + police.getlength(mot[:vis]) + 4
        d.rectangle([xc, y + asc * 0.1, xc + max(4, taille * 0.08), y + asc + desc * 0.3], fill=coul)
    return img


def compter_mots(texte):
    return len(jetons(texte))


# ---------------------------------------------------------------- cartes et ombres
def style_ombre(da, ombre=None):
    o = da.get("ombre", "dure") if ombre is None else ombre
    if o is True:
        o = "dure"
    if o in (False, None):
        o = "aucune"
    return o


def carte(w, h, ep, fond="papier", rayon=None, contour=None, ombre=None, couleur_contour="encre"):
    """Rectangle arrondi dans le style de la DA. Renvoie (image, marge) : le contenu se colle à (marge, marge)."""
    da, C = ep.da, ep.c
    w, h = int(w), int(h)
    r = int(da.get("rayon", 28) if rayon is None else rayon)
    r = min(r, w // 2, h // 2)
    bord = int(da.get("contour", 6) if contour is None else contour)
    o = style_ombre(da, ombre)
    dec = int(da.get("decalage", 9))
    m = 4 + (dec if o == "dure" else 34 if o == "douce" else 0)
    img = Image.new("RGBA", (w + 2 * m, h + 2 * m), (0, 0, 0, 0))
    if o == "dure":
        ImageDraw.Draw(img).rounded_rectangle([m + dec, m + dec, m + w + dec, m + h + dec], radius=r, fill=C(couleur_contour))
    elif o == "douce":
        calque = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(calque).rounded_rectangle([m, m + 14, m + w, m + h + 14], radius=r, fill=(0, 0, 0, 70))
        img = Image.alpha_composite(img, calque.filter(ImageFilter.GaussianBlur(16)))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([m, m, m + w, m + h], radius=r, fill=C(fond), outline=C(couleur_contour) if bord else None, width=bord)
    return img, m


def carte_autour(contenu, fond, ep, marge=26, rogner=True, **kw):
    bb = contenu.getbbox() if rogner else None
    if bb:  # la carte épouse le texte, pas la largeur réservée
        contenu = contenu.crop((max(0, bb[0] - 6), 0, min(contenu.width, bb[2] + 6), contenu.height))
    img, m = carte(contenu.width + 2 * marge, contenu.height + 2 * marge, ep, fond=fond, **kw)
    img.alpha_composite(contenu, (m + marge, m + marge))
    return img


# ---------------------------------------------------------------- icônes vectorielles
def icone(forme, d, coul, fond=None, epaisseur=None):
    """Petites icônes dessinées en code : coche, croix, coeur, etoile, eclair, plus, moins, point, cloche,
    question, exclamation, fleche. fond = couleur d'un rond derrière (ou None)."""
    d = int(d)
    img = Image.new("RGBA", (d, d), (0, 0, 0, 0))
    g = ImageDraw.Draw(img)
    e = int(epaisseur or max(4, d * 0.13))
    if fond is not None:
        g.ellipse([0, 0, d - 1, d - 1], fill=fond)
    k = 0.62 if fond is not None else 0.9
    c0, r = d / 2, d * k / 2

    def P(x, y):
        return (c0 + x * r, c0 + y * r)

    if forme == "coche":
        g.line([P(-0.75, 0.05), P(-0.25, 0.55), P(0.8, -0.6)], fill=coul, width=e, joint="curve")
    elif forme == "croix":
        g.line([P(-0.65, -0.65), P(0.65, 0.65)], fill=coul, width=e)
        g.line([P(-0.65, 0.65), P(0.65, -0.65)], fill=coul, width=e)
    elif forme == "plus":
        g.line([P(0, -0.75), P(0, 0.75)], fill=coul, width=e)
        g.line([P(-0.75, 0), P(0.75, 0)], fill=coul, width=e)
    elif forme == "moins":
        g.line([P(-0.75, 0), P(0.75, 0)], fill=coul, width=e)
    elif forme == "coeur":
        pts = []
        for i in range(60):
            a = i / 60 * 2 * math.pi
            x = 16 * math.sin(a) ** 3
            y = -(13 * math.cos(a) - 5 * math.cos(2 * a) - 2 * math.cos(3 * a) - math.cos(4 * a))
            pts.append(P(x / 17, y / 17 + 0.05))
        g.polygon(pts, fill=coul)
    elif forme == "etoile":
        pts = [P((0.95 if i % 2 == 0 else 0.42) * math.cos(-math.pi / 2 + i * math.pi / 5),
                 (0.95 if i % 2 == 0 else 0.42) * math.sin(-math.pi / 2 + i * math.pi / 5)) for i in range(10)]
        g.polygon(pts, fill=coul)
    elif forme == "eclair":
        g.polygon([P(0.15, -0.95), P(-0.55, 0.12), P(-0.05, 0.12), P(-0.2, 0.95), P(0.55, -0.15), P(0.05, -0.15)], fill=coul)
    elif forme == "point":
        g.ellipse([P(-0.45, -0.45), P(0.45, 0.45)], fill=coul)
    elif forme == "fleche":
        g.line([P(-0.7, 0), P(0.6, 0)], fill=coul, width=e)
        g.polygon([P(0.85, 0), P(0.3, -0.45), P(0.3, 0.45)], fill=coul)
    elif forme == "cloche":
        g.pieslice([P(-0.6, -0.75), P(0.6, 0.6)], 180, 360, fill=coul)
        g.rectangle([P(-0.6, -0.1), P(0.6, 0.45)], fill=coul)
        g.polygon([P(-0.8, 0.5), P(0.8, 0.5), P(0.6, 0.3), P(-0.6, 0.3)], fill=coul)
        g.ellipse([P(-0.2, 0.5), P(0.2, 0.85)], fill=coul)
    elif forme in ("question", "exclamation"):
        f = None
        for p in ("Geist.ttf",):
            chemin = os.path.join(DOSSIER_SKILL, "assets", "fonts", p)
            if os.path.isfile(chemin):
                f = ImageFont.truetype(chemin, int(d * k * 1.15))
        g.text((c0, c0), "?" if forme == "question" else "!", font=f, fill=coul, anchor="mm")
    return img


# ---------------------------------------------------------------- fonds dessinés en code
def _grille_np(W, H):
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    return x, y


def degrade(W, H, c1, c2, angle=90, radial=False, cx=0.5, cy=0.4):
    a, b = np.array(couleur(c1), np.float32), np.array(couleur(c2), np.float32)
    x, y = _grille_np(W, H)
    if radial:
        k = np.sqrt(((x - cx * W) / W) ** 2 + ((y - cy * H) / H) ** 2) / 0.75
    else:
        t = math.radians(angle)
        k = ((x - W / 2) * math.cos(t) + (y - H / 2) * math.sin(t)) / (abs(W * math.cos(t)) + abs(H * math.sin(t))) + 0.5
    k = np.clip(k, 0, 1)[..., None]
    arr = a + (b - a) * k
    return Image.fromarray(arr.astype(np.uint8), "RGBA")


def lumiere(W, H, base, coul, x=0.5, ouverture=22, force=0.8, sol=0.78):
    """Scène d'ambiance : faisceau de lumière qui tombe d'en haut et tache au sol."""
    img = np.array(Image.new("RGBA", (W, H), couleur(base)), np.float32)
    c = np.array(couleur(coul), np.float32)
    xx, yy = _grille_np(W, H)
    sx, sy = x * W, -0.08 * H
    ang = np.degrees(np.arctan2(xx - sx, yy - sy))
    demi = ouverture / 2
    k = np.clip(1 - np.abs(ang) / demi, 0, 1) ** 0.8
    k *= np.clip(1 - (yy / H) * 0.35, 0, 1)
    tache = np.exp(-(((xx - x * W) / (W * 0.33)) ** 2 + ((yy - sol * H) / (H * 0.035)) ** 2))
    k = np.clip(k * 0.55 * force + tache * 0.8 * force, 0, 1)[..., None]
    out = img + (c - img) * k
    out[..., 3] = 255
    return Image.fromarray(out.astype(np.uint8), "RGBA").filter(ImageFilter.GaussianBlur(6))


def halo(W, H, base, coul, x=0.5, y=0.45, rayon=0.55, force=0.85):
    img = np.array(Image.new("RGBA", (W, H), couleur(base)), np.float32)
    c = np.array(couleur(coul), np.float32)
    xx, yy = _grille_np(W, H)
    k = np.exp(-(((xx - x * W) ** 2 + (yy - y * H) ** 2) / (2 * (rayon * W) ** 2)))[..., None] * force
    out = img + (c - img) * k
    out[..., 3] = 255
    return Image.fromarray(out.astype(np.uint8), "RGBA")


def motif(W, H, nom, coul, pas=72, epaisseur=None):
    """Calque transparent répété. Les motifs : quadrillage, points, lignes, colonnes, diagonales, losanges,
    croix, vagues, cercles, damier, rayons."""
    calque = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(calque)
    e = int(epaisseur or (2 if nom in ("quadrillage", "diagonales", "losanges") else 3))
    if nom == "quadrillage":
        for x in range(0, W, pas):
            d.line([(x, 0), (x, H)], fill=coul, width=e)
        for y in range(0, H, pas):
            d.line([(0, y), (W, y)], fill=coul, width=e)
    elif nom == "points":
        r = epaisseur or 4
        for x in range(pas // 2, W, pas):
            for y in range(pas // 2, H, pas):
                d.ellipse([x - r, y - r, x + r, y + r], fill=coul)
    elif nom == "lignes":
        for y in range(pas, H, pas):
            d.line([(0, y), (W, y)], fill=coul, width=e)
    elif nom == "colonnes":
        for x in range(pas, W, pas):
            d.line([(x, 0), (x, H)], fill=coul, width=e)
    elif nom in ("diagonales", "losanges"):
        for k in range(-H, W + H, pas):
            d.line([(k, 0), (k + H, H)], fill=coul, width=e)
            if nom == "losanges":
                d.line([(k, H), (k + H, 0)], fill=coul, width=e)
    elif nom == "croix":
        s = max(6, pas // 7)
        for x in range(pas // 2, W, pas):
            for y in range(pas // 2, H, pas):
                d.line([(x - s, y), (x + s, y)], fill=coul, width=e)
                d.line([(x, y - s), (x, y + s)], fill=coul, width=e)
    elif nom == "vagues":
        for y0 in range(pas // 2, H + pas, pas):
            pts = [(x, y0 + math.sin(x / pas * 2 * math.pi) * pas * 0.18) for x in range(0, W + 8, 8)]
            d.line(pts, fill=coul, width=e)
    elif nom == "cercles":
        r = pas * 0.28
        for i, x in enumerate(range(pas // 2, W + pas, pas)):
            for j, y in enumerate(range(pas // 2, H + pas, pas)):
                d.ellipse([x - r, y - r, x + r, y + r], outline=coul, width=e)
    elif nom == "damier":
        for i, x in enumerate(range(0, W, pas)):
            for j, y in enumerate(range(0, H, pas)):
                if (i + j) % 2:
                    d.rectangle([x, y, x + pas - 1, y + pas - 1], fill=coul)
    elif nom == "rayons":
        cx, cy = W / 2, H * 0.42
        for i in range(0, 24, 2):
            a0, a1 = i / 24 * 2 * math.pi, (i + 1) / 24 * 2 * math.pi
            R = 3000
            d.polygon([(cx, cy), (cx + R * math.cos(a0), cy + R * math.sin(a0)), (cx + R * math.cos(a1), cy + R * math.sin(a1))], fill=coul)
    return calque


def grain(img, force=0.06, graine=3):
    rng = np.random.default_rng(graine)
    arr = np.array(img, np.float32)
    bruit = rng.normal(0, 255 * force, arr.shape[:2])[..., None]
    arr[..., :3] = np.clip(arr[..., :3] + bruit, 0, 255)
    return Image.fromarray(arr.astype(np.uint8), "RGBA")


def vignette(img, force=0.35):
    W, H = img.size
    xx, yy = _grille_np(W, H)
    k = np.clip((((xx / W - 0.5) * 1.6) ** 2 + ((yy / H - 0.5) * 1.25) ** 2) - 0.15, 0, 1) * force
    arr = np.array(img, np.float32)
    arr[..., :3] *= (1 - k)[..., None]
    return Image.fromarray(arr.astype(np.uint8), "RGBA")


def contour_blanc(im, ep_px, coul=(255, 255, 255, 255)):
    """Ajoute le liseré d'autocollant autour d'une image détourée."""
    if ep_px <= 0:
        return im
    m = ep_px + 2
    grand = Image.new("RGBA", (im.width + 2 * m, im.height + 2 * m), (0, 0, 0, 0))
    grand.alpha_composite(im, (m, m))
    a = np.array(grand.getchannel("A")) > 40
    try:
        from scipy.ndimage import binary_dilation
        yy, xx = np.ogrid[-ep_px:ep_px + 1, -ep_px:ep_px + 1]
        dil = binary_dilation(a, structure=(xx ** 2 + yy ** 2) <= ep_px ** 2)
    except ImportError:
        masque = Image.fromarray((a * 255).astype(np.uint8))
        dil = np.array(masque.filter(ImageFilter.GaussianBlur(ep_px / 2))) > 8
        for _ in range(2):
            dil = np.array(Image.fromarray((dil * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(2 * (ep_px // 2) + 1))) > 0
    fond = Image.new("RGBA", grand.size, coul)
    fond.putalpha(Image.fromarray((dil * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1)))
    fond.alpha_composite(grand)
    return fond
