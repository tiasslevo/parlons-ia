#!/usr/bin/env python3
"""Transforme la transcription de la vidéo MONTÉE en timeline.json pour rendu.py.

Chaque ligne (L1, L2…) regroupe quelques mots ; les temps viennent de Whisper,
mot par mot. Les scènes et les apparitions se calent ensuite sur "L3", "L3#2"…

Usage :
  python timeline.py analysis/mots-montes.json --sortie timeline.json
  python timeline.py mots.json --sortie timeline.json --max 2.6 --pause 0.3

Accepte la sortie de transcrire.py ("mots") ou un JSON faster-whisper
("segments" avec "words"). Une ligne se ferme sur un point, une pause, ou une
virgule quand elle dépasse --max secondes. Relire la liste affichée : on peut
corriger un mot mal entendu directement dans timeline.json (garder le même
nombre de mots dans "texte" et "mots").
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def lire_mots(d: dict) -> list[dict]:
    if "mots" in d:
        return [{"mot": m["mot"].strip(), "t0": float(m["debut"]), "t1": float(m["fin"])} for m in d["mots"]]
    out = []
    for s in d.get("segments", []):
        for w in s.get("words", []):
            out.append({"mot": w["word"].strip(), "t0": float(w["start"]), "t1": float(w["end"])})
    return out


def recoller(mots: list[dict]) -> list[dict]:
    """Whisper coupe parfois l'élision (« l » + « 'IA ») : on recolle."""
    out = []
    for m in mots:
        if out and (m["mot"].startswith("'") or m["mot"].startswith("’")):
            out[-1] = {"mot": out[-1]["mot"] + m["mot"], "t0": out[-1]["t0"], "t1": m["t1"]}
        elif m["mot"]:
            out.append(dict(m))
    return out


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("transcription", type=Path)
    p.add_argument("--sortie", type=Path, default=Path("timeline.json"))
    p.add_argument("--max", type=float, default=2.6, help="durée visée d'une ligne, en s")
    p.add_argument("--pause", type=float, default=0.3, help="pause qui ferme une ligne, en s")
    p.add_argument("--duree", type=float, help="durée de la vidéo montée (défaut : fin du dernier mot + 0,3 s)")
    a = p.parse_args()

    mots = recoller(lire_mots(json.loads(a.transcription.read_text(encoding="utf-8"))))
    if not mots:
        raise SystemExit("Aucun mot horodaté dans la transcription.")
    lignes, cur = [], []
    for i, m in enumerate(mots):
        cur.append(m)
        suivant = mots[i + 1] if i + 1 < len(mots) else None
        duree = m["t1"] - cur[0]["t0"]
        fin_phrase = re.search(r"[.!?…]$", m["mot"])
        virgule = m["mot"].endswith(",") and duree > a.max * 0.6
        pause = suivant is not None and suivant["t0"] - m["t1"] >= a.pause
        trop_long = duree > a.max * 1.6
        if suivant is None or fin_phrase or virgule or pause or trop_long:
            lignes.append(cur)
            cur = []
    sortie = {"duree": round(a.duree or mots[-1]["t1"] + 0.3, 3), "lignes": []}
    for n, ln in enumerate(lignes, start=1):
        sortie["lignes"].append({
            "n": n, "t0": round(ln[0]["t0"], 3), "t1": round(ln[-1]["t1"], 3),
            "texte": " ".join(m["mot"] for m in ln),
            "mots": [{"mot": m["mot"], "t0": round(m["t0"], 3), "t1": round(m["t1"], 3)} for m in ln],
        })
    a.sortie.write_text(json.dumps(sortie, ensure_ascii=False, indent=1), encoding="utf-8")
    for ln in sortie["lignes"]:
        print(f"L{ln['n']:<3} {ln['t0']:6.2f}-{ln['t1']:6.2f}  {ln['texte']}")
    print(f"{len(lignes)} lignes -> {a.sortie}")


if __name__ == "__main__":
    main()
