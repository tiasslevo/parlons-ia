#!/usr/bin/env python3
"""Traite la voix montée AVANT tout le reste : bruit, égalisation, compression douce, niveau.

usage :
  python voix.py edit/voix.wav edit/voix-traitee.wav
  python voix.py edit/voix.wav edit/voix-traitee.wav --bruit 6 --cible -14

Chaîne (légère, la voix reste la sienne) :
  passe-haut 80 Hz → réduction de bruit (afftdn, --bruit dB) → -2 dB vers 250 Hz (voix moins
  sourde) → +2 dB vers 3,5 kHz (voix plus claire) → compression douce (2,5:1) →
  gain jusqu'à --cible LUFS intégrés (défaut -14) et limiteur : crêtes ≤ -1 dBTP.
La voix traitée garde exactement la même durée : image et son restent calés.
Mesure finale affichée ; à vérifier aussi à l'écoute par la personne.
"""
import argparse
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import ffmpeg_exe, niveau  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("entree")
    p.add_argument("sortie")
    p.add_argument("--cible", type=float, default=-14.0)
    p.add_argument("--crete", type=float, default=-1.0, help="crête vraie maximale (dBTP)")
    p.add_argument("--bruit", type=float, default=8.0, help="réduction de bruit en dB (0 = aucune, 12 = forte)")
    a = p.parse_args()
    chaine = ["highpass=f=80"]
    if a.bruit > 0:
        chaine.append(f"afftdn=nr={a.bruit}:nf=-45:tn=1")
    chaine += ["equalizer=f=250:t=q:w=1.2:g=-2", "equalizer=f=3500:t=q:w=1.0:g=2",
               "acompressor=threshold=-20dB:ratio=2.5:attack=12:release=180:makeup=2"]
    pre = ",".join(chaine)
    lim = f"alimiter=limit={10 ** ((a.crete - 0.5) / 20):.4f}:attack=3:release=60:level=false"
    tmp = a.sortie + ".etape.wav"
    subprocess.run([ffmpeg_exe(), "-v", "error", "-y", "-i", a.entree, "-af", pre, "-ac", "1", "-ar", "48000", "-c:a", "pcm_s24le", tmp], check=True)
    gain = a.cible - niveau(tmp)[0]
    for _ in range(3):  # le limiteur mange un peu de niveau : on corrige jusqu'à la cible
        subprocess.run([ffmpeg_exe(), "-v", "error", "-y", "-i", tmp, "-af", f"volume={gain:.2f}dB,{lim}",
                        "-ar", "48000", "-c:a", "pcm_s24le", a.sortie], check=True)
        ecart = a.cible - niveau(a.sortie)[0]
        if abs(ecart) < 0.3:
            break
        gain += ecart
    os.remove(tmp)
    i, tp = niveau(a.sortie)
    print(f"Voix traitée : {a.sortie}  {i:.1f} LUFS, crête {tp:.1f} dBTP (cible {a.cible} LUFS, ≤ {a.crete} dBTP)")


if __name__ == "__main__":
    main()
