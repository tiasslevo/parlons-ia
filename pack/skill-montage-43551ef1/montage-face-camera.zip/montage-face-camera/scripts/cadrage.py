#!/usr/bin/env python3
"""Mesure le cadrage de départ (où sont la tête et les épaules) et propose des recadrages.

usage :
  python cadrage.py edit/masque.mp4
  python cadrage.py edit/masque.mp4 --json analysis/cadrage.json

Lit le masque de détourage toutes les secondes, mesure le haut de la tête, la largeur de la
tête et la ligne des épaules, puis classe le plan (très serré, serré, moyen, large) et propose
trois réglages pour "camera" et pour "ecran" (l'écran séparé) :
  garder   : tel que filmé (zoom 1) ;
  un peu   : un peu plus serré ;
  serre    : tête et épaules grandes à l'écran.
C'est la personne qui choisit. Copier "zoom" et "centre" du réglage choisi dans episode.json
(les deux "camera" d'une scène, ou l'"ecran").
"""
import argparse
import io
import json
import os
import subprocess
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import ffmpeg_exe  # noqa: E402


def frames(masque, pas=1.0):
    r = subprocess.run([ffmpeg_exe(), "-v", "error", "-i", masque, "-vf", f"fps=1/{pas},format=gray",
                        "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True)
    data, out = r.stdout, []
    sig = b"\x89PNG\r\n\x1a\n"
    for morceau in data.split(sig)[1:]:
        out.append(np.array(Image.open(io.BytesIO(sig + morceau))) > 128)
    return out


def mesurer(m):
    H, W = m.shape
    lignes = np.where(m.any(1))[0]
    if len(lignes) == 0:
        return None
    haut = int(lignes[0])
    larg = m.sum(1)
    bande = slice(haut, min(H, haut + int(H * 0.12)))
    tete = int(larg[bande].max())
    cols = np.where(m[bande].any(0))[0]
    cx = float(cols.mean())
    epaules = next((y for y in range(haut, H) if larg[y] > 1.7 * tete), H)
    return {"haut": haut, "tete": tete, "cx": cx, "epaules": int(epaules)}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("masque")
    p.add_argument("--json")
    p.add_argument("--haut-tete", type=float, default=0.27, help="place visée du haut de la tête (part de la hauteur)")
    p.add_argument("--cadre", default="90,1080,900,620", help="cadre intérieur de l'écran séparé x,y,l,h")
    p.add_argument("--depasse", type=int, default=150)
    a = p.parse_args()
    ms = [x for x in (mesurer(f) for f in frames(a.masque)) if x]
    if not ms:
        sys.exit("Masque vide : refaire le détourage.")
    H, W = 1920, 1080
    med = {k: float(np.median([x[k] for x in ms])) for k in ms[0]}
    r = med["tete"] / W
    plan = "très serré" if r > 0.55 else "serré" if r > 0.4 else "moyen" if r > 0.28 else "large (assis loin ou debout)"
    print(f"Plan de départ : {plan}. Tête : {r * 100:.0f} % de la largeur, haut de la tête à y = {med['haut']:.0f}, "
          f"épaules vers y = {med['epaules']:.0f}, centre x = {med['cx']:.0f}.")

    def camera(z):
        cy = med["haut"] - a.haut_tete * H / z + H / (2 * z)
        return {"zoom": round(z, 2), "centre": [round(med["cx"]), round(cy)]}

    def ecran(z):
        x, y, l, h = [int(v) for v in a.cadre.split(",")]
        s0 = max(l / W, (h + a.depasse) / H) * z
        haut_box = med["haut"] - 50 / s0  # cheveux à 50 px du haut : ils sortent du cadre
        return {"zoom": round(z, 2), "centre": [round(med["cx"]), round(haut_box + (h + a.depasse) / (2 * s0))]}

    serre = min(2.2, max(1.2, 0.62 / r))
    choix = {"garder": 1.0, "un peu": round(1 + (serre - 1) * 0.45, 2), "serre": serre}
    reco = "garder" if r >= 0.4 else "un peu" if r >= 0.3 else "serre"
    sortie = {"plan": plan, "mesures": med, "conseil": reco, "reglages": {}}
    for nom, z in choix.items():
        sortie["reglages"][nom] = {"camera": camera(z), "ecran": ecran(z)}
        mark = "  ← conseillé" if nom == reco else ""
        print(f"  {nom:7s} camera {sortie['reglages'][nom]['camera']}  ecran {sortie['reglages'][nom]['ecran']}{mark}")
    print("Montre l'image de contrôle de chaque réglage et laisse la personne choisir.")
    if a.json:
        json.dump(sortie, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
