#!/usr/bin/env python3
"""Assemble les segments gardés d'un rush (EDL) en une vidéo de dialogue et un WAV.

EDL attendue (JSON) :
{
  "source": "source/rush.mov",
  "fps": 30,
  "segments": [
    {"debut": 0.42, "fin": 3.88, "raison": "accroche"},
    {"debut": 5.10, "fin": 9.02, "raison": "reprise : 2e prise gardée"}
  ]
}
Les temps sont en secondes dans le rush ; la fin est exclusive. Ils sont
arrondis à la frame la plus proche pour que l'image et le son restent alignés.

Usage :
  python appliquer_edl.py edit/edl.json --video edit/dialogue.mp4 --wav edit/voix.wav
  python appliquer_edl.py edit/edl.json --video edit/dialogue.mp4 --vertical 1080x1920

Le script écrit aussi edit/edl-resolue.json : pour chaque segment, sa place dans
la vidéo montée (utile pour retrouver un passage dans le rush).
Nécessite ffmpeg dans le PATH (ou --ffmpeg CHEMIN).
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("edl", type=Path)
    p.add_argument("--video", type=Path, required=True, help="MP4 de dialogue à écrire")
    p.add_argument("--wav", type=Path, help="WAV PCM 48 kHz de la voix montée")
    p.add_argument("--vertical", help="recadre au centre puis redimensionne, ex. 1080x1920")
    p.add_argument("--piste", type=int, default=0, help="index de la piste audio")
    p.add_argument("--fondu-ms", type=float, default=12.0,
                   help="micro-fondu audio à chaque raccord, contre les clics (défaut 12 ms)")
    p.add_argument("--crf", type=int, default=18)
    p.add_argument("--ffmpeg", default="ffmpeg")
    a = p.parse_args()

    edl = json.loads(a.edl.read_text(encoding="utf-8"))
    fps = float(edl.get("fps", 30))
    source = Path(edl["source"])
    if not source.is_absolute():
        source = (a.edl.parent / source) if not source.exists() else source
    if not source.exists():
        sys.exit(f"Source introuvable : {source}")
    segments = edl["segments"]
    if not segments:
        sys.exit("EDL vide.")

    fondu = a.fondu_ms / 1000.0
    filtres = []
    resolus = []
    position = 0
    for i, seg in enumerate(segments):
        f0 = round(float(seg["debut"]) * fps)
        f1 = round(float(seg["fin"]) * fps)
        if f1 <= f0:
            sys.exit(f"Segment {i} vide ou inversé : {seg}")
        t0, t1 = f0 / fps, f1 / fps
        dur = t1 - t0
        video = f"[0:v]trim=start={t0:.6f}:end={t1:.6f},setpts=PTS-STARTPTS,fps={fps:g}"
        if a.vertical:
            w, h = a.vertical.lower().split("x")
            video += (f",scale={w}:{h}:force_original_aspect_ratio=increase,"
                      f"crop={w}:{h},setsar=1")
        filtres.append(video + f"[v{i}]")
        filtres.append(
            f"[0:a:{a.piste}]atrim=start={t0:.6f}:end={t1:.6f},asetpts=PTS-STARTPTS,"
            f"aresample=48000,afade=t=in:d={fondu:.4f},"
            f"afade=t=out:st={max(0.0, dur - fondu):.4f}:d={fondu:.4f}[a{i}]"
        )
        resolus.append({
            "segment": i,
            "source_debut": round(t0, 4), "source_fin": round(t1, 4),
            "monte_debut": round(position / fps, 4),
            "frames": f1 - f0,
            "raison": seg.get("raison", ""),
        })
        position += f1 - f0

    entrees = "".join(f"[v{i}][a{i}]" for i in range(len(segments)))
    if a.wav:
        filtres.append(f"{entrees}concat=n={len(segments)}:v=1:a=1[v][acat]")
        filtres.append("[acat]asplit=2[a][aw]")
    else:
        filtres.append(f"{entrees}concat=n={len(segments)}:v=1:a=1[v][a]")
    graphe = ";\n".join(filtres)

    a.video.parent.mkdir(parents=True, exist_ok=True)
    script_filtre = a.video.with_suffix(".filtres.txt")
    script_filtre.write_text(graphe, encoding="utf-8")

    cmd = [a.ffmpeg, "-hide_banner", "-y", "-i", str(source),
           "-filter_complex_script", str(script_filtre),
           "-map", "[v]", "-map", "[a]",
           "-c:v", "libx264", "-crf", str(a.crf), "-preset", "medium",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
           "-movflags", "+faststart", str(a.video)]
    if a.wav:
        a.wav.parent.mkdir(parents=True, exist_ok=True)
        cmd += ["-map", "[aw]", "-c:a", "pcm_s16le", "-ar", "48000", str(a.wav)]
    subprocess.run(cmd, check=True)

    rapport = {
        "source": str(source), "fps": fps,
        "frames_total": position, "duree_s": round(position / fps, 3),
        "segments": resolus,
    }
    sortie = a.edl.with_name("edl-resolue.json")
    sortie.write_text(json.dumps(rapport, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{len(segments)} segments, {position} frames ({position / fps:.2f} s) -> {a.video}")


if __name__ == "__main__":
    main()
