---
name: pub-motion
description: Pubs vidéo motion design pour commerces (TikTok, Reels, statut WhatsApp) : entretien, 3 idées en esquisse, images à générer, rendu MP4 en code, musique, kit de marque.
---

# Pub motion design pour un commerce

Ce skill fabrique des pubs vidéo verticales (1080 × 1920, 15 à 20 s par défaut) pour des boutiques,
restaurants, salons, marques. Une pub **présente et raconte** : on voit ce qu'on vend, l'offre, le lieu,
et on finit sur l'action (WhatsApp, adresse). Ce n'est pas du motion « digital » abstrait.

La variété vient de **l'idée** (l'histoire racontée), pas d'un style figé. Chaque pub combine trois
choix séparés :
1. **l'idée** : [references/idees.md](references/idees.md) (une douzaine de départ, l'idée de la personne passe avant) ;
2. **le traitement** (la matière) : [references/traitements.md](references/traitements.md) ;
3. **le rythme** : posé, vif ou rebondissant (tempo de la musique et façon de bouger).

Répondre en français simple, sans jargon : la personne n'est pas technique. Lire les fichiers de
`references/` quand l'étape en a besoin, pas tous d'un coup.

## 1. Au début de chaque conversation

**Où tu tournes** :

| Mode | Comment le reconnaître | Rendu |
|---|---|---|
| **App** | app Claude avec exécution de code, fichiers perdus en fin de conversation | `scripts/` dans le bac à sable |
| **Studio** | Claude Code sur l'ordinateur de la personne | `scripts/` en local, dossier de marque gardé |
| **Sans code** | pas d'exécution de code | fil de la pub + prompts ; montage CapCut par la personne |

```bash
python3 -c "import PIL, numpy; print('ok')"
ffmpeg -version | head -1 || pip install imageio-ffmpeg
```

Dans l'app, une vidéo de plus de 30 Mo ne se télécharge pas : rendre avec `--qualite legere` si besoin.

**Nouvelle marque ou marque connue ?** Chercher d'abord un kit : `marque.md` dans les fichiers du
Projet, `kit-*.zip` joint, ou dossier de marque (Studio). S'il existe :
`python scripts/kit.py lire <kit.zip ou dossier> --vers ma-marque`, relire « Ce qui a plu », et passer
à l'étape 3 sans reposer les questions déjà répondues. Détail des trois cas : [references/kit.md](references/kit.md).

## 2. Première fois : l'entretien

[references/entretien.md](references/entretien.md). Questions courtes, en un ou deux messages : ce
qu'il vend et à qui, ce qui le rend unique, l'offre du moment, l'action attendue (numéro, adresse au
caractère près), logo et photos, une envie de style ou une référence, voix off oui/non. **Si la
personne a une idée de pub, elle passe avant la liste.** Ce qu'elle ne sait pas, tu le décides.

## 3. Trois propositions en esquisse

Proposer **3 combinaisons idée + traitement + rythme vraiment différentes**, adaptées à ce commerce
(règles de choix : [references/idees.md](references/idees.md#choisir-les-3)). Pour chacune, en 5 lignes :
le nom, la combinaison, les 3 temps de l'histoire (accroche · produit/preuve · offre et fin), ce qu'on
voit dans la première seconde, ce qu'il faudra générer.

Puis une **image d'esquisse fixe par proposition, faite par le moteur** : écrire un petit `pub.json`
d'un plan par proposition (l'écran le plus parlant), avec les vraies photos si elles existent, sinon
des maquettes (`"src": "maquette:bouteille;couleur=accent"`, liste dans `scripts/maquettes.py`), puis
```bash
python scripts/moteur.py esquisse-1.json --image 1.5 --sortie esquisses/1.png
python scripts/planche_images.py esquisses/ esquisses/planche.jpg --fond "#FFFFFF"
```
Montrer la planche, dire que c'est une esquisse fixe, finir par : « Choisis 1, 2 ou 3, ou dis-moi ce
que tu veux mélanger. »

## 4. Le fil de la pub (après le choix)

Envoyer, et **attendre la validation** avant toute dépense :
1. **Le fil temps par temps** en tableau (6 à 9 lignes) : secondes, ce qu'on voit, texte à l'écran, son.
2. **La voix off** si demandée : environ 13 s de parole pour 18 s de pub, phrases courtes, nombres en
   lettres, le nom à la fin. Voix : [references/son.md](references/son.md).
3. **Les éléments à générer** : [references/images.md](references/images.md). Des images **séparées et
   détourables** (produit, décor de fond, objets, personnage), avec les prompts prêts à coller dans
   ChatGPT ou tout générateur relié (Codex, Gemini…). Les fonds unis, dégradés, motifs, formes,
   pastilles, boutons, téléphone, textes se font **en code** : ne pas les générer.

Quand les images arrivent : `python scripts/detoure.py recues/ elements/` (fond blanc ou uni retiré),
puis regarder chaque image détourée (`python scripts/planche_images.py elements/`).

## 5. Validation sur 4 images, puis vidéo

1. Écrire `pub.json` : [references/bibliotheque.md](references/bibliotheque.md) (tout ce que le moteur
   sait faire : plans, caméra, profondeur, révélations, chutes, typo cinétique, transitions,
   traitements, fin). `python scripts/moteur.py --catalogue` donne la liste courte.
2. Contrôler : `python scripts/moteur.py pub.json --verifier` → corriger **chaque ligne ✗** (zones
   TikTok, texte coupé ou trop petit, temps de lecture, texte sur le produit, produit trop tard, fin
   trop courte, image figée), relire la liste des textes au caractère près, regarder
   `controle/planche.jpg`.
3. `python scripts/moteur.py pub.json --validation` → `controle/validation.jpg` (première seconde,
   produit, offre, fin). La montrer. **Pas de vidéo avant l'accord.**
4. Rendu : `python scripts/moteur.py pub.json --essai` (2 s, estime le temps), puis
   `python scripts/moteur.py pub.json` → `sortie/muette.mp4` + `sortie/cues.json`.
5. Son : [references/son.md](references/son.md).
   `python scripts/musique.py pub.json` (musique composée en code sur le tempo, creux avant le logo),
   puis `python scripts/mixage.py --video sortie/muette.mp4 --musique sortie/musique.wav [--voix voix.mp3]`
   → `sortie/pub.mp4` et `sortie/pub-sans-musique.mp4`.
6. Vérifier avant de livrer : extraire quelques images de la vidéo finale et les regarder, durée, taille.
   Livrer les deux MP4 en pièces jointes, avec 3 lignes (format et durée, voix, musique) et une légende
   courte avec 3 à 5 hashtags.

## 6. Première pub seulement : le kit de marque

Remplir `ma-marque/marque.md` (modèle : [assets/fiche-marque.md](assets/fiche-marque.md)) : couleurs,
polices, logo, ton, coordonnées exactes, traitements et rythme qui ont plu, idées déjà faites,
éléments récurrents, style d'image validé. Ranger logo et images détourées dans `logo/` et `elements/`.
`python scripts/kit.py creer ma-marque` → `kit-<marque>.zip`, à donner avec l'explication de
[references/kit.md](references/kit.md). À refaire quand quelque chose change.

**Pubs suivantes** : même marque (couleurs, polices, logo, fin), mais une **autre idée** que les
précédentes (relire « idées déjà utilisées »). Le traitement peut rester ou changer avec son accord.

## Règles de pub qui ne bougent pas

- **On voit ce qu'on vend tout de suite** : quelque chose bouge et dit de quoi on parle dès la première
  image ; le produit est visible avant 3 s. Jamais d'écran vide, jamais le logo en ouverture.
- **Une idée par écran**, **3 à 6 mots par écran**, jamais tout le texte de la voix. Texte de 60 px et
  plus, contraste net, lisible deux fois (≈ 1 s pour 3 mots). La pub se comprend sans le son.
- **Zones TikTok/Instagram libres** : rien d'important en haut (y < 200), en bas (y > 1500), ni à droite
  dans la moitié basse (x > 930 pour y > 860). `--verifier` les contrôle.
- **Fonds clairs par défaut** (crème, blanc chaud, pastel, couleur claire de la marque). Un fond sombre
  seulement si la personne le demande ou si sa marque l'impose.
- **La fin** : logo ou nom, puis l'action et le contact, lisibles au moins 2 s.
- **Rien d'inventé** : textes, prix, numéros et adresses recopiés au caractère près ; pas d'avis client,
  de chiffre ou de promesse que la personne n'a pas donnés. Une offre se dit telle qu'elle est.
- **Le mouvement a un sens** pour ce commerce (le produit tombe dans le panier, la conversation
  aboutit à une commande) ; rien ne reste figé plus d'une demi-seconde hors écrans à lire.
- **Validation avant dépense** : pas d'images générées ni de voix avant le fil validé.
- **Droits** : polices OFL fournies, bruitages et musique faits en code (libres), photos de la personne,
  images qu'elle a générées. Pas de logo, musique, personnage ou pub d'une autre marque. Le téléphone
  dessiné imite une messagerie sans en reprendre le logo.
- **Honnêteté** : ne jamais dire qu'une vidéo est prête, qu'une voix est générée ou qu'un fichier est
  envoyé sans l'avoir vérifié.

Pour corriger une pub sur les retours de la personne : [references/corrections.md](references/corrections.md).
Changer seulement ce qui est demandé ; montrer l'image fixe concernée avant de refaire la vidéo.
