# Le moteur : format de pub.json

Exemples complets : `assets/exemples/*.json` (à copier puis adapter). Liste courte : `moteur.py --catalogue`.

```json
{"tempo": 104, "rythme": "vif", "marque": {"nom": "…", "couleurs": {…}, "polices": {"titre": "…", "texte": "…"}},
 "traitement": {…}, "plans": [{"nom": "accroche", "temps": 8, "fond": {…}, "camera": "avance", "entree": "pousse-gauche",
 "elements": [ … ]}], "permanent": [ … ]}
```

**Repères** : coordonnées en px sur 1080 × 1920, `x`/`y` = centre. Couleurs : noms de la marque (`fond`,
`encre`, `accent`, `second`, `clair`, `papier`, `ombre`, `whatsapp`), `#hex`, transparence `"encre/0.5"`.
Polices : `titre`, `texte`, `main`, `chiffre` ou un `.ttf` (fournies : Bricolage, Geist, DMSerifDisplay,
Fredoka, ArchivoBlack, Anton, Caveat). Images : chemin relatif, ou `"maquette:bouteille;couleur=accent"`
(bouteille, pot, petale, feuille, rondelle, verre, sac, boutique, soleil, logo, volume).
**Temps** : `1.2` s, `"2t"` (temps de musique), `"2t+0.1"`, `"fin-1t"`, `"@8t"` (depuis le début de la pub).
Plan : `"temps": 8` ou `"duree": 2.4`.

| Rubrique | Clés |
|---|---|
| Fond (`fond`) | `"fond"` (uni), `degrade` (de, vers, angle, radial), `motif` (points rayures lignes quadrillage damier vagues rayons), `partage` (gauche, droite, coupe, pente), `image` (src, flou, eclaircir) ; options `halo`, `sol`+`sol_y`, `papier`, `aquarelle`, `z` |
| Caméra (`camera`) | `fixe`, `avance`, `recule`, `plonge` (`vers_point`), `panoramique-gauche/droite`, `travelling-gauche/droite`, `monte`, `descend`, `respire` ; `{"type": "avance", "force": 0.6}` ; images clés `[{"a": 0, "z": 0}, {"a": "4t", "z": 0.2, "y": 1060}]` ; `secousses: ["4t"]` |
| Profondeur | `z` par élément (0 écran, >0 loin et plus lent, <0 devant) = parallaxe ; `mise_au_point: {"z": 0, "force": 5}` = flou de profondeur ; `net`, `flou` |
| Transitions (`entree`, `duree_entree`) | `coupe`, `pousse-*`, `recouvre-*`, `volet-*`, `diagonale`, `rond` (`centre_entree`), `rideau`, `zoom`, `flash`, `forme`/`tache` (`couleur_entree`), `bande`, `papier`, `fondu` ; bruitage auto, `son_entree` |
| Clés communes | `a`, `jusqua`, `x`, `y`, `z`, `echelle`, `rot`, `opacite`, `ancre`, `role` (produit, logo, action, contact, offre, decor, mention), `ombre` (`posee`/`portee`), `son`, `fixe_ecran`, `mouvements` `[{"a", "fin", "x", "y", "echelle", "rot", "w", "h", "rayon", "couleur", "texte", "courbe"}]` |
| Entrées (`anim`) | `pop`, `zoom`, `monte`, `descend`, `glisse-gauche/droite`, `tombe` (gravité + rebonds, `rebond`, `hauteur_chute`, `rot_chute`), `tourne`, `elastique`, `fondu`, `volet-*`, `rideau`, `diagonale`, `rond`, `ecrase`, `dessine`, `projete`, `aucune` |
| Sorties (`sortie`) | `reduit`, `fondu`, `monte`, `descend`, `glisse-*`, `volet-*`, `tombe` |
| Boucles (`boucle`) | `respire`, `balance`, `flotte`, `pulse` (sur chaque temps), `tourne` (`vitesse_rot`), `derive` |
| `image` | `src`, `largeur`/`hauteur`, `bord`, `masque` (rond arrondi arche blob pastille), `traitements` |
| `forme` | `forme` : rect (`rayon`) pastille rond etoile eclat blob (`ondule`) arche goutte coeur vague losange triangle bulle ; `w`, `h`, `couleur`, `contour` |
| `texte` | `texte` (`*mot*` = accent, `\n`), `taille`, `police`, `couleur`, `largeur`, `mode` : bloc, mots (`cadence`), lettres, masque, machine, ecrit ; `surligne`, `fond` (étiquette), `contour`, `casse` |
| `prix` | `valeur`, `ancien` (barré), `pastille` (éclat qui tourne) ; tombe et rebondit |
| `compteur` | `de`, `vers`, `duree`, `prefixe`, `suffixe` |
| `tampon` | `texte`, `forme` (rond), `rot` ; écrasé + impact |
| `bouton` | `texte`, `icone` (discussion telephone lieu panier coeur etoile coche horloge fleche), `couleur`, `clic` (doigt qui appuie + onde + clic), `largeur_max` |
| `trait` | `forme` : fleche ligne souligne vague cercle (`x y w h`) ; `points`, `courbure`, `epaisseur` ; se dessine |
| `telephone` | `largeur`, `nom`, `statut`, `avatar`, `messages` `[{"de": "client"/"boutique", "texte" ou "image", "a", "heure", "ecrit"}]` ; « en train d'écrire », défilement |
| Composés | `fin` (logo ou nom, slogan, action, contact, adresse, `pas`, `clic`) · `avis` (texte, nom) · `pluie` (srcs, nombre, zone_x, sol, ecart, rebond) · `flotte` (srcs, nombre, z) · `confettis` · `sequence` (textes, chaque) |
| Traitements d'image (`traitements`) | `noir_blanc`, `{"bichromie": [c1, c2]}`, `{"trame": c}`, `{"bord_blanc": 12}`, `{"bord_papier": 14}`, `relief`, `pate`, `aquarelle`, `{"masque": "arche"}`, `polaroid`, `{"flou": 4}` |
| Traitement global (`traitement`) | `saccade` (12 i/s), `tremble`, `papier`, `grain`, `formes` ([relief] [pate] [aquarelle]), `bord_irregulier` |

**Recettes.** Morph rond → bouton : `forme` `rect` w 200 h 200 `rayon` 100, puis `mouvements`
`{"w": 700, "h": 130, "rayon": 65, "couleur": "whatsapp"}`. Avant/après : deux `image` au même endroit,
la seconde en `volet-gauche`. Continuité : même objet au même endroit avec `anim: aucune`, transition
`rond` centrée sur lui. Objets `flotte` : z > 0 et d'une autre couleur que le texte.

**Contrôle** : `--image 3.2 --zones`, `--verifier` (zones, texte coupé/petit/trop long/sur le produit,
temps de lecture, produit avant 3 s, fin ≥ 2 s, image figée, liste des textes), `--validation`,
`--essai`, `--de 4 --jusqua 8`, `--qualite legere`. Environ 0,2 s par image et par cœur.
