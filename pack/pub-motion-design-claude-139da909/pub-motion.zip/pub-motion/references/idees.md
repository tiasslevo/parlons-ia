# Les idées de pub

Une idée = l'histoire de la pub, en **3 temps** : accroche (0-3 s, le produit déjà visible) · cœur
(produit, preuve, geste) · offre et fin (logo, action, contact). **L'idée de la personne passe avant
cette liste**, qui n'est qu'un départ.

| Idée | Les 3 temps | Pour | Traitements qui la servent | Piège |
|---|---|---|---|---|
| Le voyage du produit | d'où il vient · ce qu'il devient · chez toi | jus, épices, tissus, karité | photo mise en scène, aquarelle, papier | origine sans produit visible |
| Une journée dans la boutique | 7 h on ouvre · midi ça part · le soir il en reste | restos, boulangeries, salons | papier découpé, illustration, vue de dessus | 3 plans identiques |
| Le client qui se pose une question | sa question · le produit répond · comment l'avoir | besoin simple (chaleur, faim, cadeau) | illustration, 3D douce, pâte | question vague |
| Le détail qu'on ne voit pas | gros plan du geste · « fait main » · le produit fini | artisanat, couture, tresses, pâtisserie | photo macro, aquarelle, typo | mains génériques |
| La conversation WhatsApp | le client écrit · réponse prix + photo · « je prends » | tout commerce qui vend par WhatsApp | interface téléphone | bulles trop longues |
| Le manifeste | ce qu'on refuse · ce qu'on promet · le produit seul | parti pris : naturel, local | typographique, photo | promesse inventée |
| L'histoire du fondateur | qui, depuis quand · ce qui n'a pas changé · aujourd'hui | maisons familiales | aquarelle, bichromie, papier | date inventée |
| Eux / nous | écran partagé · la différence · tu gagnes | sucre, prix, délai | partagé + photo, typo | concurrent reconnaissable, chiffre non prouvé |
| Le compte à rebours | « plus que 3 jours » · l'offre exacte · jusqu'à quand | promos, fêtes, lancements | 3D douce, pâte, typo | fausse urgence |
| Le témoignage client | le client · sa phrase · étoiles, action | salons, restos, services | photo, aquarelle, illustration | avis inventé |
| La nouveauté dévoilée | caché · dévoilé · nom, prix, où | nouveau produit, ouverture | pâte, 3D douce, papier | dévoilement trop long |
| La recette / le geste en 3 temps | étape 1 · 2 · 3 et résultat | boissons, cuisine, routines | vue de dessus, papier, illustration | plus de 3 étapes |
| Avant / après | avant · le volet passe · après | salons, réparation, déco | photo, écran partagé | photos qui promettent trop |

## Choisir les 3
- Trois **idées** différentes (jamais la même idée en deux styles), trois traitements différents, au moins un rythme différent.
- L'idée de la personne = proposition 1. Une attendue pour son métier, une plus audacieuse, une entre les deux.
- Vérifier qu'on a ce qu'il faut : pas de témoignage sans vrai avis, pas de compte à rebours sans vraie date, pas de fondateur sans vraie histoire.
- Pubs suivantes : éviter les idées déjà faites (`marque.md`).

## Durée
À 100 BPM, 1 temps = 0,6 s ; 18 s ≈ 30 temps : accroche 6-8 · cœur 12-16 · offre 4-6 · fin 6-8.
Pour allonger, ajouter des actions au cœur, ne jamais ralentir.
