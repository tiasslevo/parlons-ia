# Le kit de marque

Le skill est le même pour tous. Le **kit** garde ce qui rend les pubs d'un commerce reconnaissables :
`marque.md` (couleurs, polices, logo, ton, coordonnées exactes, traitements et rythme qui ont plu,
idées déjà faites, éléments récurrents, style d'image validé, voix), `marque.json`, `logo/`,
`elements/` (images détourées réutilisables), `polices/`, `apercu.jpg`, `LISEZ-MOI.md`.

**Quand** : à la fin de la première pub validée (`python scripts/kit.py creer ma-marque`), puis à
chaque changement (nouvelle couleur, nouveau produit récurrent, idée faite à ajouter). Un seul kit
valable : rappeler de remplacer l'ancien. Plus de 30 Mo : `--max-px 1200`.

**Les pubs suivantes, trois cas** (l'expliquer avec ces mots) :
- **a. Projet Claude** : « Ajoute `marque.md`, `apercu.jpg`, ton logo et les images de `elements/` dans
  les fichiers de ton Projet. Ensuite, dans le Projet, écris seulement : nouvelle pub pour… »
  Au début : lire `marque.md`, chercher les fichiers dans le bac à sable et lancer
  `python scripts/kit.py lire <dossier> --vers ma-marque`. Si les images ne sont pas lisibles par le
  code, demander le ZIP.
- **b. Conversation hors Projet** : « Joins `kit-<marque>.zip` au premier message. » Puis `kit.py lire kit.zip`.
- **c. Claude Code** : le dossier de la marque reste sur l'ordinateur ; lancer Claude Code dedans.

Ensuite : recopier le bloc `"marque"` tel quel dans pub.json, reprendre la fin (logo, action, contact),
choisir **une idée pas encore faite**. Ne rien réinventer de la marque sans son accord.
