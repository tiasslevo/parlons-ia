# Les éléments à générer

Générer seulement ce que le code ne sait pas faire : **le produit** (si pas de bonne photo), **le décor
de fond** (lieu, table), **les objets** (ingrédients, outils), **le personnage** (une image par
expression). Fonds unis, dégradés, motifs, formes, boutons, téléphone, textes, chiffres en volume : en code.

Règles des prompts (un bloc de code par image, numérotés, à coller dans ChatGPT ou tout générateur relié) :
- commencer par le **bloc de style** du traitement (traitements.md), identique pour toutes les images de la pub ;
- **une image = un sujet**, entier, avec de la marge, **fond blanc uni** (ou uni d'une couleur absente de
  l'objet), **sans ombre portée**, sans texte ; format vertical 2:3 pour un objet, 9:16 pour un décor ;
- le décor se génère **sans le produit** et sans texte, avec de la place libre au centre ;
- le produit de la personne : joindre sa photo au générateur et demander « le même produit, mêmes
  couleurs, même étiquette » ; vérifier ensuite l'étiquette lettre par lettre (sinon garder la photo) ;
- même conversation ChatGPT pour toute la série d'images (cohérence) ;
- sous chaque prompt, une ligne : où l'image sert et comment elle bouge.

Après réception : `python scripts/detoure.py recues/ elements/` (le blanc relié aux bords devient
transparent ; `--contour 12` ajoute un bord blanc), puis `python scripts/planche_images.py elements/`
et regarder chaque image (liseré gris, morceau mangé, étiquette fausse). Corriger ou redemander.
Le style d'image validé va dans `marque.md` pour les pubs suivantes.
