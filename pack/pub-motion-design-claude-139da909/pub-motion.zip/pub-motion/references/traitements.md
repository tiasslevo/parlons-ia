# Traitements (la matière) et rythmes

Le traitement se choisit **après l'idée**, pour la servir. Les couleurs viennent de la marque ; on peut
mélanger. Fonds clairs par défaut. La colonne « Images » est le bloc de style à mettre en tête des
prompts (voir images.md).

| Traitement | Réglages du moteur | Images à générer | Rythme | Photos moyennes |
|---|---|---|---|---|
| Photo produit mise en scène | fond `degrade` + `halo` + `sol`, `mise_au_point`, produit `ombre: posee`, `flotte` derrière, caméra `avance` | « photo produit de studio, lumière douce, fond blanc uni, objet entier avec marge, sans ombre » | posé | détourer, ombre et fond en code |
| Papier découpé | `"traitement": {"saccade": 12, "tremble": 1, "papier": true, "bord_irregulier": true}`, images `bord: 12`, textes sur étiquette (`fond`), transition `papier` | « illustration en papier découpé, aplats de papier coloré, texture légère, fond blanc uni » | vif, rebondissant | idéal : bord blanc + ombre |
| Illustration plate | formes en code (`blob`, `vague`, `arche`, `eclat`), `trait`, typo grasse | « illustration vectorielle plate, aplats nets, palette [couleurs], fond blanc uni » | vif, rebondissant | dans une forme (`masque: rond`) |
| Aquarelle douce | `"traitement": {"formes": ["aquarelle"]}`, fond `aquarelle: true`, `fondu`, police `main` | « aquarelle, couleurs douces transparentes, fond blanc uni, beaucoup d'air » | posé | `bichromie` + `polaroid` |
| Typographique | `texte` `mode: mots` (`cadence: "1t"`), `lettres`, `masque`, `surligne`, `tampon`, `flash` ; ArchivoBlack, Anton | le produit seul, très propre | vif ; posé pour un manifeste | petit, `noir_blanc` |
| 3D douce | `"rythme": "rebondissant"`, `"traitement": {"formes": ["relief"]}`, `maquette:volume;texte=3`, `tombe`, `pulse` ; Fredoka | « 3D doux façon jouet en plastique mat, pastel, fond blanc uni, sans ombre » | rebondissant | sur une pastille en relief |
| Pâte à modeler | `"traitement": {"saccade": 12, "tremble": 0.8, "formes": ["pate"]}`, `volume;pate=1` | « pâte à modeler, empreintes de doigts, lumière douce, fond blanc uni » | rebondissant | à éviter : générer le produit en pâte |
| Interface téléphone | `telephone` + `messages`, fond `motif` points clair, caméra en images clés vers le message clé | logo (avatar) + photo du produit | vif | parfait dans une conversation |
| Vue de dessus stop-motion | `"traitement": {"saccade": 12, "tremble": 0.6, "papier": true}`, objets `glisse-*`, `ombre: portee`, chiffres `police: main`, `trait` | « photo vue de dessus, objet seul, lumière uniforme, fond blanc uni » | vif | bien si prises d'en haut |

## Rythmes

| Rythme | Tempo | Mouvement | Musique (`musique.py`) |
|---|---|---|---|
| posé | 76-92 | `monte`, `fondu`, `masque`, caméra lente | pad, kalimba, percussions légères |
| vif | 104-124 | coupes sur le temps, `pousse-*`, mots qui claquent | afro-pop : shaker, clap, basse log drum |
| rebondissant | 98-112 | `tombe` avec rebond et écrasement, `pop`, `pulse` | marimba, basse qui saute, claps |

Écrire les plans en temps (`"temps": 8`) et les apparitions en `"1t"` : les actions tombent sur la musique.
