# Le son

**Musique.** Par défaut, composée en code (libre de droits) sur le tempo de pub.json :
`python scripts/musique.py pub.json [--variante 1..3] [--tonalite sol] [--rythme vif]`. Un temps de
creux juste avant le logo, accord et cymbale sur le logo. Si le connecteur ElevenLabs propose la
musique, on peut en générer une (préciser durée, tempo en BPM, ambiance, sans voix) et la passer à
`mixage.py --musique`. Ne jamais utiliser une musique du commerce ou d'un artiste.
Le moteur ne peut pas écouter : dire à la personne d'écouter et proposer une autre `--variante` si besoin.

**Voix off** (si demandée, après validation du texte) :
- ElevenLabs relié : `creative_list_voices`, proposer 2 ou 3 voix contrastées qui ressemblent à la
  clientèle, une génération à la fois, débit posé ; la personne choisit à l'écoute. Si le fichier ne
  peut pas être récupéré, lui demander de télécharger le MP3 et de le joindre. Coût ≈ 1 crédit par caractère.
- Sa propre voix : un mémo vocal au calme, le joindre.
- `python scripts/phrases.py voix.mp3 --tempo 104` donne le début de chaque phrase en secondes et en
  temps : caler les plans et textes dessus.

**Mixage** : `python scripts/mixage.py --video sortie/muette.mp4 --musique sortie/musique.wav [--voix voix.mp3 --voix-a 0.4]`
→ `sortie/pub.mp4` (tout, -14 LUFS) et `sortie/pub-sans-musique.mp4` (pour poser un son tendance dans
TikTok). Bruitages doux pris dans `sortie/cues.json` (transitions, tampon, clic du bouton, logo) ;
`--sans-bruitages` les enlève, `--sons dossier/` les remplace. La musique baisse sous la voix.
Conseiller l'étiquette « contenu généré par IA » avec une voix IA.
