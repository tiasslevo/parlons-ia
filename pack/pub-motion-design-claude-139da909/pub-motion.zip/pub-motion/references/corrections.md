# Corriger sur les retours

Changer seulement ce qui est demandé ; montrer l'image fixe (`--image t`) avant de refaire la vidéo.

| La personne dit | Faire |
|---|---|
| « On ne comprend pas tout de suite » | produit ou offre dès la 1re image, logo gardé pour la fin |
| « Trop rapide » | plus de temps par texte (≈ 1 s pour 3 mots), moins de mots |
| « Trop lent / ennuyeux » | ajouter des actions (boucle, caméra, objet qui tombe), pas ralentir |
| « Les 3 propositions se ressemblent » | changer d'**idée**, pas seulement de couleurs |
| « Trop de choses à l'écran » | une seule chose à regarder par moment |
| « Texte trop petit / caché » | agrandir, sortir des zones, relancer `--verifier` |
| « Ça fait sombre / triste » | fond plus clair, halo, couleur claire de la marque |
| « Ce geste n'a pas de sens » | un mouvement qui sert le commerce (le produit arrive dans le panier…) |
| « Mon numéro est faux » | recopier au caractère près, relire la liste des textes de `--verifier` |
| « Le détourage est sale » | `detoure.py --seuil 225`, ou redemander l'image sur fond blanc |
| « La musique ne va pas » | autre `--variante`, autre rythme, ou sans musique |
| « Une autre pub, même style » | garder la marque et le traitement, **changer d'idée** |
