# L'entretien de départ

But : savoir assez sur le commerce pour proposer 3 pubs justes. Court : un message de questions, une
relance au plus. Ce que la personne ne sait pas, tu le décides et tu le dis.

## Les questions (un seul message, numérotées)

1. **Ton commerce** : son nom, ce que tu vends, dans quelle ville ou quel quartier.
2. **Tes clients** : qui achète (âge, quartier, étudiants, mamans, bureaux…).
3. **Ce qui te rend unique** : ce que tes clients disent de toi, ce que les autres ne font pas.
4. **Cette pub** : ce qu'elle met en avant (un produit, une offre, une nouveauté, le lieu) et l'offre
   exacte s'il y en a une (prix, date de fin).
5. **Après la pub** : ce que les gens doivent faire (écrire sur WhatsApp, passer, appeler, commander),
   avec le numéro, l'adresse ou le compte **tels qu'ils doivent s'afficher**.
6. **Tes images** : ton logo et tes photos, même moyennes. Pas de logo : ça marche aussi.
7. **Ta vision** : décris librement la pub que tu imagines, avec tes mots. L'histoire, l'ambiance, ce
   qu'on voit en premier, comment les choses apparaissent, ce que tu ne veux surtout pas. Tu peux
   joindre une pub que tu aimes (capture, lien, vidéo). Si tu n'as pas d'idée, je te propose.
8. **La durée** : 10 à 15 s (statut, teaser), 20 à 30 s (pub classique) ou jusqu'à 1 min (histoire,
   présentation complète). Par défaut 15 à 20 s.
9. **La voix** : sans voix (texte à l'écran), voix IA (ElevenLabs relié à Claude), ou ta voix enregistrée.

Si la personne écrit déjà la moitié des réponses dans son premier message, ne reposer que le reste.

## Ce que tu regardes ensuite, sans nouvelles questions

- **Les photos** : nettes, moyennes, inutilisables. Une photo moyenne se sauve souvent par un
  traitement (découpe avec bord blanc, bichromie, trame, petit cadre polaroid, image dans un téléphone)
  avant de penser à la refaire. Une photo sur fond chargé ne se détoure pas bien : la mettre en fond
  flouté, ou faire générer un produit propre.
- **Le logo** : ses couleurs donnent l'accent. Pas de logo : le nom composé en typo à la fin.
- **La couleur** : partir du logo ou du produit (le rouge du bissap, le jaune du karité). Toujours un
  fond clair, un encre foncé, un accent (réservé au mot clé, au prix, au bouton), un second.
- **La référence** si elle existe : vidéo → `ffmpeg -i ref.mp4 -vf fps=2 ref/%03d.jpg`, regarder fond,
  couleurs, typo, nombre de changements par seconde, transitions. Lien : lire la page si possible.
  Dire en une phrase ce que tu en reprends. On reprend une façon de faire, jamais le logo, la musique
  ou les visuels d'une autre marque.
- **La vision de la personne** passe avant tout le reste. Si elle en a une, la reformuler en 3 temps,
  respecter ce qu'elle décrit (ce qu'on voit, comment ça apparaît, l'ambiance) et ne proposer qu'elle,
  avec au plus une variante. Les listes d'idées et de traitements ne servent que si elle n'a pas
  d'idée, ou pour compléter ce qu'elle laisse ouvert.
- **Voix ElevenLabs** : toujours une seule génération à la fois (`generations_count` à 1), sinon le
  coût est multiplié par 4.

## Écrire les réponses

Noter tout de suite dans `ma-marque/marque.md` (modèle `assets/fiche-marque.md`) : nom, coordonnées
exactes, ton, couleurs. C'est la future fiche du kit.
