# Marque : [Nom du commerce]

Fiche remplie à la première pub, relue au début de chaque nouvelle pub. Recopier les textes de la
personne au caractère près (nom, numéro, adresse).

## Le commerce
- Ce qu'il vend :
- Pour qui :
- Ce qui le rend unique :
- Ville / quartier :

## Les coordonnées (exactes)
- Action attendue : (ex. « Commande sur WhatsApp »)
- Numéro / compte :
- Adresse :

## Le ton
- Tutoiement ou vouvoiement :
- 3 mots pour la marque :
- Mots ou tournures à éviter :

## Le code de la marque (copié tel quel dans chaque pub.json)
```json
{
  "marque": {
    "nom": "Nom du commerce",
    "couleurs": {"fond": "#FFF6EC", "encre": "#2A1A14", "accent": "#C8102E", "second": "#F2B632",
                 "clair": "#FFFFFF", "papier": "#FBF3E6", "ombre": "#2A1A14"},
    "polices": {"titre": "DMSerifDisplay.ttf", "texte": "Geist.ttf"},
    "graisses": {"titre": 400, "texte": 600}
  }
}
```

## Ce qui a plu
- Traitements préférés : (ex. photo mise en scène, papier découpé)
- Rythme préféré : (posé, vif, rebondissant) et tempo :
- Idées déjà utilisées (pour ne pas refaire la même pub) :
- Éléments récurrents : (ex. la bouteille détourée, les pétales, le bouton vert, la fin avec le logo)
- Ce qu'il ne faut plus faire :

## Les images
- `logo/` : le logo (png transparent si possible)
- `elements/` : les images réutilisables, détourées (produit, objets, décor, personnage)
- Le style d'image qui a marché (bloc à recoller au début des prompts ChatGPT) :

```
[style d'image validé, mot pour mot]
```

## La voix
- Sans voix / voix ElevenLabs (nom et identifiant de la voix) / voix de la personne
