"""Fabrique la petite banque de bruitages du skill, entièrement synthétisée en code (numpy).

usage : python sons.py [dossier]        (par défaut : assets/sons/ du skill)

Types : pop, whoosh, glisse (swipe), impact, coupe, clic, ding. Trois variantes par type.
Ces sons sont calculés ici, sans aucun enregistrement ni échantillon extérieur : ils sont libres de
droits, utilisables dans des vidéos commerciales, sans mention obligatoire. mix_son.py les utilise
par défaut ; une banque personnelle (sons réels CC0) peut les remplacer type par type.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import SR  # noqa: E402

DOSSIER_DEFAUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "sons")


def t_(d):
    return np.arange(int(d * SR)) / SR


def env(d, attaque=0.003, chute=8.0):
    t = t_(d)
    a = np.clip(t / max(attaque, 1e-4), 0, 1)
    return a * np.exp(-t * chute)


def passe_bas(x, fc, ordre=1):
    """Filtre passe-bas (une pôle par ordre), fréquence de coupure fixe ou variable (tableau)."""
    fc = np.broadcast_to(np.asarray(fc, float), x.shape)
    k = 1 - np.exp(-2 * np.pi * fc / SR)
    for _ in range(ordre):
        y = np.empty_like(x)
        acc = 0.0
        for i in range(len(x)):
            acc += k[i] * (x[i] - acc)
            y[i] = acc
        x = y
    return x


def passe_bande(x, fc, largeur=0.6, ordre=3):
    """Bande autour de fc : passe-bas raide au-dessus, passe-haut doux en dessous."""
    fc = np.asarray(fc, float)
    y = passe_bas(x, fc * (1 + largeur), ordre)
    return y - passe_bas(y, fc * (1 - largeur * 0.8), 1)


def ton(freqs, d):
    """Sinus dont la fréquence suit le tableau freqs (glissando)."""
    phase = 2 * np.pi * np.cumsum(np.broadcast_to(freqs, (int(d * SR),))) / SR
    return np.sin(phase)


def bruit(d, graine):
    return np.random.default_rng(graine).normal(0, 1, int(d * SR))


def finir(x, fondu_ms=6):
    n = int(SR * fondu_ms / 1000)
    x = x.astype(np.float64)
    x[:n] *= np.linspace(0, 1, n)
    x[-n:] *= np.linspace(1, 0, n)
    return (x / (np.abs(x).max() or 1) * 0.9).astype(np.float32)


# ---------------------------------------------------------------- les sons
def pop(v):
    d = 0.11
    f0, f1 = [(820, 260), (1100, 330), (640, 210)][v]
    t = t_(d)
    f = f1 + (f0 - f1) * np.exp(-t * 55)
    x = ton(f, d) * env(d, 0.001, 38)
    x += passe_bande(bruit(d, 10 + v), 2500, 0.5) * env(d, 0.0005, 160) * 0.5
    return finir(x)


def whoosh(v):
    d = [0.42, 0.34, 0.5][v]
    t = t_(d)
    p = t / d
    forme = np.sin(np.pi * p ** 0.75) ** 2  # monte puis retombe, sommet après le milieu
    fc = 300 + 2600 * np.sin(np.pi * p) ** 1.5 * [1.0, 1.25, 0.8][v]
    x = passe_bande(bruit(d, 20 + v), fc, 0.55) * forme
    return finir(x, 12)


def glisse(v):
    d = [0.26, 0.22, 0.3][v]
    t = t_(d)
    p = t / d
    fc = 2400 - 1700 * p * [1.0, 0.8, 1.1][v]
    x = passe_bande(bruit(d, 30 + v), fc, 0.7) * np.sin(np.pi * p) ** 1.2
    return finir(x, 10)


def impact(v):
    d = 0.55
    t = t_(d)
    f = [52, 60, 46][v] + 70 * np.exp(-t * 30)
    corps = ton(f, d) * env(d, 0.002, [7, 9, 6][v])
    claque = passe_bas(bruit(d, 40 + v), 1400, 3) * env(d, 0.0008, 45) * 3.0
    x = np.tanh((corps + claque) * 1.8)
    return finir(x, 15)


def coupe(v):
    d = 0.07
    x = passe_bande(bruit(d, 50 + v), [3200, 2600, 4000][v], 0.6) * env(d, 0.0005, 90)
    x += ton(np.full(int(d * SR), [140, 120, 170][v]), d) * env(d, 0.001, 60) * 0.5
    return finir(x, 3)


def clic(v):
    d = 0.045
    f = [3100, 2500, 3800][v]
    x = ton(np.full(int(d * SR), f), d) * env(d, 0.0003, 220)
    x += passe_bande(bruit(d, 60 + v), 5000, 0.5) * env(d, 0.0002, 400) * 0.6
    x += ton(np.full(int(d * SR), 900), d) * env(d, 0.0005, 150) * 0.35
    return finir(x, 2)


def ding(v):
    d = 0.9
    f0 = [1320, 1175, 1568][v]
    x = sum(a * ton(np.full(int(d * SR), f0 * r), d) * env(d, 0.002, c)
            for r, a, c in ((1, 1.0, 5), (2.76, 0.35, 9), (5.4, 0.15, 14), (2.0, 0.2, 7)))
    return finir(x, 20)


SONS = {"pop": pop, "whoosh": whoosh, "glisse": glisse, "impact": impact, "coupe": coupe, "clic": clic, "ding": ding}


def fabriquer(dossier=DOSSIER_DEFAUT):
    from outils import ecrire_wav
    n = 0
    for typ, f in SONS.items():
        os.makedirs(os.path.join(dossier, typ), exist_ok=True)
        for v in range(3):
            ecrire_wav(os.path.join(dossier, typ, f"{typ}-{v + 1}.wav"), f(v))
            n += 1
    return n


if __name__ == "__main__":
    d = sys.argv[1] if len(sys.argv) > 1 else DOSSIER_DEFAUT
    print(f"{fabriquer(d)} sons écrits dans {d}")
