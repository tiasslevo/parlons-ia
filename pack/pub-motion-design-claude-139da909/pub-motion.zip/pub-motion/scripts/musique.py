"""Musique de pub composée en code, calée sur le tempo de pub.json. Libre de droits (rien d'enregistré).

usage :
  python musique.py pub.json [--sortie sortie/musique.wav] [--rythme pose|vif|rebondissant] [--tonalite fa]
                             [--variante 2] [--sans-creux]

- Le tempo, la durée et le rythme viennent de pub.json (clés "tempo", "rythme").
- Un creux d'un temps (batterie coupée) juste avant le logo, puis un accord frappé sur le logo.
- Trois couleurs : pose (pad doux, kalimba, percussions légères), vif (afro-pop : shaker, clap,
  basse façon log drum, accords piqués), rebondissant (marimba, basse qui saute, claps).
- --variante change la suite d'accords et la mélodie (même tempo).
"""
import argparse
import json
import math
import os
import sys

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
from outils import SR, ecrire_wav  # noqa: E402

NOTES = {"do": 0, "do#": 1, "re": 2, "re#": 3, "mi": 4, "fa": 5, "fa#": 6, "sol": 7, "sol#": 8, "la": 9, "la#": 10, "si": 11}
SUITES = [[0, 7, 9, 5], [0, 5, 9, 7], [9, 5, 0, 7], [0, 9, 5, 7]]  # I V vi IV, I IV vi V, vi IV I V, I vi IV V
MAJ = [0, 2, 4, 5, 7, 9, 11]


def freq(n):  # n = demi-tons depuis le la 440
    return 440.0 * 2 ** (n / 12)


def env(n, a=0.005, d=0.3, s=0.0, r=0.05, duree=None):
    t = np.arange(n) / SR
    e = np.minimum(1, t / max(a, 1e-4))
    e = e * (s + (1 - s) * np.exp(-np.maximum(0, t - a) / max(d, 1e-4)))
    if duree is not None:
        e *= np.clip((duree - t) / max(r, 1e-4), 0, 1)
    return e


def sinus(f, n, phase=0.0):
    return np.sin(2 * np.pi * np.cumsum(np.broadcast_to(f, (n,))) / SR + phase)


def bruit(n, graine):
    return np.random.default_rng(graine).normal(0, 1, n)


def lisser(x, k):
    """Passe-bas simple (moyenne glissante exponentielle) en numpy."""
    n = max(1, int(k))
    noyau = np.exp(-np.arange(n * 4) / n)
    noyau /= noyau.sum()
    return np.convolve(x, noyau, mode="full")[:len(x)]


# ---------------------------------------------------------------- instruments
def kick(force=1.0):
    n = int(0.35 * SR)
    t = np.arange(n) / SR
    f = 45 + 95 * np.exp(-t * 28)
    return np.tanh(sinus(f, n) * env(n, 0.001, 0.12) * 2.2) * 0.9 * force


def clap(graine=1, force=1.0):
    n = int(0.25 * SR)
    x = np.zeros(n)
    b = bruit(n, graine)
    for k, dt in enumerate((0, 0.008, 0.017)):
        i = int(dt * SR)
        x[i:] += b[:n - i] * env(n - i, 0.0005, 0.012 if k < 2 else 0.09)
    x = lisser(x - lisser(x, 12), 2)  # bande moyenne : moins agressif
    return x * 0.32 * force


def shaker(graine=1, force=1.0):
    n = int(0.07 * SR)
    x = bruit(n, graine)
    x = x - lisser(x, 3)
    return lisser(x, 1.5) * env(n, 0.006, 0.02) * 0.14 * force


def rim(force=1.0):
    n = int(0.08 * SR)
    x = sinus(1700, n) * env(n, 0.0005, 0.012) + sinus(820, n) * env(n, 0.0005, 0.02) * 0.6
    return x * 0.35 * force


def log_drum(f0, duree, force=1.0):
    n = int(duree * SR)
    t = np.arange(n) / SR
    f = f0 * (1 + 0.5 * np.exp(-t * 40))
    x = sinus(f, n) + 0.3 * sinus(f * 2, n) * np.exp(-t * 12)
    return np.tanh(x * env(n, 0.002, duree * 0.45, 0, 0.03, duree) * 1.6) * 0.55 * force


def basse(f0, duree, force=1.0):
    n = int(duree * SR)
    x = sinus(f0, n) + 0.25 * sinus(f0 * 2, n) + 0.08 * sinus(f0 * 3, n)
    return np.tanh(x * env(n, 0.006, duree * 0.6, 0.5, 0.04, duree) * 1.3) * 0.5 * force


def pluck(f0, duree, force=1.0, brillance=1.0):
    """Kalimba / marimba : fondamentale + partiel aigu qui s'éteint vite."""
    n = int(max(duree, 0.6) * SR)
    t = np.arange(n) / SR
    x = sinus(f0, n) * np.exp(-t * 5) + 0.35 * brillance * sinus(f0 * 4.02, n) * np.exp(-t * 28) \
        + 0.15 * sinus(f0 * 2, n) * np.exp(-t * 9)
    return x * env(n, 0.002, 2, 1) * 0.32 * force


def piano_doux(f0, duree, force=1.0):
    n = int((duree + 0.4) * SR)
    t = np.arange(n) / SR
    x = sinus(f0, n) + 0.4 * sinus(f0 * 2, n) * np.exp(-t * 3) + 0.12 * sinus(f0 * 3, n) * np.exp(-t * 6)
    return x * env(n, 0.004, 0.9, 0.25, 0.4, duree + 0.4) * 0.18 * force


def pad(freqs, duree, force=1.0):
    n = int((duree + 0.5) * SR)
    x = np.zeros(n)
    for f in freqs:
        for det in (-0.12, 0.12):
            x += sinus(f * 2 ** (det / 12), n) + 0.3 * sinus(f * 2 * 2 ** (det / 12), n)
    x /= max(1, len(freqs) * 2)
    t = np.arange(n) / SR
    e = np.minimum(1, t / 0.25) * np.clip((duree + 0.5 - t) / 0.5, 0, 1)
    return x * e * 0.22 * force


def crash(force=1.0):
    n = int(1.6 * SR)
    x = bruit(n, 9)
    x = x - lisser(x, 2)
    return lisser(x, 1.5) * env(n, 0.001, 0.35) * 0.12 * force


# ---------------------------------------------------------------- composition
def composer(tempo, duree, rythme="vif", tonalite="fa", variante=0, t_logo=None, creux=True):
    beat = 60 / tempo
    pas16 = beat / 4
    n = int((duree + 1.2) * SR)
    mix = {k: np.zeros(n) for k in ("batterie", "basse", "harmonie", "melodie")}

    def poser(piste, son, t, gain=1.0):
        i = int(t * SR)
        if i >= n or i < 0:
            return
        j = min(n, i + len(son))
        mix[piste][i:j] += son[:j - i] * gain

    racine = NOTES.get(tonalite, 5) - 9  # demi-tons depuis la 440 (fa = -4)
    suite = SUITES[variante % len(SUITES)]
    rng = np.random.default_rng(variante + 11)
    mesure = beat * 4
    nb_mesures = int(math.ceil((duree + 0.6) / mesure))
    t_creux = (t_logo - beat) if (creux and t_logo) else None

    def dans_creux(t):
        return t_creux is not None and t_creux <= t < t_logo

    for m in range(nb_mesures):
        deg = suite[m % 4]
        r = racine + deg
        mineur = deg in (9, 2, 4)
        accord = [r, r + (3 if mineur else 4), r + 7]
        t0 = m * mesure
        # harmonie
        if rythme == "pose":
            poser("harmonie", pad([freq(x - 12) for x in accord], mesure), t0, 1.0)
        elif rythme == "vif":
            for s in (2, 6, 10, 14):
                if not dans_creux(t0 + s * pas16):
                    for x in accord:
                        poser("harmonie", piano_doux(freq(x), pas16 * 1.2, 0.8), t0 + s * pas16)
        else:
            for s in (0, 8):
                for x in accord:
                    poser("harmonie", piano_doux(freq(x), beat * 1.5, 0.6), t0 + s * pas16)
        # batterie
        motifs = {
            "pose": {"kick": [0, 10], "clap": [], "rim": [4, 12], "shaker": [2, 6, 10, 14]},
            "vif": {"kick": [0, 6, 8, 14] if m % 2 else [0, 7, 8], "clap": [4, 12], "rim": [3, 11, 15], "shaker": list(range(16))},
            "rebondissant": {"kick": [0, 8, 11], "clap": [4, 12], "rim": [7, 15], "shaker": [0, 2, 4, 6, 8, 10, 12, 14]},
        }[rythme if rythme in ("pose", "vif", "rebondissant") else "vif"]
        for inst, pas in motifs.items():
            for s in pas:
                t = t0 + s * pas16
                if t > duree - 0.3 or dans_creux(t):
                    continue
                if m == 0 and inst == "kick" and rythme == "pose" and s > 0:
                    continue
                if inst == "kick":
                    poser("batterie", kick(0.9 if rythme != "pose" else 0.6), t)
                elif inst == "clap":
                    poser("batterie", clap(s + m, 0.8), t)
                elif inst == "rim":
                    poser("batterie", rim(0.7), t)
                elif inst == "shaker":
                    poser("batterie", shaker(s + 3 * m, 1.0 if s % 4 == 2 else 0.55), t)
        # basse
        fb = freq(r - 24)
        if rythme == "vif":
            for s, l in ((0, 3), (3, 3), (6, 2), (10, 3), (13, 2)):
                t = t0 + s * pas16
                if not dans_creux(t) and t < duree:
                    poser("basse", log_drum(fb, pas16 * l * 1.3), t)
        elif rythme == "rebondissant":
            for k, s in enumerate((0, 2, 4, 6, 8, 10, 12, 14)):
                t = t0 + s * pas16
                if not dans_creux(t) and t < duree:
                    poser("basse", basse(fb * (2 if k % 2 else 1), pas16 * 1.4, 0.9), t)
        else:
            for s in (0, 8):
                t = t0 + s * pas16
                if not dans_creux(t) and t < duree:
                    poser("basse", basse(fb, beat * 1.8, 0.7), t)
        # mélodie (gamme majeure de la tonalité, notes de l'accord en priorité)
        gamme = [racine + 12 + g for g in MAJ] + [racine + 24 + g for g in MAJ[:3]]
        pas_mel = {"pose": [0, 3, 6, 10, 12], "vif": [0, 3, 6, 8, 11, 14], "rebondissant": [0, 2, 4, 6, 8, 10, 12, 14]}.get(rythme, [0, 4, 8, 12])
        for s in pas_mel:
            t = t0 + s * pas16
            if t > duree - 0.4 or dans_creux(t) or rng.random() < 0.18:
                continue
            note = rng.choice([x + 12 for x in accord] + gamme[:5])
            poser("melodie", pluck(freq(note), beat, 0.8 if rythme != "pose" else 0.6, 1.3 if rythme == "rebondissant" else 1.0), t)
    if t_logo:  # accord frappé + cymbale sur le logo
        deg = suite[int(t_logo // mesure) % 4]
        r = racine + deg
        for x in (r, r + 4, r + 7, r + 12):
            poser("harmonie", piano_doux(freq(x), beat * 3, 1.3), t_logo)
        poser("batterie", crash(0.9), t_logo)
        poser("batterie", kick(1.0), t_logo)
    gains = {"batterie": 0.7, "basse": 0.9, "harmonie": 1.1, "melodie": 0.85}
    y = sum(mix[k] * g for k, g in gains.items())
    fin = int(duree * SR)
    fondu = int(0.9 * SR)
    y[max(0, fin - fondu):fin] *= np.linspace(1, 0.35, min(fin, fondu))
    y[fin:] *= np.linspace(0.35, 0, n - fin)
    y = np.tanh(y * 1.1)
    return (y / (np.abs(y).max() or 1) * 0.85).astype(np.float32)[: int((duree + 0.3) * SR)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pub")
    ap.add_argument("--sortie")
    ap.add_argument("--rythme")
    ap.add_argument("--tonalite", default="fa")
    ap.add_argument("--variante", type=int, default=0)
    ap.add_argument("--sans-creux", action="store_true")
    a = ap.parse_args()
    import moteur
    pub = moteur.Pub(a.pub)
    rythme = a.rythme or pub.rythme
    y = composer(pub.horloge.tempo, pub.duree, rythme, a.tonalite, a.variante, pub.moment_logo(), not a.sans_creux)
    s = a.sortie or os.path.join(os.path.dirname(os.path.abspath(a.pub)), "sortie", "musique.wav")
    os.makedirs(os.path.dirname(s), exist_ok=True)
    ecrire_wav(s, y)
    print(f"Musique : {s} ({len(y) / SR:.1f} s, {pub.horloge.tempo:.0f} BPM, {rythme}, logo à {pub.moment_logo():.2f} s)")


if __name__ == "__main__":
    main()
