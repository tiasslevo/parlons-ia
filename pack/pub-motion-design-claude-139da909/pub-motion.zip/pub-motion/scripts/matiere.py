"""La matière des pubs : couleurs, polices, mise en page du texte, formes, traitements, fonds.

Tout est dessiné avec Pillow et numpy. Les traitements (bord blanc, bichromie, trame, relief de pâte
ou de 3D douce, aquarelle, grain de papier) s'appliquent une fois à une image, puis l'image est mise
en mouvement par moteur.py. Ce module ne connaît pas le temps.
"""
import math
import os
from functools import lru_cache

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

ICI = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(ICI)
POLICES_SKILL = os.path.join(SKILL, "assets", "fonts")

PALETTE_DEFAUT = {
    "fond": "#FFF8EF", "encre": "#2A1A14", "accent": "#C8102E", "second": "#F2B632",
    "clair": "#FFFFFF", "papier": "#FBF6EC", "ombre": "#2A1A14", "whatsapp": "#25D366",
}
POLICES_DEFAUT = {"titre": "Bricolage.ttf", "texte": "Geist.ttf", "main": "Caveat.ttf", "chiffre": "Anton.ttf"}
GRAISSES_DEFAUT = {"titre": 800, "texte": 600, "main": 700, "chiffre": 400}


# ---------------------------------------------------------------- couleurs
def hex_rgba(c):
    c = c.lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    if len(c) == 6:
        c += "FF"
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4, 6))


class Palette:
    """Couleurs de la marque. Un nom (« accent ») ou un code (« #C8102E »), avec une transparence
    facultative : « accent/0.5 », « #000000/0.2 »."""

    def __init__(self, couleurs=None):
        self.c = dict(PALETTE_DEFAUT)
        self.c.update(couleurs or {})

    def __call__(self, v, defaut="encre"):
        if v is None:
            v = defaut
        if isinstance(v, (list, tuple)):
            t = tuple(int(x) for x in v)
            return t if len(t) == 4 else t + (255,)
        a = None
        if "/" in v:
            v, a = v.split("/", 1)
            a = float(a)
        v = v.strip()
        for _ in range(4):  # un nom peut renvoyer à un autre nom
            if v in self.c:
                v = self.c[v]
            else:
                break
        rgba = hex_rgba(v) if v.startswith("#") else hex_rgba(PALETTE_DEFAUT.get(v, "#FF00FF"))
        if a is not None:
            rgba = rgba[:3] + (int(rgba[3] * a),)
        return rgba


def lum(c):
    r, g, b = [x / 255 for x in c[:3]]
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def melange(c1, c2, k):
    return tuple(int(round(a + (b - a) * k)) for a, b in zip(c1, c2))


# ---------------------------------------------------------------- polices
class Polices:
    def __init__(self, base, polices=None, graisses=None):
        self.base = base
        self.noms = dict(POLICES_DEFAUT)
        self.noms.update(polices or {})
        self.graisses = dict(GRAISSES_DEFAUT)
        self.graisses.update(graisses or {})
        self.cache = {}

    def chemin(self, nom):
        cands = [nom]
        d = self.base
        for _ in range(3):
            cands += [os.path.join(d, nom), os.path.join(d, "polices", nom)]
            d = os.path.dirname(d)
        cands.append(os.path.join(POLICES_SKILL, nom))
        for p in cands:
            if p and os.path.isfile(p):
                return p
        return os.path.join(POLICES_SKILL, "Geist.ttf")

    def get(self, taille, police="titre", graisse=None):
        nom = self.noms.get(police, police)
        g = graisse or self.graisses.get(police, 700)
        cle = (nom, int(taille), g)
        if cle not in self.cache:
            f = ImageFont.truetype(self.chemin(nom), max(4, int(taille)))
            try:
                vals = []
                for ax in f.get_variation_axes():
                    n = ax["name"].decode() if isinstance(ax["name"], bytes) else ax["name"]
                    v = ax["default"]
                    if str(n).lower() == "weight":
                        v = max(ax["minimum"], min(ax["maximum"], g))
                    vals.append(v)
                f.set_variation_by_axes(vals)
            except Exception:
                pass
            self.cache[cle] = f
        return self.cache[cle]


# ---------------------------------------------------------------- texte
def insecables(texte):
    """Évite les coupures absurdes : « 5 000 F », « 77 000 00 00 », « Ouakam ? » restent d'un bloc."""
    import re
    nb = "\u00a0"
    texte = re.sub(r"(?<=\d) (?=\d)", nb, texte)
    texte = re.sub(r"(?<=\d) (?=(F|FCFA|CFA|€|%|h|min|kg|g|L)\b)", nb, texte)
    texte = re.sub(r" (?=[?!:;»])", nb, texte)
    texte = re.sub(r"(?<=«) ", nb, texte)
    return texte


def jetons(texte):
    """« Du *vrai* jus\\nchaque matin » → [(mot, accent, saut_avant)]. *...* = mot clé (couleur accent)."""
    texte = insecables(texte.replace("\\n", "\n"))
    out, acc = [], False
    for i, ligne in enumerate(texte.split("\n")):
        premier = True
        for brut in ligne.split(" "):
            if not brut:
                continue
            m = brut
            debut = m.startswith("*")
            m = m.lstrip("*") if debut else m
            fin = m.endswith("*") or m.rstrip(".,;:!?…»").endswith("*")
            if debut:
                acc = True
            mot_acc = acc
            if fin:
                m = m.replace("*", "")
                acc = False
            out.append((m, mot_acc, i > 0 and premier))
            premier = False
    return out


def texte_brut(texte):
    return " ".join(m for m, _, _ in jetons(texte)).replace("\u00a0", " ")


def mise_en_page(texte, police, largeur, interligne=1.08, aligne="centre", espace=None):
    """Place les mots en lignes. Renvoie (mots, w, h) ; mots = [dict(mot, accent, x, y, w, h, ligne)].
    Coordonnées dans un bloc qui commence en (0, 0)."""
    jet = jetons(texte)
    esp = espace if espace is not None else police.getlength(" ")
    asc, desc = police.getmetrics()
    hl = (asc + desc) * interligne
    lignes, cur, lw = [], [], 0
    for mot, acc, saut in jet:
        w = police.getlength(mot)
        if cur and (saut or lw + esp + w > largeur):
            lignes.append(cur)
            cur, lw = [], 0
        cur.append((mot, acc, w))
        lw += (esp if len(cur) > 1 else 0) + w
    if cur:
        lignes.append(cur)
    mots = []
    bw = 0
    for li, l in enumerate(lignes):
        tot = sum(w for _, _, w in l) + esp * (len(l) - 1)
        bw = max(bw, tot)
    for li, l in enumerate(lignes):
        tot = sum(w for _, _, w in l) + esp * (len(l) - 1)
        x = {"centre": (bw - tot) / 2, "gauche": 0, "droite": bw - tot}.get(aligne, (bw - tot) / 2)
        for mot, acc, w in l:
            mots.append({"mot": mot, "accent": acc, "x": x, "y": li * hl, "w": w, "h": asc + desc, "ligne": li})
            x += w + esp
    return mots, bw, len(lignes) * hl - (asc + desc) * (interligne - 1)


def sprite_texte(txt, police, couleur, contour=0, couleur_contour=(255, 255, 255, 255)):
    """Un mot (ou une lettre) en image RGBA, avec une marge. Renvoie (image, dx, dy) : décalage du point
    d'origine du texte dans l'image."""
    asc, desc = police.getmetrics()
    m = contour + 6
    w = int(police.getlength(txt)) + 2 * m + 4
    h = asc + desc + 2 * m
    im = Image.new("RGBA", (max(1, w), max(1, h)), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.text((m, m), txt, font=police, fill=couleur, stroke_width=contour, stroke_fill=couleur_contour)
    return im, m, m


# ---------------------------------------------------------------- formes
SS = 2  # suréchantillonnage des formes (bords lisses)


def _poly_etoile(cx, cy, r, branches=5, creux=0.45, rot=-90):
    pts = []
    for i in range(branches * 2):
        a = math.radians(rot + i * 180 / branches)
        rr = r if i % 2 == 0 else r * creux
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return pts


def _poly_blob(cx, cy, rx, ry, graine=1, irreg=0.12, n=90, phase=0.0):
    rng = np.random.default_rng(graine)
    harm = [(k, rng.uniform(0.3, 1.0) * irreg / k ** 0.6, rng.uniform(0, 6.28)) for k in range(2, 6)]
    pts = []
    for i in range(n):
        a = 2 * math.pi * i / n
        f = 1 + sum(amp * math.sin(k * a + ph + phase * (1 + k * 0.3)) for k, amp, ph in harm)
        pts.append((cx + rx * f * math.cos(a), cy + ry * f * math.sin(a)))
    return pts


def _poly_eclat(cx, cy, r, pointes=16, creux=0.82):
    return _poly_etoile(cx, cy, r, pointes, creux, rot=0)


def _poly_coeur(cx, cy, r):
    pts = []
    for i in range(120):
        t = 2 * math.pi * i / 120
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * r / 17, cy + y * r / 17))
    return pts


def forme(nom, w, h, couleur, rayon=None, contour=0, couleur_contour=None, graine=1, phase=0.0, **opt):
    """Dessine une forme pleine de w × h px. nom : rect, rond, pastille, etoile, eclat, blob, arche, goutte,
    coeur, vague, losange, triangle, bulle."""
    w, h = max(2, int(w)), max(2, int(h))
    W, H = w * SS, h * SS
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = couleur
    ce = couleur_contour if contour else None
    lw = int(contour * SS)
    if nom == "rect":
        r = int((rayon or 0) * SS)
        d.rounded_rectangle([0, 0, W - 1, H - 1], radius=min(r, min(W, H) // 2), fill=c, outline=ce, width=lw)
    elif nom == "pastille":
        d.rounded_rectangle([0, 0, W - 1, H - 1], radius=min(W, H) // 2, fill=c, outline=ce, width=lw)
    elif nom == "rond":
        d.ellipse([0, 0, W - 1, H - 1], fill=c, outline=ce, width=lw)
    elif nom == "etoile":
        d.polygon(_poly_etoile(W / 2, H / 2, min(W, H) / 2, opt.get("branches", 5), opt.get("creux", 0.45)), fill=c, outline=ce, width=lw)
    elif nom == "eclat":
        d.polygon(_poly_eclat(W / 2, H / 2, min(W, H) / 2, opt.get("pointes", 16), opt.get("creux", 0.84)), fill=c, outline=ce, width=lw)
    elif nom == "blob":
        d.polygon(_poly_blob(W / 2, H / 2, W / 2 * 0.86, H / 2 * 0.86, graine, opt.get("irreg", 0.12), phase=phase), fill=c, outline=ce, width=lw)
    elif nom == "arche":
        d.rounded_rectangle([0, 0, W - 1, H - 1], radius=0, fill=c)
        im2 = Image.new("L", (W, H), 0)
        d2 = ImageDraw.Draw(im2)
        d2.rectangle([0, W // 2, W, H], fill=255)
        d2.ellipse([0, 0, W - 1, W - 1], fill=255)
        im.putalpha(ImageChops.multiply(im.getchannel("A"), im2))
    elif nom == "goutte":
        d.ellipse([0, H - W, W - 1, H - 1], fill=c)
        d.polygon([(W * 0.08, H - W * 0.62), (W / 2, 0), (W * 0.92, H - W * 0.62)], fill=c)
    elif nom == "coeur":
        d.polygon(_poly_coeur(W / 2, H / 2 + H * 0.04, min(W, H) / 2 * 0.98), fill=c)
    elif nom == "losange":
        d.polygon([(W / 2, 0), (W, H / 2), (W / 2, H), (0, H / 2)], fill=c, outline=ce, width=lw)
    elif nom == "triangle":
        d.polygon([(W / 2, 0), (W, H), (0, H)], fill=c, outline=ce, width=lw)
    elif nom == "vague":
        amp, n = opt.get("amplitude", 0.12) * H, opt.get("ondes", 2.5)
        pts = [(x, amp + amp * math.sin(2 * math.pi * n * x / W + phase)) for x in range(0, W + 8, 8)]
        d.polygon(pts + [(W, H), (0, H)], fill=c)
    elif nom == "bulle":
        r = int((rayon or 36) * SS)
        q = int(H * 0.16)
        d.rounded_rectangle([0, 0, W - 1, H - 1 - q], radius=r, fill=c, outline=ce, width=lw)
        cote = opt.get("queue", "gauche")
        bx = W * (0.18 if cote == "gauche" else 0.82)
        d.polygon([(bx - q * 0.7, H - 1 - q - 2), (bx + q * 0.7, H - 1 - q - 2), (bx - (q if cote == "gauche" else -q) * 0.9, H - 1)], fill=c)
    else:
        d.rectangle([0, 0, W - 1, H - 1], fill=c)
    return im.resize((w, h), Image.LANCZOS)


# ---------------------------------------------------------------- icônes simples
def icone(nom, d, couleur=(255, 255, 255, 255)):
    """Petites icônes dessinées (aucun logo de marque) : discussion, telephone, lieu, panier, coeur,
    etoile, coche, horloge, fleche."""
    S = d * 4
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    g = ImageDraw.Draw(im)
    lw = max(4, S // 11)
    if nom == "discussion":  # bulle ronde avec un combiné : l'idée « écrire / appeler »
        g.ellipse([S * .06, S * .06, S * .94, S * .9], outline=couleur, width=lw)
        g.polygon([(S * .14, S * .7), (S * .06, S * .96), (S * .34, S * .86)], fill=couleur)
        # combiné stylisé
        g.rounded_rectangle([S * .32, S * .28, S * .44, S * .44], radius=S // 30, fill=couleur)
        g.rounded_rectangle([S * .54, S * .52, S * .70, S * .64], radius=S // 30, fill=couleur)
        g.line([(S * .37, S * .42), (S * .44, S * .55), (S * .58, S * .6)], fill=couleur, width=lw, joint="curve")
    elif nom == "telephone":
        g.rounded_rectangle([S * .28, S * .06, S * .72, S * .94], radius=S // 10, outline=couleur, width=lw)
        g.ellipse([S * .46, S * .78, S * .54, S * .86], fill=couleur)
    elif nom == "lieu":
        g.ellipse([S * .2, S * .04, S * .8, S * .64], fill=couleur)
        g.polygon([(S * .24, S * .44), (S * .5, S * .96), (S * .76, S * .44)], fill=couleur)
        g.ellipse([S * .38, S * .22, S * .62, S * .46], fill=(0, 0, 0, 0))
    elif nom == "panier":
        g.polygon([(S * .1, S * .38), (S * .9, S * .38), (S * .78, S * .9), (S * .22, S * .9)], fill=couleur)
        g.arc([S * .28, S * .08, S * .72, S * .62], 180, 360, fill=couleur, width=lw)
    elif nom == "coeur":
        g.polygon(_poly_coeur(S / 2, S / 2, S * .46), fill=couleur)
    elif nom == "etoile":
        g.polygon(_poly_etoile(S / 2, S * .54, S * .48), fill=couleur)
    elif nom == "coche":
        g.line([(S * .14, S * .54), (S * .4, S * .8), (S * .88, S * .22)], fill=couleur, width=lw * 2, joint="curve")
    elif nom == "horloge":
        g.ellipse([S * .06, S * .06, S * .94, S * .94], outline=couleur, width=lw)
        g.line([(S * .5, S * .5), (S * .5, S * .22)], fill=couleur, width=lw)
        g.line([(S * .5, S * .5), (S * .7, S * .6)], fill=couleur, width=lw)
    elif nom == "fleche":
        g.line([(S * .1, S * .5), (S * .82, S * .5)], fill=couleur, width=lw * 2)
        g.polygon([(S * .62, S * .24), (S * .95, S * .5), (S * .62, S * .76)], fill=couleur)
    # pastille transparente au centre des formes trouées
    if nom == "lieu":
        a = im.getchannel("A")
        trou = Image.new("L", (S, S), 0)
        ImageDraw.Draw(trou).ellipse([S * .38, S * .22, S * .62, S * .46], fill=255)
        im.putalpha(ImageChops.subtract(a, trou))
    return im.resize((d, d), Image.LANCZOS)


# ---------------------------------------------------------------- bruits et textures
@lru_cache(maxsize=16)
def bruit_doux(w, h, echelle=60, graine=1):
    """Bruit lisse (taches) de valeurs 0..1, de la taille demandée."""
    rng = np.random.default_rng(graine)
    pw, ph = max(2, w // echelle + 2), max(2, h // echelle + 2)
    petit = Image.fromarray((rng.random((ph, pw)) * 255).astype("uint8"))
    return np.asarray(petit.resize((w, h), Image.BICUBIC), dtype=np.float32) / 255


@lru_cache(maxsize=8)
def texture_papier(w, h, graine=3, force=1.0):
    """Texture de papier (fibres + grain), valeurs autour de 1 (à multiplier)."""
    rng = np.random.default_rng(graine)
    fin = rng.normal(0, 1, (h, w)).astype(np.float32)
    fibres = np.asarray(Image.fromarray(((fin * 30) + 128).clip(0, 255).astype("uint8")).filter(
        ImageFilter.GaussianBlur(1.2)), np.float32) / 128 - 1
    taches = bruit_doux(w, h, 180, graine + 1) - 0.5
    t = 1 + (fin * 0.018 + fibres * 0.05 + taches * 0.05) * force
    return t.astype(np.float32)


_GRAINS = {}


def grain_image(img, force=0.05, graine=0):
    """Grain de film léger. Quatre tirages gardés en mémoire (calcul rapide, vidéo moins lourde)."""
    cle = (img.size, round(force, 3), graine % 4)
    if cle not in _GRAINS:
        n = np.random.default_rng(graine % 4).normal(0, 255 * force, (img.size[1], img.size[0]))
        _GRAINS[cle] = np.clip(n, -127, 127).astype(np.int16)[..., None]
    a = np.asarray(img.convert("RGB"), np.int16) + _GRAINS[cle]
    return Image.fromarray(np.clip(a, 0, 255).astype("uint8"))


# ---------------------------------------------------------------- traitements d'une image (une fois)
def dilater(alpha, r, irreg=0.0, graine=1):
    """Agrandit un masque de r px (rond). irreg > 0 : bord irrégulier façon découpe aux ciseaux."""
    if r <= 0:
        return alpha
    b = alpha.filter(ImageFilter.GaussianBlur(r * 0.6))
    a = np.asarray(b, np.float32) / 255
    seuil = 0.08
    if irreg:
        seuil = seuil + (bruit_doux(alpha.width, alpha.height, max(8, int(r * 2.5)), graine) - 0.5) * irreg * 0.12
    m = (a > seuil).astype(np.float32)
    m = np.maximum(m, np.asarray(alpha, np.float32) / 255)
    return Image.fromarray((m * 255).astype("uint8")).filter(ImageFilter.GaussianBlur(0.7))


def avec_marge(im, m):
    out = Image.new("RGBA", (im.width + 2 * m, im.height + 2 * m), (0, 0, 0, 0))
    out.paste(im, (m, m))
    return out


def bord_blanc(im, ep, couleur=(255, 255, 255, 255), irreg=0.0, graine=1):
    """Contour autocollant / papier découpé autour d'une image détourée."""
    im = avec_marge(im, int(ep * 1.6) + 4)
    a = im.getchannel("A")
    grand = dilater(a, ep, irreg, graine)
    fond = Image.new("RGBA", im.size, couleur)
    fond.putalpha(grand)
    fond.alpha_composite(im)
    return fond


def ombre_portee(im, dx=0, dy=18, flou=18, opacite=0.28, couleur=(40, 25, 20)):
    m = int(flou * 2 + max(abs(dx), abs(dy))) + 2
    base = avec_marge(im, m)
    a = base.getchannel("A").point(lambda v: int(v * opacite))
    om = Image.new("RGBA", base.size, couleur + (0,))
    om.putalpha(a.filter(ImageFilter.GaussianBlur(flou)))
    out = Image.new("RGBA", base.size, (0, 0, 0, 0))
    out.alpha_composite(om, (int(dx), int(dy))) if dx >= 0 and dy >= 0 else out.paste(om, (int(dx), int(dy)), om)
    out.alpha_composite(base)
    return out, m


def bichromie(im, sombre, clair):
    a = np.asarray(im.convert("RGBA"), np.float32)
    L = (0.299 * a[..., 0] + 0.587 * a[..., 1] + 0.114 * a[..., 2]) / 255
    L = np.clip((L - 0.08) / 0.84, 0, 1)[..., None]
    s, c = np.array(sombre[:3], np.float32), np.array(clair[:3], np.float32)
    rgb = s + (c - s) * L
    return Image.fromarray(np.dstack([rgb, a[..., 3:]]).clip(0, 255).astype("uint8"), "RGBA")


def trame(im, couleur, fond=None, pas=14):
    """Trame de points d'imprimerie : la taille du point suit le sombre de l'image."""
    rgba = im.convert("RGBA")
    g = np.asarray(rgba.convert("L"), np.float32) / 255
    al = np.asarray(rgba.getchannel("A"), np.float32) / 255
    w, h = rgba.size
    S = 3
    out = Image.new("RGBA", (w * S, h * S), fond if fond else (0, 0, 0, 0))
    d = ImageDraw.Draw(out)
    for y in range(0, h, pas):
        dec = (pas // 2) if (y // pas) % 2 else 0
        for x in range(-dec, w, pas):
            xs, ys = min(max(x + pas // 2, 0), w - 1), min(y + pas // 2, h - 1)
            v = (1 - g[ys, xs]) * al[ys, xs]
            r = pas * 0.72 * math.sqrt(v) * S
            if r > 0.6:
                cx, cy = (x + pas / 2) * S, (y + pas / 2) * S
                d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=couleur)
    out = out.resize((w, h), Image.LANCZOS)
    out.putalpha(ImageChops.multiply(out.getchannel("A"), rgba.getchannel("A")))
    return out


def relief(im, force=0.55, lisse=True, texture=0.0, graine=2):
    """Donne du volume à un aplat (lumière en haut à gauche). lisse=True → 3D douce (plastique mat,
    reflet) ; texture > 0 → pâte à modeler (surface irrégulière, empreintes)."""
    rgba = np.asarray(im.convert("RGBA"), np.float32)
    w, h = im.size
    taille = max(3.0, min(w, h) * (0.07 if lisse else 0.05))
    hmap = np.asarray(im.getchannel("A").filter(ImageFilter.GaussianBlur(taille)), np.float32) / 255
    hmap = np.sqrt(np.clip(hmap, 0, 1))  # bords arrondis, dessus plus plat
    if texture:
        hmap = hmap + (bruit_doux(w, h, max(4, int(taille * 0.5)), graine) - 0.5) * 0.06 * texture \
            + (bruit_doux(w, h, max(3, int(taille * 0.18)), graine + 1) - 0.5) * 0.025 * texture
    gy, gx = np.gradient(hmap)
    pente = taille * 1.4
    nx, ny, nz = -gx * pente, -gy * pente, np.ones_like(hmap)
    n = np.sqrt(nx ** 2 + ny ** 2 + nz ** 2)
    nx, ny, nz = nx / n, ny / n, nz / n
    L = np.array([-0.45, -0.55, 0.70])
    L = L / np.linalg.norm(L)
    diff = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0, 1)
    plat = L[2]
    k = (0.62 + 0.38 * diff / plat) * (1 - 0.1 * force)
    k = 1 + (k - 1) * (force / 0.55)
    rgb = rgba[..., :3] * k[..., None]
    if lisse:
        Hv = L + np.array([0, 0, 1.0])
        Hv = Hv / np.linalg.norm(Hv)
        spec = np.clip(nx * Hv[0] + ny * Hv[1] + nz * Hv[2], 0, 1) ** 40 * 120 * force
        rgb = rgb + spec[..., None]
    out = np.dstack([rgb.clip(0, 255), rgba[..., 3:]])
    return Image.fromarray(out.astype("uint8"), "RGBA")


def aquarelle(im, graine=4, force=1.0):
    """Aplat façon aquarelle : couleur qui varie, bord plus foncé, papier qui transparaît."""
    rgba = np.asarray(im.convert("RGBA"), np.float32)
    w, h = im.size
    a = rgba[..., 3] / 255
    # bord irrégulier
    ab = np.asarray(im.getchannel("A").filter(ImageFilter.GaussianBlur(3)), np.float32) / 255
    seuil = 0.5 + (bruit_doux(w, h, 26, graine) - 0.5) * 0.5
    a2 = np.clip((ab - seuil) * 6 + 0.5, 0, 1) * (ab > 0.05)
    er = np.asarray(Image.fromarray((a2 * 255).astype("uint8")).filter(ImageFilter.GaussianBlur(5)), np.float32) / 255
    bord = np.clip(a2 - er, 0, 1) * 2.2
    taches = bruit_doux(w, h, 50, graine + 1)
    k = 0.92 + taches[..., None] * 0.16 - bord[..., None] * 0.22 * force
    rgb = rgba[..., :3] * k
    pap = texture_papier(w, h, graine)[..., None]
    rgb = rgb * (1 + (pap - 1) * 3)
    alpha = a2 * (0.82 + taches * 0.18) * 255
    return Image.fromarray(np.dstack([rgb.clip(0, 255), alpha]).astype("uint8"), "RGBA")


def noir_blanc(im):
    a = im.getchannel("A") if im.mode == "RGBA" else None
    g = im.convert("L").convert("RGBA")
    if a:
        g.putalpha(a)
    return g


def masque_forme(im, nom, rayon=40):
    """Découpe une photo dans une forme : rond, arrondi, arche, blob, pastille."""
    w, h = im.size
    m = forme({"arrondi": "rect"}.get(nom, nom), w, h, (255, 255, 255, 255), rayon=rayon).getchannel("A")
    out = im.convert("RGBA")
    out.putalpha(ImageChops.multiply(out.getchannel("A"), m))
    return out


def cadre_polaroid(im, marge=28, bas=90, couleur=(255, 255, 255, 255)):
    out = Image.new("RGBA", (im.width + 2 * marge, im.height + marge + bas), couleur)
    out.alpha_composite(im.convert("RGBA"), (marge, marge))
    return out


def appliquer_traitements(im, liste, pal, base_graine=1):
    """liste : [« noir_blanc », {"bichromie": ["encre", "second"]}, {"trame": "encre"}, {"bord_blanc": 12},
    « relief », « pate », « aquarelle », {"masque": "arche"}, « polaroid »]. Ordre respecté."""
    for tr in liste or []:
        nom, v = (tr, None) if isinstance(tr, str) else next(iter(tr.items()))
        if nom == "noir_blanc":
            im = noir_blanc(im)
        elif nom == "bichromie":
            v = v or ["encre", "papier"]
            im = bichromie(im, pal(v[0]), pal(v[1]))
        elif nom == "trame":
            im = trame(im, pal(v or "encre"))
        elif nom == "bord_blanc":
            im = bord_blanc(im, int(v or 12), pal("clair"))
        elif nom == "bord_papier":
            im = bord_blanc(im, int(v or 14), pal("papier"), irreg=1.0, graine=base_graine)
        elif nom == "relief":
            im = relief(im, force=float(v or 0.55))
        elif nom == "pate":
            im = relief(im, force=float(v or 0.5), lisse=False, texture=1.0, graine=base_graine)
        elif nom == "aquarelle":
            im = aquarelle(im, base_graine)
        elif nom == "masque":
            im = masque_forme(im, v or "arrondi")
        elif nom == "polaroid":
            im = cadre_polaroid(im)
        elif nom == "flou":
            im = im.filter(ImageFilter.GaussianBlur(float(v or 4)))
    return im


# ---------------------------------------------------------------- fonds
def degrade(W, H, c1, c2, angle=90, radial=False, cx=0.5, cy=0.4, mx=0, my=0):
    """Dégradé sur une image (W + 2 mx) × (H + 2 my) ; positions relatives à l'écran W × H."""
    y, x = np.mgrid[-my:H + my, -mx:W + mx].astype(np.float32)
    if radial:
        d = np.sqrt(((x / W - cx) * W / H) ** 2 + (y / H - cy) ** 2) / 0.75
    else:
        a = math.radians(angle)
        d = ((x / W - 0.5) * math.cos(a) * W / H + (y / H - 0.5) * math.sin(a)) + 0.5
    d = np.clip(d, 0, 1)[..., None]
    c1, c2 = np.array(c1, np.float32), np.array(c2, np.float32)
    return Image.fromarray((c1 + (c2 - c1) * d).astype("uint8"), "RGBA")


def motif(W, H, nom, base, coul, pas=70, ep=None):
    im = Image.new("RGBA", (W, H), base)
    d = ImageDraw.Draw(im)
    ep = ep or max(2, pas // 12)
    if nom == "points":
        r = ep * 1.6
        for j, y in enumerate(range(0, H + pas, pas)):
            for x in range(0, W + pas, pas):
                xx = x + (pas / 2 if j % 2 else 0)
                d.ellipse([xx - r, y - r, xx + r, y + r], fill=coul)
    elif nom == "rayures":
        for x in range(-H, W + H, pas):
            d.polygon([(x, 0), (x + pas / 2, 0), (x + pas / 2 + H * 0.4, H), (x + H * 0.4, H)], fill=coul)
    elif nom == "lignes":
        for y in range(0, H, pas):
            d.line([(0, y), (W, y)], fill=coul, width=ep)
    elif nom == "quadrillage":
        for y in range(0, H, pas):
            d.line([(0, y), (W, y)], fill=coul, width=ep)
        for x in range(0, W, pas):
            d.line([(x, 0), (x, H)], fill=coul, width=ep)
    elif nom == "damier":
        for j, y in enumerate(range(0, H, pas)):
            for i, x in enumerate(range(0, W, pas)):
                if (i + j) % 2:
                    d.rectangle([x, y, x + pas, y + pas], fill=coul)
    elif nom == "vagues":
        for y in range(0, H + pas, pas):
            pts = [(x, y + pas * 0.18 * math.sin(x / pas * 2.2)) for x in range(0, W + 10, 10)]
            d.line(pts, fill=coul, width=ep)
    elif nom == "rayons":
        cx, cy, n = W / 2, H * 0.42, 24
        R = max(W, H) * 1.5
        for i in range(n):
            if i % 2:
                continue
            a0, a1 = 2 * math.pi * i / n, 2 * math.pi * (i + 1) / n
            d.polygon([(cx, cy), (cx + R * math.cos(a0), cy + R * math.sin(a0)), (cx + R * math.cos(a1), cy + R * math.sin(a1))], fill=coul)
    return im


def fond_image(spec, W, H, pal, base, graine=1, mx=0, my=0):
    """Construit l'image du fond d'un plan : (W + 2 mx) × (H + 2 my), la marge sert aux mouvements de
    caméra. Les positions (sol_y, halo_x, coupe…) sont relatives à l'écran W × H."""
    FW, FH = W + 2 * mx, H + 2 * my
    if spec is None:
        spec = "fond"
    if isinstance(spec, str):
        spec = {"type": "uni", "couleur": spec}
    t = spec.get("type", "uni")
    c = pal(spec.get("couleur", "fond"))
    if t == "degrade":
        im = degrade(W, H, pal(spec.get("de", "fond")), pal(spec.get("vers", "clair")), spec.get("angle", 90),
                     spec.get("radial", False), spec.get("x", 0.5), spec.get("y", 0.4), mx, my)
    elif t == "motif":
        im = motif(FW, FH, spec.get("motif", "points"), c, pal(spec.get("motif_couleur", "encre/0.08")), spec.get("pas", 70), spec.get("epaisseur"))
    elif t == "partage":  # écran partagé (eux / nous)
        im = Image.new("RGBA", (FW, FH), pal(spec.get("gauche", "#E9E9E9")))
        d = ImageDraw.Draw(im)
        k = spec.get("coupe", 0.5)
        pente = spec.get("pente", 0) * H
        xc = mx + W * k
        d.polygon([(xc + pente / 2, 0), (FW, 0), (FW, FH), (xc - pente / 2, FH)], fill=pal(spec.get("droite", "fond")))
    elif t == "image":
        src = Image.open(os.path.join(base, spec["src"])).convert("RGBA")
        k = max(FW / src.width, FH / src.height)
        src = src.resize((int(src.width * k) + 1, int(src.height * k) + 1), Image.LANCZOS)
        x0, y0 = (src.width - FW) // 2, (src.height - FH) // 2
        im = src.crop((x0, y0, x0 + FW, y0 + FH))
        if spec.get("flou"):
            im = im.filter(ImageFilter.GaussianBlur(spec["flou"]))
        if spec.get("eclaircir"):
            im = Image.blend(im, Image.new("RGBA", im.size, (255, 255, 255, 255)), spec["eclaircir"])
    else:
        im = Image.new("RGBA", (FW, FH), c)
    if spec.get("sol"):  # une surface où l'on pose les objets (table, comptoir)
        sy = int(my + H * float(spec.get("sol_y", 0.66)))
        sc = pal(spec["sol"])
        sol = degrade(FW, FH - sy, sc, melange(sc, (0, 0, 0, 255), spec.get("sol_ombre", 0.08)), 90) if spec.get("sol_ombre", 0.08) else Image.new("RGBA", (FW, FH - sy), sc)
        im.alpha_composite(sol, (0, sy))
    if spec.get("halo"):  # lumière douce derrière le sujet
        hc = pal(spec["halo"]) if isinstance(spec["halo"], str) else pal("clair")
        hx, hy = spec.get("halo_x", 0.5), spec.get("halo_y", 0.45)
        y, x = np.mgrid[-my:H + my, -mx:W + mx].astype(np.float32)
        d = np.sqrt(((x / W - hx) * W / H) ** 2 + (y / H - hy) ** 2)
        k = np.clip(1 - d / spec.get("halo_rayon", 0.45), 0, 1) ** 1.6 * spec.get("halo_force", 0.8)
        a = np.asarray(im, np.float32).copy()
        a[..., :3] = a[..., :3] + (np.array(hc[:3], np.float32) - a[..., :3]) * k[..., None]
        im = Image.fromarray(a.astype("uint8"), "RGBA")
    if spec.get("papier") or t == "papier":
        f = spec.get("papier", 1.0)
        a = np.asarray(im, np.float32).copy()
        a[..., :3] *= texture_papier(FW, FH, graine, 1.0 if f is True else float(f))[..., None]
        im = Image.fromarray(a.clip(0, 255).astype("uint8"), "RGBA")
    if spec.get("aquarelle"):
        a = np.asarray(im, np.float32).copy()
        taches = bruit_doux(FW, FH, 220, graine + 5)[..., None]
        a[..., :3] *= 0.94 + taches * 0.1
        a[..., :3] *= texture_papier(FW, FH, graine, 1.6)[..., None]
        im = Image.fromarray(a.clip(0, 255).astype("uint8"), "RGBA")
    return im
