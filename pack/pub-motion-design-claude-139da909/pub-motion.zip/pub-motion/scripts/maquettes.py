"""Maquettes dessinées en code : des objets simples (bouteille, pot, pétale, feuille, rondelle, verre,
sac, boutique, soleil, logo, chiffre en volume) pour les esquisses et les essais, avant d'avoir les
vraies images. Aucune IA, aucun fichier extérieur.

Dans pub.json : "src": "maquette:bouteille;couleur=#B5122B;etiquette=Bissap & Co"
En ligne de commande : python maquettes.py dossier/   → écrit toutes les maquettes en PNG (planche de test).

Ce sont des maquettes : pour la vraie pub, les remplacer par les photos de la personne ou par les
images générées (references/images.md).
"""
import math
import os
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matiere as M  # noqa: E402

S = 2  # dessin à 2× puis réduction (bords lisses)


def _fin(im):
    return im.resize((im.width // S, im.height // S), Image.LANCZOS)


def _rgba(c):
    return M.hex_rgba(c) if isinstance(c, str) else c


def _plus_clair(c, k):
    return M.melange(c, (255, 255, 255, 255), k)


def _plus_fonce(c, k):
    return M.melange(c, (0, 0, 0, 255), k)


def _degrade_vertical(w, h, c1, c2):
    return M.degrade(w, h, c1, c2, 90)


def _degrade_h(w, h, c1, c2):
    return M.degrade(w, h, c1, c2, 0)


def bouteille(couleur="#B5122B", etiquette="Bissap\n& Co", bouchon="#C9C9C9", papier="#FBF3E6", encre="#7A0F1F", polices=None):
    w, h = 360 * S, 960 * S
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    c = _rgba(couleur)
    verre = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(verre)
    col_w = w * 0.36
    d.rounded_rectangle([w * 0.06, h * 0.32, w * 0.94, h * 0.995], radius=int(w * 0.16), fill=255)
    d.polygon([(w * 0.06, h * 0.40), (w / 2 - col_w / 2, h * 0.17), (w / 2 + col_w / 2, h * 0.17), (w * 0.94, h * 0.40)], fill=255)
    d.ellipse([w * 0.06, h * 0.24, w * 0.94, h * 0.52], fill=255)
    d.rectangle([w / 2 - col_w / 2, h * 0.09, w / 2 + col_w / 2, h * 0.22], fill=255)
    verre = verre.filter(ImageFilter.GaussianBlur(3))
    liquide = _degrade_h(w, h, _plus_fonce(c, 0.35), _plus_clair(c, 0.05))
    liquide = Image.blend(liquide, _degrade_h(w, h, _plus_clair(c, 0.15), _plus_fonce(c, 0.3)), 0.5)
    corps = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    corps.paste(liquide, (0, 0), verre)
    # air en haut du goulot
    haut = Image.new("RGBA", (w, int(h * 0.15)), (235, 235, 235, 120))
    m = verre.crop((0, 0, w, int(h * 0.15)))
    corps.paste(haut, (0, 0), m)
    # reflets
    ref = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dr = ImageDraw.Draw(ref)
    dr.rounded_rectangle([w * 0.16, h * 0.42, w * 0.25, h * 0.93], radius=int(w * 0.05), fill=(255, 255, 255, 120))
    dr.rounded_rectangle([w * 0.78, h * 0.45, w * 0.82, h * 0.9], radius=int(w * 0.02), fill=(255, 255, 255, 60))
    ref = ref.filter(ImageFilter.GaussianBlur(6 * S))
    ref.putalpha(Image.fromarray(np.minimum(np.asarray(ref.getchannel("A")), np.asarray(verre))))
    corps.alpha_composite(ref)
    im.alpha_composite(corps)
    # bouchon
    d = ImageDraw.Draw(im)
    bc = _rgba(bouchon)
    d.rounded_rectangle([w / 2 - col_w * 0.58, h * 0.03, w / 2 + col_w * 0.58, h * 0.11], radius=int(w * 0.03), fill=bc)
    for i in range(9):
        x = w / 2 - col_w * 0.5 + i * col_w / 8
        d.line([(x, h * 0.04), (x, h * 0.1)], fill=_plus_fonce(bc, 0.15), width=S * 2)
    # étiquette
    if etiquette:
        ex0, ey0, ex1, ey1 = w * 0.1, h * 0.56, w * 0.9, h * 0.84
        et = M.forme("rect", (ex1 - ex0), (ey1 - ey0), _rgba(papier), rayon=8 * S)
        pol = M.Polices(os.path.dirname(os.path.abspath(__file__)), polices).get(int(66 * S), "DMSerifDisplay.ttf")
        mots, bw, bh = M.mise_en_page(etiquette, pol, (ex1 - ex0) * 0.9, 0.95)
        dd = ImageDraw.Draw(et)
        oy = (et.height - bh) / 2 - pol.size * 0.08
        for mm in mots:
            dd.text(((et.width - bw) / 2 + mm["x"], oy + mm["y"]), mm["mot"], font=pol, fill=_rgba(encre))
        im.alpha_composite(et, (int(ex0), int(ey0)))
    return _fin(im)


def pot(couleur="#F3E3C3", couvercle="#7A4B2A", etiquette="Karité\nDoux", encre="#5A3418"):
    w, h = 520 * S, 560 * S
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = _rgba(couleur)
    corps = _degrade_h(int(w * 0.9), int(h * 0.72), _plus_fonce(c, 0.12), _plus_clair(c, 0.3))
    m = M.forme("rect", corps.width, corps.height, (255, 255, 255, 255), rayon=50 * S).getchannel("A")
    im.paste(corps, (int(w * 0.05), int(h * 0.26)), m)
    cv = _rgba(couvercle)
    d.rounded_rectangle([w * 0.02, h * 0.06, w * 0.98, h * 0.3], radius=30 * S, fill=cv)
    d.rounded_rectangle([w * 0.06, h * 0.09, w * 0.94, h * 0.14], radius=14 * S, fill=_plus_clair(cv, 0.25))
    if etiquette:
        pol = M.Polices(os.path.dirname(os.path.abspath(__file__))).get(int(70 * S), "DMSerifDisplay.ttf")
        mots, bw, bh = M.mise_en_page(etiquette, pol, w * 0.8, 0.95)
        for mm in mots:
            d.text(((w - bw) / 2 + mm["x"], h * 0.4 + mm["y"]), mm["mot"], font=pol, fill=_rgba(encre))
    return _fin(im)


def petale(couleur="#B5122B", graine=1):
    """Pétale ou calice (hibiscus, fleur) : forme de larme arrondie avec nervures."""
    w, h = 240 * S, 340 * S
    c = _rgba(couleur)
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    pts = []
    for i in range(100):
        u = i / 99
        a = math.pi * u
        larg = math.sin(a) ** 0.8 * (0.55 + 0.45 * u) * w * 0.46 * (1 + 0.05 * math.sin(7 * u + graine))
        pts.append((w / 2 + larg, h * 0.96 - u * h * 0.9))
    pts += [(w - x, y) for x, y in reversed(pts)]
    d.polygon(pts, fill=255)
    m = m.filter(ImageFilter.GaussianBlur(1.2))
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    im.paste(_degrade_vertical(w, h, _plus_clair(c, 0.18), _plus_fonce(c, 0.3)), (0, 0), m)
    nerv = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dn = ImageDraw.Draw(nerv)
    f = _plus_fonce(c, 0.4)[:3] + (120,)
    for k in (-0.5, -0.25, 0, 0.25, 0.5):
        dn.line([(w / 2, h * 0.94)] + [(w / 2 + k * w * 0.36 * math.sin(math.pi * u * 0.9), h * 0.94 - u * h * 0.78) for u in (0.3, 0.6, 0.9)],
                fill=f, width=2 * S, joint="curve")
    nerv.putalpha(Image.fromarray(np.minimum(np.asarray(nerv.getchannel("A")), np.asarray(m))))
    im.alpha_composite(nerv)
    return _fin(im)


def feuille(couleur="#3E9B4F"):
    w, h = 220 * S, 380 * S
    c = _rgba(couleur)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    pts = [(w / 2 + math.sin(math.pi * u) * w * 0.46 * (1 if s > 0 else -1), h * 0.04 + u * h * 0.9)
           for s in (1, -1) for u in ([i / 40 for i in range(41)] if s > 0 else [1 - i / 40 for i in range(41)])]
    d.polygon(pts, fill=255)
    im.paste(_degrade_h(w, h, _plus_fonce(c, 0.2), _plus_clair(c, 0.15)), (0, 0), m)
    dd = ImageDraw.Draw(im)
    v = _plus_clair(c, 0.35)
    dd.line([(w / 2, h * 0.06), (w / 2, h * 0.97)], fill=v, width=4 * S)
    for i in range(1, 6):
        y = h * (0.12 + i * 0.13)
        dd.line([(w / 2, y + 30 * S), (w * 0.16, y - 10 * S)], fill=v, width=2 * S)
        dd.line([(w / 2, y + 30 * S), (w * 0.84, y - 10 * S)], fill=v, width=2 * S)
    return _fin(im)


def rondelle(couleur="#F5C842", peau="#E9A81B"):
    """Rondelle d'agrume (citron, orange) vue de face."""
    D = 300 * S
    im = Image.new("RGBA", (D, D), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse([0, 0, D - 1, D - 1], fill=_rgba(peau))
    d.ellipse([D * 0.05, D * 0.05, D * 0.95, D * 0.95], fill=(253, 248, 225, 255))
    c = _rgba(couleur)
    for i in range(10):
        a0, a1 = 2 * math.pi * i / 10 + 0.06, 2 * math.pi * (i + 1) / 10 - 0.06
        r = D * 0.4
        pts = [(D / 2 + 6 * S * math.cos((a0 + a1) / 2), D / 2 + 6 * S * math.sin((a0 + a1) / 2))]
        pts += [(D / 2 + r * math.cos(a0 + (a1 - a0) * u), D / 2 + r * math.sin(a0 + (a1 - a0) * u)) for u in [k / 12 for k in range(13)]]
        d.polygon(pts, fill=c)
    return _fin(im)


def verre(couleur="#B5122B"):
    w, h = 340 * S, 480 * S
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = _rgba(couleur)
    d.polygon([(w * 0.05, 0), (w * 0.95, 0), (w * 0.86, h), (w * 0.14, h)], fill=(225, 235, 240, 110))
    liq = Image.new("L", (w, h), 0)
    ImageDraw.Draw(liq).polygon([(w * 0.09, h * 0.22), (w * 0.91, h * 0.22), (w * 0.85, h * 0.97), (w * 0.15, h * 0.97)], fill=255)
    im.paste(_degrade_h(w, h, _plus_fonce(c, 0.3), _plus_clair(c, 0.1)), (0, 0), liq)
    for x, y in ((0.32, 0.3), (0.58, 0.36), (0.44, 0.5)):  # glaçons
        d.rounded_rectangle([w * x, h * y, w * x + 70 * S, h * y + 70 * S], radius=14 * S, fill=(255, 255, 255, 120))
    d.rounded_rectangle([w * 0.16, h * 0.08, w * 0.22, h * 0.9], radius=6 * S, fill=(255, 255, 255, 110))
    return _fin(im)


def sac(couleur="#E8D3B0", logo="B&Co", encre="#7A0F1F"):
    w, h = 460 * S, 560 * S
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = _rgba(couleur)
    d.arc([w * 0.28, 0, w * 0.72, h * 0.4], 180, 360, fill=_plus_fonce(c, 0.4), width=14 * S)
    d.polygon([(w * 0.06, h * 0.2), (w * 0.94, h * 0.2), (w, h), (0, h)], fill=c)
    d.polygon([(w * 0.06, h * 0.2), (w * 0.94, h * 0.2), (w * 0.9, h * 0.27), (w * 0.1, h * 0.27)], fill=_plus_fonce(c, 0.1))
    pol = M.Polices(os.path.dirname(os.path.abspath(__file__))).get(int(90 * S), "DMSerifDisplay.ttf")
    tw = pol.getlength(logo)
    d.text(((w - tw) / 2, h * 0.5), logo, font=pol, fill=_rgba(encre))
    return _fin(im)


def boutique(mur="#FFF4E4", store="#B5122B", nom="Bissap & Co", encre="#7A0F1F"):
    """Façade simple de boutique (illustration plate) : store rayé, vitrine, enseigne."""
    w, h = 900 * S, 900 * S
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rectangle([0, h * 0.1, w, h], fill=_rgba(mur))
    pol = M.Polices(os.path.dirname(os.path.abspath(__file__))).get(int(96 * S), "DMSerifDisplay.ttf")
    tw = pol.getlength(nom)
    d.text(((w - tw) / 2, h * 0.13), nom, font=pol, fill=_rgba(encre))
    sc = _rgba(store)
    for i in range(10):
        x0 = i * w / 10
        d.polygon([(x0, h * 0.34), (x0 + w / 10, h * 0.34), (x0 + w / 10, h * 0.44), (x0, h * 0.44)], fill=sc if i % 2 == 0 else (255, 255, 255, 255))
        d.pieslice([x0, h * 0.4, x0 + w / 10, h * 0.48], 0, 180, fill=sc if i % 2 == 0 else (255, 255, 255, 255))
    d.rectangle([w * 0.1, h * 0.52, w * 0.9, h * 0.92], fill=(250, 226, 190, 255))
    for k in range(3):  # étagères avec bouteilles
        y = h * (0.62 + k * 0.1)
        d.rectangle([w * 0.12, y, w * 0.88, y + 8 * S], fill=(160, 110, 70, 255))
        for j in range(9):
            x = w * 0.15 + j * w * 0.08
            col = [(181, 18, 43), (242, 182, 50), (240, 230, 200), (232, 120, 40)][(j + k) % 4] + (255,)
            d.rounded_rectangle([x, y - 60 * S, x + 34 * S, y], radius=8 * S, fill=col)
            d.rectangle([x + 10 * S, y - 76 * S, x + 24 * S, y - 58 * S], fill=col)
    d.rectangle([0, h * 0.92, w, h], fill=(214, 196, 170, 255))
    return _fin(im)


def soleil(couleur="#F6C431"):
    D = 420 * S
    im = Image.new("RGBA", (D, D), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = _rgba(couleur)
    for i in range(12):
        a = 2 * math.pi * i / 12
        d.line([(D / 2 + D * 0.3 * math.cos(a), D / 2 + D * 0.3 * math.sin(a)), (D / 2 + D * 0.48 * math.cos(a), D / 2 + D * 0.48 * math.sin(a))],
               fill=c, width=22 * S)
    d.ellipse([D * 0.22, D * 0.22, D * 0.78, D * 0.78], fill=c)
    return _fin(im)


def logo(nom="Bissap & Co", couleur="#B5122B", fond="#FFFFFF", sous_titre="jus pressés · Dakar"):
    D = 600 * S
    im = Image.new("RGBA", (D, D), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = _rgba(couleur)
    d.ellipse([0, 0, D - 1, D - 1], fill=c)
    d.ellipse([D * 0.04, D * 0.04, D * 0.96, D * 0.96], fill=_rgba(fond))
    d.ellipse([D * 0.07, D * 0.07, D * 0.93, D * 0.93], outline=c, width=3 * S)
    pol = M.Polices(os.path.dirname(os.path.abspath(__file__))).get(int(118 * S), "DMSerifDisplay.ttf")
    mots, bw, bh = M.mise_en_page(nom.replace(" & ", "\n& "), pol, D * 0.8, 0.9)
    for mm in mots:
        d.text(((D - bw) / 2 + mm["x"], D * 0.27 + mm["y"]), mm["mot"], font=pol, fill=c)
    if sous_titre:
        p2 = M.Polices(os.path.dirname(os.path.abspath(__file__))).get(int(34 * S), "Geist.ttf", 600)
        tw = p2.getlength(sous_titre)
        d.text(((D - tw) / 2, D * 0.72), sous_titre, font=p2, fill=_plus_fonce(c, 0.1))
    return _fin(im)


def volume(texte="3", couleur="#E8336D", taille=700, police="Fredoka.ttf", pate=False):
    """Un chiffre ou un mot en volume (3D douce, ou pâte à modeler avec pate=1)."""
    pol = M.Polices(os.path.dirname(os.path.abspath(__file__))).get(int(taille), police, 700)
    w = int(pol.getlength(texte)) + 80
    a, dsc = pol.getmetrics()
    im = Image.new("RGBA", (w, a + dsc + 80), (0, 0, 0, 0))
    ImageDraw.Draw(im).text((40, 40), texte, font=pol, fill=_rgba(couleur))
    im = im.crop(im.getbbox())
    im = M.avec_marge(im, 20)
    return M.relief(im, 0.7, lisse=not pate, texture=1.0 if pate else 0)


MAQUETTES = {"bouteille": bouteille, "pot": pot, "petale": petale, "feuille": feuille, "rondelle": rondelle, "verre": verre,
             "sac": sac, "boutique": boutique, "soleil": soleil, "logo": logo, "volume": volume}


def depuis_texte(txt, pal=None):
    """« bouteille;couleur=#B5122B;etiquette=Bissap & Co » → image. Les couleurs peuvent être des noms
    de la palette de la marque (accent, second…)."""
    morceaux = txt.split(";")
    nom = morceaux[0].strip()
    kw = {}
    for m in morceaux[1:]:
        if "=" in m:
            k, v = m.split("=", 1)
            v = v.strip().replace("\\n", "\n")
            if pal is not None and k.strip() in ("couleur", "bouchon", "papier", "encre", "couvercle", "peau", "mur", "store", "fond") and not v.startswith("#"):
                v = pal(v)
            elif k.strip() in ("taille", "graine"):
                v = int(v)
            elif k.strip() == "pate":
                v = v not in ("0", "non", "false")
            kw[k.strip()] = v
    if nom not in MAQUETTES:
        raise SystemExit(f"Maquette inconnue : {nom}. Au choix : {', '.join(MAQUETTES)}")
    return MAQUETTES[nom](**kw)


if __name__ == "__main__":
    d = sys.argv[1] if len(sys.argv) > 1 else "maquettes"
    os.makedirs(d, exist_ok=True)
    for nom, f in MAQUETTES.items():
        f().save(os.path.join(d, f"{nom}.png"))
    print(f"{len(MAQUETTES)} maquettes dans {d}")
