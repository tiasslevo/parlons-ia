"""Assemble le son de la pub et livre deux vidéos : avec musique, et sans musique.

usage :
  python mixage.py --video sortie/muette.mp4 [--musique sortie/musique.wav] [--cues sortie/cues.json]
                   [--voix voix.mp3 --voix-a 0.4] [--sons ma-banque/] [--sans-bruitages] [--dossier sortie/]

Sorties (dans --dossier, par défaut celui de la vidéo) :
  pub.mp4               voix + musique + bruitages, -14 LUFS (niveau TikTok / Reels)
  pub-sans-musique.mp4  voix + bruitages (ou bruitages seuls) : pour poser un son tendance dans TikTok
- La musique baisse toute seule sous la voix (9 dB).
- Bruitages : la banque du skill (assets/sons/, synthétisée en code, libre de droits), ou --sons
  (sous-dossiers pop/, whoosh/, glisse/, impact/, clic/, ding/, coupe/ ; wav ou mp3).
- --voix-a : instant (s) où la voix commence dans la vidéo.
"""
import argparse
import json
import os
import random
import re
import subprocess
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import SR, ecrire_wav, ffmpeg_exe, lire_audio, normaliser  # noqa: E402

GAINS = {"impact": -16.0, "whoosh": -22.0, "coupe": -24.0, "pop": -24.0, "glisse": -25.0, "clic": -20.0, "ding": -22.0}
ECART_MIN = {"impact": 1.5, "pop": 0.3, "whoosh": 0.4, "glisse": 0.5, "coupe": 0.3, "clic": 0.2, "ding": 1.0}
BANQUE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "sons")


def banque(dossier):
    b = {}
    if dossier and os.path.isdir(dossier):
        for typ in os.listdir(dossier):
            d = os.path.join(dossier, typ)
            if os.path.isdir(d):
                fs = sorted(os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith((".wav", ".mp3", ".ogg", ".flac")))
                if fs:
                    b[typ] = fs
    return b


def duree_video(v):
    err = subprocess.run([ffmpeg_exe(), "-i", v], capture_output=True, text=True).stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", err)
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def coller_son(video, wav, sortie):
    subprocess.run([ffmpeg_exe(), "-v", "error", "-y", "-i", video, "-i", wav, "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                    "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", sortie], check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--musique")
    ap.add_argument("--cues")
    ap.add_argument("--voix")
    ap.add_argument("--voix-a", type=float, default=0.3)
    ap.add_argument("--sons")
    ap.add_argument("--sans-bruitages", action="store_true")
    ap.add_argument("--musique-db", type=float, default=-15.0)
    ap.add_argument("--dossier")
    ap.add_argument("--graine", type=int, default=5)
    a = ap.parse_args()
    random.seed(a.graine)
    dossier = a.dossier or os.path.dirname(os.path.abspath(a.video))
    duree = duree_video(a.video)
    n = int((duree + 0.1) * SR)

    voix = np.zeros(n, np.float32)
    if a.voix:
        v = lire_audio(a.voix)
        i0 = int(a.voix_a * SR)
        voix[i0:i0 + len(v)] += v[: max(0, n - i0)]
        if i0 + len(v) > n:
            print(f"Attention : la voix dépasse la vidéo de {(i0 + len(v) - n) / SR:.1f} s (allonger la fin ou resserrer la voix).")

    bruits = np.zeros(n, np.float32)
    cues_f = a.cues or os.path.join(os.path.dirname(os.path.abspath(a.video)), "cues.json")
    if not a.sans_bruitages and os.path.exists(cues_f):
        b = banque(BANQUE)
        b.update(banque(a.sons))
        cache, dernier, poses = {}, {}, 0
        for c in json.load(open(cues_f, encoding="utf-8")):
            typ, t = c.get("type", "pop"), float(c["t"])
            f = c.get("fichier")
            if not f:
                if typ not in b or t - dernier.get(typ, -99) < ECART_MIN.get(typ, 0.3):
                    continue
                f = random.choice(b[typ])
            dernier[typ] = t
            if f not in cache:
                y = lire_audio(f)
                cache[f] = y / (np.abs(y).max() or 1)
            y = cache[f][: int(SR * 2)] * 10 ** (float(c.get("gain", GAINS.get(typ, -22))) / 20)
            i0 = int(max(0, t - (0.12 if typ == "whoosh" else 0)) * SR)
            if i0 >= n:
                continue
            i1 = min(n, i0 + len(y))
            bruits[i0:i1] += y[: i1 - i0]
            poses += 1
        print(f"{poses} bruitages posés")

    musique = np.zeros(n, np.float32)
    if a.musique:
        m = lire_audio(a.musique)
        if len(m) < n:
            m = np.tile(m, n // max(1, len(m)) + 1)
        m = m[:n] / (np.abs(m).max() or 1) * 10 ** (a.musique_db / 20)
        if a.voix:  # la musique baisse sous la voix
            fen = int(0.3 * SR)
            cs = np.concatenate([[0.0], np.cumsum(np.abs(voix).astype(np.float64))])
            i = np.arange(n)
            env = (cs[np.clip(i + fen // 2, 0, n)] - cs[np.clip(i - fen // 2, 0, n)]) / fen
            ref = np.percentile(env[env > 0], 60) if np.any(env > 0) else 1
            m = m * (1 - np.clip(env / ref, 0, 1) * (1 - 10 ** (-9 / 20)))
        fin = int(0.6 * SR)
        m[-fin:] *= np.linspace(1, 0, fin)
        musique = m.astype(np.float32)

    sorties = []
    for nom, pistes in (("pub", (voix, bruits, musique)), ("pub-sans-musique", (voix, bruits))):
        if nom == "pub" and not a.musique:
            continue
        mix = np.tanh(sum(pistes)).astype(np.float32)
        brut = os.path.join(dossier, f"{nom}-brut.wav")
        wav = os.path.join(dossier, f"{nom}.wav")
        ecrire_wav(brut, mix)
        if a.voix or nom == "pub":
            normaliser(brut, wav, -14.0)
            os.remove(brut)
        else:  # bruitages seuls : on garde leur niveau
            os.replace(brut, wav)
        mp4 = os.path.join(dossier, f"{nom}.mp4")
        coller_son(a.video, wav, mp4)
        os.remove(wav)
        sorties.append(mp4)
        print(f"Vidéo : {mp4} ({os.path.getsize(mp4) / 1e6:.1f} Mo)")


if __name__ == "__main__":
    main()
