"""Planche de contrôle : toutes les images d'un dossier sur un damier, avec leur nom.

usage : python planche.py dossier [planche.jpg] [--fond "#FFE45C"]
Le damier fait ressortir un fond mal détouré ; --fond montre les images sur la couleur d'un décor.
"""
import argparse
import math
import os

from PIL import Image, ImageDraw, ImageFont


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dossier")
    ap.add_argument("sortie", nargs="?")
    ap.add_argument("--fond")
    a = ap.parse_args()
    fs = sorted(f for f in os.listdir(a.dossier) if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp")))
    if not fs:
        raise SystemExit("Aucune image.")
    c, cols = 320, 4
    rows = math.ceil(len(fs) / cols)
    pl = Image.new("RGB", (cols * (c + 16) + 16, rows * (c + 50) + 16), (40, 40, 44))
    d = ImageDraw.Draw(pl)
    try:
        pol = ImageFont.truetype(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "fonts", "Geist.ttf"), 22)
    except OSError:
        pol = ImageFont.load_default()
    for i, f in enumerate(fs):
        x, y = 16 + (i % cols) * (c + 16), 16 + (i // cols) * (c + 50)
        if a.fond:
            case = Image.new("RGBA", (c, c), a.fond)
        else:
            case = Image.new("RGBA", (c, c), (255, 255, 255, 255))
            dc = ImageDraw.Draw(case)
            for cx in range(0, c, 20):
                for cy in range(0, c, 20):
                    if (cx + cy) // 20 % 2:
                        dc.rectangle([cx, cy, cx + 19, cy + 19], fill=(214, 214, 220))
        im = Image.open(os.path.join(a.dossier, f)).convert("RGBA")
        im.thumbnail((c - 20, c - 20))
        case.alpha_composite(im, ((c - im.width) // 2, (c - im.height) // 2))
        pl.paste(case.convert("RGB"), (x, y))
        d.text((x, y + c + 10), f[:34], font=pol, fill=(230, 230, 230))
    sortie = a.sortie or os.path.join(a.dossier, "planche.jpg")
    pl.save(sortie, quality=88)
    print(f"Planche : {sortie} ({len(fs)} images)")


if __name__ == "__main__":
    main()
