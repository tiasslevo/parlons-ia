"""Les éléments d'une pub (calques) et leurs mouvements.

Chaque élément sait dire, pour un instant t, où il est (etat) et à quoi il ressemble (contenu).
moteur.py s'occupe de la caméra, de la profondeur, des transitions et de l'assemblage.
Rien ne dépend de l'image précédente : on peut rendre n'importe quel instant, dans n'importe quel ordre.
"""
import math
import os
import random

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter

import matiere as M

# ---------------------------------------------------------------- courbes
def douce(p):
    return 0.5 - 0.5 * math.cos(math.pi * min(1, max(0, p)))


def sortie_c(p):
    p = min(1, max(0, p))
    return 1 - (1 - p) ** 3


def entree_c(p):
    p = min(1, max(0, p))
    return p ** 3


def rebond_c(p, s=1.70158):
    p = min(1, max(0, p)) - 1
    return p * p * ((s + 1) * p + s) + 1


def ressort(tau, amorti=8.0, freq=15.0):
    """0 → 1 avec un petit dépassement (pop). tau en secondes."""
    if tau <= 0:
        return 0.0
    return 1 - math.exp(-amorti * tau) * math.cos(freq * tau)


def elastique_c(p):
    p = min(1, max(0, p))
    if p in (0, 1):
        return p
    return 2 ** (-10 * p) * math.sin((p * 10 - 0.75) * (2 * math.pi) / 3) + 1


COURBES = {"douce": douce, "sortie": sortie_c, "entree": entree_c, "rebond": rebond_c, "lineaire": lambda p: min(1, max(0, p)),
           "elastique": elastique_c}


def courbe(nom):
    return COURBES.get(nom or "douce", douce)


def chute(tau, h0, t_chute, e=0.35, rebonds=3):
    """Hauteur au-dessus du sol d'un objet lâché de h0 px, qui touche le sol à t_chute puis rebondit.
    Renvoie (hauteur, choc) ; choc ∈ [0, 1] marque l'instant d'un impact (pour l'écrasement)."""
    if h0 <= 0:
        return 0.0, 0.0
    g = 2 * h0 / max(1e-3, t_chute ** 2)
    if tau < t_chute:
        return h0 - 0.5 * g * tau * tau, 0.0
    v = g * t_chute
    t = tau - t_chute
    choc = math.exp(-t * 30)
    for _ in range(rebonds):
        v *= e
        duree = 2 * v / g
        if t < duree:
            return v * t - 0.5 * g * t * t, choc
        t -= duree
    return 0.0, choc


# ---------------------------------------------------------------- masques de révélation
def masquer(im, nom, p, centre=(0.5, 0.5)):
    """Ne garde que la partie révélée d'une image (p de 0 à 1)."""
    if p >= 1:
        return im
    w, h = im.size
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    if p <= 0:
        out = im.copy()
        out.putalpha(m)
        return out
    if nom == "volet-gauche":  # se dévoile de gauche à droite
        d.rectangle([0, 0, w * p, h], fill=255)
    elif nom == "volet-droite":
        d.rectangle([w * (1 - p), 0, w, h], fill=255)
    elif nom == "volet-haut":
        d.rectangle([0, 0, w, h * p], fill=255)
    elif nom == "volet-bas":
        d.rectangle([0, h * (1 - p), w, h], fill=255)
    elif nom == "rideau":
        d.rectangle([w / 2 * (1 - p), 0, w / 2 * (1 + p), h], fill=255)
    elif nom == "rond":
        cx, cy = centre[0] * w, centre[1] * h
        r = p * math.hypot(max(cx, w - cx), max(cy, h - cy))
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=255)
    elif nom == "diagonale":
        k = p * (w + h)
        d.polygon([(0, 0), (k, 0), (0, k)], fill=255)
    else:
        d.rectangle([0, 0, w, h], fill=255)
    out = im.copy()
    out.putalpha(ImageChops.multiply(im.getchannel("A"), m))
    return out


ANIM_MASQUE = {"volet-gauche", "volet-droite", "volet-haut", "volet-bas", "rideau", "rond", "diagonale"}
ANIM_DUREE = {"pop": 0.5, "zoom": 0.45, "monte": 0.5, "descend": 0.5, "glisse-gauche": 0.55, "glisse-droite": 0.55,
              "tombe": 0.55, "tourne": 0.6, "elastique": 0.7, "fondu": 0.4, "ecrase": 0.35, "dessine": 0.6,
              "projete": 2.4, "aucune": 0.0}


# ---------------------------------------------------------------- l'élément de base
class Calque:
    statique = True      # contenu identique d'une image à l'autre (cache possible)
    est_texte = False
    type = "calque"

    def __init__(self, spec, pub, plan):
        self.spec, self.pub, self.plan = spec, pub, plan
        H = pub.horloge
        self.id = spec.get("id") or f"{plan.nom if plan else 'perm'}:{spec.get('type')}:{id(self) % 100000}"
        base = plan.t0 if plan else 0.0
        fin = plan.t_fin_rendu if plan else pub.duree
        self.t0 = H.t(spec.get("a", 0), base, plan.t1 if plan else pub.duree)
        self.t1 = H.t(spec["jusqua"], base, plan.t1 if plan else pub.duree) if "jusqua" in spec else fin
        self.anim = spec.get("anim", self.anim_defaut())
        self.d_anim = H.d(spec.get("duree_anim", ANIM_DUREE.get(self.anim, 0.5)))
        self.sortie = spec.get("sortie")
        self.d_sortie = H.d(spec.get("duree_sortie", 0.35)) if self.sortie else 0.0
        self.role = spec.get("role", "texte" if self.est_texte else "objet")
        self.z = float(spec.get("z", 0))
        self.mouv = []
        for m in spec.get("mouvements", []):
            a = H.t(m.get("a", 0), base, plan.t1 if plan else pub.duree)
            f = H.t(m["fin"], base, plan.t1 if plan else pub.duree) if "fin" in m else a + 0.5
            self.mouv.append((a, f, m))
        self.mouv.sort(key=lambda x: x[0])
        if any(k in m for _, _, m in self.mouv for k in ("w", "h", "rayon", "couleur", "texte")):
            self.statique = False
        tr = pub.traitement(plan)
        self.saccade = spec.get("saccade", tr.get("saccade"))
        self.tremble = float(spec.get("tremble", tr.get("tremble", 0) if not self.est_texte else 0))
        self.graine = abs(hash(self.id)) % 10000

    def anim_defaut(self):
        return "pop"

    # temps vu par l'élément (saccade : image par image façon stop motion)
    def temps(self, t):
        if self.saccade:
            f = float(self.saccade)
            return math.floor(t * f + 1e-6) / f
        return t

    def visible(self, t):
        return self.t0 <= t < self.t1 + self.d_sortie

    def base(self):
        s = self.spec
        return {"x": float(s.get("x", 540)), "y": float(s.get("y", 960)), "z": self.z, "echelle": float(s.get("echelle", 1)),
                "rot": float(s.get("rot", 0)), "opacite": float(s.get("opacite", 1)), "w": s.get("w"), "h": s.get("h"),
                "rayon": s.get("rayon", 0 if s.get("type") == "forme" else None), "couleur": s.get("couleur")}

    def etat(self, t):
        t = self.temps(t)
        st = self.base()
        pal = self.pub.pal
        for a, f, m in self.mouv:
            if t <= a:
                break
            p = courbe(m.get("courbe", "douce"))((t - a) / max(1e-3, f - a))
            for k, v in m.items():
                if k in ("a", "fin", "courbe"):
                    continue
                if k == "couleur":
                    c0 = pal(st["couleur"] or "accent")
                    st[k] = M.melange(c0, pal(v), p) if p < 1 else pal(v)
                elif isinstance(v, (int, float)) and st.get(k) is not None:
                    st[k] = st[k] + (float(v) - st[k]) * p
                else:
                    st[k] = v if p >= 0.5 else st.get(k)
        st.update(sx=1.0, sy=1.0, dx=0.0, dy=0.0, masque=None, hauteur=0.0, stable=True)
        tau = t - self.t0
        self.appliquer_entree(st, tau)
        if self.sortie and t >= self.t1:
            self.appliquer_sortie(st, (t - self.t1) / max(1e-3, self.d_sortie))
        self.appliquer_boucle(st, t)
        if self.tremble:
            pas = math.floor(t * float(self.saccade or 8))
            rng = random.Random(self.graine * 1000 + pas)
            st["dx"] += rng.uniform(-1.5, 1.5) * self.tremble
            st["dy"] += rng.uniform(-1.5, 1.5) * self.tremble
            st["rot"] += rng.uniform(-0.7, 0.7) * self.tremble
        return st

    def appliquer_entree(self, st, tau):
        a, d = self.anim, max(1e-3, self.d_anim)
        p = tau / d
        if a == "aucune" or tau >= d * 2.2 and a not in ("tombe", "projete"):
            return
        st["stable"] = tau >= d
        dist = float(self.spec.get("distance", 160))
        if a == "pop":
            k = ressort(tau * 0.5 / d * 1.0 / 0.5)
            st["echelle"] *= max(0.0, k)
            st["opacite"] *= min(1, tau / 0.08)
        elif a == "zoom":
            st["echelle"] *= 0.7 + 0.3 * sortie_c(p)
            st["opacite"] *= min(1, p * 1.6)
        elif a in ("monte", "descend"):
            sgn = 1 if a == "monte" else -1
            st["dy"] += sgn * dist * (1 - rebond_c(p, 1.2))
            st["opacite"] *= min(1, p * 2)
        elif a in ("glisse-gauche", "glisse-droite"):
            sgn = -1 if a == "glisse-gauche" else 1
            st["dx"] += sgn * float(self.spec.get("distance", 900)) * (1 - rebond_c(p, 1.0))
        elif a == "tombe":
            h0 = float(self.spec.get("hauteur_chute", st["y"] + 300))
            e = float(self.spec.get("rebond", self.pub.rebond))
            h, choc = chute(tau, h0, d, e)
            st["dy"] -= h
            st["hauteur"] = h
            st["stable"] = h < 1 and tau > d
            if self.pub.ecrasement and choc > 0.01:
                st["sy"] *= 1 - 0.18 * choc
                st["sx"] *= 1 + 0.12 * choc
            r0 = float(self.spec.get("rot_chute", 0))
            if r0:
                st["rot"] += r0 * (1 - sortie_c(min(1, tau / d)))
        elif a == "tourne":
            st["echelle"] *= max(0, ressort(tau))
            st["rot"] += -100 * (1 - sortie_c(p))
            st["opacite"] *= min(1, tau / 0.1)
        elif a == "elastique":
            k = elastique_c(p)
            st["sx"] *= 0.4 + 0.6 * k
            st["sy"] *= 1.5 - 0.5 * k
            st["opacite"] *= min(1, p * 4)
        elif a == "fondu":
            st["opacite"] *= min(1, p)
        elif a in ANIM_MASQUE:
            st["masque"] = (a, sortie_c(p))
        elif a == "ecrase":  # tampon
            if p < 1:
                st["echelle"] *= 1 + 1.5 * (1 - entree_c(p))
                st["opacite"] *= min(1, p * 3)
            else:
                k = math.exp(-(tau - d) * 18)
                st["dx"] += math.sin(tau * 90) * 9 * k
                st["dy"] += math.cos(tau * 77) * 6 * k
        elif a == "projete":  # confettis, éclats
            vx, vy = self.spec.get("vitesse", [0, -1200])
            g = float(self.spec.get("gravite", 2600))
            frein = float(self.spec.get("frein", 1.6))
            ex = (1 - math.exp(-frein * tau)) / frein
            st["dx"] += vx * ex
            st["dy"] += vy * ex + 0.5 * g * tau * tau * 0.6
            st["rot"] += float(self.spec.get("spin", 360)) * tau
            st["sx"] *= abs(math.cos(tau * float(self.spec.get("flip", 7)))) * 0.8 + 0.2
            st["opacite"] *= max(0, min(1, (d - tau) / 0.6))
            st["stable"] = False
        elif a == "dessine":
            st["trace"] = sortie_c(p)

    def appliquer_sortie(self, st, p):
        p = min(1, max(0, p))
        s = self.sortie
        st["stable"] = False
        if s == "reduit":
            st["echelle"] *= 1 - entree_c(p)
        elif s == "fondu":
            st["opacite"] *= 1 - p
        elif s in ("monte", "descend"):
            st["dy"] += (-1 if s == "monte" else 1) * 220 * entree_c(p)
            st["opacite"] *= 1 - p
        elif s in ("glisse-gauche", "glisse-droite"):
            st["dx"] += (-1 if s == "glisse-gauche" else 1) * 1200 * entree_c(p)
        elif s in ANIM_MASQUE:
            st["masque"] = ({"volet-gauche": "volet-droite", "volet-droite": "volet-gauche", "volet-haut": "volet-bas",
                             "volet-bas": "volet-haut"}.get(s, s), 1 - entree_c(p))
        elif s == "tombe":
            st["dy"] += 2400 * entree_c(p) ** 1.2
            st["rot"] += 40 * p

    def appliquer_boucle(self, st, t):
        b = self.spec.get("boucle")
        if not b:
            return
        tempo = self.pub.horloge.temps_s
        noms = b if isinstance(b, list) else [b]
        amp = float(self.spec.get("amplitude_boucle", 1.0))
        ph = (self.graine % 100) / 100 * 2 * math.pi
        for nom in noms:
            if nom == "respire":
                st["echelle"] *= 1 + 0.018 * amp * math.sin(2 * math.pi * t / (tempo * 4) + ph)
            elif nom == "balance":
                st["rot"] += 3.0 * amp * math.sin(2 * math.pi * t / (tempo * 4) + ph)
            elif nom == "flotte":
                st["dy"] += 12 * amp * math.sin(2 * math.pi * t / (tempo * 4) + ph)
            elif nom == "pulse":  # petit battement sur chaque temps de la musique
                k = (t - self.pub.horloge.decalage) / tempo
                fr = k - math.floor(k)
                st["echelle"] *= 1 + 0.045 * amp * math.exp(-fr * 7)
            elif nom == "tourne":
                st["rot"] += float(self.spec.get("vitesse_rot", 20)) * t
            elif nom == "derive":  # pétale qui descend en se balançant, revient en haut
                v = float(self.spec.get("vitesse_chute", 90)) * amp
                H = self.pub.H + 300
                y = (st["y"] + 150 + v * t) % H - 150
                st["dy"] += y - st["y"]
                st["dx"] += 40 * math.sin(t * 1.3 + ph)
                st["rot"] += 25 * math.sin(t * 0.9 + ph) + 30 * t * (1 if self.graine % 2 else -1)

    # ---- contenu : renvoie (image RGBA, ancre_x, ancre_y, echelle_de_dessin)
    def contenu(self, t, st, s_hint):
        raise NotImplementedError

    def ancre(self, w, h):
        a = self.spec.get("ancre", "centre")
        return {"centre": (w / 2, h / 2), "bas": (w / 2, h), "haut": (w / 2, 0), "gauche": (0, h / 2),
                "droite": (w, h / 2)}.get(a, (w / 2, h / 2))

    def info_verif(self):
        return {}


# ---------------------------------------------------------------- images
class Img(Calque):
    type = "image"

    def __init__(self, spec, pub, plan):
        super().__init__(spec, pub, plan)
        self._base = None

    def charger(self):
        if self._base is None:
            src = self.spec["src"]
            im = self.pub.charger_image(src)
            tr = self.spec.get("traitements", [])
            if self.spec.get("masque"):
                tr = [{"masque": self.spec["masque"]}] + list(tr)
            if self.spec.get("bord"):
                tr = list(tr) + [{"bord_papier" if self.pub.bord_irregulier else "bord_blanc": self.spec["bord"]}]
            cible = self.spec.get("largeur")
            cible_h = self.spec.get("hauteur")
            k = (cible / im.width) if cible else (cible_h / im.height) if cible_h else 1.0
            # on garde jusqu'à 1,6 × la taille affichée pour les zooms
            kk = min(1.0, 1.6 * k)
            if kk < 1:
                im = im.resize((max(1, int(im.width * kk)), max(1, int(im.height * kk))), Image.LANCZOS)
            im = M.appliquer_traitements(im, tr, self.pub.pal, self.graine)
            if self.spec.get("ombre") == "portee" or self.spec.get("ombre_portee"):
                o = self.spec.get("ombre_portee", {}) if isinstance(self.spec.get("ombre_portee"), dict) else {}
                im, m = M.ombre_portee(im, o.get("dx", 0), o.get("dy", 22 * kk), o.get("flou", 22 * kk), o.get("opacite", 0.26),
                                       self.pub.pal("ombre")[:3])
            self._base = (im, k / kk if kk < 1 else k)
        return self._base

    def contenu(self, t, st, s_hint):
        im, s_img = self.charger()
        ax, ay = self.ancre(im.width, im.height)
        return im, ax, ay, 1.0 / s_img


# ---------------------------------------------------------------- formes
class Forme(Calque):
    type = "forme"

    def anim_defaut(self):
        return "zoom"

    def __init__(self, spec, pub, plan):
        super().__init__(spec, pub, plan)
        if spec.get("ondule"):
            self.statique = False
        self._cache = {}

    def contenu(self, t, st, s_hint):
        sp = self.spec
        s = max(0.25, round(s_hint * 20) / 20)
        w = float(st["w"] or sp.get("w", 200))
        h = float(st["h"] or sp.get("h", w))
        coul = self.pub.pal(st["couleur"] or sp.get("couleur", "accent"))
        ph = t * 1.6 if sp.get("ondule") else 0.0
        if sp.get("ondule") and self.saccade:
            ph = math.floor(t * float(self.saccade)) / float(self.saccade) * 1.6
        cle = (round(w * s), round(h * s), coul, round(ph, 2), round((st["rayon"] or 0) * s))
        if cle not in self._cache:
            if len(self._cache) > 40:
                self._cache.clear()
            im = M.forme(sp.get("forme", "rect"), w * s, h * s, coul, rayon=(st["rayon"] or sp.get("rayon", 0)) * s,
                         contour=sp.get("contour", 0) * s, couleur_contour=self.pub.pal(sp.get("couleur_contour", "clair")),
                         graine=sp.get("graine", 1), phase=ph, **{k: sp[k] for k in ("branches", "creux", "pointes", "irreg", "amplitude", "ondes", "queue") if k in sp})
            im = M.appliquer_traitements(im, sp.get("traitements", self.pub.traitement(self.plan).get("formes", [])), self.pub.pal, self.graine)
            if sp.get("ombre") == "portee":
                im, _ = M.ombre_portee(im, 0, 16 * s, 18 * s, 0.22, self.pub.pal("ombre")[:3])
            self._cache[cle] = im
        im = self._cache[cle]
        ax, ay = self.ancre(im.width, im.height)
        return im, ax, ay, s


# ---------------------------------------------------------------- texte
class Texte(Calque):
    type = "texte"
    est_texte = True

    def __init__(self, spec, pub, plan):
        super().__init__(spec, pub, plan)
        self.mode = spec.get("mode", "bloc")
        self.cadence = pub.horloge.d(spec.get("cadence", "0.5t" if self.mode == "mots" else 0.035 if self.mode == "lettres" else 0.06))
        self.statique = self.mode == "bloc" and not spec.get("surligne") and self.statique
        self._mots = {}
        self._unites = {}
        self.texte = str(spec.get("texte", ""))

    def anim_defaut(self):
        return {"mots": "aucune", "lettres": "aucune", "masque": "aucune", "machine": "aucune", "ecrit": "aucune"}.get(
            self.spec.get("mode", "bloc"), "monte")

    def taille(self):
        return float(self.spec.get("taille", 96))

    def police(self, s):
        sp = self.spec
        return self.pub.polices.get(self.taille() * s, sp.get("police", "titre"), sp.get("graisse"))

    def casse(self, txt):
        return txt.upper() if self.spec.get("casse") == "majuscules" else txt

    def page(self, s):
        cle = round(s, 3)
        if cle not in self._mots:
            sp = self.spec
            larg = float(sp.get("largeur", 900)) * s
            pol = self.police(s)
            mots, w, h = M.mise_en_page(self.casse(self.texte), pol, larg, sp.get("interligne", 1.04), sp.get("aligne", "centre"))
            # un mot plus large que la colonne : on réduit (rien ne doit être coupé)
            k = 1.0
            while mots and max(m["w"] for m in mots) > larg * 1.001 and k > 0.5:
                k *= 0.94
                pol = self.pub.polices.get(self.taille() * s * k, sp.get("police", "titre"), sp.get("graisse"))
                mots, w, h = M.mise_en_page(self.casse(self.texte), pol, larg, sp.get("interligne", 1.04), sp.get("aligne", "centre"))
            self._mots[cle] = (mots, w, h, pol, k)
        return self._mots[cle]

    def unite(self, txt, pol, coul, s):
        cle = (txt, id(pol), coul)
        if cle not in self._unites:
            ct = int(self.spec.get("contour", 0) * s)
            self._unites[cle] = M.sprite_texte(txt, pol, coul, ct, self.pub.pal(self.spec.get("couleur_contour", "clair")))
        return self._unites[cle]

    def couleurs(self, st):
        pal = self.pub.pal
        c = pal(st["couleur"] or self.spec.get("couleur", "encre"))
        ca = pal(self.spec.get("couleur_accent", "accent"))
        return c, ca

    def texte_a(self, t):
        """Texte affiché à t (les mouvements peuvent changer le texte)."""
        txt = self.spec.get("texte", "")
        for a, f, m in self.mouv:
            if "texte" in m and t >= a:
                txt = m["texte"]
        return str(txt)

    def contenu(self, t, st, s_hint):
        sp = self.spec
        s = max(0.3, round(s_hint * 25) / 25)
        txt = self.texte_a(self.temps(t))
        if txt != self.texte:
            self.texte, self._mots = txt, {}
        mots, bw, bh, pol, k = self.page(s)
        c, ca = self.couleurs(st)
        marge = int(40 * s)
        fond = sp.get("fond")
        pad = int((fond.get("marge", 34) if isinstance(fond, dict) else 34) * s) if fond else 0
        W, Hh = int(bw + 2 * (marge + pad)), int(bh + 2 * (marge + pad))
        im = Image.new("RGBA", (max(1, W), max(1, Hh)), (0, 0, 0, 0))
        ox, oy = marge + pad, marge + pad
        tau = self.temps(t) - self.t0
        if fond:
            fd = fond if isinstance(fond, dict) else {}
            carte = M.forme(fd.get("forme", "rect"), bw + 2 * pad, bh + 2 * pad, self.pub.pal(fd.get("couleur", "clair")),
                            rayon=fd.get("rayon", 28) * s)
            if fd.get("ombre", True):
                carte, mm = M.ombre_portee(carte, 0, 10 * s, 18 * s, 0.18, self.pub.pal("ombre")[:3])
                im.alpha_composite(carte, (marge - mm, marge - mm)) if marge >= mm else im.paste(carte, (marge - mm, marge - mm), carte)
            else:
                im.alpha_composite(carte, (marge, marge))
        # surligneur derrière les mots clés
        if sp.get("surligne"):
            debut = self.pub.horloge.d(sp.get("surligne_a", 0.35))
            p = sortie_c((tau - debut) / 0.4)
            if p > 0:
                cs = self.pub.pal(sp.get("couleur_surligne", "second/0.75"))
                d = ImageDraw.Draw(im)
                lignes = {}
                for m in mots:
                    if m["accent"]:
                        L = lignes.setdefault(m["ligne"], [1e9, -1e9, m["y"], m["h"]])
                        L[0], L[1] = min(L[0], m["x"]), max(L[1], m["x"] + m["w"])
                for li, (x0, x1, y, h) in lignes.items():
                    xe = x0 + (x1 - x0 + 16 * s) * p
                    d.rounded_rectangle([ox + x0 - 8 * s, oy + y + h * 0.42, ox + xe, oy + y + h * 0.92], radius=int(8 * s), fill=cs)
        mode = self.mode
        asc = pol.getmetrics()[0]
        if mode in ("bloc",):
            for m in mots:
                spr, dx, dy = self.unite(m["mot"], pol, ca if m["accent"] else c, s)
                im.alpha_composite(spr, (int(ox + m["x"] - dx), int(oy + m["y"] - dy)))
        elif mode == "mots":
            for i, m in enumerate(mots):
                tl = tau - i * self.cadence
                if tl <= 0:
                    continue
                spr, dx, dy = self.unite(m["mot"], pol, ca if m["accent"] else c, s)
                kk = max(0.0, ressort(tl, 9, 16))
                if kk < 0.999 or tl < 0.6:
                    if kk <= 0.01:
                        continue
                    w2, h2 = max(1, int(spr.width * kk)), max(1, int(spr.height * kk))
                    spr2 = spr.resize((w2, h2), Image.BILINEAR)
                    cx, cy = ox + m["x"] - dx + spr.width / 2, oy + m["y"] - dy + spr.height / 2
                    im.alpha_composite(spr2, (int(cx - w2 / 2), int(cy - h2 / 2)))
                else:
                    im.alpha_composite(spr, (int(ox + m["x"] - dx), int(oy + m["y"] - dy)))
        elif mode in ("lettres", "masque"):
            n = 0
            for i, m in enumerate(mots):
                coul = ca if m["accent"] else c
                if mode == "masque":
                    tl = tau - m["ligne"] * self.pub.horloge.d(sp.get("cadence", 0.14))
                    p = sortie_c(tl / 0.45)
                    spr, dx, dy = self.unite(m["mot"], pol, coul, s)
                    decal = int((1 - p) * m["h"] * 1.05)
                    if p <= 0:
                        continue
                    morceau = spr.crop((0, 0, spr.width, spr.height - decal)) if decal > 0 else spr
                    im.alpha_composite(morceau, (int(ox + m["x"] - dx), int(oy + m["y"] - dy + decal)))
                else:
                    x = m["x"]
                    for ch in m["mot"]:
                        tl = tau - n * self.cadence
                        n += 1
                        wch = pol.getlength(ch)
                        if tl > 0:
                            p = sortie_c(tl / 0.32)
                            spr, dx, dy = self.unite(ch, pol, coul, s)
                            decal = int((1 - p) * m["h"] * 0.9)
                            morceau = spr.crop((0, 0, spr.width, spr.height - decal)) if decal > 0 else spr
                            if morceau.height > 0:
                                im.alpha_composite(morceau, (int(ox + x - dx), int(oy + m["y"] - dy + decal)))
                        x += wch
                    n += 1
        elif mode == "machine":
            total = sum(len(m["mot"]) + 1 for m in mots)
            nb = int(tau / self.cadence)
            n = 0
            fin_x, fin_y = ox, oy
            for m in mots:
                if n >= nb:
                    break
                vis = m["mot"][:max(0, nb - n)]
                n += len(m["mot"]) + 1
                if vis:
                    spr, dx, dy = self.unite(vis, pol, ca if m["accent"] else c, s)
                    im.alpha_composite(spr, (int(ox + m["x"] - dx), int(oy + m["y"] - dy)))
                    fin_x, fin_y = ox + m["x"] + pol.getlength(vis), oy + m["y"]
            if nb < total + 8 and int(tau * 2.4) % 2 == 0:
                d = ImageDraw.Draw(im)
                d.rectangle([fin_x + 4 * s, fin_y + asc * 0.12, fin_x + 4 * s + max(3, 6 * s), fin_y + asc * 1.02], fill=ca)
        elif mode == "ecrit":  # se dévoile ligne par ligne, de gauche à droite
            nl = max(m["ligne"] for m in mots) + 1 if mots else 1
            d_ligne = self.pub.horloge.d(sp.get("cadence", 0.5))
            calque = Image.new("RGBA", im.size, (0, 0, 0, 0))
            for m in mots:
                spr, dx, dy = self.unite(m["mot"], pol, ca if m["accent"] else c, s)
                calque.alpha_composite(spr, (int(ox + m["x"] - dx), int(oy + m["y"] - dy)))
            masque = Image.new("L", im.size, 0)
            dm = ImageDraw.Draw(masque)
            hl = bh / nl
            for li in range(nl):
                p = sortie_c((tau - li * d_ligne) / d_ligne) if tau > li * d_ligne else 0
                if p > 0:
                    dm.rectangle([0, oy + li * hl - marge * 0.5, ox + bw * p + marge * 0.2, oy + (li + 1) * hl + marge * 0.5], fill=255)
            calque.putalpha(ImageChops.multiply(calque.getchannel("A"), masque))
            im.alpha_composite(calque)
        ax, ay = self.ancre(W, Hh)
        self._bloc = (W, Hh, marge)
        return im, ax, ay, s

    def nb_mots(self):
        return len(M.texte_brut(self.texte).split())

    def info_verif(self):
        mots, bw, bh, pol, k = self.page(1.0)
        return {"texte": M.texte_brut(self.texte), "mots": self.nb_mots(), "taille": self.taille() * k,
                "fond_carte": bool(self.spec.get("fond"))}


class Prix(Texte):
    """Un prix qui arrive en rebondissant, avec l'ancien prix barré au-dessus si donné."""
    type = "prix"

    def __init__(self, spec, pub, plan):
        spec = dict(spec)
        spec.setdefault("texte", spec.get("valeur", ""))
        spec.setdefault("police", "chiffre")
        spec.setdefault("couleur", "accent")
        spec.setdefault("taille", 200)
        super().__init__(spec, pub, plan)
        self.statique = False

    def anim_defaut(self):
        return "tombe"

    def contenu(self, t, st, s_hint):
        im, ax, ay, s = super().contenu(t, st, s_hint)
        sp = self.spec
        anc = sp.get("ancien")
        pastille = sp.get("pastille")
        if not anc and not pastille:
            self._utile = None
            return im, ax, ay, s
        tau = self.temps(t) - self.t0
        pol2 = self.pub.polices.get(self.taille() * 0.36 * s, sp.get("police_ancien", "texte"), 700)
        extra_h = int(pol2.size * 1.5) if anc else 0
        bb = im.getbbox() or (0, 0, im.width, im.height)
        cote = max((bb[2] - bb[0]) * 1.32, (bb[3] - bb[1] + extra_h) * 1.6) if pastille else 0
        W = int(max(im.width, cote))
        Hh = int(max(im.height + extra_h, cote))
        out = Image.new("RGBA", (W, Hh), (0, 0, 0, 0))
        if pastille:
            pc = self.pub.pal(pastille if isinstance(pastille, str) else "second")
            e = M.forme("eclat", cote, cote, pc, pointes=18, creux=0.88)
            e = e.rotate(-tau * 18, resample=Image.BICUBIC)
            out.alpha_composite(e, (int((W - e.width) / 2), int((Hh - e.height) / 2)))
        y_prix = (Hh - im.height - extra_h) // 2 + extra_h
        if anc:
            spr, dx, dy = M.sprite_texte(anc, pol2, self.pub.pal(sp.get("couleur_ancien", "encre/0.7")))
            xa, ya = (W - spr.width) // 2, y_prix + int(36 * s) - spr.height + int(pol2.size * 0.2)
            out.alpha_composite(spr, (xa, ya))
            p = sortie_c((tau - 0.45) / 0.3)
            if p > 0:
                d = ImageDraw.Draw(out)
                x0, x1 = xa + dx - 6, xa + dx + pol2.getlength(anc) + 6
                ym = ya + dy + pol2.getmetrics()[0] * 0.62
                d.line([(x0, ym + 6), (x0 + (x1 - x0) * p, ym - 6)], fill=self.pub.pal("accent"), width=max(3, int(7 * s)))
        out.alpha_composite(im, ((W - im.width) // 2, y_prix))
        x0 = (W - im.width) // 2 + bb[0]
        self._utile = (x0 - W / 2, y_prix + bb[1] - Hh / 2 - extra_h, x0 + bb[2] - bb[0] - W / 2, y_prix + bb[3] - Hh / 2)
        return out, W / 2, Hh / 2, s


class Compteur(Texte):
    type = "compteur"

    def __init__(self, spec, pub, plan):
        spec = dict(spec)
        spec.setdefault("police", "chiffre")
        spec.setdefault("taille", 180)
        spec.setdefault("texte", self.formater(spec.get("vers", 100), spec))
        super().__init__(spec, pub, plan)
        self.statique = False
        self.d_compte = pub.horloge.d(spec.get("duree", "4t"))

    def anim_defaut(self):
        return "pop"

    @staticmethod
    def formater(v, sp):
        v = int(round(v))
        txt = f"{v:,}".replace(",", sp.get("separateur", " "))
        return f"{sp.get('prefixe', '')}{txt}{sp.get('suffixe', '')}"

    def texte_a(self, t):
        sp = self.spec
        p = sortie_c((t - self.t0) / max(1e-3, self.d_compte))
        v = float(sp.get("de", 0)) + (float(sp.get("vers", 100)) - float(sp.get("de", 0))) * p
        return self.formater(v, sp)


class Tampon(Texte):
    type = "tampon"

    def __init__(self, spec, pub, plan):
        spec = dict(spec)
        spec.setdefault("casse", "majuscules")
        spec.setdefault("couleur", "accent")
        spec.setdefault("rot", -9)
        spec.setdefault("taille", 84)
        spec.setdefault("largeur", 700)
        super().__init__(spec, pub, plan)
        self._t = None

    def anim_defaut(self):
        return "ecrase"

    def contenu(self, t, st, s_hint):
        s = max(0.3, round(s_hint * 25) / 25)
        if self._t and self._t[0] == s:
            im = self._t[1]
        else:
            txt, ax, ay, s = super().contenu(self.t0 + 5, st, s)
            c = self.couleurs(st)[0]
            bb = txt.getbbox() or (0, 0, txt.width, txt.height)
            txt = txt.crop(bb)
            m = int(34 * s)
            ep = max(4, int(9 * s))
            W, H = txt.width + 2 * m, txt.height + 2 * m
            im = Image.new("RGBA", (W + 20, H + 20), (0, 0, 0, 0))
            d = ImageDraw.Draw(im)
            if self.spec.get("forme") == "rond":
                cote = max(W, H)
                im = Image.new("RGBA", (cote + 20, cote + 20), (0, 0, 0, 0))
                d = ImageDraw.Draw(im)
                d.ellipse([10, 10, cote + 10, cote + 10], outline=c, width=ep)
                d.ellipse([10 + ep * 2, 10 + ep * 2, cote + 10 - ep * 2, cote + 10 - ep * 2], outline=c, width=max(2, ep // 2))
                im.alpha_composite(txt, ((im.width - txt.width) // 2, (im.height - txt.height) // 2))
            else:
                d.rounded_rectangle([10, 10, W + 10, H + 10], radius=int(16 * s), outline=c, width=ep)
                im.alpha_composite(txt, (10 + m, 10 + m))
            # encre irrégulière
            a = np.asarray(im.getchannel("A"), np.float32)
            n = M.bruit_doux(im.width, im.height, 6, self.graine)
            a = a * np.clip(0.55 + n * 0.9, 0, 1)
            im.putalpha(Image.fromarray(a.astype("uint8")))
            self._t = (s, im)
        return im, im.width / 2, im.height / 2, s

    def info_verif(self):
        d = super().info_verif()
        d["fond_carte"] = True
        return d


# ---------------------------------------------------------------- bouton d'action
class Bouton(Calque):
    type = "bouton"
    est_texte = True

    def __init__(self, spec, pub, plan):
        super().__init__(spec, pub, plan)
        self.statique = False
        H = pub.horloge
        self.t_clic = H.t(spec["clic"], plan.t0 if plan else 0, plan.t1 if plan else pub.duree) if spec.get("clic") is not None else None
        self._base = {}
        self.role = spec.get("role", "action")

    def base_bouton(self, s):
        cle = round(s, 2)
        if cle not in self._base:
            sp = self.spec
            txt = sp.get("texte", "Écris-nous sur WhatsApp")
            taille = float(sp.get("taille", 54))
            ic0 = 1.15 + 0.5 if sp.get("icone", "discussion") else 0
            pol = self.pub.polices.get(taille, sp.get("police", "texte"), sp.get("graisse", 700))
            larg_max = float(sp.get("largeur_max", 760))
            w1 = pol.getlength(txt) + taille * (ic0 + 1.6)
            if w1 > larg_max:  # bouton trop large : il passerait sous les boutons de TikTok
                taille *= larg_max / w1
            pol = self.pub.polices.get(taille * s, sp.get("police", "texte"), sp.get("graisse", 700))
            ct = self.pub.pal(sp.get("couleur_texte", "clair"))
            spr, dx, dy = M.sprite_texte(txt, pol, ct)
            ic = sp.get("icone", "discussion")
            di = int(pol.size * 1.15) if ic else 0
            h = int(pol.size * 2.1)
            w = int(pol.getlength(txt) + di + (pol.size * 0.5 if ic else 0) + pol.size * 1.6)
            b = M.forme("pastille", w, h, self.pub.pal(sp.get("couleur", "whatsapp")))
            if sp.get("relief", self.pub.traitement(self.plan).get("formes")):
                b = M.relief(b, 0.35)
            x = (w - (pol.getlength(txt) + di + (pol.size * 0.5 if ic else 0))) / 2
            if ic:
                b.alpha_composite(M.icone(ic, di, ct), (int(x), int((h - di) / 2)))
                x += di + pol.size * 0.5
            b.alpha_composite(spr, (int(x - dx), int((h - (pol.getmetrics()[0] + pol.getmetrics()[1])) / 2 - dy)))
            b, m = M.ombre_portee(b, 0, 12 * s, 20 * s, 0.25, self.pub.pal("ombre")[:3])
            self._base[cle] = (b, w, h, m)
        return self._base[cle]

    def contenu(self, t, st, s_hint):
        s = max(0.3, round(s_hint * 20) / 20)
        b, w, h, m = self.base_bouton(s)
        self._utile = (-w / 2, -h / 2, w / 2, h / 2)
        if self.t_clic is None:
            return b, b.width / 2, b.height / 2, s
        tc = self.t_clic
        dt = t - tc
        marge = int(260 * s)
        W, H = b.width + 2 * marge, b.height + 2 * marge
        out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        k = 1.0
        if 0 <= dt < 0.25:
            k = 1 - 0.08 * math.sin(math.pi * dt / 0.25)
        bb = b if k == 1 else b.resize((int(b.width * k), int(b.height * k)), Image.BICUBIC)
        out.alpha_composite(bb, (int((W - bb.width) / 2), int((H - bb.height) / 2)))
        cx, cy = W / 2 + w * 0.22, H / 2 + h * 0.1
        d = ImageDraw.Draw(out)
        if 0 <= dt < 0.6:  # onde du clic
            r = (30 + 160 * sortie_c(dt / 0.6)) * s
            a = int(200 * (1 - dt / 0.6))
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(255, 255, 255, a), width=max(2, int(8 * s)))
        if self.spec.get("doigt", True) and -0.6 < dt < 0.7:
            # le doigt (un rond blanc, comme l'indicateur de toucher d'un téléphone) arrive, appuie, repart
            if dt < 0:
                p = sortie_c((dt + 0.6) / 0.5)
            else:
                p = 1 - entree_c(max(0, dt - 0.3) / 0.4)
            fx, fy = cx + (1 - p) * 230 * s, cy + (1 - p) * 300 * s
            r = 38 * s * (0.86 if 0 <= dt < 0.2 else 1)
            ombre = Image.new("RGBA", out.size, (0, 0, 0, 0))
            ImageDraw.Draw(ombre).ellipse([fx - r + 4, fy - r + 10, fx + r + 4, fy + r + 10], fill=(0, 0, 0, int(70 * p)))
            out.alpha_composite(ombre.filter(ImageFilter.GaussianBlur(8 * s)))
            d.ellipse([fx - r, fy - r, fx + r, fy + r], fill=(255, 255, 255, int(235 * p)), outline=(200, 200, 200, int(255 * p)), width=2)
        return out, W / 2, H / 2, s

    def info_verif(self):
        return {"texte": self.spec.get("texte", ""), "mots": len(self.spec.get("texte", "").split()), "taille": float(self.spec.get("taille", 54)),
                "fond_carte": True}


# ---------------------------------------------------------------- trait dessiné
class Trait(Calque):
    """ligne, fleche, cercle (entoure un point), souligne, vague. Coordonnées en pixels de l'écran."""
    type = "trait"
    statique = False

    def __init__(self, spec, pub, plan):
        super().__init__(spec, pub, plan)
        pts = self.points()
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        m = float(spec.get("epaisseur", 12)) * 3 + 20
        self.bbox = (min(xs) - m, min(ys) - m, max(xs) + m, max(ys) + m)

    def anim_defaut(self):
        return "dessine"

    def base(self):
        b = super().base()
        x0, y0, x1, y1 = self.bbox
        b["x"], b["y"] = (x0 + x1) / 2, (y0 + y1) / 2
        return b

    def points(self):
        sp = self.spec
        f = sp.get("forme", "fleche")
        if f == "cercle":
            cx, cy, w, h = sp.get("x", 540), sp.get("y", 960), sp.get("w", 300), sp.get("h", 200)
            pts = []
            for i in range(80):
                a = -math.pi * 0.6 + 2.15 * math.pi * i / 79
                r = 1 + 0.04 * math.sin(i * 0.4 + self.graine)
                pts.append((cx + w / 2 * r * math.cos(a), cy + h / 2 * r * math.sin(a)))
            return pts
        p = sp.get("points", [[300, 900], [700, 1100]])
        if f in ("ligne", "souligne", "fleche") and len(p) == 2:
            (x0, y0), (x1, y1) = p
            courb = float(sp.get("courbure", 0.25 if f == "fleche" else 0.0))
            mx, my = (x0 + x1) / 2 - (y1 - y0) * courb, (y0 + y1) / 2 + (x1 - x0) * courb
            return [((1 - u) ** 2 * x0 + 2 * (1 - u) * u * mx + u * u * x1, (1 - u) ** 2 * y0 + 2 * (1 - u) * u * my + u * u * y1)
                    for u in [i / 40 for i in range(41)]]
        if f == "vague":
            (x0, y0), (x1, y1) = p[0], p[-1]
            return [(x0 + (x1 - x0) * u, y0 + (y1 - y0) * u + 14 * math.sin(u * 18)) for u in [i / 80 for i in range(81)]]
        return [tuple(q) for q in p]

    def contenu(self, t, st, s_hint):
        sp = self.spec
        tous = self.points()
        tr = st.get("trace", 1.0)
        pts = tous[:max(2, int(len(tous) * tr))]
        ep = float(sp.get("epaisseur", 12))
        x0, y0, x1, y1 = self.bbox
        W, H = int(x1 - x0), int(y1 - y0)
        S = 2
        im = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        c = self.pub.pal(sp.get("couleur", "accent"))
        q = [((x - x0) * S, (y - y0) * S) for x, y in pts]
        d.line(q, fill=c, width=int(ep * S), joint="curve")
        for x, y in (q[0], q[-1]):
            d.ellipse([x - ep * S / 2, y - ep * S / 2, x + ep * S / 2, y + ep * S / 2], fill=c)
        if sp.get("forme", "fleche") == "fleche" and tr > 0.92 and len(q) > 3:
            (xa, ya), (xb, yb) = q[-4], q[-1]
            a = math.atan2(yb - ya, xb - xa)
            L = ep * S * 3.2
            d.polygon([(xb + math.cos(a) * ep * S, yb + math.sin(a) * ep * S),
                       (xb - L * math.cos(a - 0.5), yb - L * math.sin(a - 0.5)),
                       (xb - L * math.cos(a + 0.5), yb - L * math.sin(a + 0.5))], fill=c)
        im = im.resize((W, H), Image.LANCZOS)
        return im, W / 2, H / 2, 1.0


# ---------------------------------------------------------------- téléphone (conversation)
class Telephone(Calque):
    """Un téléphone avec une conversation de messagerie qui se construit message par message.
    Couleurs inspirées des messageries courantes (en-tête vert, bulles claires), sans logo de marque."""
    type = "telephone"
    statique = False

    def anim_defaut(self):
        return "monte"

    def __init__(self, spec, pub, plan):
        super().__init__(spec, pub, plan)
        H = pub.horloge
        self.msgs = []
        for m in spec.get("messages", []):
            self.msgs.append(dict(m, t=H.t(m.get("a", 0), plan.t0 if plan else 0, plan.t1 if plan else pub.duree)))
        self._corps = {}
        self._bulles = {}
        self.role = spec.get("role", "interface")

    def dims(self, s):
        L = float(self.spec.get("largeur", 820)) * s
        return L, L * 2.06

    def corps(self, s):
        cle = round(s, 2)
        if cle in self._corps:
            return self._corps[cle]
        sp = self.spec
        L, Ht = self.dims(s)
        L, Ht = int(L), int(Ht)
        pal = self.pub.pal
        im = Image.new("RGBA", (L, Ht), (0, 0, 0, 0))
        corps = M.forme("rect", L, Ht, pal(sp.get("couleur_coque", "#1C1C21")), rayon=L * 0.13)
        im.alpha_composite(corps)
        b = int(L * 0.032)
        ecran = M.forme("rect", L - 2 * b, Ht - 2 * b, pal(sp.get("papier_peint", "#EFE7DD")), rayon=L * 0.105)
        # motif léger du papier peint
        mot = M.motif(L - 2 * b, Ht - 2 * b, "points", (0, 0, 0, 0), (120, 100, 80, 22), pas=int(L * 0.07))
        ecran.alpha_composite(Image.composite(mot, Image.new("RGBA", mot.size, (0, 0, 0, 0)), ecran.getchannel("A")))
        d = ImageDraw.Draw(ecran)
        we, he = ecran.size
        hb = int(L * 0.075)  # barre d'état
        hh = int(L * 0.15)  # en-tête
        vert = pal(sp.get("couleur_entete", "#0B7A5E"))
        entete = Image.new("RGBA", (we, hb + hh), vert)
        ecran.alpha_composite(Image.composite(entete, Image.new("RGBA", entete.size, (0, 0, 0, 0)), ecran.getchannel("A").crop((0, 0, we, hb + hh))))
        d = ImageDraw.Draw(ecran)
        pol_e = self.pub.polices.get(L * 0.032, "texte", 600)
        d.text((L * 0.09, hb * 0.28), sp.get("heure", "10:24"), font=pol_e, fill=(255, 255, 255, 255))
        d.rounded_rectangle([we / 2 - L * 0.12, hb * 0.2, we / 2 + L * 0.12, hb * 0.2 + L * 0.05], radius=int(L * 0.025), fill=(20, 20, 24, 255))
        # avatar + nom
        ra = int(hh * 0.62)
        ay = hb + (hh - ra) // 2
        if sp.get("avatar"):
            av = self.pub.charger_image(sp["avatar"]).convert("RGBA")
            k = ra / min(av.size)
            av = av.resize((max(1, int(av.width * k)), max(1, int(av.height * k))), Image.LANCZOS).crop((0, 0, ra, ra))
            av = M.masque_forme(av, "rond")
        else:
            av = M.forme("rond", ra, ra, pal("clair"))
            ini = "".join(w[0] for w in sp.get("nom", "Boutique").split()[:2]).upper()
            pi = self.pub.polices.get(ra * 0.42, "titre")
            sp_i, dx, dy = M.sprite_texte(ini, pi, pal("accent"))
            av.alpha_composite(sp_i, (int((ra - pi.getlength(ini)) / 2 - dx), int(ra / 2 - (pi.getmetrics()[0] + pi.getmetrics()[1]) / 2 - dy)))
        ecran.alpha_composite(av, (int(L * 0.1), ay))
        pol_n = self.pub.polices.get(L * 0.046, "texte", 700)
        pol_s = self.pub.polices.get(L * 0.032, "texte", 500)
        d.text((L * 0.1 + ra + L * 0.03, ay + ra * 0.02), sp.get("nom", "Boutique"), font=pol_n, fill=(255, 255, 255, 255))
        d.text((L * 0.1 + ra + L * 0.03, ay + ra * 0.58), sp.get("statut", "en ligne"), font=pol_s, fill=(220, 240, 232, 255))
        d.text((L * 0.035, hb + hh * 0.3), "‹", font=self.pub.polices.get(L * 0.07, "texte", 500), fill=(255, 255, 255, 255))
        # barre de saisie
        hs = int(L * 0.11)
        ys = he - hs - int(L * 0.05)
        d.rounded_rectangle([L * 0.04, ys, we - L * 0.04 - hs - L * 0.02, ys + hs], radius=hs // 2, fill=(255, 255, 255, 255))
        d.text((L * 0.1, ys + hs * 0.28), sp.get("saisie", "Message"), font=pol_s, fill=(150, 150, 150, 255))
        d.ellipse([we - L * 0.04 - hs, ys, we - L * 0.04, ys + hs], fill=vert)
        im.alpha_composite(ecran, (b, b))
        zone = (b, b + hb + hh + int(L * 0.03), b + we, b + ys - int(L * 0.03))
        self._corps[cle] = (im, zone)
        return self._corps[cle]

    def bulle(self, i, m, s, larg_zone):
        cle = (i, round(s, 2))
        if cle in self._bulles:
            return self._bulles[cle]
        L = self.dims(s)[0]
        moi = m.get("de", "client") == "client"
        fond = (217, 253, 211, 255) if moi else (255, 255, 255, 255)
        pol = self.pub.polices.get(L * float(self.spec.get("taille_texte", 0.06)), "texte", 500)
        pad = L * 0.03
        maxw = larg_zone * 0.74
        if m.get("image"):
            ph = self.pub.charger_image(m["image"]).convert("RGBA")
            iw = maxw - 2 * pad * 0.5
            k = iw / ph.width
            ph = ph.resize((int(iw), int(ph.height * k)), Image.LANCZOS)
            ph = M.masque_forme(ph, "arrondi", rayon=L * 0.025)
            w, h = int(iw + pad), int(ph.height + pad)
            b = M.forme("rect", w, h, fond, rayon=L * 0.03)
            b.alpha_composite(ph, (int(pad / 2), int(pad / 2)))
        else:
            mots, bw, bh = M.mise_en_page(m.get("texte", ""), pol, maxw - 2 * pad, 1.12, "gauche")
            pol_h = self.pub.polices.get(L * 0.028, "texte", 500)
            w = int(max(bw, L * 0.16) + 2 * pad + L * 0.11)
            h = int(bh + 2 * pad * 0.9)
            b = M.forme("rect", w, h, fond, rayon=L * 0.032)
            d = ImageDraw.Draw(b)
            for mm in mots:
                d.text((pad + mm["x"], pad * 0.8 + mm["y"]), mm["mot"], font=pol, fill=(30, 30, 30, 255) if not mm["accent"] else self.pub.pal("accent"))
            hr = m.get("heure", "")
            if hr:
                d.text((w - pad - L * 0.1, h - pad * 0.4 - pol_h.size), hr, font=pol_h, fill=(120, 120, 120, 255))
            if moi:  # coches de lecture
                x, y = w - pad - L * 0.03, h - pad * 0.5 - pol_h.size * 0.4
                cl = (52, 183, 241, 255)
                for k in (0, L * 0.012):
                    d.line([(x - L * 0.022 + k, y - L * 0.004), (x - L * 0.013 + k, y + L * 0.006), (x + k, y - L * 0.012)], fill=cl, width=max(2, int(L * 0.004)))
        b, mo = M.ombre_portee(b, 0, 2, 3, 0.18)
        self._bulles[cle] = (b, mo, moi)
        return self._bulles[cle]

    def contenu(self, t, st, s_hint):
        s = max(0.3, round(s_hint * 20) / 20)
        corps, (zx0, zy0, zx1, zy1) = self.corps(s)
        im = corps.copy()
        L = self.dims(s)[0]
        larg = zx1 - zx0
        gap = L * 0.022
        vus = []
        self._produit = any(m.get("image") and t >= m["t"] for m in self.msgs)
        for i, m in enumerate(self.msgs):
            dt = t - m["t"]
            ecrit = m.get("ecrit", m.get("de", "client") != "client")
            if dt >= 0:
                vus.append(("msg", i, m, dt))
            elif ecrit and dt > -0.75 and not any(v[0] == "ecrit" for v in vus):
                vus.append(("ecrit", i, m, dt))
        # hauteur totale, défilement
        items = []
        for kind, i, m, dt in vus:
            if kind == "msg":
                b, mo, moi = self.bulle(i, m, s, larg)
                items.append((kind, b, mo, moi, dt))
            else:
                items.append((kind, None, 0, False, dt))
        hs = [(it[1].height - 2 * it[2]) if it[0] == "msg" else L * 0.11 for it in items]
        total = sum(hs) + gap * max(0, len(hs) - 1)
        place = zy1 - zy0 - gap
        decal = 0.0
        if total > place:
            decal = total - place
            if items and items[-1][0] == "msg":  # la conversation remonte en douceur
                derniere = hs[-1] + gap
                decal -= derniere * (1 - sortie_c(items[-1][4] / 0.3))
        couche = Image.new("RGBA", (int(larg), int(zy1 - zy0)), (0, 0, 0, 0))
        y = gap - decal
        dcouche = ImageDraw.Draw(couche)
        for (kind, b, mo, moi, dt), h in zip(items, hs):
            if kind == "msg":
                k = max(0.0, min(1.0, ressort(dt, 10, 16))) if dt < 0.5 else 1.0
                bb = b if k >= 0.999 else b.resize((max(1, int(b.width * (0.7 + 0.3 * k))), max(1, int(b.height * (0.7 + 0.3 * k)))), Image.BILINEAR)
                if k < 0.999:
                    a = bb.getchannel("A").point(lambda v, kk=min(1, dt / 0.12): int(v * kk))
                    bb.putalpha(a)
                bw = bb.width - 2 * mo * (bb.width / b.width)
                x = (larg - L * 0.03 - bw - mo) if moi else (L * 0.03 - mo)
                yy = y - mo + (h - (bb.height - 2 * mo)) * (1 if k < 1 else 0)
                couche.alpha_composite(bb, (int(x), int(yy))) if x >= 0 and yy >= 0 else couche.paste(bb, (int(x), int(yy)), bb)
            else:  # « en train d'écrire » : trois points
                w, hh = L * 0.2, L * 0.1
                x = L * 0.03
                dcouche.rounded_rectangle([x, y, x + w, y + hh], radius=int(hh / 2), fill=(255, 255, 255, 255))
                for j in range(3):
                    ph = (t * 3 - j * 0.25) % 1
                    r = L * 0.012 * (1 + 0.35 * math.sin(ph * math.pi * 2))
                    cx, cy = x + w * (0.28 + 0.22 * j), y + hh / 2
                    dcouche.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(140, 140, 140, 255))
            y += h + gap
        im.alpha_composite(couche, (int(zx0), int(zy0)))
        return im, im.width / 2, im.height / 2, s

    def info_verif(self):
        return {"texte": " / ".join(m.get("texte", "[image]") for m in self.msgs), "mots": 0, "taille": 99, "fond_carte": True}


TYPES = {"image": Img, "forme": Forme, "texte": Texte, "prix": Prix, "compteur": Compteur, "tampon": Tampon,
         "bouton": Bouton, "trait": Trait, "telephone": Telephone}


# ---------------------------------------------------------------- éléments composés (développés en éléments simples)
def developper(spec, pub, plan):
    """fin, avis, pluie, flotte, confettis, sequence → liste d'éléments simples."""
    out = _developper(spec, pub, plan)
    if len(out) > 1 or out[0] is not spec:
        for e in out:
            for k in ("jusqua", "sortie", "z", "saccade", "tremble"):
                if k in spec and k not in e:
                    e[k] = spec[k]
    return out


def _developper(spec, pub, plan):
    t = spec.get("type")
    H = pub.horloge
    if t == "sequence":
        out = []
        chaque = spec.get("chaque", "2t")
        a = spec.get("a", 0)
        textes = spec["textes"]
        for i, tx in enumerate(textes):
            e = {k: v for k, v in spec.items() if k not in ("type", "textes", "chaque", "a", "jusqua")}
            e.update(type=spec.get("type_element", "texte"), texte=tx, a=_decale(a, chaque, i))
            if i < len(textes) - 1:
                e["jusqua"] = _decale(a, chaque, i + 1)
                e.setdefault("sortie", None)
            elif "jusqua" in spec:
                e["jusqua"] = spec["jusqua"]
            e.setdefault("anim", "pop")
            e["id"] = f"{spec.get('id', 'seq')}-{i}"
            out.append(e)
        return out
    if t == "avis":
        x, y = spec.get("x", 540), spec.get("y", 1000)
        w = spec.get("largeur", 860)
        pol = pub.polices.get(spec.get("taille", 62), spec.get("police", "titre"))
        _, bw, bh = M.mise_en_page(spec.get("texte", ""), pol, w - 120)
        h = bh + 300
        a = spec.get("a", 0)
        base = [{"type": "forme", "forme": "rect", "w": w, "h": h, "rayon": 36, "couleur": spec.get("couleur_carte", "clair"), "x": x, "y": y,
                 "ombre": "portee", "a": a, "anim": spec.get("anim", "monte"), "id": "avis-carte"}]
        for i in range(int(spec.get("etoiles", 5))):
            base.append({"type": "forme", "forme": "etoile", "w": 70, "h": 70, "couleur": spec.get("couleur_etoiles", "second"),
                         "x": x - 2 * 84 + i * 84, "y": y - h / 2 + 90, "a": _decale(a, 0.1, 3 + i), "anim": "tourne", "id": f"avis-etoile-{i}"})
        base.append({"type": "texte", "texte": spec.get("texte", ""), "taille": spec.get("taille", 62), "police": spec.get("police", "titre"),
                     "largeur": w - 120, "x": x, "y": y + 20, "a": _decale(a, 0.1, 6), "mode": "mots", "cadence": 0.12,
                     "couleur": spec.get("couleur", "encre"), "id": "avis-texte", "role": spec.get("role", "avis")})
        if spec.get("nom"):
            base.append({"type": "texte", "texte": spec["nom"], "taille": 44, "police": "texte", "couleur": "encre/0.75",
                         "x": x, "y": y + h / 2 - 70, "a": _decale(a, 0.1, 12), "anim": "fondu", "id": "avis-nom", "role": "mention"})
        for e in base:
            if "jusqua" in spec:
                e["jusqua"] = spec["jusqua"]
            e["z"] = spec.get("z", 0)
        return base
    if t in ("pluie", "flotte"):
        rng = random.Random(spec.get("graine", 7))
        srcs = spec.get("srcs") or [spec.get("src")]
        n = int(spec.get("nombre", 10))
        zx = spec.get("zone_x", [100, 980])
        out = []
        for i in range(n):
            e = {"type": "image", "src": srcs[i % len(srcs)], "id": f"{spec.get('id', t)}-{i}"}
            ech = spec.get("echelle", [0.8, 1.2])
            e["echelle"] = rng.uniform(*ech) if isinstance(ech, list) else ech
            e["largeur"] = spec.get("largeur", 120)
            for k in ("traitements", "bord", "jusqua", "sortie", "saccade", "role", "tremble"):
                if k in spec:
                    e[k] = spec[k]
            if t == "pluie":
                sol = spec.get("sol", [1250, 1420])
                e["x"] = rng.uniform(*zx)
                e["y"] = rng.uniform(*sol) if isinstance(sol, list) else sol
                e["rot"] = rng.uniform(*spec.get("rot", [-35, 35]))
                e["rot_chute"] = rng.uniform(-160, 160)
                e["anim"] = "tombe"
                e["a"] = _decale(spec.get("a", 0), spec.get("ecart", 0.09), i)
                e["duree_anim"] = spec.get("duree_chute", 0.55)
                e["rebond"] = spec.get("rebond", pub.rebond)
                e["ombre"] = spec.get("ombre", "posee")
                zr = spec.get("z", [-0.05, 0.2])
                e["z"] = rng.uniform(*zr) if isinstance(zr, list) else zr
            else:
                e["x"] = rng.uniform(*zx)
                e["y"] = rng.uniform(-100, pub.H + 100)
                e["rot"] = rng.uniform(0, 360)
                e["boucle"] = "derive"
                e["vitesse_chute"] = rng.uniform(*spec.get("vitesse", [60, 140]))
                e["anim"] = spec.get("anim", "fondu")
                e["a"] = spec.get("a", 0)
                zr = spec.get("z", [0.15, 1.6])
                e["z"] = rng.uniform(*zr) if isinstance(zr, list) else zr
                e["opacite"] = spec.get("opacite", 1)
            out.append(e)
        return out
    if t == "confettis":
        rng = random.Random(spec.get("graine", 3))
        couleurs = spec.get("couleurs", ["accent", "second", "clair", "encre"])
        out = []
        for i in range(int(spec.get("nombre", 36))):
            ang = rng.uniform(-math.pi * 0.95, -math.pi * 0.05)
            v = rng.uniform(600, float(spec.get("force", 1700)))
            fm = rng.choice(["rect", "rect", "rond", "etoile"]) if spec.get("formes") is None else rng.choice(spec["formes"])
            taille = rng.uniform(16, 34)
            out.append({"type": "forme", "forme": fm, "w": taille, "h": taille * (1.6 if fm == "rect" else 1), "couleur": rng.choice(couleurs),
                        "x": spec.get("x", 540), "y": spec.get("y", 900), "z": -0.1, "anim": "projete",
                        "vitesse": [math.cos(ang) * v, math.sin(ang) * v], "spin": rng.uniform(-600, 600), "flip": rng.uniform(4, 11),
                        "a": spec.get("a", 0), "duree_anim": spec.get("duree", 2.2), "jusqua": _decale(spec.get("a", 0), spec.get("duree", 2.2), 1),
                        "id": f"confetti-{i}", "role": "decor"})
        return out
    if t == "fin":
        a = spec.get("a", 0)
        pas = spec.get("pas", "1t")
        out = []
        y = spec.get("y", 700)
        if spec.get("logo"):
            out.append({"type": "image", "src": spec["logo"], "largeur": spec.get("largeur_logo", 420), "x": 540, "y": y, "anim": "pop",
                        "a": a, "role": "logo", "id": "fin-logo", "boucle": spec.get("boucle_logo")})
            y += spec.get("ecart_logo", spec.get("largeur_logo", 420) * 0.5 + 170)
        elif spec.get("nom"):
            out.append({"type": "texte", "texte": spec["nom"], "taille": spec.get("taille_nom", 132), "police": "titre", "couleur": spec.get("couleur_nom", "accent"),
                        "x": 540, "y": y, "anim": "elastique", "a": a, "role": "logo", "id": "fin-logo", "largeur": 900})
            y += 230
        i = 1
        if spec.get("slogan"):
            out.append({"type": "texte", "texte": spec["slogan"], "taille": 58, "police": "texte", "couleur": "encre", "x": 540, "y": y,
                        "anim": "monte", "a": _decale(a, pas, i), "id": "fin-slogan", "largeur": 860})
            y += 150
            i += 1
        if spec.get("action"):
            out.append({"type": "bouton", "texte": spec["action"], "x": 540, "y": y, "anim": "pop", "a": _decale(a, pas, i),
                        "clic": spec.get("clic", _decale(a, pas, i + 2)), "icone": spec.get("icone", "discussion"),
                        "couleur": spec.get("couleur_bouton", "whatsapp"), "taille": spec.get("taille_bouton", 54), "id": "fin-bouton",
                        "boucle": "pulse", "amplitude_boucle": 0.5})
            y += 190
            i += 1
        if spec.get("contact"):
            out.append({"type": "texte", "texte": spec["contact"], "taille": spec.get("taille_contact", 82), "police": spec.get("police_contact", "titre"),
                        "couleur": "encre", "x": 540, "y": y, "anim": "monte", "a": _decale(a, pas, i), "role": "contact", "id": "fin-contact",
                        "largeur": 820})
            y += 120
            i += 1
        if spec.get("adresse"):
            out.append({"type": "texte", "texte": spec["adresse"], "taille": spec.get("taille_adresse", 56), "police": "texte", "couleur": "encre/0.8", "x": 540, "y": y,
                        "anim": "fondu", "a": _decale(a, pas, i), "role": "contact", "id": "fin-adresse", "largeur": 820})
        return out
    return [spec]


def _decale(a, pas, i):
    """« a + i × pas » écrit dans la syntaxe des temps (secondes ou « 2t »)."""
    def part(v):
        return v if isinstance(v, str) else f"{float(v)}"
    if i == 0:
        return a
    if isinstance(pas, (int, float)):
        p = f"{float(pas) * i:.4f}"
    else:
        p = pas.strip()
        p = f"{float(p[:-1]) * i:.4f}t" if p.endswith("t") else f"{float(p) * i:.4f}"
    return f"{part(a)}+{p}"


def creer(spec, pub, plan):
    cls = TYPES.get(spec.get("type", "image"))
    if cls is None:
        raise SystemExit(f"Type d'élément inconnu : {spec.get('type')} (voir references/bibliotheque.md)")
    return cls(spec, pub, plan)
