"""Fonctions communes aux scripts du skill : trouver ffmpeg, lire et écrire l'audio."""
import json
import os
import shutil
import subprocess
import sys

SR = 48000


def ffmpeg_exe():
    """ffmpeg du système, sinon celui du paquet Python imageio-ffmpeg (pip install imageio-ffmpeg)."""
    env = os.environ.get("FFMPEG")
    if env:
        return env
    sys_ff = shutil.which("ffmpeg")
    if sys_ff:
        return sys_ff
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        sys.exit("ffmpeg introuvable. Installer ffmpeg, ou lancer : pip install imageio-ffmpeg")


def lire_audio(chemin, sr=SR):
    """Décode n'importe quel fichier audio en mono float32."""
    import numpy as np
    out = subprocess.run([ffmpeg_exe(), "-v", "error", "-i", chemin, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"],
                         capture_output=True)
    if out.returncode != 0:
        sys.exit(f"Lecture impossible : {chemin}\n{out.stderr.decode(errors='ignore')}")
    return np.frombuffer(out.stdout, np.float32).copy()


def ecrire_wav(chemin, y, sr=SR):
    import numpy as np
    subprocess.run([ffmpeg_exe(), "-v", "error", "-y", "-f", "f32le", "-ar", str(sr), "-ac", "1", "-i", "-", chemin],
                   input=y.astype(np.float32).tobytes(), check=True)


def volume_lufs(chemin):
    """Volume intégré (LUFS) mesuré par le filtre loudnorm de ffmpeg."""
    out = subprocess.run([ffmpeg_exe(), "-hide_banner", "-i", chemin, "-af", "loudnorm=print_format=json", "-f", "null", "-"],
                         capture_output=True, text=True)
    txt = out.stderr
    debut = txt.rfind("{")
    try:
        return float(json.loads(txt[debut:txt.rfind("}") + 1])["input_i"])
    except Exception:
        return None


def normaliser(entree, sortie, cible=-14.0):
    subprocess.run([ffmpeg_exe(), "-v", "error", "-y", "-i", entree, "-af", f"loudnorm=I={cible}:TP=-1.0:LRA=11",
                    "-ar", str(SR), sortie], check=True)
