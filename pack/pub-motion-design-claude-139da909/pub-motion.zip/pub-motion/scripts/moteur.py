"""Moteur de rendu des pubs motion design (1080 × 1920, verticales).

usage :
  python moteur.py pub.json                         vidéo muette sortie/muette.mp4 + sortie/cues.json (bruitages)
  python moteur.py pub.json --essai                 rend les 2 premières secondes et estime le temps total
  python moteur.py pub.json --image 2.5 [--zones]   une image fixe à 2,5 s (esquisse, contrôle)
  python moteur.py pub.json --validation            les 4 images à faire valider (controle/validation.jpg)
  python moteur.py pub.json --verifier              liste les problèmes + controle/planche.jpg
  python moteur.py pub.json --planche               planche de contrôle seule
  python moteur.py --catalogue                      tout ce que le moteur sait faire, en bref

Options : --sortie fichier, --fps 30, --qualite normale|legere, --de 0 --jusqua 6 (morceau), --process N.
Le format de pub.json est décrit dans references/bibliotheque.md.
"""
import argparse
import json
import math
import multiprocessing as mp
import os
import re
import subprocess
import sys
import time
from collections import OrderedDict

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)

import numpy as np  # noqa: E402
from PIL import Image, ImageChops, ImageDraw, ImageFilter  # noqa: E402

import calques as C  # noqa: E402
import matiere as M  # noqa: E402
from outils import ffmpeg_exe  # noqa: E402

# zones couvertes par les boutons et légendes de TikTok / Reels (en pixels sur 1080 × 1920)
ZONE_HAUT, ZONE_BAS, ZONE_DROITE, ZONE_DROITE_Y = 200, 1500, 930, 860
RYTHMES = {"pose": {"rebond": 0.22, "ecrasement": False}, "vif": {"rebond": 0.3, "ecrasement": False},
           "rebondissant": {"rebond": 0.5, "ecrasement": True}}
SONS_TRANSITION = {"pousse": "whoosh", "recouvre": "glisse", "volet": "glisse", "rond": "pop", "rideau": "whoosh", "zoom": "whoosh",
                   "flash": "impact", "forme": "pop", "bande": "whoosh", "papier": "glisse", "fondu": None, "coupe": None}


# ---------------------------------------------------------------- le temps
class Horloge:
    """Temps en secondes (3.2) ou en temps de musique (« 2t », « 1.5t »). « fin » = fin du plan
    (ou de la pub pour les éléments permanents), « @4t » = compté depuis le début de la pub."""

    def __init__(self, tempo=100, decalage=0.0):
        self.tempo = float(tempo)
        self.temps_s = 60.0 / self.tempo
        self.decalage = float(decalage)

    def _somme(self, v, fin):
        if isinstance(v, (int, float)):
            return float(v), False
        s = str(v).strip().replace(" ", "")
        absolu = s.startswith("@")
        s = s.lstrip("@")
        total, a_fin = 0.0, False
        for signe, terme in re.findall(r"([+-]?)(fin|[0-9]*\.?[0-9]+(?:\*[0-9]*\.?[0-9]+)?t?)", s):
            if terme == "fin":
                val, a_fin = (fin if fin is not None else 0.0), True
            else:
                beat = terme.endswith("t")
                terme = terme.rstrip("t")
                if "*" in terme:
                    x, y = terme.split("*")
                    val = float(x) * float(y)
                else:
                    val = float(terme)
                if beat:
                    val *= self.temps_s
            total += -val if signe == "-" else val
        return total, (a_fin or absolu)

    def t(self, v, base=0.0, fin=None):
        val, absolu = self._somme(v, fin)
        return val if absolu else base + val

    def d(self, v):
        return self._somme(v, None)[0]


# ---------------------------------------------------------------- caméra
def cam_defaut():
    return {"x": 540.0, "y": 960.0, "z": 0.0, "rot": 0.0, "px": 0.0, "py": 0.0}


PRESETS = {
    "fixe": ({}, {}),
    "avance": ({"z": 0.0}, {"z": 0.14}),
    "recule": ({"z": 0.16}, {"z": 0.0}),
    "plonge": ({"z": 0.0}, {"z": 0.45}),
    "panoramique-gauche": ({"px": 90}, {"px": -90}),
    "panoramique-droite": ({"px": -90}, {"px": 90}),
    "travelling-gauche": ({"x": 690}, {"x": 390}),
    "travelling-droite": ({"x": 390}, {"x": 690}),
    "monte": ({"y": 1110}, {"y": 810}),
    "descend": ({"y": 810}, {"y": 1110}),
    "respire": ({}, {}),
}


class Camera:
    def __init__(self, spec, plan, horloge):
        self.plan = plan
        self.cles = []  # [(t, valeurs, courbe)]
        self.respire = False
        self.secousses = [horloge.t(s, plan.t0, plan.t1) for s in plan.spec.get("secousses", [])]
        if spec is None:
            spec = "fixe"
        if isinstance(spec, str):
            spec = {"type": spec}
        if isinstance(spec, list):
            for k in spec:
                v = cam_defaut()
                if self.cles:
                    v = dict(self.cles[-1][1])
                v.update({a: float(b) for a, b in k.items() if a in v})
                self.cles.append((horloge.t(k.get("a", 0), plan.t0, plan.t1), v, k.get("courbe", "douce")))
            return
        typ = spec.get("type", "perso")
        force = float(spec.get("force", 1.0))
        de, vers = cam_defaut(), cam_defaut()
        if typ in PRESETS:
            a, b = PRESETS[typ]
            for k, v in a.items():
                de[k] = 540 + (v - 540) * force if k == "x" else 960 + (v - 960) * force if k == "y" else v * force
            for k, v in b.items():
                vers[k] = 540 + (v - 540) * force if k == "x" else 960 + (v - 960) * force if k == "y" else v * force
            self.respire = typ == "respire"
        if typ == "plonge" and "vers_point" in spec:  # avance vers un point de l'écran
            vers["x"], vers["y"] = spec["vers_point"]
        de.update({k: float(v) for k, v in spec.get("de", {}).items()})
        vers.update({k: float(v) for k, v in spec.get("vers", {}).items()})
        t0 = horloge.t(spec.get("a", 0), plan.t0, plan.t1)
        t1 = horloge.t(spec["fin"], plan.t0, plan.t1) if "fin" in spec else plan.t1
        self.cles = [(t0, de, "douce"), (t1, vers, spec.get("courbe", "douce"))]

    def __call__(self, t):
        cl = self.cles
        if t <= cl[0][0]:
            v = dict(cl[0][1])
        elif t >= cl[-1][0]:
            v = dict(cl[-1][1])
        else:
            for (ta, va, _), (tb, vb, cb) in zip(cl, cl[1:]):
                if ta <= t <= tb:
                    p = C.courbe(cb)((t - ta) / max(1e-3, tb - ta))
                    v = {k: va[k] + (vb[k] - va[k]) * p for k in va}
                    break
        if self.respire:
            v["z"] += 0.025 * (0.5 - 0.5 * math.cos(2 * math.pi * (t - self.plan.t0) / 4.0))
        for ts in self.secousses:
            dt = t - ts
            if 0 <= dt < 0.4:
                k = math.exp(-dt * 12)
                v["px"] += math.sin(dt * 95) * 16 * k
                v["py"] += math.cos(dt * 80) * 12 * k
        return v


def projeter(X, Y, Z, cam, W=1080, H=1920):
    """Position à l'écran et facteur de taille d'un point (X, Y) à la profondeur Z.
    Z = 0 : plan de l'écran ; Z > 0 : plus loin (bouge moins, grossit moins) ; Z < 0 : plus près."""
    d = max(0.08, 1 + Z - cam["z"])
    k = (1 + Z) / d
    cx, cy = W / 2, H / 2
    ux = (X - cx - (cam["x"] - cx) / (1 + Z) - cam["px"]) * k
    uy = (Y - cy - (cam["y"] - cy) / (1 + Z) - cam["py"]) * k
    r = cam["rot"]
    if r:
        a = math.radians(r)
        ux, uy = ux * math.cos(a) - uy * math.sin(a), ux * math.sin(a) + uy * math.cos(a)
    return cx + ux, cy + uy, k


# ---------------------------------------------------------------- la pub
class Plan:
    def __init__(self, spec, i, t0, t1, pub):
        self.spec, self.i, self.t0, self.t1 = spec, i, t0, t1
        self.nom = spec.get("nom", f"plan{i + 1}")
        self.entree = spec.get("entree", "coupe" if i == 0 else spec.get("entree", "coupe"))
        if i == 0:
            self.entree = "coupe"
        self.d_entree = pub.horloge.d(spec.get("duree_entree", "1t" if self.entree not in ("flash",) else "0.5t"))
        if self.entree == "coupe":
            self.d_entree = 0.0
        self.t_fin_rendu = t1

    def construire(self, pub):
        self.camera = Camera(self.spec.get("camera"), self, pub.horloge)
        f = self.spec.get("fond", "fond")
        self.fond_spec = f
        self.fond_z = float(f.get("z", 2.0)) if isinstance(f, dict) else 2.0
        self.mise_au_point = self.spec.get("mise_au_point")
        specs = []
        for e in self.spec.get("elements", []):
            specs += C.developper(e, pub, self)
        self.elements = [C.creer(e, pub, self) for e in specs]
        self.elements = [e for _, _, e in sorted(((-e.z, i, e) for i, e in enumerate(self.elements)), key=lambda x: (x[0], x[1]))]


class Pub:
    def __init__(self, chemin, donnees=None):
        self.chemin = os.path.abspath(chemin)
        self.base = os.path.dirname(self.chemin)
        self.d = donnees if donnees is not None else json.load(open(chemin, encoding="utf-8"))
        d = self.d
        self.W, self.H = d.get("taille", [1080, 1920])
        self.fps = int(d.get("fps", 30))
        self.horloge = Horloge(d.get("tempo", 100), d.get("decalage", 0))
        mq = d.get("marque", {})
        self.pal = M.Palette(mq.get("couleurs"))
        self.polices = M.Polices(self.base, mq.get("polices"), mq.get("graisses"))
        self.rythme = d.get("rythme", "vif")
        r = RYTHMES.get(self.rythme, RYTHMES["vif"])
        self.rebond = float(d.get("rebond", r["rebond"]))
        self.ecrasement = bool(d.get("ecrasement", r["ecrasement"]))
        self._tr = d.get("traitement", {}) or {}
        self.bord_irregulier = bool(self._tr.get("bord_irregulier", False))
        self.images = {}
        # plans
        t = 0.0
        self.plans = []
        for i, p in enumerate(d.get("plans", [])):
            dur = self.horloge.d(p["temps"] if "temps" in p else p.get("duree", "8t"))
            if "temps" in p and not isinstance(p["temps"], str):
                dur = float(p["temps"]) * self.horloge.temps_s
            self.plans.append(Plan(p, i, t, t + dur, self))
            t += dur
        self.duree = float(d["duree"]) if "duree" in d else t
        if self.plans:
            self.plans[-1].t1 = max(self.plans[-1].t1, self.duree)
        for a, b in zip(self.plans, self.plans[1:]):
            a.t_fin_rendu = a.t1 + b.d_entree
        for p in self.plans:
            if p.t_fin_rendu == p.t1:
                p.t_fin_rendu = p.t1
        self.plans[-1].t_fin_rendu = self.duree + 1
        for p in self.plans:
            p.construire(self)
        perm_specs = []
        for e in d.get("permanent", []):
            perm_specs += C.developper(e, self, None)
        self.permanent = [C.creer(e, self, None) for e in perm_specs]
        self._fonds = {}
        self._cache = OrderedDict()
        self._ombres = {}
        self._papier = None

    def traitement(self, plan):
        tr = dict(self._tr)
        if plan is not None and plan.spec.get("traitement"):
            tr.update(plan.spec["traitement"])
        return tr

    def charger_image(self, src):
        if src not in self.images:
            if src.startswith("maquette:"):
                import maquettes
                self.images[src] = maquettes.depuis_texte(src[len("maquette:"):], self.pal)
            else:
                p = src if os.path.isabs(src) else os.path.join(self.base, src)
                if not os.path.exists(p):
                    raise SystemExit(f"Image introuvable : {src} (chemin relatif à {self.base})")
                self.images[src] = Image.open(p).convert("RGBA")
        return self.images[src]

    # ------------------------------------------------------------ dessin d'un plan
    def fond(self, plan, cam):
        mx, my = 220, 300
        cle = plan.i
        if cle not in self._fonds:
            self._fonds[cle] = M.fond_image(plan.fond_spec, self.W, self.H, self.pal, self.base, plan.i + 1, mx, my)
        im = self._fonds[cle]
        z = plan.fond_z
        x, y, k = projeter(self.W / 2, self.H / 2, z, cam, self.W, self.H)
        ox, oy = x - self.W / 2, y - self.H / 2
        r = cam["rot"]
        if abs(k - 1) < 1e-4 and abs(ox) < 0.01 and abs(oy) < 0.01 and not r:
            out = im.crop((mx, my, mx + self.W, my + self.H))
        else:
            # pixel écran (u, v) ← pixel du fond
            a = math.radians(-r)
            ca, sa = math.cos(a) / k, math.sin(a) / k
            cx, cy = self.W / 2, self.H / 2
            # (u - cx - ox, v - cy - oy) tourné de -r, divisé par k, + centre du fond
            c0 = -(cx + ox) * ca + (cy + oy) * sa + cx + mx
            f0 = -(cx + ox) * sa - (cy + oy) * ca + cy + my
            out = im.transform((self.W, self.H), Image.AFFINE, (ca, -sa, c0, sa, ca, f0), resample=Image.BILINEAR)
        mp_ = plan.mise_au_point
        if mp_:
            rb = self.flou_profondeur(mp_, z, cam)
            if rb > 0.4:
                out = out.filter(ImageFilter.GaussianBlur(rb))
        return out

    def flou_profondeur(self, mp_, z, cam):
        focus = float(mp_.get("z", 0))
        return float(mp_.get("force", 6)) * abs(z - focus)

    def ombre_posee(self, w, h, a):
        cle = (int(w / 4) * 4, int(h / 2) * 2, int(a * 20))
        if cle not in self._ombres:
            W2, H2 = cle[0] + 60, cle[1] + 40
            im = Image.new("RGBA", (W2, H2), (0, 0, 0, 0))
            oc = self.pal("ombre")[:3]
            ImageDraw.Draw(im).ellipse([30, 20, 30 + cle[0], 20 + cle[1]], fill=oc + (int(255 * a),))
            self._ombres[cle] = im.filter(ImageFilter.GaussianBlur(max(3, cle[1] / 4)))
            if len(self._ombres) > 200:
                self._ombres.pop(next(iter(self._ombres)))
        return self._ombres[cle]

    def dessiner_element(self, canvas, e, t, cam, plan, journal):
        st = e.etat(t)
        if st["opacite"] <= 0.01 or st["echelle"] <= 0.002:
            return
        X, Y, Z = st["x"] + st["dx"], st["y"] + st["dy"], st["z"]
        if e.spec.get("fixe_ecran"):
            sx, sy, k = X, Y, 1.0
        else:
            sx, sy, k = projeter(X, Y, Z, cam, self.W, self.H)
        s_tot = st["echelle"] * k
        rot = st["rot"] + (cam["rot"] if not e.spec.get("fixe_ecran") else 0)
        blur = float(e.spec.get("flou", 0))
        if plan is not None and plan.mise_au_point and not e.spec.get("net"):
            blur += self.flou_profondeur(plan.mise_au_point, Z, cam)
        cle = None
        if e.statique and st["masque"] is None:
            cle = (e.id, round(s_tot * st["sx"], 3), round(s_tot * st["sy"], 3), round(rot, 1), round(blur, 1))
        if cle is not None and cle in self._cache:
            spr, ax, ay, w0, h0, ay0 = self._cache[cle]
            self._cache.move_to_end(cle)
        else:
            img, ax, ay, s_img = e.contenu(t, st, s_tot)
            e._s_dessin = s_img
            if st["masque"]:
                nom, p = st["masque"]
                img = C.masquer(img, nom, p, tuple(e.spec.get("centre_masque", (0.5, 0.5))))
            f = s_tot / s_img
            fx, fy = f * st["sx"], f * st["sy"]
            if abs(fx - 1) > 0.004 or abs(fy - 1) > 0.004:
                nw, nh = max(1, int(round(img.width * fx))), max(1, int(round(img.height * fy)))
                if nw * nh > 9e6:
                    return
                img = img.resize((nw, nh), Image.BICUBIC if fx > 0.5 else Image.LANCZOS)
                ax, ay = ax * fx, ay * fy
            w0, h0, ay0 = img.width, img.height, ay
            if abs(rot) > 0.05:
                cx, cy = img.width / 2, img.height / 2
                img = img.rotate(-rot, resample=Image.BICUBIC, expand=True)
                a = math.radians(rot)
                vx, vy = ax - cx, ay - cy
                ax = img.width / 2 + vx * math.cos(a) - vy * math.sin(a)
                ay = img.height / 2 + vx * math.sin(a) + vy * math.cos(a)
            if blur > 0.4:
                pad = int(blur * 2)
                img = M.avec_marge(img, pad).filter(ImageFilter.GaussianBlur(blur))
                ax, ay = ax + pad, ay + pad
            spr = img
            if cle is not None:
                self._cache[cle] = (spr, ax, ay, w0, h0, ay0)
                if len(self._cache) > 260:
                    self._cache.popitem(last=False)
        op = st["opacite"]
        if e.spec.get("ombre") == "posee":
            hauteur = st.get("hauteur", 0) * k
            bas = sy + (h0 - ay0) + hauteur
            larg = w0 * float(e.spec.get("largeur_ombre", 0.78)) / (1 + hauteur / 350)
            a = float(e.spec.get("force_ombre", 0.32)) / (1 + hauteur / 220) * op
            o = self.ombre_posee(larg, max(8, larg * 0.16), a)
            coller(canvas, o, sx - o.width / 2, bas - o.height / 2 - larg * 0.02)
        if op < 0.995:
            spr = spr.copy()
            spr.putalpha(spr.getchannel("A").point(lambda v: int(v * op)))
        x0, y0 = sx - ax, sy - ay
        coller(canvas, spr, x0, y0)
        if journal is not None:
            bb = spr.getbbox()
            ut = getattr(e, "_utile", None)
            if bb and ut:  # boîte de ce qui compte (sans la marge du doigt ou la pastille)
                f = s_tot / max(1e-6, getattr(e, "_s_dessin", s_tot))
                bb = (ax + ut[0] * f * st["sx"], ay + ut[1] * f * st["sy"], ax + ut[2] * f * st["sx"], ay + ut[3] * f * st["sy"])
            if bb:
                role = e.role
                if e.type == "telephone" and getattr(e, "_produit", False):
                    role = "produit"
                info = {"id": e.id, "type": e.type, "role": role, "bbox": [x0 + bb[0], y0 + bb[1], x0 + bb[2], y0 + bb[3]],
                        "stable": st["stable"], "opacite": op, "echelle": s_tot, "texte_elt": e.est_texte, "plan": plan.nom if plan else "permanent"}
                if e.est_texte:
                    info.update(e.info_verif())
                    info["taille_ecran"] = info.get("taille", 0) * s_tot
                journal.append(info)

    def dessiner_plan(self, plan, t, journal=None):
        cam = plan.camera(C.Calque.temps(_Saccade(self.traitement(plan).get("saccade")), t))
        canvas = self.fond(plan, cam).copy()
        for e in plan.elements:
            if e.visible(t):
                self.dessiner_element(canvas, e, t, cam, plan, journal)
        return canvas

    # ------------------------------------------------------------ une image complète
    def plan_a(self, t):
        for i, p in enumerate(self.plans):
            if p.t0 <= t < p.t1:
                return i
        return len(self.plans) - 1

    def image(self, t, journal=None):
        i = self.plan_a(t)
        p = self.plans[i]
        if i > 0 and p.entree != "coupe" and t < p.t0 + p.d_entree:
            prog = (t - p.t0) / max(1e-3, p.d_entree)
            A = self.dessiner_plan(self.plans[i - 1], t, None)
            B = self.dessiner_plan(p, t, journal)
            out = transition(A, B, p.entree, prog, p, self)
        else:
            out = self.dessiner_plan(p, t, journal)
        cam0 = cam_defaut()
        for e in self.permanent:
            if e.visible(t):
                self.dessiner_element(out, e, t, cam0, None, journal)
        return self.post(out, t, p)

    def post(self, im, t, plan):
        tr = self.traitement(plan)
        if tr.get("papier"):
            if self._papier is None:
                self._papier = M.texture_papier(self.W, self.H, 11, 0.4)[..., None]
            a = np.asarray(im.convert("RGB"), np.float32) * self._papier
            im = Image.fromarray(a.clip(0, 255).astype("uint8"))
        if tr.get("grain"):
            pas = math.floor(t * float(tr.get("saccade") or 8))
            im = M.grain_image(im, float(tr["grain"]), graine=pas % 6)
        return im.convert("RGB")

    # ------------------------------------------------------------ repères
    def cues(self):
        out = []
        for p in self.plans[1:]:
            typ = p.entree.split("-")[0]
            son = p.spec.get("son_entree", SONS_TRANSITION.get(typ))
            if son:
                out.append({"t": round(p.t0, 3), "type": son})
        for e in [e for p in self.plans for e in p.elements] + self.permanent:
            son = e.spec.get("son")
            if son is False:
                continue
            if son is None:
                son = {"tampon": "impact", "prix": "pop"}.get(e.type)
                if e.type == "bouton" and getattr(e, "t_clic", None) is not None:
                    out.append({"t": round(e.t_clic, 3), "type": "clic"})
                if e.role == "logo":
                    son = "ding"
            if son:
                t = e.t0
                if e.anim == "tombe":
                    t += e.d_anim
                out.append({"t": round(t, 3), "type": son})
            if e.type == "telephone":
                for m in e.msgs:
                    out.append({"t": round(m["t"], 3), "type": "pop"})
        return sorted(out, key=lambda c: c["t"])

    def moment_logo(self):
        for e in self.plans[-1].elements:
            if e.role == "logo":
                return e.t0
        return self.plans[-1].t0


class _Saccade:
    """Petit adaptateur pour appliquer la saccade du plan à la caméra."""

    def __init__(self, f):
        self.saccade = f


def coller(canvas, spr, x, y):
    x, y = int(round(x)), int(round(y))
    W, H = canvas.size
    if x >= W or y >= H or x + spr.width <= 0 or y + spr.height <= 0:
        return
    if x < 0 or y < 0 or x + spr.width > W or y + spr.height > H:
        cx0, cy0 = max(0, -x), max(0, -y)
        cx1, cy1 = min(spr.width, W - x), min(spr.height, H - y)
        spr = spr.crop((cx0, cy0, cx1, cy1))
        x, y = x + cx0, y + cy0
    canvas.alpha_composite(spr, (x, y))


# ---------------------------------------------------------------- transitions
def _decaler(im, dx, dy, fond):
    out = Image.new("RGBA", im.size, fond)
    coller(out, im, dx, dy)
    return out


def _zoom(im, k):
    W, H = im.size
    if abs(k - 1) < 1e-3:
        return im
    w, h = int(W / k), int(H / k)
    x0, y0 = (W - w) // 2, (H - h) // 2
    return im.crop((x0, y0, x0 + w, y0 + h)).resize((W, H), Image.BILINEAR)


def transition(A, B, nom, p, plan, pub):
    W, H = A.size
    e = C.douce(p)
    es = C.sortie_c(p)
    if nom == "fondu":
        return Image.blend(A, B, e)
    if nom.startswith("pousse"):
        d = nom.split("-")[1] if "-" in nom else "gauche"
        k = 0.5 - 0.5 * math.cos(math.pi * min(1, p)) if p < 1 else 1
        k = 1 - (1 - k) ** 2 if p < 1 else 1
        vx, vy = {"gauche": (-W, 0), "droite": (W, 0), "haut": (0, -H), "bas": (0, H)}[d]
        out = Image.new("RGBA", A.size)
        coller(out, A, vx * k, vy * k)
        coller(out, B, vx * (k - 1), vy * (k - 1))
        return out
    if nom.startswith("recouvre"):
        d = nom.split("-")[1] if "-" in nom else "haut"
        vx, vy = {"gauche": (-W, 0), "droite": (W, 0), "haut": (0, -H), "bas": (0, H)}[d]
        out = A.copy()
        coller(out, B, -vx * (1 - es), -vy * (1 - es))
        return out
    if nom.startswith("volet") or nom in ("rond", "rideau", "diagonale"):
        cm = tuple(v / s for v, s in zip(plan.spec.get("centre_entree", [540, 960]), (W, H)))
        if nom == "rideau":  # l'ancienne scène s'ouvre en deux
            out = B.copy()
            g = A.crop((0, 0, W // 2, H))
            dr = A.crop((W // 2, 0, W, H))
            coller(out, g, -W / 2 * e, 0)
            coller(out, dr, W / 2 + W / 2 * e, 0)
            return out
        Bm = C.masquer(B, nom, es, cm)
        out = A.copy()
        out.alpha_composite(Bm)
        return out
    if nom == "zoom":
        if p < 0.5:
            return Image.blend(_zoom(A, 1 + 0.5 * C.entree_c(p * 2)), _zoom(B, 1.3), C.douce(p * 2) * 0.5)
        return Image.blend(_zoom(A, 1.5), _zoom(B, 1.3 - 0.3 * C.sortie_c((p - 0.5) * 2)), 0.5 + 0.5 * C.douce((p - 0.5) * 2))
    if nom == "flash":
        c = pub.pal(plan.spec.get("couleur_entree", "clair"))
        blanc = Image.new("RGBA", A.size, c)
        if p < 0.4:
            return Image.blend(A, blanc, (p / 0.4) ** 2)
        return Image.blend(blanc, B, C.sortie_c((p - 0.4) / 0.6))
    if nom in ("forme", "tache"):
        c = pub.pal(plan.spec.get("couleur_entree", "accent"))
        cx, cy = plan.spec.get("centre_entree", [540, 960])
        R = math.hypot(max(cx, W - cx), max(cy, H - cy)) * 1.15
        r1 = R * C.sortie_c(p / 0.6)
        r2 = R * C.sortie_c((p - 0.3) / 0.7) if p > 0.3 else 0
        out = A.copy()
        for r, src in ((r1, None), (r2, B)):
            if r <= 1:
                continue
            m = Image.new("L", A.size, 0)
            pts = M._poly_blob(cx, cy, r, r, graine=plan.i + 3, irreg=0.1 if nom == "tache" else 0.0, phase=p * 3)
            ImageDraw.Draw(m).polygon(pts, fill=255)
            couche = Image.new("RGBA", A.size, c) if src is None else src
            out = Image.composite(couche, out, m)
        return out
    if nom == "bande":
        c = pub.pal(plan.spec.get("couleur_entree", "accent"))
        larg = W * 0.9
        pos = -larg + (W + H * 0.5 + 2 * larg) * C.douce(p)
        m = Image.new("L", A.size, 0)
        d = ImageDraw.Draw(m)
        d.polygon([(pos - H * 0.5, H), (pos, 0), (W * 3, 0), (W * 3, H)], fill=255)
        out = Image.composite(A, B, m)
        bande = Image.new("L", A.size, 0)
        ImageDraw.Draw(bande).polygon([(pos - H * 0.5 - larg, H), (pos - larg, 0), (pos, 0), (pos - H * 0.5, H)], fill=255)
        out = Image.composite(Image.new("RGBA", A.size, c), out, bande)
        return out
    if nom == "papier":  # une feuille déchirée remonte
        bord = (1 - es) * (H + 160) - 80
        xs = np.arange(0, W + 20, 20)
        rng = np.random.default_rng(plan.i + 5)
        ondes = rng.normal(0, 14, len(xs)) + 22 * np.sin(xs / 140 + plan.i)
        pts = [(float(x), float(bord + o)) for x, o in zip(xs, ondes)]
        m = Image.new("L", A.size, 0)
        ImageDraw.Draw(m).polygon(pts + [(W, H), (0, H)], fill=255)
        out = Image.composite(B, A, m)
        liseré = Image.new("L", A.size, 0)
        dl = ImageDraw.Draw(liseré)
        dl.polygon(pts + [(x, y + 26) for x, y in reversed(pts)], fill=255)
        out = Image.composite(Image.new("RGBA", A.size, pub.pal("papier")), out, liseré)
        return out
    return B



# ---------------------------------------------------------------- rendu vidéo (en parallèle)
_PUB = None


def _init(chemin):
    global _PUB
    _PUB = Pub(chemin)


def _une(i):
    t = i / _PUB.fps
    return _PUB.image(t).tobytes()


def rendre_video(chemin, sortie, fps=None, qualite="normale", de=0.0, jusqua=None, process=None):
    pub = Pub(chemin)
    fps = fps or pub.fps
    pub.fps = fps
    fin = min(pub.duree, jusqua) if jusqua else pub.duree
    i0, i1 = int(round(de * fps)), int(round(fin * fps))
    os.makedirs(os.path.dirname(os.path.abspath(sortie)), exist_ok=True)
    crf, debit = ("19", "9M") if qualite == "normale" else ("24", "4M")
    cmd = [ffmpeg_exe(), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{pub.W}x{pub.H}", "-r", str(fps),
           "-i", "-", "-c:v", "libx264", "-preset", "medium", "-crf", crf, "-maxrate", debit, "-bufsize", "18M",
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", sortie]
    ff = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    t_debut = time.time()
    n = process or max(1, min(8, (os.cpu_count() or 2) - 1))
    idx = list(range(i0, i1))
    if n > 1:
        ctx = mp.get_context("fork" if sys.platform != "win32" else "spawn")
        with ctx.Pool(n, initializer=_init, initargs=(chemin,)) as pool:
            for k, b in enumerate(pool.imap(_une, idx, chunksize=4)):
                ff.stdin.write(b)
                if k % (fps * 2) == 0:
                    print(f"  {k / fps:5.1f} s / {(i1 - i0) / fps:.1f} s", flush=True)
    else:
        for k, i in enumerate(idx):
            ff.stdin.write(pub.image(i / fps).tobytes())
    ff.stdin.close()
    ff.wait()
    duree_calc = time.time() - t_debut
    with open(os.path.join(os.path.dirname(os.path.abspath(sortie)), "cues.json"), "w", encoding="utf-8") as f:
        json.dump([c for c in pub.cues() if de <= c["t"] < fin], f, indent=1)
    print(f"Vidéo : {sortie} ({(i1 - i0) / fps:.1f} s, {os.path.getsize(sortie) / 1e6:.1f} Mo, calcul {duree_calc:.0f} s)")
    print(f"Bruitages repérés : {os.path.join(os.path.dirname(os.path.abspath(sortie)), 'cues.json')}")
    return duree_calc


# ---------------------------------------------------------------- contrôle
def dessiner_zones(im):
    im = im.convert("RGBA")
    calque = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(calque)
    W, H = im.size
    rouge = (230, 40, 60, 70)
    d.rectangle([0, 0, W, ZONE_HAUT], fill=rouge)
    d.rectangle([0, ZONE_BAS, W, H], fill=rouge)
    d.rectangle([ZONE_DROITE, ZONE_DROITE_Y, W, ZONE_BAS], fill=rouge)
    im.alpha_composite(calque)
    return im.convert("RGB")


def vignette(im, t, legende, w=270):
    h = int(w * im.height / im.width)
    v = im.resize((w, h), Image.LANCZOS)
    out = Image.new("RGB", (w, h + 34), (34, 34, 38))
    out.paste(v, (0, 0))
    d = ImageDraw.Draw(out)
    pol = M.Polices(ICI).get(19, "texte", 600)
    d.text((6, h + 6), f"{t:.2f} s  {legende}"[:44], font=pol, fill=(235, 235, 235))
    return out


def planche_images(images, cols, sortie, titre=None):
    w, h = images[0].size
    lignes = math.ceil(len(images) / cols)
    ht = 50 if titre else 0
    pl = Image.new("RGB", (cols * (w + 10) + 10, lignes * (h + 10) + 10 + ht), (24, 24, 28))
    if titre:
        ImageDraw.Draw(pl).text((14, 12), titre, font=M.Polices(ICI).get(26, "texte", 700), fill=(240, 240, 240))
    for k, im in enumerate(images):
        pl.paste(im, (10 + (k % cols) * (w + 10), ht + 10 + (k // cols) * (h + 10)))
    os.makedirs(os.path.dirname(os.path.abspath(sortie)), exist_ok=True)
    pl.save(sortie, quality=88)
    return sortie


def moments_planche(pub):
    ts = []
    for p in pub.plans:
        ts += [p.t0 + min(0.5, (p.t1 - p.t0) * 0.3), (p.t0 + p.t1) / 2, p.t1 - 0.05]
    return sorted(set(round(min(pub.duree - 0.02, t), 2) for t in ts))


def faire_planche(pub, sortie, zones=True, journal_par_t=None):
    ims = []
    for t in moments_planche(pub):
        im = pub.image(t)
        if zones:
            im = dessiner_zones(im)
        if journal_par_t and t in journal_par_t:
            d = ImageDraw.Draw(im)
            for x0, y0, x1, y1 in journal_par_t[t]:
                d.rectangle([x0, y0, x1, y1], outline=(255, 0, 0), width=6)
        ims.append(vignette(im, t, pub.plans[pub.plan_a(t)].nom))
    return planche_images(ims, 6, sortie, f"Planche de contrôle · {os.path.basename(pub.chemin)} · {pub.duree:.1f} s · {pub.horloge.tempo:.0f} BPM")


def verifier(pub, sortie_planche):
    pas = 1 / 6
    n = int(pub.duree / pas)
    problemes = {}
    vus = {}
    images = []
    produit_t = None
    fin_roles = {}
    textes = OrderedDict()

    def note(cle, msg, t, bbox=None):
        if cle not in problemes:
            problemes[cle] = (t, msg, bbox)

    for i in range(n + 1):
        t = min(pub.duree - 0.01, i * pas)
        j = []
        im = pub.image(t, j)
        images.append((t, np.asarray(im.resize((90, 160)), np.float32)))
        for e in j:
            x0, y0, x1, y1 = e["bbox"]
            vus.setdefault(e["id"], {"t0": t, "t1": t, "stable": 0, "e": e})
            v = vus[e["id"]]
            v["t1"] = t
            if e["role"] == "produit" and produit_t is None and e["opacite"] > 0.8:
                produit_t = t
            if e["role"] in ("logo", "action", "contact") and e["opacite"] > 0.8 and e["stable"]:
                fin_roles.setdefault(e["role"], []).append(t)
            if not e["stable"] or e["opacite"] < 0.9:
                continue
            v["stable"] += pas
            if e["texte_elt"]:
                if e.get("texte"):
                    textes.setdefault(e["texte"], e["plan"])
                if x0 < -4 or y0 < -4 or x1 > pub.W + 4 or y1 > pub.H + 4:
                    note((e["id"], "coupe"), f"texte coupé par le bord de l'écran : « {e.get('texte', '')[:40]} »", t, e["bbox"])
                if y0 < ZONE_HAUT or y1 > ZONE_BAS or (x1 > ZONE_DROITE and y1 > ZONE_DROITE_Y):
                    if e["role"] not in ("decor",):
                        note((e["id"], "zone"), f"texte dans une zone couverte par TikTok/Reels : « {e.get('texte', '')[:40]} » (boîte {int(x0)},{int(y0)} → {int(x1)},{int(y1)})", t, e["bbox"])
                if e.get("taille_ecran", 99) < 52 and e["role"] not in ("mention", "interface"):
                    note((e["id"], "petit"), f"texte trop petit pour un téléphone ({e['taille_ecran']:.0f} px, viser 60 px et plus) : « {e.get('texte', '')[:40]} »", t, e["bbox"])
                if e.get("mots", 0) > 6 and e["role"] not in ("mention", "interface", "avis"):  # un avis client peut être plus long
                    note((e["id"], "mots"), f"{e['mots']} mots à l'écran (viser 3 à 6) : « {e.get('texte', '')[:50]} »", t)
                if not e.get("fond_carte"):
                    for f in j:
                        if f["role"] == "produit" and f["opacite"] > 0.8 and f["stable"] and f["type"] != "telephone":
                            a0, b0, a1, b1 = f["bbox"]
                            ix = max(0, min(x1, a1) - max(x0, a0)) * max(0, min(y1, b1) - max(y0, b0))
                            if ix > 0.25 * (x1 - x0) * (y1 - y0):
                                note((e["id"], "sur"), f"le texte « {e.get('texte', '')[:30]} » passe sur le produit", t, e["bbox"])
            elif e["role"] in ("produit", "logo") and e["type"] == "image":
                if x0 < -4 or y0 < -4 or x1 > pub.W + 4 or y1 > pub.H + 4:
                    note((e["id"], "coupe"), f"{e['role']} coupé par le bord de l'écran ({e['id']})", t, e["bbox"])
    # temps de lecture
    for v in vus.values():
        e = v["e"]
        if e["texte_elt"] and e.get("mots") and e["type"] not in ("telephone",):
            besoin = 0.45 if e["mots"] == 1 and len(e.get("texte", "")) <= 3 else max(0.8, 0.3 * e["mots"] + 0.4)
            if v["stable"] + 1e-6 < besoin and v["t1"] < pub.duree - 0.3:
                note((e["id"], "lecture"), f"« {e.get('texte', '')[:40]} » reste {v['stable']:.1f} s lisible, il faut {besoin:.1f} s", v["t0"])
    if produit_t is None:
        note(("global", "produit"), "aucun élément marqué \"role\": \"produit\" : marquer le produit pour vérifier qu'on le voit avant 3 s", 0)
    elif produit_t > 3.0:
        note(("global", "produit"), f"le produit n'apparaît qu'à {produit_t:.1f} s : il doit se voir avant 3 s", produit_t)
    for r in ("logo", "action", "contact"):
        ts = [t for t in fin_roles.get(r, []) if t >= pub.duree - 3]
        if len(ts) * pas < 1.95:
            note(("global", r), f"fin : {r} lisible seulement {len(ts) * pas:.1f} s dans les 3 dernières secondes (il faut 2 s)", pub.duree - 2)
    # rien ne bouge ?
    calme = 0.0
    for (ta, a), (tb, b) in zip(images, images[1:]):
        if np.abs(a - b).mean() < 0.35 and tb < pub.duree - 3:
            calme += pas
            if calme >= 0.8:
                note(("global", f"fige{int(ta)}"), f"rien ne bouge autour de {ta:.1f} s : ajouter une action (boucle, caméra, élément)", ta)
        else:
            calme = 0.0
    # rapport
    print(f"\nVérification de {os.path.basename(pub.chemin)} : {pub.duree:.1f} s, {len(pub.plans)} plans, tempo {pub.horloge.tempo:.0f}")
    if problemes:
        for (t, msg, _) in sorted(problemes.values(), key=lambda x: x[0]):
            print(f"  ✗ {t:5.2f} s  {msg}")
    else:
        print("  ✓ aucun problème détecté (regarder quand même la planche)")
    print("\nTextes à l'écran (à relire au caractère près avec ceux de la personne) :")
    for tx, pl in textes.items():
        print(f"  [{pl}] {tx}")
    boites = {}
    mom = moments_planche(pub)
    for (t, msg, bb) in problemes.values():
        if bb:
            proche = min(mom, key=lambda m: abs(m - t))
            if abs(proche - t) < 0.6:
                boites.setdefault(proche, []).append(bb)
    faire_planche(pub, sortie_planche, True, boites)
    print(f"\nPlanche : {sortie_planche}")
    return len(problemes)


def validation(pub, sortie):
    d = pub.d.get("validation")
    if d:
        ts = [pub.horloge.t(v, 0, pub.duree) for v in d]
    else:
        ts = [min(0.6, pub.duree * 0.05)]
        prod = next((e for p in pub.plans for e in p.elements if e.role == "produit"), None)
        t_prod = (prod.t0 + prod.d_anim + 0.4) if prod else pub.duree * 0.3
        if t_prod < 1.6 and len(pub.plans) > 2:  # le produit est déjà dans la 1re image : montrer le plan 2
            t_prod = (pub.plans[1].t0 + pub.plans[1].t1) / 2
        ts.append(t_prod)
        offre = next((e for p in pub.plans for e in p.elements if e.type in ("prix", "tampon", "compteur") or e.role == "offre"), None)
        ts.append((offre.t0 + offre.d_anim + 0.4) if offre else pub.duree * 0.6)
        ts.append(pub.duree - 0.5)
    noms = ["1 · première seconde", "2 · le produit", "3 · l'offre / la preuve", "4 · la fin"]
    ims = []
    for k, t in enumerate(ts[:4]):
        im = pub.image(min(pub.duree - 0.02, t))
        ims.append(vignette(im, t, noms[k] if k < 4 else "", w=420))
    return planche_images(ims, 4, sortie, "Validation : 4 images tirées du vrai moteur (esquisse fixe, la vidéo bouge)")


CATALOGUE = """Plans : temps (en temps de musique) ou duree, fond, camera, entree, mise_au_point, traitement, secousses, elements
Fonds : uni, degrade (radial), motif (points rayures lignes quadrillage damier vagues rayons), partage, image ; + halo, sol, papier, aquarelle, z
Caméra : fixe avance recule plonge panoramique-gauche/droite travelling-gauche/droite monte descend respire, ou images clés
Transitions : coupe pousse-* recouvre-* volet-* rond rideau diagonale zoom flash forme tache bande papier fondu
Éléments : image forme texte prix compteur tampon bouton trait telephone ; composés : fin avis pluie flotte confettis sequence
Texte (mode) : bloc mots lettres masque machine ecrit ; *mot* = accent ; surligne
Entrées : pop zoom monte descend glisse-gauche/droite tombe tourne elastique fondu ecrase volet-* rond rideau diagonale dessine projete aucune
Sorties : reduit fondu monte descend glisse-* volet-* tombe     Boucles : respire balance flotte pulse tourne derive
Traitements image : noir_blanc bichromie trame bord_blanc bord_papier relief pate aquarelle masque polaroid flou
Traitement global : saccade (12), tremble, grain, papier, formes ([relief] / [pate] / [aquarelle]), bord_irregulier"""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pub", nargs="?")
    ap.add_argument("--sortie")
    ap.add_argument("--image", type=float)
    ap.add_argument("--zones", action="store_true")
    ap.add_argument("--validation", action="store_true")
    ap.add_argument("--verifier", action="store_true")
    ap.add_argument("--planche", action="store_true")
    ap.add_argument("--essai", action="store_true")
    ap.add_argument("--catalogue", action="store_true")
    ap.add_argument("--fps", type=int)
    ap.add_argument("--qualite", default="normale", choices=["normale", "legere"])
    ap.add_argument("--de", type=float, default=0.0)
    ap.add_argument("--jusqua", type=float)
    ap.add_argument("--process", type=int)
    a = ap.parse_args()
    if a.catalogue:
        print(CATALOGUE)
        return
    if not a.pub:
        ap.error("donner le fichier pub.json")
    dossier = os.path.dirname(os.path.abspath(a.pub))
    if a.image is not None:
        pub = Pub(a.pub)
        im = pub.image(a.image)
        if a.zones:
            im = dessiner_zones(im)
        s = a.sortie or os.path.join(dossier, "controle", f"image-{a.image:.2f}.png")
        os.makedirs(os.path.dirname(os.path.abspath(s)), exist_ok=True)
        im.save(s)
        print(f"Image : {s}")
        return
    if a.validation:
        pub = Pub(a.pub)
        print("Validation :", validation(pub, a.sortie or os.path.join(dossier, "controle", "validation.jpg")))
        return
    if a.verifier:
        pub = Pub(a.pub)
        verifier(pub, a.sortie or os.path.join(dossier, "controle", "planche.jpg"))
        return
    if a.planche:
        pub = Pub(a.pub)
        print("Planche :", faire_planche(pub, a.sortie or os.path.join(dossier, "controle", "planche.jpg")))
        return
    if a.essai:
        s = os.path.join(dossier, "controle", "essai.mp4")
        dc = rendre_video(a.pub, s, a.fps, "legere", 0, 2.0, a.process)
        pub = Pub(a.pub)
        print(f"Estimation pour toute la pub ({pub.duree:.1f} s) : environ {dc * pub.duree / 2 / 60:.1f} min")
        return
    sortie = a.sortie or os.path.join(dossier, "sortie", "muette.mp4")
    rendre_video(a.pub, sortie, a.fps, a.qualite, a.de, a.jusqua, a.process)


if __name__ == "__main__":
    main()
