"""Le kit de marque : ce qui rend les pubs d'un commerce reconnaissables, dans un seul ZIP.

usage :
  python kit.py creer ma-marque/ [--sortie kit-ma-marque.zip] [--max-px 1600]
  python kit.py lire kit-ma-marque.zip [--vers ma-marque/]     # ou un dossier (kit décompressé, fichiers d'un Projet)

Dossier de la marque :
  ma-marque/
    marque.md        la fiche (modèle : assets/fiche-marque.md), avec le bloc JSON "marque"
    logo/            le logo
    elements/        images réutilisables détourées (produit, objets, décor, personnage)
    polices/         polices ajoutées (facultatif)
    pubs/            les pubs déjà faites (pub.json, sorties) : pas mises dans le kit

Le kit contient : LISEZ-MOI.md, marque.md, marque.json, logo/, elements/, polices/, apercu.jpg.
"""
import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile

from PIL import Image

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
IMAGES = (".png", ".jpg", ".jpeg", ".webp")
LIMITE_APP = 30e6

LISEZ_MOI = """# Kit de marque : {nom}

Ce kit garde le style de tes pubs (couleurs, polices, logo, images, ce qui a plu).

- **Projet Claude** : ajoute `marque.md`, `apercu.jpg`, le logo et les images de `elements/` dans les
  fichiers du Projet. Ensuite, dans le Projet : « Nouvelle pub pour… ».
- **Conversation hors Projet** : joins ce ZIP au premier message : « Voici le kit de ma marque, nouvelle pub pour… ».
- **Claude Code** : garde le dossier de ta marque et lance Claude Code dedans.

Un seul kit valable à la fois : quand Claude le refait, remplace l'ancien partout.
"""


def bloc_marque(texte):
    for m in re.finditer(r"```json\s*(\{.*?\})\s*```", texte, re.S):
        try:
            d = json.loads(m.group(1))
        except json.JSONDecodeError as e:
            sys.exit(f"Le bloc JSON de marque.md est invalide : {e}")
        if "marque" in d:
            return d["marque"]
    sys.exit("marque.md n'a pas de bloc ```json {\"marque\": …} ``` (modèle : assets/fiche-marque.md).")


def slug(t):
    import unicodedata
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", t.lower()).strip("-") or "marque"


def images(d):
    if not os.path.isdir(d):
        return []
    return sorted(os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith(IMAGES))


def copier_image(src, dst, max_px):
    im = Image.open(src)
    if max(im.size) > max_px:
        im.thumbnail((max_px, max_px), Image.LANCZOS)
    if dst.lower().endswith((".jpg", ".jpeg")):
        im.convert("RGB").save(dst, quality=90)
    else:
        im.save(dst)


def apercu(dossier, marque, sortie):
    """Trois écrans types rendus par le moteur avec les couleurs, polices, logo et images de la marque."""
    import moteur
    logo = images(os.path.join(dossier, "logo"))
    elts = images(os.path.join(dossier, "elements"))
    rel = lambda p: os.path.relpath(p, dossier)  # noqa: E731
    produit = rel(elts[0]) if elts else "maquette:bouteille;couleur=accent;etiquette=" + marque.get("nom", "")
    fin = {"type": "fin", "pas": 0.01, "action": marque.get("action", "Écris-nous sur WhatsApp"),
           "contact": marque.get("contact", "00 00 00 00")}
    fin.update({"logo": rel(logo[0])} if logo else {"nom": marque.get("nom", "Ma marque")})
    d = {"tempo": 100, "marque": marque, "plans": [
        {"temps": 4, "fond": {"type": "uni", "couleur": "fond", "halo": "clair"}, "elements": [
            {"type": "texte", "texte": marque.get("nom", "Ma marque"), "taille": 130, "y": 760, "couleur": "accent", "anim": "aucune"},
            {"type": "texte", "texte": "Le titre en *accent*", "taille": 84, "y": 1060, "anim": "aucune"}]},
        {"temps": 4, "fond": {"type": "degrade", "de": "fond", "vers": "clair", "halo": "clair"}, "elements": [
            {"type": "image", "src": produit, "largeur": 420, "x": 540, "y": 930, "anim": "aucune", "ombre": "posee"},
            {"type": "prix", "valeur": "5 000 F", "taille": 120, "x": 790, "y": 1400, "anim": "aucune", "pastille": "second"}]},
        {"temps": 4, "fond": "fond", "elements": [fin]}]}
    for e in d["plans"][2]["elements"]:
        e["a"] = 0
    pub = moteur.Pub(os.path.join(dossier, "_apercu.json"), d)
    for p in pub.plans:
        for e in p.elements:
            e.anim, e.d_anim = "aucune", 0
    ims = [moteur.vignette(pub.image(p.t1 - 0.05), 0, n, w=360) for p, n in zip(pub.plans, ["titre", "produit + prix", "fin"])]
    moteur.planche_images(ims, 3, sortie, f"Aperçu de la marque · {marque.get('nom', '')}")


def creer(a):
    dossier = os.path.abspath(a.dossier)
    fiche = os.path.join(dossier, "marque.md")
    if not os.path.exists(fiche):
        sys.exit(f"Pas de marque.md dans {dossier} (modèle : assets/fiche-marque.md).")
    texte = open(fiche, encoding="utf-8").read()
    marque = bloc_marque(texte)
    nom = marque.get("nom", os.path.basename(dossier))
    s = slug(nom)
    sortie = a.sortie or os.path.join(os.path.dirname(dossier), f"kit-{s}.zip")
    avert = []
    if not images(os.path.join(dossier, "logo")):
        avert.append("pas de logo dans logo/ : la fin affichera le nom en texte")
    if not images(os.path.join(dossier, "elements")):
        avert.append("pas d'image dans elements/ : les pubs suivantes devront refaire les images")
    for cle, police in (marque.get("polices") or {}).items():
        trouve = any(os.path.exists(p) for p in (os.path.join(dossier, "polices", police), os.path.join(ICI, "..", "assets", "fonts", police)))
        if not trouve:
            avert.append(f"police introuvable : {police} ({cle})")
    with tempfile.TemporaryDirectory() as tmp:
        racine = os.path.join(tmp, f"kit-{s}")
        os.makedirs(racine)
        shutil.copy(fiche, os.path.join(racine, "marque.md"))
        json.dump({"marque": marque}, open(os.path.join(racine, "marque.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        for sd in ("logo", "elements"):
            fs = images(os.path.join(dossier, sd))
            if fs:
                os.makedirs(os.path.join(racine, sd))
                for f in fs:
                    copier_image(f, os.path.join(racine, sd, os.path.basename(f)), a.max_px)
        pol_dst = os.path.join(racine, "polices")
        os.makedirs(pol_dst)
        for police in set((marque.get("polices") or {}).values()):
            for src in (os.path.join(dossier, "polices", police), os.path.join(ICI, "..", "assets", "fonts", police)):
                if os.path.exists(src):
                    shutil.copy(src, pol_dst)
                    lic = os.path.join(os.path.dirname(src), "OFL-" + os.path.splitext(police)[0].lower() + ".txt")
                    for l in [lic] + [os.path.join(os.path.dirname(src), x) for x in os.listdir(os.path.dirname(src)) if x.startswith("OFL-") and os.path.splitext(police)[0].lower()[:5] in x]:
                        if os.path.exists(l):
                            shutil.copy(l, pol_dst)
                    break
        apercu(racine, marque, os.path.join(racine, "apercu.jpg"))
        open(os.path.join(racine, "LISEZ-MOI.md"), "w", encoding="utf-8").write(LISEZ_MOI.format(nom=nom))
        if os.path.exists(os.path.join(racine, "_apercu.json")):
            os.remove(os.path.join(racine, "_apercu.json"))
        with zipfile.ZipFile(sortie, "w", zipfile.ZIP_DEFLATED) as z:
            for r, _, fs in os.walk(racine):
                for f in fs:
                    p = os.path.join(r, f)
                    z.write(p, os.path.relpath(p, tmp))
    taille = os.path.getsize(sortie)
    print(f"Kit : {sortie} ({taille / 1e6:.1f} Mo)")
    if taille > LIMITE_APP:
        print("  ! plus de 30 Mo (limite de l'app) : relancer avec --max-px 1200")
    for w in avert:
        print("  !", w)


def lire(a):
    src = os.path.abspath(a.kit)
    tmp = None
    if zipfile.is_zipfile(src):
        tmp = tempfile.mkdtemp()
        with zipfile.ZipFile(src) as z:
            z.extractall(tmp)
        racines = [os.path.join(r) for r, _, fs in os.walk(tmp) if "marque.md" in fs]
        if not racines:
            sys.exit("Ce ZIP ne contient pas de marque.md.")
        racine = racines[0]
    else:
        racines = [r for r, _, fs in os.walk(src) if "marque.md" in fs]
        if not racines:
            sys.exit(f"Pas de marque.md dans {src}.")
        racine = racines[0]
    marque = bloc_marque(open(os.path.join(racine, "marque.md"), encoding="utf-8").read())
    vers = os.path.abspath(a.vers or slug(marque.get("nom", "marque")))
    os.makedirs(vers, exist_ok=True)
    shutil.copy(os.path.join(racine, "marque.md"), vers)
    json.dump({"marque": marque}, open(os.path.join(vers, "marque.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    n = 0
    for sd in ("logo", "elements", "polices"):
        d = os.path.join(racine, sd)
        if os.path.isdir(d):
            os.makedirs(os.path.join(vers, sd), exist_ok=True)
            for f in os.listdir(d):
                shutil.copy(os.path.join(d, f), os.path.join(vers, sd, f))
                n += 1
    # fichiers d'un Projet posés à plat : ranger les images selon leur nom
    if not os.path.isdir(os.path.join(racine, "elements")):
        for f in os.listdir(racine):
            if f.lower().endswith(IMAGES) and not f.startswith("apercu"):
                sd = "logo" if "logo" in f.lower() else "elements"
                os.makedirs(os.path.join(vers, sd), exist_ok=True)
                shutil.copy(os.path.join(racine, f), os.path.join(vers, sd, f))
                n += 1
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"Marque « {marque.get('nom', '?')} » rangée dans {vers} ({n} fichiers)")
    print("Couleurs :", ", ".join(f"{k} {v}" for k, v in (marque.get("couleurs") or {}).items()))
    print("Polices :", ", ".join(f"{k} {v}" for k, v in (marque.get("polices") or {}).items()))
    print("Logo :", ", ".join(os.listdir(os.path.join(vers, "logo"))) if os.path.isdir(os.path.join(vers, "logo")) else "aucun (nom en texte)")
    print("Éléments :", ", ".join(os.listdir(os.path.join(vers, "elements"))) if os.path.isdir(os.path.join(vers, "elements")) else "aucun")
    print("À faire : recopier le bloc \"marque\" de marque.json dans pub.json, relire « Ce qui a plu » dans marque.md.")


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    c = sp.add_parser("creer")
    c.add_argument("dossier")
    c.add_argument("--sortie")
    c.add_argument("--max-px", type=int, default=1600)
    l_ = sp.add_parser("lire")
    l_.add_argument("kit")
    l_.add_argument("--vers")
    a = ap.parse_args()
    creer(a) if a.cmd == "creer" else lire(a)


if __name__ == "__main__":
    main()
