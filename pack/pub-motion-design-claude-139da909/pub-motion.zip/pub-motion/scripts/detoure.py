"""Détoure des images générées sur fond blanc (personnages, objets) et les recadre.

usage :
  python detoure.py entree.png sortie.png
  python detoure.py dossier_entree dossier_sortie [--contour 14] [--carre] [--seuil 235]

- Si l'image a déjà un fond transparent, il est gardé et nettoyé : le halo flou ou gris autour du
  dessin (pixels à moitié transparents) est durci, les poussières isolées sont effacées.
  --garder-alpha laisse la transparence telle quelle.
- Sinon, le blanc relié aux bords devient transparent (le blanc à l'intérieur du dessin reste).
- --contour N ajoute un contour blanc de N px autour (effet autocollant, lisible sur fond de couleur).
- --carre met l'image au carré, ancrée en bas (pratique pour les poses d'un personnage). Le côté du
  carré vaut la plus grande dimension du dessin : pour une pose plus large que haute (bras écartés), le
  personnage occupe moins que toute la hauteur. Les tailles réelles sont affichées pour chaque fichier.
"""
import argparse
import os
import sys

from PIL import Image, ImageChops, ImageDraw, ImageFilter


def fond_relie_au_bord(blanc):
    """Masque (255 = fond) des zones blanches qui touchent le bord de l'image."""
    try:
        import numpy as np
        from scipy import ndimage
        m = np.array(blanc) > 0
        lab, _ = ndimage.label(m)
        bords = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
        return Image.fromarray((np.isin(lab, list(bords)) * 255).astype("uint8"))
    except ImportError:  # sans scipy : remplissage par Pillow, plus lent
        blanc = blanc.copy()
        w, h = blanc.size
        pix = blanc.load()
        bords = [(x, 0) for x in range(w)] + [(x, h - 1) for x in range(w)] + [(0, y) for y in range(h)] + [(w - 1, y) for y in range(h)]
        for p in bords:
            if pix[p] == 255:
                ImageDraw.floodfill(blanc, p, 128)
        return blanc.point(lambda v: 255 if v == 128 else 0)


def nettoyer_alpha(im, bas=40, haut=215):
    """Durcit le bord d'une image déjà transparente : sous `bas` → transparent, au-dessus de `haut` → opaque,
    entre les deux → étiré. Puis efface les poussières de 1 à 2 px. Les couleurs du halo sont remplacées
    par celles du dessin voisin pour ne pas laisser de liseré gris ou blanc."""
    a = im.getchannel("A")
    a = a.point(lambda v: 0 if v < bas else 255 if v > haut else int((v - bas) * 255 / (haut - bas)))
    masque = a.point(lambda v: 255 if v > 0 else 0)
    ouvert = masque.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3))  # poussières
    a = ImageChops.multiply(a, ouvert.filter(ImageFilter.MaxFilter(3)))
    # couleur des pixels de bord : celle du dessin plein le plus proche (évite le liseré clair)
    plein = a.point(lambda v: 255 if v > 200 else 0)
    rgb = im.convert("RGB")
    etale = Image.composite(rgb, Image.new("RGB", im.size), plein)
    poids = plein
    for _ in range(3):
        etale = etale.filter(ImageFilter.BoxBlur(1))
        poids = poids.filter(ImageFilter.BoxBlur(1))
    import numpy as np
    e = np.asarray(etale, np.float32)
    p = np.asarray(poids, np.float32)[..., None] / 255
    voisin = np.clip(e / np.maximum(p, 1e-3), 0, 255)
    orig = np.asarray(rgb, np.float32)
    k = (np.asarray(a, np.float32)[..., None] / 255)
    bord = (k < 0.8) & (p > 0.02)
    out = np.where(bord, voisin, orig).astype("uint8")
    res = Image.fromarray(out, "RGB").convert("RGBA")
    res.putalpha(a)
    return res


def detourer(src, dst, seuil=235, contour=0, carre=False, garder_alpha=False):
    im = Image.open(src).convert("RGBA")
    alpha = im.getchannel("A")
    deja = alpha.getextrema()[0] < 250 and sum(alpha.histogram()[:16]) > im.width * im.height * 0.05
    if deja and not garder_alpha:
        im = nettoyer_alpha(im)
    if not deja:
        # blanc = les trois canaux au-dessus du seuil
        r, g, b = (c.point(lambda v: 255 if v > seuil else 0) for c in im.convert("RGB").split())
        blanc = ImageChops.multiply(ImageChops.multiply(r, g), b)
        # remplissage depuis les bords : seul le blanc relié au bord est du fond
        fond = fond_relie_au_bord(blanc)
        fond = fond.filter(ImageFilter.MaxFilter(3))  # grignote le halo gris du bord
        alpha = Image.eval(fond, lambda v: 255 - v)
        im.putalpha(alpha)
    if contour > 0:
        k = contour * 2 + 1
        a = im.getchannel("A").point(lambda v: 255 if v > 30 else 0)
        pad = contour + 4
        grand = Image.new("RGBA", (im.width + 2 * pad, im.height + 2 * pad), (0, 0, 0, 0))
        a_pad = Image.new("L", grand.size, 0)
        a_pad.paste(a, (pad, pad))
        epais = a_pad
        while k > 1:  # MaxFilter limité aux petites tailles : on l'applique par pas
            pas = min(k, 9)
            epais = epais.filter(ImageFilter.MaxFilter(pas))
            k -= pas - 1
        blanc_img = Image.new("RGBA", grand.size, (255, 255, 255, 255))
        blanc_img.putalpha(epais.filter(ImageFilter.GaussianBlur(0.8)))
        grand.alpha_composite(blanc_img)
        grand.alpha_composite(im, (pad, pad))
        im = grand
    bbox = im.getchannel("A").point(lambda v: 255 if v > 8 else 0).getbbox()
    if not bbox:
        print(f"  vide après détourage : {src}")
        return
    im = im.crop(bbox)
    if carre:
        c = max(im.size)
        fond = Image.new("RGBA", (c, c), (0, 0, 0, 0))
        fond.paste(im, ((c - im.width) // 2, c - im.height), im)
        im = fond
    im.save(dst)
    info = f" (déjà transparente, bord nettoyé)" if deja and not garder_alpha else ""
    if carre:
        bb2 = im.getchannel("A").point(lambda v: 255 if v > 8 else 0).getbbox() or (0, 0, im.width, im.height)
        info += f" ; dessin réel {bb2[2] - bb2[0]}×{bb2[3] - bb2[1]}, soit {100 * (bb2[3] - bb2[1]) / im.height:.0f} % de la hauteur"
    print(f"  {os.path.basename(src)} → {dst} ({im.width}×{im.height}){info}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("entree")
    ap.add_argument("sortie")
    ap.add_argument("--seuil", type=int, default=235)
    ap.add_argument("--contour", type=int, default=0)
    ap.add_argument("--carre", action="store_true")
    ap.add_argument("--garder-alpha", action="store_true", help="ne pas nettoyer une image déjà transparente")
    a = ap.parse_args()
    if os.path.isdir(a.entree):
        os.makedirs(a.sortie, exist_ok=True)
        fichiers = sorted(f for f in os.listdir(a.entree) if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp")))
        if not fichiers:
            sys.exit("Aucune image dans le dossier.")
        for f in fichiers:
            detourer(os.path.join(a.entree, f), os.path.join(a.sortie, os.path.splitext(f)[0] + ".png"), a.seuil, a.contour, a.carre,
                     a.garder_alpha)
    else:
        detourer(a.entree, a.sortie, a.seuil, a.contour, a.carre, a.garder_alpha)


if __name__ == "__main__":
    main()
