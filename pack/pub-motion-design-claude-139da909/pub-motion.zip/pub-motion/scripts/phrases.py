"""Repère les phrases d'une voix off (silences) pour caler les textes et les plans dessus.

usage : python phrases.py voix.mp3 [--tempo 100] [--seuil -38] [--silence 0.25]
Affiche, pour chaque phrase, son début et sa fin en secondes et en temps de musique (« 6.5t »).
"""
import argparse
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import SR, lire_audio  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("voix")
    ap.add_argument("--tempo", type=float, default=100)
    ap.add_argument("--seuil", type=float, default=-38, help="dBFS sous lequel c'est du silence")
    ap.add_argument("--silence", type=float, default=0.25, help="durée minimale d'un silence entre deux phrases (s)")
    a = ap.parse_args()
    y = lire_audio(a.voix)
    fen = int(0.02 * SR)
    nb = len(y) // fen
    rms = np.sqrt((y[:nb * fen].reshape(nb, fen) ** 2).mean(1) + 1e-12)
    db = 20 * np.log10(rms / (np.abs(y).max() or 1))
    parle = db > a.seuil
    phrases, debut, calme = [], None, 0
    for i, p in enumerate(parle):
        if p:
            if debut is None:
                debut = i
            calme = 0
        elif debut is not None:
            calme += 1
            if calme * 0.02 >= a.silence:
                phrases.append((debut * 0.02, (i - calme + 1) * 0.02))
                debut, calme = None, 0
    if debut is not None:
        phrases.append((debut * 0.02, nb * 0.02))
    b = 60 / a.tempo
    print(f"Voix : {len(y) / SR:.2f} s, {len(phrases)} phrases (tempo {a.tempo:.0f})")
    for k, (d, f) in enumerate(phrases, 1):
        print(f"  {k:2d}. {d:5.2f} → {f:5.2f} s   ({d / b:.1f}t → {f / b:.1f}t)")


if __name__ == "__main__":
    main()
