# Mon style de vidéo dessinée : [nom de la chaîne ou du projet]

Ce fichier garde ce qui rend mes vidéos reconnaissables. Claude le lit au début de chaque
nouvelle vidéo et le recopie dans video.json.

```json
{"style": {
  "nom": "Ma chaîne",
  "dessin": "flat",
  "affichage": "fresque",
  "tableau": "vert",
  "couleurs": {"fond": "#FFFFFF", "encre": "#111111", "accent": "#F2643A", "second": "#1FA89E"},
  "main": "marqueur",
  "main_taille": 640,
  "police": "Caveat.ttf",
  "sous_titres": true,
  "vitesse": 1.0,
  "voix": {"source": "elevenlabs", "nom": "", "voice_id": ""}
}}
```

## Ce qui a plu
- (ex. la caméra qui recule à la fin, la couleur qui se remplit, les titres en rouge)

## Ce qui n'a pas plu
- (ex. main trop rapide, dessins trop chargés)

## Le prompt d'image validé
(le prompt ChatGPT qui a donné le bon style, à reprendre tel quel)

## Les personnages et dessins récurrents
(fichiers rangés dans dessins/ : nom, ce qu'ils montrent)

## Sujets déjà faits
- (titre, date)
