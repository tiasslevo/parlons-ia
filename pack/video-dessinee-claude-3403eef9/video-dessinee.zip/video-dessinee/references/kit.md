# Le kit de style

Le skill est le même pour tous. Le **kit** garde ce qui rend les vidéos d'une personne
reconnaissables : `style.md` (style de dessin, affichage, couleurs, main, voix choisie, prompt d'image
validé, ce qui a plu ou non, sujets déjà faits), `style.json`, `main/` (main personnalisée),
`dessins/` (personnages et dessins récurrents), `apercu.jpg`, `LISEZ-MOI.md`.

**Quand** : à la fin de la première vidéo validée (`python scripts/kit.py creer mon-style`), puis à
chaque changement (une nouvelle couleur, un personnage récurrent, un retour qui a plu). Un seul kit
valable : rappeler de remplacer l'ancien. Plus de 30 Mo : `--max-px 1200`.

**Les vidéos suivantes, trois cas** (l'expliquer avec ces mots) :
- **a. Projet Claude** (le plus simple) : « Ajoute `style.md`, `apercu.jpg` et les images de `main/` et
  `dessins/` dans les fichiers de ton Projet. Ensuite, dans le Projet, écris seulement : nouvelle vidéo
  sur… » Au début : lire `style.md`, chercher les fichiers dans le bac à sable et lancer
  `python scripts/kit.py lire <dossier> --vers mon-style`. Si les images ne sont pas lisibles par le
  code, demander le ZIP.
- **b. Conversation hors Projet** : « Joins `kit-<nom>.zip` au premier message. » Puis `kit.py lire kit.zip`.
- **c. Claude Code** : le dossier du style reste sur l'ordinateur ; lancer Claude Code dedans.

`kit.py lire` affiche les clés à recopier en tête de video.json (style, affichage, couleurs, main…).
Ensuite : reprendre la même voix (même `voice_id`), le même bloc de style dans les prompts d'images,
et un **sujet pas encore fait**. La personne peut changer d'affichage d'une vidéo à l'autre ; le style
de dessin reste, sauf si elle demande autre chose.
