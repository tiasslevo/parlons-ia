# Les images à générer

Une image par partie de la fresque : personnage, objet, petite scène. Ce qui se fait en code n'est pas
généré : flèches, textes, objets simples (`python scripts/croquis.py --liste`).

## Règles pour toutes les images

- Style flat (le bloc ci-dessous, recopié **mot pour mot** dans chaque prompt).
- **Un seul sujet par image**, entier, centré, marge blanche autour, détourable : fond **blanc pur**
  uni, pas de sol, pas d'ombre portée, pas de décor.
- **Simple** : 1 ou 2 personnages, 1 à 3 objets, peu de détails.
- **Aucun texte, lettre, chiffre ni logo** : les mots s'écrivent en code. Un écran de téléphone montre
  des bulles ou des lignes grises vides.
- Mêmes personnages d'une image à l'autre : les décrire une fois, recopier la description, joindre la
  première image en référence.

## Le bloc de style (à copier)

> Illustration flat façon dessin animé moderne : contour noir épais et régulier (même épaisseur
> partout), formes rondes et sympathiques, aplats de couleurs franches à l'intérieur des contours,
> sans dégradé, sans ombre, sans texture, sans hachure, peu de détails. Un seul sujet entier, centré,
> large marge blanche, fond blanc pur uni (#FFFFFF), pas de sol, pas d'ombre portée. Aucun texte,
> aucune lettre, aucun chiffre, aucun logo.

En anglais (Codex, Gemini…) : « Flat cartoon illustration in the style of a modern animated series:
THICK, even, solid black outline (same weight everywhere), rounded friendly shapes, flat bold solid
colours inside the outlines (no gradients, no shading, no shadows, no texture, no hatching), simple
and clean with few details. Single subject, whole, centred, wide pure white margin, pure plain white
background (#FFFFFF), no ground, no cast shadow, absolutely no text, no letters, no numbers, no logo. »

## Les prompts

**Un personnage** : « [Description fixe : prénom, âge, peau, coiffure, tenue et couleurs], buste,
[ce qu'il fait : tient un téléphone et sourit]. [Bloc de style]. Format carré. »

**Un objet ou une petite scène** : « [Le sujet : un scooter de livraison avec un colis à l'arrière].
[Bloc de style]. Format carré. »

**Un groupe** (une foule de clients) : « [Six clients souriants qui saluent, deux rangs, visages
simples]. [Bloc de style]. Format paysage 3:2. »

**Une main** (si la personne veut la sienne) : « Photo réaliste d'une main droite [couleur de peau]
tenant un marqueur noir épais, vue de dessus comme pour dessiner sur une feuille posée à plat. La
pointe est bien visible en haut à gauche, le poignet sort du cadre en bas à droite. Lumière douce.
Fond blanc pur uni, sans ombre. Format carré. » Puis `python scripts/detoure.py main.png main-d.png`
et `"main": "main-d.png"` dans video.json.

Autre style demandé : remplacer le bloc par celui du style (styles.md), même structure de prompt.

## Quand les images arrivent

Les ranger dans `images/`, puis `python scripts/planche_images.py images/ controle/images.jpg` et
regarder : fond bien blanc, contour noir partout, pas de texte, style identique, pas trop de détails.
Une image hors style : redonner un prompt corrigé (une seule chose changée), pas trois variantes.
