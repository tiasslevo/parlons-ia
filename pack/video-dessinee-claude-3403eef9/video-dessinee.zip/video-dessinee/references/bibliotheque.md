# Le moteur : format de video.json

Exemples dans `assets/exemples/` : **fresque-flat** (le rendu par défaut), fresque-flat-en-code,
tableau-flat, tableau-noir-flat, successifs-craie, fresque-feutre, melange-croquis. Liste courte : `python scripts/moteur.py --catalogue`.

```json
{"style": "flat", "affichage": "fresque", "voix": "voix.mp3",
 "scenes": [
   {"texte": "Avec le Mobile Money, ton téléphone devient un porte-monnaie.",
    "elements": [
      {"type": "image", "id": "telephone", "src": "images/telephone.png", "mot": "téléphone", "place": [0.3, 0.2, 0.42]},
      {"type": "texte", "texte": "porte-monnaie", "mot": "porte-monnaie", "taille": 130,
       "pres": {"id": "telephone", "cote": "dessous"}}]}
 ]}
```

Texte de la voix = les `"texte"` des scènes bout à bout. Chemins relatifs à video.json. 1080 × 1920, 30 i/s.

## Clés générales

| Clé | Valeurs (défaut) |
|---|---|
| `style` | **`flat`** (défaut), sur demande `feutre`, `croquis`, `craie` |
| `affichage` | **`fresque`** (défaut), sur demande `successifs`, `tableau`, `melange` |
| `tableau` | `vert`, `noir`, `bleu` : n'importe quel style sur un tableau, trait clair (craie : vert par défaut) |
| `couleurs` | `{"fond", "encre", "accent", "second", "troisieme"}` en #hex |
| `voix`, `voix_a` | fichier audio ; décalage de départ (0,3 s) |
| `mots`, `whisper` | timeline (mots.json, refaite si absente) ; transcription Whisper existante |
| `debit`, `pause` | sans voix : mots/s (2,4), pause entre scènes (1 s) |
| `main`, `main_taille`, `main_pointe` | `feutre`, `marqueur`, `craie`, un fichier PNG détouré, ou `aucune` ; largeur (600) ; pointe [x, y] |
| `vitesse` | tout plus rapide (>1) ou plus lent (<1) |
| `sous_titres` | mot à mot en bas (oui avec une voix) |
| `fin` | temps tenu sur l'image finale (1,5 s) |
| `son_trait` | bruit de feutre très bas (non, désactivé par défaut) |
| `transition` | pages : `efface`, `fondu`, `coupe`, `glisse` |
| `zoom`, `recul`, `camera` | fresque : taille du tableau (2), recul final (oui), `suit` ou `fixe` |
| `colonnes`, `fleches` | tableau : colonnes (2), flèches entre les cases (non) ; `camera: "suit"` |
| `agrandir_max`, `respire` | pages : agrandissement max des dessins (1,3) ; respiration de caméra (0,03) |

## Les éléments

| `type` | Clés propres |
|---|---|
| `image` | `src` ; `zones` (fresque : `[{"id", "rect": [x0, y0, x1, y1], "mot", "scene"}]`) ; `rogner` (oui) |
| `dessin` | `sujet` (`croquis.py --liste` : personnage, foule, boutique, maison, telephone, billet, soleil, nuage, pluie, riviere, pot, graine, pousse, arrosoir…) ; `options` (`{"pose": "content"}`, `{"sens": "bas"}`) |
| `texte` | `texte` (`\n` = retour à la ligne), `taille` (70, titre 92), `couleur` (`encre`, `accent`…), `role: "titre"`, `police`, `largeur` |
| `photo` | `src` ; `cadre` (oui) ; `couleur: "fondu"` pour un fondu au lieu du balayage |
| `fleche` | `de`, `vers` : deux `id` d'éléments |

Clés communes : `id`, `mot` (le dessin commence 0,15 s avant ce mot ; cherché dans la scène, puis
après), `a` (début forcé en s), `duree` (durée totale), `lenteur` (1,3 = plus lent), `largeur`
(fraction de la largeur utile), `place` `[x, y, largeur]` (fractions), `pres`
`{"id", "cote": dessous|dessus|gauche|droite|dedans, "ecart", "dx", "dy"}`, `couleur`
`remplit|fondu|aucune`, `marge` (fresque : recul de la caméra sur cet élément, 1,4).

## Commandes

```bash
python scripts/moteur.py video.json --verifier     # contrôles + controle/planche.jpg
python scripts/moteur.py video.json --image 6.5    # une image fixe
python scripts/moteur.py video.json --essai        # 3 s, estime le temps de calcul
python scripts/moteur.py video.json                # sortie/muette.mp4 puis sortie/video.mp4 (voix)
python scripts/croquis.py --planche croquis.jpg    # tous les dessins en code
```

Temps de calcul mesuré : environ 1 s par seconde de vidéo sur 12 cœurs. Dans le bac à sable de
l'app (moins de cœurs), lancer d'abord `--essai` pour connaître le temps.
