# L'affichage

## Par défaut : `fresque`

Un grand tableau blanc (2 fois l'écran, `"zoom": 2`) se construit petit à petit. La caméra se pose
sur la partie qui se dessine pendant qu'on en parle, glisse vers la suivante, puis **recule à la fin**
sur le tableau entier, qui reste 1 à 2 s.

**Composer la fresque** : 4 à 6 parties, une par idée, chacune une image séparée (ou un objet en
code) posée avec `"place": [x, y, largeur]` en fractions du tableau. Penser la vue d'ensemble comme
une page d'affiche : un parcours de lecture clair (haut → bas, ou en zigzag), du blanc entre les
parties, des flèches (`"type": "fleche"`) qui relient les étapes. Garder tout entre y 0,08 et 0,9.

Repères de placement (tableau vertical) :
- 4 parties : en zigzag `[0.3, 0.17]`, `[0.7, 0.38]`, `[0.3, 0.6]`, `[0.7, 0.82]`, largeur 0,42 ;
- 5 parties : la 5ᵉ au centre en bas `[0.5, 0.84]`, ou la plus importante en grand au milieu ;
- légendes : `"pres": {"id": "…", "cote": "dessous"}` ; dans une fresque, `taille` et `largeur` des
  textes sont en px du grand tableau (2 160 de large) : 120 à 150 pour une légende.

Réglages : `"marge"` par élément (1,4 ; plus grand = moins de zoom, la main paraît plus lente),
`"recul": false` pour garder le dernier zoom, `"camera": "fixe"` pour tout montrer sans bouger.

Variante : une seule grande image découpée en zones (`"zones": [{"rect": [x0, y0, x1, y1], "mot"}]`).
À éviter si l'image est riche : la main ne suit plus.

## Les autres affichages (seulement si la personne en demande un)

- `successifs` : un dessin par idée, la page s'efface avant la suivante (`"transition"` : `efface`,
  `fondu`, `coupe`, `glisse`). Pour « un dessin à la fois ».
- `tableau` : une seule page qui se remplit de cases (`"colonnes"`, légendes, `"fleches": true`).
  Pour « les étapes côte à côte », « un schéma ».
- `melange` : pages avec des `photo` (cadre tracé, puis la photo se révèle) et plus de texte. Pour
  « avec mes vraies photos ».

## Commun

- Sous-titres mot à mot en bas (`"sous_titres": true` par défaut avec une voix) : le mot dit passe en
  couleur `accent`.
- Placer à la main : `"place"` ; sinon la mise en page est automatique.
