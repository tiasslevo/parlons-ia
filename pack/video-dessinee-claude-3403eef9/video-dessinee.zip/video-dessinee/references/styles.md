# Le style de dessin

## Le style par défaut : `flat` (contour épais)

C'est le style du skill, celui à utiliser sauf demande explicite d'un autre :
- **contour noir épais et régulier**, le même partout : la main le suit vraiment ;
- **formes rondes**, façon dessin animé moderne, visages simples et souriants ;
- **aplats de couleurs franches** à l'intérieur des contours, **sans ombre**, sans dégradé, sans hachure ;
- **fond blanc**.

Le moteur trace d'abord le contour noir (la main suit la ligne), puis remplit les aplats zone par
zone, main en va-et-vient (`"couleur": "remplit"`). Main fournie : marqueur noir.

**Rester simple** : 1 ou 2 personnages et 1 à 3 objets par image, peu de détails. Une scène riche
se fait avec plusieurs images posées sur la fresque, pas avec une image chargée. Le trait doit être
net et bien fait plutôt que nombreux.

Couleurs par défaut (modifiables dans `"couleurs"`, à reprendre du kit) : encre `#111111`, accent
`#F2643A` (titres, mot clé), second `#1FA89E`, troisieme `#FFC93C`, vert `#5DBB63`.

## Les autres styles (seulement si la personne en demande un)

Ne pas les proposer d'office. Si la personne demande autre chose, prendre le plus proche :

| Demande | Style |
|---|---|
| « au feutre fin, hachures, carnet » | `feutre` (images générées ; rester peu détaillé, découper en zones) |
| « crayon, croquis rapide » | `croquis` (trait gris doublé, papier clair) |
| « craie, tableau d'école » | `craie` (tableau vert, noir ou bleu, grain de craie) |
| « sur un tableau noir » mais le dessin flat | `flat` + `"tableau": "noir"` (trait clair, main craie) |

Pas d'aquarelle : le trait doit pouvoir se suivre. Les anciens noms `trait-couleur` et `stickman`
donnent `flat`.

## La vitesse de la main

Plus une image a de traits, plus la main va vite. Repère : un dessin flat simple se trace en 2 à 3 s.
`--verifier` mesure la vitesse de la main à l'écran : ⚠ au-delà de 2 000 px/s, ✗ au-delà de 3 200.
Remèdes : une image plus simple, plus petite sur la fresque, plus de mots sur la phrase, `"lenteur":
1.3` sur l'élément, `"couleur": "fondu"` (la couleur arrive sans la main, tout le temps va au trait).

## Ce qui se fait en code

Flèches, textes manuscrits, et une trentaine d'objets simples (`python scripts/croquis.py --liste`) :
soleil, nuage, pluie, rivière, maison, boutique, téléphone, billet, pièce, ampoule, graphique, pot,
graine, pousse… Ils prennent le contour épais et les aplats du style. Utiles pour compléter les
images générées ; l'ordre du tracé y est exactement celui des traits.
