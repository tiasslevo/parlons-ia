# La voix et la timeline mot à mot

## Trois choix

1. **Voix IA ElevenLabs** (connecteur relié à Claude) : `creative_list_voices` avec la langue `fr` et
   la description de la personne (« voix d'homme africain posée », « voix féminine chaleureuse ») ;
   dire quelle voix est choisie. `creative_generate_speech` avec le texte validé, modèle `eleven_v4`,
   **`generations_count: 1`** (sinon le coût est multiplié par 4). Ne jamais relancer pour réessayer
   sans l'accord de la personne. Attendre la fin avec `creative_get_flow_run_status`, télécharger le
   MP3 (`curl -o voix.mp3 "<url>"`), puis l'écouter par la mesure : durée cohérente avec le texte.
2. **Sa voix** : elle enregistre le script sur son téléphone, d'une traite, et envoie le fichier.
   Couper les silences de début avec `"voix_a"` si besoin.
3. **Sans voix** : les titres écrits portent le message. Ne pas mettre de clé `"voix"`.

Une voix IA se signale comme « contenu généré par IA » à la publication.

## La timeline mot à mot

```bash
python scripts/mots.py --texte script.txt --voix voix.mp3          # → mots.json
```
- Avec **Whisper** (paquet `faster-whisper`, essayé tout seul ; ou `--whisper transcription.json`
  si la transcription existe déjà), chaque mot du script reçoit son temps réel. Les mots mal entendus
  (un nom propre) gardent l'orthographe du script.
- Sans Whisper : les mots sont répartis sur les moments où la voix parle, au prorata des syllabes
  (0,2 à 0,4 s près). Suffisant, car le dessin démarre 0,15 s avant son mot.
- Le moteur crée `mots.json` tout seul s'il manque, et le refait si le texte change. Le texte de la
  voix = les `"texte"` des scènes mis bout à bout : il doit être **exactement** ce qui est dit.
- `"voix_a"` (0,3 s par défaut) : la voix commence un peu après le début, pour que la main arrive.
  Le monter (0,8 s) pour écrire un titre avant la première phrase.

## Le son final

`moteur.py` assemble `sortie/video.mp4` : la voix seule, à -14 LUFS. **Pas de bruit de dessin par
défaut** (il agace vite). Seulement si la personne le demande : `--son-trait` (ou `"son_trait": true`)
ajoute un bruit de feutre ou de craie très bas, calculé sur les gestes de la main. Musique en plus :
`python scripts/son.py sortie/muette.mp4 --voix voix.mp3 --voix-a 0.3 --musique fond.mp3` (elle
baisse sous la voix).
