# Le script et le plan des dessins

## Le texte de la voix

- Une idée par scène, une à trois phrases courtes. Ton parlé, mots simples, nombres en lettres.
- Débit : environ 2,5 mots par seconde. 15 s ≈ 35 mots, 45 s ≈ 110 mots, 1 min ≈ 150 mots.
- Une accroche dans la première phrase (une question, un fait étonnant, le problème), une fin qui
  ferme l'idée ou appelle à l'action.
- Chaque scène contient le **mot qui déclenche** son dessin : le nom de la chose dessinée, dit tôt
  dans la phrase. « Le baobab donne un fruit » : le baobab se dessine sur « baobab ».
- Sans voix : le texte de chaque scène devient le titre écrit à l'écran (5 à 7 mots). Les dessins
  s'enchaînent à leur rythme, avec une pause de lecture entre les scènes (`"pause"`).

## Le plan, à envoyer avec le script

Un tableau, une ligne par scène :

| Scène | Ce que dit la voix | Ce qui se dessine (et sur quel mot) | Écrit à la main | Image ou code |
|---|---|---|---|---|
| 1 | Le pain de singe, c'est le fruit du baobab. | le baobab, sur « pain » | — | zone 1 de la fresque |
| 2 | Sous sa coque dure… vitamine C. | le fruit ouvert, sur « coque » | « Vitamine C ! » sur « vitamine » | zone 2 |

Annonce aussi : le style, l'affichage, la durée visée, la voix, et ce qui sera généré (le nombre
d'images). Attends le « oui » avant de générer quoi que ce soit.

## Le rythme

- Un dessin dure ce qu'il faut pour que la main ne coure pas : 1,5 à 3 s pour un dessin simple. Si
  une phrase est trop courte pour son dessin, allonger la phrase, simplifier le dessin, ou fusionner
  deux idées.
- Un texte à la main : 2 à 5 mots. Il prend environ 0,05 s par lettre.
- Tenir l'image finale au moins 1 s (`"fin"`, 1,5 s par défaut). La fresque ajoute son recul.
- Un dessin à la fois : la main ne dessine jamais deux choses en même temps. Si deux dessins tombent
  sur la même phrase, ils se suivent ; le second se cale sur un mot plus loin.
