# Corriger sur les retours

Changer seulement ce qui est demandé. Refaire `--verifier`, montrer l'image fixe concernée
(`--image T`), puis refaire la vidéo.

| Ce que la personne dit | Ce que tu changes |
|---|---|
| « Le dessin arrive avant / après que je le dise » | `"mot"` de l'élément (un mot plus tôt ou plus tard), ou `"a"` en secondes |
| « La main va trop vite » | `"lenteur": 1.4` sur l'élément, `"vitesse": 0.8` globale, dessin plus simple, ou une phrase plus longue |
| « C'est trop lent, ça traîne » | `"vitesse": 1.3`, phrases plus courtes, `"fin"` plus court |
| « La main cache ce qu'elle dessine » | `"main_taille"` plus petite (500), ou une autre main |
| « Je ne vois pas le trait se faire » | vérifier que l'image a des traits foncés ; sinon `"couleur": "fondu"` et un prompt avec contours noirs |
| « La couleur arrive mal » | `"couleur"` : `remplit` (avec la main), `fondu`, ou `aucune` |
| « Le texte est trop long » | garder 2 à 5 mots ; la phrase reste dans la voix |
| « Trop de choses à l'écran » | affichage `successifs`, ou une nouvelle scène |
| « La caméra bouge trop » (fresque) | `"marge": 1.8` sur les zones (moins de zoom), ou `"camera": "fixe"` |
| « Je ne veux pas du recul final » | `"recul": false` |
| « Les sous-titres gênent » | `"sous_titres": false` |
| « Ce dessin ne ressemble pas aux autres » | nouveau prompt avec le bloc de style mot pour mot et l'image validée en référence |
| « Je veux un autre style / un autre affichage » | seulement à sa demande : `"style"` (feutre, croquis, craie) ou `"affichage"` (successifs, tableau, melange), puis `--verifier` |
| « Trop de choses dans ce dessin » | une image plus simple (1 ou 2 personnages, 1 à 3 objets), ou la scène partagée en deux parties |
| « J'aimerais entendre le feutre » | rendre avec `--son-trait` (très bas ; désactivé par défaut) |

Après une correction qui a plu (ou déplu), l'écrire dans `style.md` (« Ce qui a plu ») et refaire le kit.
