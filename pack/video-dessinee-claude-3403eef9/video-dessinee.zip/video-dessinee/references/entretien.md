# La vision de la personne

But : savoir ce que la personne veut dire avant de proposer quoi que ce soit. Un message de questions,
une relance au plus. Si son premier message répond déjà à certaines, ne pose que le reste.

Par défaut, la vidéo est en **style flat** (contour noir épais, aplats francs, fond blanc) et en
**fresque** (un grand dessin qui se construit, zoom sur chaque partie pendant qu'on en parle, recul sur
la vue d'ensemble à la fin). Ne pas faire choisir parmi les autres styles et affichages : les utiliser
seulement si la personne en demande un explicitement (styles.md, affichages.md).

## Le message de départ (numéroté)

1. **Ta vidéo, avec tes mots** : de quoi elle parle, ce qu'on doit retenir à la fin, pour qui.
2. **Le ton** : explicatif, drôle, histoire racontée, sérieux.
3. **Les personnages ou objets** qui doivent apparaître (toi, ton produit, un client…), s'il y en a.
4. **La durée** : libre (15 s, 45 s, 2 min…). Par défaut 30 à 45 s.
5. **La voix** : voix IA (ElevenLabs relié à Claude, décris la voix), ta voix enregistrée, ou sans voix.
6. **Une référence** si tu en as une : une vidéo, des captures, un lien.

Dire en une ligne le rendu prévu : « Dessin à contour noir épais et couleurs franches, sur un grand
tableau que la caméra parcourt partie par partie, puis montre en entier. » La personne peut demander
autre chose à ce moment.

## Une vidéo de référence

Vidéo : `ffmpeg -i ref.mp4 -vf fps=2 ref/%03d.jpg`, regarde les images. Sinon les captures. Note, sans
t'arrêter aux détails (couleurs exactes, logos) :
- quand un dessin apparaît par rapport à la voix, et à quelle vitesse il se trace ;
- ce qui est dessiné, écrit ou montré, et comment la page est occupée ;
- le rythme : durée des scènes, pauses, mouvements de caméra ;
- le ton de la voix et la structure (accroche, explication, fin).
Dis en 3 lignes ce que tu reprends (une façon de faire), puis traduis-le en réglages du moteur
(`vitesse`, `camera`, `marge`, et le style ou l'affichage seulement si la référence l'impose). On ne
copie pas les dessins d'une autre chaîne.

## Ensuite

Reformule la vision en 3 lignes (sujet, parties de la fresque, durée et voix) et passe au script.
Note tout de suite les choix dans `mon-style/style.md` : ce sera la fiche du kit.
