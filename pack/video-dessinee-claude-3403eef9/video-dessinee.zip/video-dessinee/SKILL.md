---
name: video-dessinee
description: Vidéos dessinées à la main (une main dessine chaque idée au moment où la voix la dit) pour TikTok, Reels, YouTube. Par défaut, dessin flat à contour noir épais et aplats francs, en fresque (zoom sur chaque partie, recul final sur la vue d'ensemble). Vision de la personne, script, prompts d'images, voix, rendu MP4 en code, kit de style.
---

# Vidéo dessinée

Une main dessine chaque idée au moment où elle est dite. Le trait se trace, la couleur se remplit
ensuite si le style le demande, et tout est calé mot à mot sur la voix. Le rendu est fait en code
(`scripts/moteur.py`) : tu écris un `video.json`, le moteur fait le reste.

**Le rendu par défaut**, à garder sauf demande explicite d'autre chose :
1. **le style flat** : contour noir épais et régulier, formes rondes façon dessin animé, aplats de
   couleurs franches, sans ombre, fond blanc ([references/styles.md](references/styles.md)) ;
2. **la fresque** : un grand dessin qui se construit, la caméra zoome sur chaque partie pendant qu'on
   en parle, puis recule sur la vue d'ensemble ([references/affichages.md](references/affichages.md)).
Les autres styles (feutre, croquis, craie) et affichages (successifs, tableau, mélange) existent, mais
ne se proposent pas d'office. Les dessins restent **simples** : peu de personnages et d'éléments par
partie, un contour net que la main suit vraiment.

Réponds en français simple, sans jargon. Lis les fichiers de `references/` quand l'étape en a besoin.

## 1. Au début de chaque conversation

| Mode | Comment le reconnaître | Rendu |
|---|---|---|
| **App** | app Claude avec exécution de code, fichiers perdus en fin de conversation | `scripts/` dans le bac à sable |
| **Studio** | Claude Code sur l'ordinateur de la personne | `scripts/` en local, dossier de style gardé |
| **Sans code** | pas d'exécution de code | script, plan des dessins et prompts ; montage par la personne |

```bash
python3 -c "import PIL, numpy; print('ok')"
ffmpeg -version | head -1 || pip install imageio-ffmpeg
```

**Kit de style ?** Cherche `style.md` dans les fichiers du Projet, un `kit-*.zip` joint ou un dossier
de style (Studio). S'il existe : `python scripts/kit.py lire <kit> --vers mon-style`, relis « Ce qui a
plu » et passe à l'étape 3 sans reposer les questions. Détail : [references/kit.md](references/kit.md).

## 2. La vision d'abord

[references/entretien.md](references/entretien.md). Demande d'abord à la personne de décrire sa vidéo
avec ses mots : sujet, ce qu'on doit retenir, ton, personnages, durée, voix. **Sa vision passe avant
tout.** Annonce le rendu par défaut en une ligne ; elle peut demander autre chose. Une vidéo de
référence : analyse-la (même fichier).

## 3. Le script et le plan des dessins

[references/script.md](references/script.md). Envoie, et **attends la validation** avant toute dépense :
1. le texte de la voix, découpé en scènes (une idée par scène) ;
2. le plan de la fresque : pour chaque scène, la partie qui se dessine, **sur quel mot** elle commence,
   où elle se place sur le grand tableau, les textes écrits à la main (2 à 5 mots), les flèches ;
3. les images à générer, avec les prompts prêts à coller : [references/images.md](references/images.md).
   Une image par partie, un sujet par image, fond blanc. Ce qui se fait en code n'est pas généré :
   flèches, titres, objets simples (`python scripts/croquis.py --liste`). Une main est fournie
   (`assets/mains/` : marqueur par défaut, feutre, craie).

## 4. La voix

[references/voix.md](references/voix.md) : ElevenLabs (une seule génération, `generations_count` à 1),
voix enregistrée de la personne, ou pas de voix. Puis la timeline mot à mot :
`python scripts/mots.py --texte script.txt --voix voix.mp3` (Whisper si disponible, sinon estimée).

## 5. Le rendu

1. Écris `video.json` : [references/bibliotheque.md](references/bibliotheque.md). Pars d'un exemple de
   `assets/exemples/` : `fresque-flat.json` (le rendu par défaut). Range les images reçues dans `images/` ; une image sur fond blanc s'utilise
   telle quelle (les marges sont rognées, le trait est extrait en code).
2. `python scripts/moteur.py video.json --verifier` : corrige **chaque ligne ✗** (mot introuvable, main
   trop rapide, texte trop petit ou dans une zone cachée par TikTok, fin trop courte) ; les ⚠ se
   discutent. Regarde `controle/planche.jpg`.
3. Montre la planche, ou 2-3 images fixes (`--image 4.2`). **Pas de vidéo avant l'accord.**
4. `python scripts/moteur.py video.json --essai` (estime le temps), puis
   `python scripts/moteur.py video.json` → `sortie/video.mp4` (avec la voix, sans bruit de dessin).
   Dans l'app, au-delà de 30 Mo : `--qualite legere`.
5. Avant de livrer : extrais 6 à 10 images de la vidéo finale (`ffmpeg -ss T -i sortie/video.mp4
   -frames:v 1 f.png`) et regarde-les : le trait qui se trace, la main sur le trait, le texte lisible,
   la fin. Livre le MP4 en pièce jointe avec 3 lignes (durée, style, affichage) et une légende courte.

Corrections sur retour : [references/corrections.md](references/corrections.md). Ne change que ce qui
est demandé ; montre l'image fixe concernée avant de refaire la vidéo.

## 6. Première vidéo seulement : le kit de style

Remplis `mon-style/style.md` (modèle [assets/fiche-style.md](assets/fiche-style.md)) : style,
affichage, couleurs, main, voix, prompt d'image validé, ce qui a plu ou non, sujets faits. Range les
personnages récurrents dans `dessins/`. `python scripts/kit.py creer mon-style` → `kit-<nom>.zip`, à
garder dans un Projet Claude ([references/kit.md](references/kit.md)).

## Règles qui ne bougent pas

- **Le dessin suit la voix** : chaque dessin commence sur le mot qui l'annonce (0,15 s avant), jamais
  longtemps avant ni après. Rien de figé plus de 2,5 s pendant que la voix parle.
- **La main ne court pas** : un dessin flat simple se trace en 2 à 3 s. Si `--verifier`
  dit « trop rapide » : simplifier le dessin, le couper en zones, ou lui donner plus de mots.
- **Une idée par dessin**, texte écrit à la main seulement quand il aide (2 à 5 mots), jamais la phrase.
- **Fonds clairs par défaut** (blanc, papier). La craie a son tableau vert, noir ou bleu, c'est assumé.
- **Zones TikTok/Reels libres** pour le texte : rien en haut (y < 200), en bas (y > 1500), ni à droite
  dans la moitié basse. `--verifier` les contrôle.
- **Rien d'inventé** : chiffres, noms et dates viennent de la personne ou d'une source qu'elle valide.
- **Validation avant dépense** : pas d'images générées ni de voix avant le script et le plan validés.
- **Droits** : polices OFL fournies, mains fournies (générées pour ce skill), bruit du trait (option,
  désactivé par défaut) fait en code. Pas de personnage, logo ou dessin d'une autre chaîne.
- **Honnêteté** : ne dis jamais qu'une vidéo est prête, qu'une voix est générée ou qu'un fichier est
  envoyé sans l'avoir vérifié.
