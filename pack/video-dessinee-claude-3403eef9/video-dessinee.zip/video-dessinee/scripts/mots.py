"""Le moment où chaque mot est dit : la timeline sur laquelle les dessins se calent.

usage :
  python mots.py --texte script.txt --voix voix.mp3 [--sortie mots.json]      # Whisper si possible, sinon estimé
  python mots.py --texte script.txt --voix voix.mp3 --whisper transcription.json  # transcription déjà faite
  python mots.py --texte script.txt --sans-voix [--debit 2.4]                  # vidéo muette : temps de lecture

--texte : un fichier texte ou directement la phrase entre guillemets.
Avec Whisper (paquet faster-whisper, ou un JSON avec "segments"/"words"), les mots du script sont
alignés sur ceux entendus : le texte affiché reste celui du script, même si Whisper entend mal un nom.
Sans Whisper, les mots sont répartis sur les zones où la voix parle, au prorata des syllabes : précis
à 0,2-0,4 s près, ce qui suffit pour un dessin qui commence un peu avant le mot.
"""
import argparse
import difflib
import json
import os
import re
import subprocess
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import ffmpeg_exe  # noqa: E402


def norm(m):
    m = unicodedata.normalize("NFKD", m.lower()).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]", "", m)


def decouper(texte):
    return [m for m in re.split(r"\s+", texte.strip()) if norm(m) or m.strip() in ("?", "!")] if texte.strip() else []


def syllabes(m):
    ch = re.sub(r"\D", "", m)
    if ch:
        return 1.6 * len(ch)
    v = re.findall(r"[aeiouyàâäéèêëîïôöùûü]+", m.lower())
    k = len(v)
    if k > 1 and re.search(r"[^aeiouy]e$|es$|ent$", m.lower()):
        k -= 1
    return max(1, k)


def duree_audio(chemin):
    err = subprocess.run([ffmpeg_exe(), "-i", chemin], capture_output=True, text=True).stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", err)
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0.0


def zones_parole(chemin, seuil=-38, trou=0.18):
    out = subprocess.run([ffmpeg_exe(), "-hide_banner", "-i", chemin, "-af", f"silencedetect=noise={seuil}dB:d={trou}", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    debuts = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", out)]
    fins = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", out)]
    total = duree_audio(chemin)
    zones, t = [], 0.0
    for a, b in zip(debuts, fins + [None] * (len(debuts) - len(fins))):
        if a - t > 0.08:
            zones.append((max(0.0, t), a))
        t = b if b is not None else total
    if total - t > 0.08:
        zones.append((t, total))
    return zones or [(0.0, total)]


def estimer(mots, voix=None, debit=2.4, pause=0.35):
    """Sans transcription : répartit les mots sur la parole (voix) ou sur un débit de lecture."""
    poids = [syllabes(m) + (1.2 if re.search(r"[.!?:]$", m) else 0.4 if m.endswith(",") else 0) for m in mots]
    if not voix:
        t, res = 0.3, []
        par_syll = 1 / (debit * 1.55)
        for m, p in zip(mots, poids):
            d = syllabes(m) * par_syll
            res.append({"mot": m, "debut": round(t, 3), "fin": round(t + d, 3)})
            t += d + (pause if re.search(r"[.!?:]$", m) else 0.12 if m.endswith(",") else 0.03)
        return res
    zones = zones_parole(voix)
    parole = sum(b - a for a, b in zones)
    total_p = sum(poids)

    def a_temps(x):  # x : temps de parole cumulé → temps réel
        for a, b in zones:
            if x <= b - a:
                return a + x
            x -= b - a
        return zones[-1][1]

    res, cum = [], 0.0
    for m, p, s in zip(mots, poids, [syllabes(m) for m in mots]):
        d0 = cum / total_p * parole
        d1 = (cum + s) / total_p * parole
        res.append({"mot": m, "debut": round(a_temps(d0), 3), "fin": round(a_temps(d1), 3)})
        cum += p
    return res


def mots_whisper(donnees):
    """Liste (mot, début, fin) depuis un JSON Whisper ; recolle « c » + « 'est »."""
    bruts = []
    for s in donnees.get("segments", []):
        bruts += s.get("words") or []
    bruts = bruts or donnees.get("words", [])
    res = []
    for w in bruts:
        txt = w.get("word", w.get("text", ""))
        if res and txt and not txt.startswith(" "):
            res[-1] = (res[-1][0] + txt, res[-1][1], w.get("end", res[-1][2]))
        else:
            res.append((txt.strip(), w.get("start", 0.0), w.get("end", 0.0)))
    return res


def transcrire(voix):
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return None
    try:
        modele = WhisperModel(os.environ.get("WHISPER_MODELE", "small"), device="auto", compute_type="int8")
        segs, _ = modele.transcribe(voix, language="fr", word_timestamps=True)
        return {"segments": [{"words": [{"word": w.word, "start": w.start, "end": w.end} for w in (s.words or [])]} for s in segs]}
    except Exception as e:  # modèle non téléchargeable, etc.
        print(f"  Whisper indisponible ({e}) : temps estimés.")
        return None


def aligner(mots, entendus):
    """Donne aux mots du script les temps des mots entendus (les non-reconnus sont interpolés)."""
    a = [norm(m) for m in mots]
    b = [norm(w[0]) for w in entendus]
    t = [None] * len(mots)
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            for k in range(i2 - i1):
                t[i1 + k] = (entendus[j1 + k][1], entendus[j1 + k][2])
        elif op == "replace" and j2 > j1:
            d0, d1 = entendus[j1][1], entendus[j2 - 1][2]
            n = i2 - i1
            for k in range(n):
                t[i1 + k] = (d0 + (d1 - d0) * k / n, d0 + (d1 - d0) * (k + 1) / n)
    # interpolation des trous
    connus = [i for i, v in enumerate(t) if v]
    if not connus:
        return None
    for i, v in enumerate(t):
        if v:
            continue
        av = max([k for k in connus if k < i], default=None)
        ap = min([k for k in connus if k > i], default=None)
        d0 = t[av][1] if av is not None else max(0.0, t[ap][0] - 0.3)
        d1 = t[ap][0] if ap is not None else d0 + 0.3
        t[i] = (d0, max(d0 + 0.05, d1))
    return [{"mot": m, "debut": round(float(x[0]), 3), "fin": round(float(x[1]), 3)} for m, x in zip(mots, t)]


def timeline(texte, voix=None, whisper=None, sans_whisper=False, debit=2.4):
    mots = decouper(texte)
    source = "estimé"
    res = None
    if voix:
        donnees = None
        if whisper:
            donnees = json.load(open(whisper, encoding="utf-8"))
        elif not sans_whisper:
            donnees = transcrire(voix)
        if donnees:
            res = aligner(mots, mots_whisper(donnees))
            if res:
                source = "whisper"
    if res is None:
        res = estimer(mots, voix, debit)
    duree = duree_audio(voix) if voix else (res[-1]["fin"] + 0.3 if res else 0.0)
    return {"source": source, "duree": round(duree, 3), "mots": res}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--texte", required=True)
    ap.add_argument("--voix")
    ap.add_argument("--whisper")
    ap.add_argument("--sans-voix", action="store_true")
    ap.add_argument("--sans-whisper", action="store_true")
    ap.add_argument("--debit", type=float, default=2.4, help="mots par seconde sans voix")
    ap.add_argument("--sortie", default="mots.json")
    a = ap.parse_args()
    texte = open(a.texte, encoding="utf-8").read() if os.path.exists(a.texte) else a.texte
    tl = timeline(texte, None if a.sans_voix else a.voix, a.whisper, a.sans_whisper, a.debit)
    json.dump(tl, open(a.sortie, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{a.sortie} : {len(tl['mots'])} mots, {tl['duree']:.2f} s, temps {tl['source']}")
    for m in tl["mots"][:6]:
        print(f"  {m['debut']:5.2f} {m['mot']}")


if __name__ == "__main__":
    main()
