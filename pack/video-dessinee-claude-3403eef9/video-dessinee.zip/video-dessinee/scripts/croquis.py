"""Petits dessins faits en code, trait par trait (bonhommes, objets, flèches).

Pour compléter les images générées (flèches, objets simples), ou pour les styles craie et croquis.
Chaque sujet renvoie des traits dans l'ordre où on les dessinerait et, si besoin, des zones de couleur.
Les coordonnées sont dans une boîte de largeur 1 (hauteur = "ar") ; moteur.py les met à l'échelle.

  python croquis.py --liste            les sujets et leurs options
  python croquis.py --planche f.jpg    tous les sujets sur une planche

Couleurs des zones : "accent", "second", "troisieme", "vert", "encre" (prises dans les couleurs de la vidéo).
"""
import argparse
import math

import numpy as np

SUJETS = {}


def sujet(nom, aide):
    def deco(f):
        SUJETS[nom] = (f, aide)
        return f
    return deco


# ---------------------------------------------------------------- primitives
def arc(cx, cy, r, a0=0, a1=360, n=None, ry=None):
    ry = r if ry is None else ry
    n = n or max(8, int(abs(a1 - a0) / 8))
    return [(cx + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)), cy + ry * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]


def courbe(*pts, n=24):
    """Bézier quadratique ou cubique passant par les points de contrôle."""
    p = np.array(pts, float)
    t = np.linspace(0, 1, n)[:, None]
    if len(p) == 3:
        b = (1 - t) ** 2 * p[0] + 2 * (1 - t) * t * p[1] + t ** 2 * p[2]
    elif len(p) == 4:
        b = (1 - t) ** 3 * p[0] + 3 * (1 - t) ** 2 * t * p[1] + 3 * (1 - t) * t ** 2 * p[2] + t ** 3 * p[3]
    else:
        return [tuple(x) for x in p]
    return [tuple(x) for x in b]


def rect(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]


class D:
    """Accumulateur de traits et de zones de couleur."""

    def __init__(self, ar):
        self.ar = ar
        self.traits, self.zones = [], []

    def t(self, pts, ep=1.0, coul="encre"):
        self.traits.append({"pts": list(pts), "ep": ep, "coul": coul})
        return self

    def z(self, poly, coul="accent"):
        self.zones.append({"poly": list(poly), "coul": coul})
        return self


# ---------------------------------------------------------------- personnages
POSES = ("debout", "content", "pointe", "reflechit", "triste", "marche", "porte", "salue")


@sujet("personnage", "bonhomme bâton ; pose : " + ", ".join(POSES) + " ; option chapeau, sac")
def personnage(pose="debout", chapeau=False, sac=False, **_):
    d = D(1.7)
    cx, tete_y, r = 0.5, 0.25, 0.15
    d.t(arc(cx, tete_y, r, -90, 270), 1.0)
    cou, hanche = tete_y + r, 1.05
    # visage
    if pose == "triste":
        d.t(arc(cx, tete_y + 0.09, 0.055, 200, 340), 0.7)
    elif pose == "reflechit":
        d.t([(cx - 0.04, tete_y + 0.06), (cx + 0.05, tete_y + 0.06)], 0.7)
    else:
        d.t(arc(cx, tete_y + 0.01, 0.07, 20, 160), 0.7)
    d.t([(cx - 0.05, tete_y - 0.04), (cx - 0.05, tete_y - 0.02)], 0.9)
    d.t([(cx + 0.05, tete_y - 0.04), (cx + 0.05, tete_y - 0.02)], 0.9)
    if chapeau:
        d.t([(cx - 0.2, tete_y - 0.1), (cx + 0.2, tete_y - 0.1)], 1.0)
        d.t(rect(cx - 0.11, tete_y - 0.27, cx + 0.11, tete_y - 0.1), 1.0)
        d.z(rect(cx - 0.11, tete_y - 0.27, cx + 0.11, tete_y - 0.1), "accent")
    d.t([(cx, cou), (cx, hanche)], 1.0)
    epaule = cou + 0.12
    bras = {
        "debout": [((cx - 0.22, epaule + 0.3),), ((cx + 0.22, epaule + 0.3),)],
        "content": [((cx - 0.3, epaule - 0.25),), ((cx + 0.3, epaule - 0.25),)],
        "pointe": [((cx - 0.2, epaule + 0.3),), ((cx + 0.45, epaule - 0.05),)],
        "reflechit": [((cx - 0.2, epaule + 0.3),), ((cx + 0.18, epaule + 0.12), (cx + 0.06, tete_y + 0.12))],
        "triste": [((cx - 0.12, epaule + 0.34),), ((cx + 0.12, epaule + 0.34),)],
        "marche": [((cx - 0.25, epaule + 0.22),), ((cx + 0.25, epaule + 0.2),)],
        "porte": [((cx - 0.3, epaule + 0.08),), ((cx + 0.3, epaule + 0.08),)],
        "salue": [((cx - 0.2, epaule + 0.3),), ((cx + 0.26, epaule - 0.05), (cx + 0.3, epaule - 0.3))],
    }[pose if pose in POSES else "debout"]
    for b in bras:
        d.t([(cx, epaule)] + list(b), 1.0)
    jambes = {"marche": [(cx - 0.24, 1.6), (cx + 0.24, 1.6)], "content": [(cx - 0.2, 1.6), (cx + 0.2, 1.6)]}.get(pose, [(cx - 0.15, 1.62), (cx + 0.15, 1.62)])
    for j in jambes:
        d.t([(cx, hanche), j], 1.0)
    if sac:
        x0 = cx + 0.24 if pose != "porte" else cx - 0.12
        y0 = epaule + 0.3 if pose != "porte" else epaule + 0.08
        poly = rect(x0, y0, x0 + 0.24, y0 + 0.26)
        d.t(poly, 0.9)
        d.t(arc(x0 + 0.12, y0, 0.07, 180, 360), 0.8)
        d.z(poly, "second")
    return d


@sujet("foule", "trois bonshommes côte à côte (clients, équipe)")
def foule(**_):
    d = D(0.95)
    for k, (dx, s, pose) in enumerate([(0.0, 0.5, "debout"), (0.33, 0.56, "content"), (0.66, 0.5, "salue")]):
        p = personnage(pose)
        for t in p.traits:
            d.t([(dx + x * 0.34, 0.08 + y * s) for x, y in t["pts"]], t["ep"] * 0.8, t["coul"])
    return d


# ---------------------------------------------------------------- lieux et objets
@sujet("boutique", "petit commerce avec auvent rayé")
def boutique(**_):
    d = D(0.95)
    d.t(rect(0.1, 0.38, 0.9, 0.9), 1.0)
    aw = [(0.04, 0.38), (0.12, 0.16), (0.88, 0.16), (0.96, 0.38), (0.04, 0.38)]
    d.t(aw, 1.0)
    for i in range(1, 4):
        x = 0.04 + i * 0.92 / 4
        d.t([(x, 0.38), (0.12 + (x - 0.04) * 0.76 / 0.92, 0.16)], 0.7)
    for i in range(0, 4, 2):
        x0, x1 = 0.04 + i * 0.92 / 4, 0.04 + (i + 1) * 0.92 / 4
        d.z([(x0, 0.38), (0.12 + (x0 - 0.04) * 0.826, 0.16), (0.12 + (x1 - 0.04) * 0.826, 0.16), (x1, 0.38)], "accent")
    d.t(rect(0.18, 0.5, 0.46, 0.9), 0.9)
    d.t(rect(0.56, 0.5, 0.82, 0.72), 0.9)
    d.z(rect(0.56, 0.5, 0.82, 0.72), "second")
    d.t([(0.0, 0.9), (1.0, 0.9)], 1.0)
    return d


@sujet("maison", "maison simple, toit")
def maison(**_):
    d = D(0.9)
    d.t(rect(0.18, 0.42, 0.82, 0.86), 1.0)
    d.t([(0.08, 0.46), (0.5, 0.1), (0.92, 0.46)], 1.0)
    d.z([(0.08, 0.46), (0.5, 0.1), (0.92, 0.46)], "accent")
    d.t(rect(0.42, 0.6, 0.58, 0.86), 0.9)
    d.t(rect(0.24, 0.5, 0.36, 0.62), 0.8)
    d.z(rect(0.24, 0.5, 0.36, 0.62), "second")
    return d


@sujet("soleil", "soleil et rayons")
def soleil(**_):
    d = D(1.0)
    d.t(arc(0.5, 0.5, 0.2, -90, 270), 1.0)
    d.z(arc(0.5, 0.5, 0.2), "accent")
    for k in range(10):
        a = math.radians(k * 36)
        d.t([(0.5 + 0.28 * math.cos(a), 0.5 + 0.28 * math.sin(a)), (0.5 + 0.42 * math.cos(a), 0.5 + 0.42 * math.sin(a))], 0.9)
    return d


@sujet("piece", "pièce de monnaie")
def piece(**_):
    d = D(1.0)
    d.t(arc(0.5, 0.5, 0.4, -90, 270), 1.0)
    d.z(arc(0.5, 0.5, 0.4), "accent")
    d.t(arc(0.5, 0.5, 0.3, -90, 270), 0.7)
    d.t([(0.5, 0.32), (0.5, 0.68)], 0.9)
    return d


@sujet("billet", "billet de banque")
def billet(**_):
    d = D(0.55)
    d.t(rect(0.05, 0.05, 0.95, 0.5), 1.0)
    d.z(rect(0.05, 0.05, 0.95, 0.5), "second")
    d.t(arc(0.5, 0.275, 0.11, -90, 270), 0.8)
    d.t([(0.14, 0.14), (0.24, 0.14)], 0.7)
    d.t([(0.76, 0.41), (0.86, 0.41)], 0.7)
    return d


@sujet("telephone", "téléphone portable")
def telephone(**_):
    d = D(1.6)
    d.t(rect(0.14, 0.08, 0.86, 1.52), 1.0)
    d.t(rect(0.22, 0.22, 0.78, 1.3), 0.8)
    d.z(rect(0.22, 0.22, 0.78, 1.3), "second")
    d.t(arc(0.5, 1.41, 0.04, -90, 270), 0.8)
    return d


@sujet("fleche", "flèche ; sens : droite, gauche, bas, haut")
def fleche(sens="droite", **_):
    d = D(0.5)
    pts = courbe((0.05, 0.3), (0.5, 0.12), (0.92, 0.27))
    d.t(pts, 1.0)
    d.t([(0.78, 0.14), (0.93, 0.27), (0.76, 0.38)], 1.0)
    rot = {"droite": None, "gauche": "g", "bas": "b", "haut": "h"}.get(sens)
    if rot:
        for t in d.traits:
            if rot == "g":
                t["pts"] = [(1 - x, y) for x, y in t["pts"]]
            else:
                t["pts"] = [(0.25 + (y - 0.25), x * 0.5) if rot == "b" else (0.25 - (y - 0.25), (1 - x) * 0.5) for x, y in t["pts"]]
    return d


@sujet("coeur", "cœur")
def coeur(**_):
    d = D(0.9)
    pts = courbe((0.5, 0.82), (0.0, 0.45), (0.12, 0.05), (0.5, 0.3)) + courbe((0.5, 0.3), (0.88, 0.05), (1.0, 0.45), (0.5, 0.82))
    d.t(pts, 1.0)
    d.z(pts, "accent")
    return d


@sujet("etoile", "étoile")
def etoile(**_):
    d = D(1.0)
    pts = []
    for k in range(11):
        r = 0.45 if k % 2 == 0 else 0.19
        a = math.radians(-90 + k * 36)
        pts.append((0.5 + r * math.cos(a), 0.52 + r * math.sin(a)))
    d.t(pts, 1.0)
    d.z(pts, "accent")
    return d


@sujet("ampoule", "ampoule (une idée)")
def ampoule(**_):
    d = D(1.3)
    pts = arc(0.5, 0.45, 0.3, 135, 405)
    d.t(pts + [(0.62, 0.95), (0.38, 0.95), pts[0]], 1.0)
    d.z(pts + [(0.62, 0.95), (0.38, 0.95)], "accent")
    for y in (1.02, 1.1):
        d.t([(0.4, y), (0.6, y)], 0.9)
    for a in (-150, -90, -30):
        r = math.radians(a)
        d.t([(0.5 + 0.38 * math.cos(r), 0.45 + 0.38 * math.sin(r)), (0.5 + 0.48 * math.cos(r), 0.45 + 0.48 * math.sin(r))], 0.8)
    return d


@sujet("nuage", "nuage")
def nuage(**_):
    d = D(0.6)
    pts = arc(0.3, 0.35, 0.16, 90, 270) + arc(0.5, 0.25, 0.2, 200, 340) + arc(0.72, 0.35, 0.16, 270, 450)
    pts.append(pts[0])
    d.t(pts, 1.0)
    return d


@sujet("cahier", "cahier ouvert avec lignes")
def cahier(**_):
    d = D(0.75)
    d.t([(0.5, 0.12), (0.05, 0.08), (0.05, 0.66), (0.5, 0.7), (0.95, 0.66), (0.95, 0.08), (0.5, 0.12), (0.5, 0.7)], 1.0)
    for k in range(4):
        y = 0.22 + k * 0.11
        d.t([(0.12, y - 0.01), (0.42, y + 0.005)], 0.6)
        d.t([(0.58, y + 0.005), (0.88, y - 0.01)], 0.6)
    d.t([(0.72, 0.6), (0.98, 0.3)], 1.1, "accent")
    return d


@sujet("sac", "sac de courses")
def sac(**_):
    d = D(1.0)
    poly = [(0.18, 0.32), (0.82, 0.32), (0.9, 0.92), (0.1, 0.92), (0.18, 0.32)]
    d.t(poly, 1.0)
    d.z(poly, "second")
    d.t(arc(0.5, 0.32, 0.17, 180, 360), 0.9)
    return d


@sujet("arbre", "arbre")
def arbre(**_):
    d = D(1.3)
    d.t([(0.44, 1.25), (0.46, 0.7), (0.54, 0.7), (0.56, 1.25)], 1.0)
    pts = arc(0.5, 0.45, 0.36, 100, 460)
    d.t(pts, 1.0)
    d.z(arc(0.5, 0.45, 0.36), "second")
    return d


@sujet("horloge", "horloge (le temps)")
def horloge(**_):
    d = D(1.0)
    d.t(arc(0.5, 0.5, 0.4, -90, 270), 1.0)
    d.t([(0.5, 0.5), (0.5, 0.24)], 1.0)
    d.t([(0.5, 0.5), (0.68, 0.6)], 1.0)
    for k in range(12):
        a = math.radians(k * 30)
        d.t([(0.5 + 0.33 * math.cos(a), 0.5 + 0.33 * math.sin(a)), (0.5 + 0.37 * math.cos(a), 0.5 + 0.37 * math.sin(a))], 0.6)
    return d


@sujet("graphique", "courbe qui monte sur deux axes")
def graphique(baisse=False, **_):
    d = D(0.8)
    d.t([(0.1, 0.05), (0.1, 0.72), (0.95, 0.72)], 1.0)
    pts = [(0.15, 0.6), (0.35, 0.5), (0.5, 0.55), (0.7, 0.3), (0.9, 0.12)]
    if baisse:
        pts = [(x, 0.77 - y) for x, y in pts]
    d.t(pts, 1.2, "accent")
    return d


@sujet("coche", "coche (c'est bon)")
def coche(**_):
    d = D(0.8)
    d.t([(0.12, 0.42), (0.38, 0.7), (0.9, 0.1)], 1.6, "second")
    return d


@sujet("croix", "croix (non)")
def croix(**_):
    d = D(1.0)
    d.t([(0.15, 0.15), (0.85, 0.85)], 1.6, "accent")
    d.t([(0.85, 0.15), (0.15, 0.85)], 1.6, "accent")
    return d


@sujet("bulle", "bulle de parole vide (on écrit dedans avec un texte)")
def bulle(**_):
    d = D(0.62)
    pts = arc(0.5, 0.26, 0.45, 110, 430, ry=0.22)
    d.t(pts + [(0.28, 0.58), (0.36, 0.46)], 1.0)
    return d


@sujet("cadeau", "paquet cadeau")
def cadeau(**_):
    d = D(1.0)
    d.t(rect(0.15, 0.38, 0.85, 0.9), 1.0)
    d.z(rect(0.15, 0.38, 0.85, 0.9), "accent")
    d.t(rect(0.1, 0.26, 0.9, 0.38), 1.0)
    d.t([(0.5, 0.26), (0.5, 0.9)], 0.9)
    d.t(courbe((0.5, 0.26), (0.25, 0.0), (0.3, 0.3)), 0.9)
    d.t(courbe((0.5, 0.26), (0.75, 0.0), (0.7, 0.3)), 0.9)
    return d


# ---------------------------------------------------------------- eau, plantes
def _goutte(cx, cy, r):
    return courbe((cx, cy - 2.2 * r), (cx + 1.6 * r, cy - 0.2 * r), (cx + 0.9 * r, cy + r), (cx, cy + r)) + \
        courbe((cx, cy + r), (cx - 0.9 * r, cy + r), (cx - 1.6 * r, cy - 0.2 * r), (cx, cy - 2.2 * r))


@sujet("goutte", "goutte d'eau")
def goutte(**_):
    d = D(1.2)
    pts = _goutte(0.5, 0.75, 0.28)
    d.t(pts, 1.0)
    d.z(pts, "second")
    d.t(arc(0.42, 0.72, 0.09, 150, 230), 0.7)
    return d


@sujet("pluie", "gouttes de pluie qui tombent (sous un nuage)")
def pluie(**_):
    d = D(0.7)
    for x, y in [(0.15, 0.15), (0.38, 0.32), (0.62, 0.12), (0.85, 0.3), (0.27, 0.55), (0.72, 0.52)]:
        pts = _goutte(x, y, 0.045)
        d.t(pts, 0.8)
        d.z(pts, "second")
    return d


@sujet("riviere", "rivière : vagues et eau")
def riviere(**_):
    d = D(0.38)
    haut = [(x, 0.1 + 0.035 * math.sin(x * 18)) for x in np.linspace(0.02, 0.98, 30)]
    bas = [(x, 0.3 + 0.035 * math.sin(x * 15 + 1)) for x in np.linspace(0.98, 0.02, 30)]
    d.t(haut, 1.0)
    d.t(bas, 1.0)
    d.z(haut + bas, "second")
    d.t([(x, 0.2 + 0.02 * math.sin(x * 25)) for x in np.linspace(0.25, 0.5, 10)], 0.6)
    d.t([(x, 0.22 + 0.02 * math.sin(x * 25)) for x in np.linspace(0.62, 0.85, 10)], 0.6)
    return d


@sujet("vapeur", "vapeur qui monte (trois lignes ondulées)")
def vapeur(**_):
    d = D(1.2)
    for x in (0.25, 0.5, 0.75):
        d.t([(x + 0.06 * math.sin(y * 9), y) for y in np.linspace(1.1, 0.1, 20)], 0.9)
    return d


@sujet("pot", "pot de fleurs rempli de terre")
def pot(**_):
    d = D(0.85)
    poly = [(0.15, 0.3), (0.85, 0.3), (0.74, 0.8), (0.26, 0.8), (0.15, 0.3)]
    d.t(poly, 1.0)
    d.z(poly, "accent")
    d.t([(0.1, 0.3), (0.9, 0.3), (0.9, 0.18), (0.1, 0.18), (0.1, 0.3)], 1.0)
    d.t(courbe((0.18, 0.18), (0.5, 0.06), (0.82, 0.18)), 0.8)
    d.z(courbe((0.18, 0.18), (0.5, 0.06), (0.82, 0.18)), "troisieme")
    return d


@sujet("graine", "graine (haricot)")
def graine(**_):
    d = D(0.7)
    pts = arc(0.5, 0.35, 0.36, -90, 270, ry=0.24)
    d.t(pts, 1.0)
    d.z(pts, "troisieme")
    d.t(arc(0.5, 0.42, 0.13, 205, 335), 0.8)
    return d


@sujet("arrosoir", "arrosoir qui verse de l'eau")
def arrosoir(**_):
    d = D(0.85)
    corps = rect(0.25, 0.3, 0.7, 0.75)
    d.t(corps, 1.0)
    d.z(corps, "second")
    d.t(courbe((0.7, 0.4), (0.9, 0.35), (0.7, 0.62)), 0.9)
    d.t([(0.25, 0.6), (0.06, 0.32), (0.0, 0.3)], 1.0)
    for x, y in [(0.02, 0.45), (0.06, 0.58), (0.0, 0.7)]:
        d.t([(x, y), (x - 0.02, y + 0.06)], 0.8, "second")
    return d


@sujet("pousse", "jeune plante : tige et deux feuilles (option fleur)")
def pousse(fleur=False, **_):
    d = D(1.25)
    d.t(courbe((0.5, 1.2), (0.46, 0.8), (0.52, 0.35)), 1.0)
    f1 = courbe((0.5, 0.7), (0.2, 0.62), (0.12, 0.42)) + courbe((0.12, 0.42), (0.36, 0.42), (0.5, 0.7))
    f2 = courbe((0.51, 0.55), (0.8, 0.5), (0.88, 0.28)) + courbe((0.88, 0.28), (0.62, 0.3), (0.51, 0.55))
    for f in (f1, f2):
        d.t(f, 0.9)
        d.z(f, "vert")
    if fleur:
        c = arc(0.52, 0.25, 0.1)
        d.t(c, 0.9)
        d.z(c, "troisieme")
    d.t([(0.25, 1.2), (0.75, 1.2)], 1.0)
    return d


# ---------------------------------------------------------------- mise à l'échelle + tremblé
def construire(nom, largeur, ep_base, couleurs, style="flat", graine=0, options=None):
    """Renvoie (traits px, zones px, w, h) prêts pour traits.depuis_traits."""
    if nom not in SUJETS:
        raise SystemExit(f"Sujet de croquis inconnu : {nom}. Liste : python croquis.py --liste")
    d = SUJETS[nom][0](**(options or {}))
    marge = ep_base * 1.5
    w = largeur
    h = largeur * d.ar
    rng = np.random.default_rng(graine)
    amp = {"croquis": 0.007, "craie": 0.005}.get(style, 0.004) * largeur

    def tremble(pts):
        p = np.array(pts, float) * [w - 2 * marge, (h - 2 * marge) / d.ar] + marge
        n = len(p)
        if n < 2:
            return p
        ph = rng.uniform(0, 6.28, 2)
        k = np.linspace(0, 1, n)
        p[:, 0] += amp * np.sin(k * 5 + ph[0])
        p[:, 1] += amp * np.sin(k * 4 + ph[1])
        return p

    def col(c):
        return couleurs.get(c, couleurs["encre"]) if isinstance(c, str) else c

    traits = []
    for t in d.traits:
        p = tremble(t["pts"])
        traits.append({"pts": [tuple(x) for x in p], "ep": ep_base * t["ep"], "coul": col(t["coul"])})
        if style == "croquis":  # crayon : un second passage léger, décalé
            p2 = p + rng.normal(0, amp * 0.6, 2)
            traits.append({"pts": [tuple(x) for x in p2], "ep": ep_base * t["ep"] * 0.5, "coul": col(t["coul"])})
    zones = [{"poly": [tuple(x) for x in np.array(z["poly"], float) * [w - 2 * marge, (h - 2 * marge) / d.ar] + marge],
              "coul": col(z["coul"])} for z in d.zones]
    return traits, zones, w, h


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--liste", action="store_true")
    ap.add_argument("--planche")
    ap.add_argument("--style", default="flat")
    a = ap.parse_args()
    if a.liste or not a.planche:
        for k, (_, aide) in SUJETS.items():
            print(f"  {k:12s} {aide}")
        return
    import traits as T
    from PIL import Image, ImageDraw
    coul = {"encre": (25, 25, 25), "accent": (230, 87, 46), "second": (42, 157, 143), "troisieme": (244, 196, 48), "vert": (93, 187, 99)}
    noms = list(SUJETS)
    cell = 260
    pl = Image.new("RGB", (cell * 6, cell * math.ceil(len(noms) / 6) + 10), "white")
    for i, n in enumerate(noms):
        tr, zo, w, h = construire(n, 200, 6, coul, a.style, i)
        c = T.depuis_traits(tr, zo, w, h, a.style, coul, i)
        im = Image.fromarray(c.final())
        im.thumbnail((cell - 30, cell - 50))
        pl.paste(im, ((i % 6) * cell + 15, (i // 6) * cell + 10), im)
        ImageDraw.Draw(pl).text(((i % 6) * cell + 15, (i // 6) * cell + cell - 30), n, fill=(90, 90, 90))
    pl.save(a.planche)
    print(a.planche)


if __name__ == "__main__":
    main()
