"""Moteur de vidéo dessinée : une main dessine chaque idée au moment où elle est dite.

usage :
  python moteur.py video.json --verifier        contrôles + controle/planche.jpg (rien n'est rendu)
  python moteur.py video.json --image 4.2       une image fixe à 4,2 s → controle/image-4.2.png
  python moteur.py video.json --essai           3 premières secondes, estime le temps de calcul
  python moteur.py video.json                   sortie/muette.mp4, puis sortie/video.mp4 (avec la voix)
  python moteur.py video.json --son-trait       idem, avec un bruit de feutre très bas (désactivé par défaut)
  python moteur.py --catalogue                  styles, affichages, éléments, croquis

Format de video.json : references/bibliotheque.md. Exemples : assets/exemples/.
"""
import argparse
import json
import math
import multiprocessing as mp
import os
import re
import subprocess
import sys
import time

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ICI = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(ICI)
sys.path.insert(0, ICI)
import croquis  # noqa: E402
import mots as M  # noqa: E402
import traits as T  # noqa: E402
from outils import ffmpeg_exe  # noqa: E402

W, H = 1080, 1920
ZONE_HAUT, ZONE_BAS, ZONE_DROITE, ZONE_DROITE_Y = 200, 1500, 930, 860

STYLES = {
    # le style par défaut : contour noir épais et régulier, formes rondes, aplats francs, sans ombre
    "flat": {"fond": "#FFFFFF", "encre": "#111111", "accent": "#F2643A", "second": "#1FA89E", "troisieme": "#FFC93C", "vert": "#5DBB63",
             "ep": 9, "main": "marqueur", "main_taille": 640, "couleur": "remplit", "police": "Caveat.ttf"},
    "croquis": {"fond": "#FCFBF8", "encre": "#34342F", "accent": "#C8553D", "second": "#4F7CAC", "troisieme": "#E0B04B", "vert": "#7A9A5B",
                "ep": 3.4, "main": "feutre", "main_taille": 600, "couleur": "fondu", "police": "Caveat.ttf"},
    "feutre": {"fond": "#FFFFFF", "encre": "#141414", "accent": "#D7263D", "second": "#1B998B", "troisieme": "#F2A541", "vert": "#4E9F3D",
               "ep": 4.5, "main": "feutre", "main_taille": 600, "couleur": "remplit", "police": "Caveat.ttf"},
    "craie": {"fond": "#2E4A3B", "encre": "#F2F0E8", "accent": "#FFD27F", "second": "#9FD8E6", "troisieme": "#F4A9B8", "vert": "#A8E6A1",
              "ep": 6.5, "main": "craie", "main_taille": 600, "couleur": "remplit", "police": "Caveat.ttf"},
}
TABLEAUX = {"vert": "#2E4A3B", "noir": "#24282B", "bleu": "#23344A"}
AFFICHAGES = ("fresque", "successifs", "tableau", "melange")
TYPES = ("image", "dessin", "texte", "photo", "fleche")


def rgb(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def lisse(x):
    x = min(1.0, max(0.0, x))
    return x * x * (3 - 2 * x)


def police(nom):
    for p in (nom, os.path.join(SKILL, "assets", "fonts", nom)):
        if os.path.exists(p):
            return p
    return os.path.join(SKILL, "assets", "fonts", "Caveat.ttf")


def rognage(src, marge=0.03):
    """Cadre utile d'un dessin sur fond blanc (fractions), pour ne pas garder les grandes marges blanches."""
    im = Image.open(src)
    if im.mode in ("RGBA", "LA"):
        a = np.asarray(im.convert("RGBA"))[..., 3] > 20
    else:
        a = np.asarray(im.convert("RGB"), np.float32).min(2) < 235
    if not a.any():
        return None
    ys, xs = np.nonzero(a)
    h, w = a.shape
    m = marge * max(w, h)
    return (max(0, xs.min() - m) / w, max(0, ys.min() - m) / h, min(w, xs.max() + m) / w, min(h, ys.max() + m) / h)


# ---------------------------------------------------------------- un élément
class Elt:
    def __init__(self, spec, scene, i):
        self.spec = spec
        self.type = spec.get("type", "image")
        self.scene = scene
        self.i = i
        self.id = spec.get("id", f"e{i}")
        self.t0 = self.dt = self.dc = 0.0
        self.t_efface = None
        self.mode_efface = "efface"
        self.box = (0, 0, 10, 10)  # x, y, w, h dans le grand tableau
        self.calques = None
        self.fondu_c = False
        self.cible = None
        self.page = 0
        self.notes = []
        self._final = None

    @property
    def fin(self):
        return self.t0 + self.dt + self.dc

    def etat(self, t):
        if t < self.t0 or self.calques is None:
            return None
        p = 1.0 if self.dt <= 0 else (t - self.t0) / self.dt
        q = 1.0 if self.dc <= 0 else (t - self.t0 - self.dt) / self.dc
        p, q = min(1.0, max(0.0, p)), min(1.0, max(0.0, q))
        e = 0.0
        if self.t_efface is not None and t >= self.t_efface:
            e = (t - self.t_efface) / 0.45
            if e >= 1:
                return None
            if self.mode_efface == "fondu":
                im = self.image_finale() if (p >= 1 and q >= 1) else Image.fromarray(self.calques.etat(p, q, 0, self.fondu_c))
                a = im.split()[3].point(lambda v: int(v * (1 - e)))
                im = im.copy()
                im.putalpha(a)
                return im
            if self.mode_efface == "coupe":
                return None
        if p >= 1 and q >= 1 and e <= 0:
            return self.image_finale()
        return Image.fromarray(self.calques.etat(p, q, e, self.fondu_c))

    def image_finale(self):
        if self._final is None:
            self._final = Image.fromarray(self.calques.final())
        return self._final


# ---------------------------------------------------------------- la vidéo
class Video:
    def __init__(self, chemin, donnees=None):
        self.chemin = os.path.abspath(chemin)
        self.base = os.path.dirname(self.chemin)
        d = donnees if donnees is not None else json.load(open(chemin, encoding="utf-8"))
        self.d = d
        self.fps = d.get("fps", 30)
        self.style = {"trait-couleur": "flat", "stickman": "flat"}.get(d.get("style", "flat"), d.get("style", "flat"))
        if self.style not in STYLES:
            sys.exit(f"Style inconnu : {self.style}. Choix : {', '.join(STYLES)}")
        st = dict(STYLES[self.style])
        # "tableau" : n'importe quel style sur un tableau vert, noir ou bleu, trait clair
        self.tableau = self.style == "craie" or d.get("tableau") in TABLEAUX
        if d.get("tableau") in TABLEAUX:
            st["fond"] = TABLEAUX[d["tableau"]]
            if self.style != "craie":
                st.update({"encre": "#F4F1E8", "main": "craie"})
        st.update(d.get("couleurs", {}))
        self.st = st
        self.coul = {k: rgb(st[k]) for k in ("fond", "encre", "accent", "second", "troisieme", "vert")}
        self.affichage = d.get("affichage", "fresque")
        if self.affichage not in AFFICHAGES:
            sys.exit(f"Affichage inconnu : {self.affichage}. Choix : {', '.join(AFFICHAGES)}")
        self.k = float(d.get("zoom", 2.0)) if self.affichage == "fresque" else 1.0
        self.CW, self.CH = int(W * self.k), int(H * self.k)
        self.sous_titres = d.get("sous_titres", bool(d.get("voix")))
        self.voix = self._chemin(d["voix"]) if d.get("voix") else None
        self.voix_a = float(d.get("voix_a", 0.3)) if self.voix else 0.0
        self.problemes = []
        self._mots()
        self._elements()
        self._placer()
        self._calques()
        self._temps()
        self._camera()
        self._fond()
        self._main()
        self._st_cache = {}

    # ------------------------------------------------------------ chargement
    def _chemin(self, p):
        return p if os.path.isabs(p) else os.path.join(self.base, p)

    def note(self, niveau, msg):
        self.problemes.append((niveau, msg))

    def _mots(self):
        d = self.d
        scenes = d.get("scenes", [])
        textes = [s.get("texte", "") for s in scenes]
        self.texte = " ".join(t for t in textes if t)
        fm = self._chemin(d.get("mots", "mots.json"))
        tl = None
        if os.path.exists(fm):
            tl = json.load(open(fm, encoding="utf-8"))
            if [M.norm(m["mot"]) for m in tl["mots"]] != [M.norm(m) for m in M.decouper(self.texte)]:
                tl = None  # le texte a changé : on refait
        if tl is None:
            whisper = self._chemin(d["whisper"]) if d.get("whisper") else None
            tl = M.timeline(self.texte, self.voix, whisper, debit=d.get("debit", 2.4))
            json.dump(tl, open(fm, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        self.tl = tl
        self.mots = [dict(m, debut=m["debut"] + self.voix_a, fin=m["fin"] + self.voix_a) for m in tl["mots"]]
        self.duree_voix = (tl["duree"] + self.voix_a) if self.voix else (self.mots[-1]["fin"] if self.mots else 0)
        # plages de mots de chaque scène
        self.plages, k = [], 0
        for t in textes:
            n = len(M.decouper(t))
            self.plages.append((k, k + n))
            k += n

    def temps_du_mot(self, mot, scene):
        cle = [M.norm(x) for x in M.decouper(mot)]
        if not cle:
            return None
        elision = lambda m: M.norm(re.sub(r"^(?:[lLdDjJnNsScCmMtT]|[qQ]u)['’]", "", m))  # noqa: E731
        cle = [elision(x) for x in M.decouper(mot)]
        normes = [elision(m["mot"]) for m in self.mots]
        a, b = self.plages[scene] if scene < len(self.plages) else (0, len(normes))
        for debut, fin in ((a, b), (a, len(normes)), (0, len(normes))):
            for i in range(debut, max(debut, fin - len(cle) + 1)):
                if normes[i:i + len(cle)] == cle or (len(cle) == 1 and normes[i].startswith(cle[0]) and len(cle[0]) >= 4):
                    return self.mots[i]["debut"]
        return None

    def _elements(self):
        self.elts = []
        for si, s in enumerate(self.d.get("scenes", [])):
            for spec in s.get("elements", []):
                if spec.get("type", "image") == "image" and spec.get("zones"):
                    for zi, z in enumerate(spec["zones"]):
                        sub = dict(spec)
                        sub.pop("zones")
                        sub.update(z)
                        sub["_parent"] = spec
                        sub["_zone"] = zi
                        sub.setdefault("id", f"{spec.get('id', 'fresque')}-{zi + 1}")
                        e = Elt(sub, z.get("scene", si), len(self.elts))
                        self.elts.append(e)
                else:
                    self.elts.append(Elt(spec, si, len(self.elts)))
        par_id = {e.id: e for e in self.elts}
        self.par_id = par_id
        for e in self.elts:
            if e.type not in TYPES:
                sys.exit(f"Type d'élément inconnu : {e.type} ({e.id}). Choix : {', '.join(TYPES)}")
            if e.type in ("image", "photo"):
                src = self._chemin(e.spec.get("src", ""))
                if not os.path.exists(src):
                    sys.exit(f"Image introuvable : {src} ({e.id})")
                e.src = src
                e.rogne = None
                if e.type == "image" and "_parent" not in e.spec and e.spec.get("rogner", True):
                    e.rogne = rognage(src)

    # ------------------------------------------------------------ mise en page
    def _ratio(self, e):
        """hauteur / largeur naturelle de l'élément."""
        if e.type in ("image", "photo"):
            im = Image.open(e.src)
            r = None
            if "_parent" in e.spec:
                r = self._rects_zones(e.spec["_parent"], e.src)[e.spec["_zone"]]
            elif getattr(e, "rogne", None):
                r = e.rogne
            if r:
                return (r[3] - r[1]) * im.height / max(1e-6, (r[2] - r[0]) * im.width)
            return im.height / im.width
        if e.type == "dessin":
            f = croquis.SUJETS.get(e.spec.get("sujet", "personnage"))
            if not f:
                sys.exit(f"Sujet de croquis inconnu : {e.spec.get('sujet')}. Liste : python croquis.py --liste")
            return f[0](**e.spec.get("options", {})).ar
        return 0.3

    def _rects_zones(self, parent, src):
        """Partage une grande image en zones : chaque pixel va à la première zone qui le contient, sinon à la plus proche."""
        cle = id(parent)
        if not hasattr(self, "_zones_cache"):
            self._zones_cache = {}
        if cle in self._zones_cache:
            return self._zones_cache[cle][0]
        im = Image.open(src)
        w = 240
        h = int(w * im.height / im.width)
        lab = np.full((h, w), -1, np.int32)
        ys, xs = np.mgrid[0:h, 0:w]
        fx, fy = (xs + 0.5) / w, (ys + 0.5) / h
        zs = parent["zones"]
        for k, z in enumerate(zs):
            x0, y0, x1, y1 = z["rect"]
            dans = (fx >= x0) & (fx <= x1) & (fy >= y0) & (fy <= y1) & (lab < 0)
            lab[dans] = k
        reste = lab < 0
        if reste.any():
            best = np.argmin(np.stack([np.hypot(np.maximum(0, np.maximum(z["rect"][0] - fx, fx - z["rect"][2])),
                                                np.maximum(0, np.maximum(z["rect"][1] - fy, fy - z["rect"][3]))) for z in zs]), 0)
            lab[reste] = best[reste]
        petit = np.asarray(im.convert("RGB").resize((w, h), Image.BOX), np.float32).min(2) < 238
        rects, masques = [], []
        for k in range(len(zs)):
            m = lab == k
            if (m & petit).any():
                yy, xx = np.nonzero(m & petit)
                x0, x1 = max(0, xx.min() - 2), min(w, xx.max() + 3)
                y0, y1 = max(0, yy.min() - 2), min(h, yy.max() + 3)
                rects.append((x0 / w, y0 / h, x1 / w, y1 / h))
                masques.append(m[y0:y1, x0:x1])
                continue
            if not m.any():
                rects.append(tuple(zs[k]["rect"]))
                masques.append(np.ones((2, 2), bool))
                continue
            yy, xx = np.nonzero(m)
            x0, x1, y0, y1 = xx.min(), xx.max() + 1, yy.min(), yy.max() + 1
            rects.append((x0 / w, y0 / h, x1 / w, y1 / h))
            masques.append(m[y0:y1, x0:x1])
        self._zones_cache[cle] = (rects, masques)
        return rects

    def _placer(self):
        aff = self.affichage
        haut = 250
        bas = 1290 if self.sous_titres else 1440
        for e in self.elts:
            e.ratio = self._ratio(e) if e.type != "texte" else None
        if aff == "fresque":
            self._placer_fresque()
        elif aff == "tableau":
            self._placer_tableau(haut, bas)
        else:
            self._placer_pages(haut, bas)
        # éléments placés à côté d'un autre
        for e in self.elts:
            if e.spec.get("pres"):
                self._placer_pres(e)

    def _taille_texte(self, e):
        taille = e.spec.get("taille", 92 if e.spec.get("role") == "titre" else 70) * (self.k if self.affichage == "fresque" and "taille" not in e.spec else 1)
        lmax = e.spec.get("largeur", 820 if self.affichage != "fresque" else 900) * (self.k if self.affichage == "fresque" and "largeur" not in e.spec else 1)
        coul = self.coul.get(e.spec.get("couleur", "accent" if e.spec.get("role") == "titre" else "encre"), self.coul["encre"])
        e.calques = T.depuis_texte(e.spec["texte"], police(e.spec.get("police", self.st["police"])), taille, coul, self.style, self.coul,
                                   lmax, graine=e.i)
        e.taille = taille
        return e.calques.w, e.calques.h

    def _poser(self, e, cx, cy, w):
        if e.type == "texte":
            tw, th = self._taille_texte(e)
            e.box = (int(cx - tw / 2), int(cy - th / 2), tw, th)
        else:
            h = w * e.ratio
            e.box = (int(cx - w / 2), int(cy - h / 2), int(w), int(h))

    def _place_explicite(self, e):
        p = e.spec.get("place")
        if not p:
            return False
        cx, cy = p[0] * self.CW, p[1] * self.CH
        w = (p[2] if len(p) > 2 else 0.6) * self.CW
        self._poser(e, cx, cy, w)
        return True

    def _placer_pres(self, e):
        pr = e.spec["pres"]
        ref = self.par_id.get(pr.get("id"))
        if not ref:
            self.note("✗", f"{e.id} : « pres » vise un id inconnu ({pr.get('id')})")
            return
        x, y, w, h = ref.box
        if e.type == "texte" and e.calques is None:
            self._taille_texte(e)
        ew, eh = (e.calques.w, e.calques.h) if e.type == "texte" else (e.box[2], e.box[3])
        ecart = pr.get("ecart", 20) * self.k
        cote = pr.get("cote", "dessous")
        cx, cy = {"dessous": (x + w / 2, y + h + ecart + eh / 2), "dessus": (x + w / 2, y - ecart - eh / 2),
                  "gauche": (x - ecart - ew / 2, y + h / 2), "droite": (x + w + ecart + ew / 2, y + h / 2),
                  "dedans": (x + w / 2, y + h / 2)}.get(cote, (x + w / 2, y + h + ecart + eh / 2))
        cx += pr.get("dx", 0) * self.k
        cy += pr.get("dy", 0) * self.k
        e.box = (int(cx - ew / 2), int(cy - eh / 2), int(ew), int(eh))

    def _placer_fresque(self):
        y = 0.08 * self.CH
        cote = 0
        for e in self.elts:
            if e.spec.get("pres"):
                if e.type == "texte":
                    self._taille_texte(e)
                else:
                    w = e.spec.get("largeur", 0.4) * self.CW
                    e.box = (0, 0, int(w), int(w * e.ratio))
                continue
            if "_parent" in e.spec:
                par = e.spec["_parent"]
                p = par.get("place", [0.5, 0.5, 0.92])
                im = Image.open(e.src)
                pw = p[2] * self.CW
                ph = pw * im.height / im.width
                if ph > 0.94 * self.CH:
                    ph = 0.94 * self.CH
                    pw = ph * im.width / im.height
                px, py = p[0] * self.CW - pw / 2, p[1] * self.CH - ph / 2
                r = self._rects_zones(par, e.src)[e.spec["_zone"]]
                e.box = (int(px + r[0] * pw), int(py + r[1] * ph), max(4, int((r[2] - r[0]) * pw)), max(4, int((r[3] - r[1]) * ph)))
                continue
            if self._place_explicite(e):
                continue
            if e.type == "texte":
                tw, th = self._taille_texte(e)
                e.box = (int(self.CW / 2 - tw / 2), int(y), tw, th)
                y += th + 0.03 * self.CH
                continue
            w = e.spec.get("largeur", 0.48) * self.CW
            h = w * e.ratio
            cx = self.CW * (0.32 if cote % 2 == 0 else 0.68)
            e.box = (int(cx - w / 2), int(y), int(w), int(h))
            y += h * 0.75 + 0.03 * self.CH
            cote += 1

    def _rangees(self, elts):
        rangees, cour = [], []
        for e in elts:
            if e.spec.get("pres") or e.spec.get("place"):
                continue
            if e.type == "texte":
                if cour:
                    rangees.append(cour)
                    cour = []
                rangees.append([e])
            else:
                cour.append(e)
        if cour:
            rangees.append(cour)
        return rangees

    def _placer_pages(self, haut, bas):
        g = 940 - 90
        for si in range(len(self.d.get("scenes", []))):
            elts = [e for e in self.elts if e.scene == si]
            for e in elts:
                e.page = si
                self._place_explicite(e)
            rangees = self._rangees(elts)
            tailles = []
            for r in rangees:
                if r[0].type == "texte":
                    tw, th = self._taille_texte(r[0])
                    tailles.append((th, [(tw, th)]))
                else:
                    n = len(r)
                    wl = [e.spec.get("largeur", 0.82 if n == 1 else 0.9 / n) * g for e in r]
                    k = min(1.0, (g - 40 * (n - 1)) / sum(wl))
                    wl = [w * k for w in wl]
                    hl = [w * e.ratio for w, e in zip(wl, r)]
                    tailles.append((max(hl), list(zip(wl, hl))))
            if not rangees:
                continue
            ecart = 46
            dispo = bas - haut
            # les dessins grandissent pour remplir la page (sans dépasser la largeur utile ni 1,6 fois)
            h_txt = sum(t[0] for r, t in zip(rangees, tailles) if r[0].type == "texte")
            h_vis = sum(t[0] for r, t in zip(rangees, tailles) if r[0].type != "texte")
            larg = max([sum(w for w, _ in t[1]) + 40 * (len(t[1]) - 1) for r, t in zip(rangees, tailles) if r[0].type != "texte"] or [1])
            if h_vis > 0 and self.d.get("agrandir", True):
                g_k = min(float(self.d.get("agrandir_max", 1.3)), g / larg, max(0.3, (dispo * 0.88 - h_txt - ecart * (len(rangees) - 1)) / h_vis))
                tailles = [(t[0] * g_k, [(w * g_k, h * g_k) for w, h in t[1]]) if r[0].type != "texte" else t for r, t in zip(rangees, tailles)]
            total = sum(t[0] for t in tailles) + ecart * (len(rangees) - 1)
            k = min(1.0, dispo / total) if total > 0 else 1
            y = haut + (dispo - total * k) / 2
            for r, (hr, dims) in zip(rangees, tailles):
                if r[0].type == "texte":
                    e = r[0]
                    if k < 1:
                        e.spec = dict(e.spec, taille=int(e.spec.get("taille", 70) * max(0.6, k)))
                        self._taille_texte(e)
                    e.box = (int(515 - e.calques.w / 2), int(y), e.calques.w, e.calques.h)
                    y += e.calques.h + ecart * k
                    continue
                wtot = sum(w * k for w, _ in dims) + 40 * (len(r) - 1)
                x = 515 - wtot / 2
                for e, (w, h) in zip(r, dims):
                    e.box = (int(x), int(y + (hr - h) * k / 2), int(w * k), int(h * k))
                    x += w * k + 40
                y += hr * k + ecart * k
        if self.d.get("transition") == "glisse":
            self.CH = H * max(1, len(self.d.get("scenes", [])))
            for e in self.elts:
                x, y, w, h = e.box
                e.box = (x, y + e.page * H, w, h)

    def _placer_tableau(self, haut, bas):
        visuels = [e for e in self.elts if e.type != "texte" and not e.spec.get("place") and not e.spec.get("pres") and e.type != "fleche"]
        textes = [e for e in self.elts if e.type == "texte" and not e.spec.get("place") and not e.spec.get("pres")]
        # un texte juste après un dessin de la même scène devient sa légende ; les autres sont des titres
        legendes = {}
        for e in textes:
            av = [v for v in self.elts[:e.i] if v.type in ("image", "dessin", "photo") and v.scene == e.scene]
            if av and e.spec.get("role") != "titre" and av[-1].id not in legendes:
                legendes[av[-1].id] = e
        titres = [e for e in textes if e not in legendes.values()]
        y = haut
        for e in titres:
            tw, th = self._taille_texte(e)
            e.box = (int(515 - tw / 2), int(y), tw, th)
            y += th + 30
        n = len(visuels)
        if not n:
            return
        cols = self.d.get("colonnes", 1 if n == 1 else 2 if n <= 6 else 3)
        rows = math.ceil(n / cols)
        gx, gy = 70, 40
        largeur = 940 - 90
        cw = (largeur - gx * (cols - 1)) / cols
        hl = 0
        for e in legendes.values():
            e.spec = dict(e.spec, taille=e.spec.get("taille", 54 if cols > 1 else 70))
            self._taille_texte(e)
            hl = max(hl, e.calques.h)
        dispo = bas - y
        ch = (dispo - gy * (rows - 1)) / rows - hl
        # hauteur réellement prise par les dessins : la grille est centrée dans la place restante
        ch_reel = max(min(cw * 0.92, ch / e.ratio) * e.ratio for e in visuels)
        y += max(0.0, (dispo - (rows * (ch_reel + hl) + gy * (rows - 1))) / 2) * 0.8
        ch = min(ch, ch_reel)
        for k, e in enumerate(visuels):
            c, r = k % cols, k // cols
            w = min(cw * 0.92, ch / e.ratio)
            h = w * e.ratio
            cx = 90 + c * (cw + gx) + cw / 2
            cy = y + r * (ch + hl + gy) + ch / 2
            e.box = (int(cx - w / 2), int(cy - h / 2), int(w), int(h))
            e.cellule = (cx, y + r * (ch + hl + gy), cw, ch)
            lg = legendes.get(e.id)
            if lg:
                lg.box = (int(cx - lg.calques.w / 2), int(y + r * (ch + hl + gy) + ch + 4), lg.calques.w, lg.calques.h)
        # flèches automatiques entre les cases
        if self.d.get("fleches"):
            nouv = []
            for a, b in zip(visuels, visuels[1:]):
                nouv.append(self._fleche_auto(a, b))
            for f in nouv:
                self.elts.append(f)
                self.par_id[f.id] = f

    def _fleche_auto(self, a, b):
        ax, ay, aw, ah = a.box
        bx, by, bw, bh = b.box
        p0 = np.array([ax + aw / 2, ay + ah / 2], float)
        p1 = np.array([bx + bw / 2, by + bh / 2], float)
        v = p1 - p0
        L = np.hypot(*v)
        u = v / max(L, 1)

        def bord(c, box, sens):
            x, y, w, h = box
            tx = (w / 2 + 18) / max(abs(sens[0]), 1e-6)
            ty = (h / 2 + 18) / max(abs(sens[1]), 1e-6)
            return c + sens * min(tx, ty)

        s0, s1 = bord(p0, a.box, u), bord(p1, b.box, -u)
        if np.dot(s1 - s0, u) < 30:
            s0, s1 = p0 + u * 0.35 * L, p1 - u * 0.35 * L
        e = Elt({"type": "fleche", "id": f"fleche-{a.id}-{b.id}", "_de": a.id, "_vers": b.id}, b.scene, len(self.elts))
        e.points = (s0, s1)
        return e

    # ------------------------------------------------------------ calques
    def _calques(self):
        ep = self.st["ep"] * self.k
        for e in self.elts:
            s = e.spec
            x, y, w, h = e.box
            mode = s.get("couleur", self.st["couleur"])
            if e.type == "texte":
                if e.calques is None:
                    self._taille_texte(e)
            elif e.type == "image":
                rect, masque = e.rogne, None
                if "_parent" in s:
                    rects = self._rects_zones(s["_parent"], e.src)
                    rect = rects[s["_zone"]]
                    masque = self._zones_cache[id(s["_parent"])][1][s["_zone"]]
                e.calques = T.depuis_image(e.src, w, self.style, self.coul, couleur=(mode != "aucune"), rect=rect, masque_zone=masque)
                if self.tableau and self.style != "craie" and e.calques.coul_rgb is not None:
                    # sur un tableau, les contours noirs de l'image deviennent clairs
                    ta = e.calques.trait_a[..., None]
                    e.calques.coul_rgb = (e.calques.coul_rgb * (1 - ta) + np.array(self.coul["encre"]) * ta).astype(np.uint8)
            elif e.type == "dessin":
                tr, zo, cw, chh = croquis.construire(s.get("sujet", "personnage"), w, ep, self.coul, self.style, graine=e.i + 3,
                                                     options=s.get("options"))
                if mode == "aucune":
                    zo = []
                e.calques = T.depuis_traits(tr, zo, cw, chh, self.style, self.coul, graine=e.i)
            elif e.type == "photo":
                e.calques = T.depuis_photo(e.src, w - 28, self.style, self.coul, cadre=s.get("cadre", True), graine=e.i)
            elif e.type == "fleche":
                if not hasattr(e, "points"):
                    de, vers = self.par_id.get(s.get("de")), self.par_id.get(s.get("vers"))
                    if not de or not vers:
                        sys.exit(f"Flèche {e.id} : « de » et « vers » doivent être des id d'éléments.")
                    e.points = self._fleche_auto(de, vers).points
                s0, s1 = e.points
                v = s1 - s0
                L = float(np.hypot(*v))
                u = v / max(L, 1)
                n = np.array([-u[1], u[0]])
                mid = (s0 + s1) / 2 + n * L * 0.08
                pts = [tuple(s0 + (mid - s0) * t * 2) if t < 0.5 else tuple(mid + (s1 - mid) * (t - 0.5) * 2) for t in np.linspace(0, 1, 12)]
                tete = 26 * self.k
                g1 = s1 - u * tete + n * tete * 0.6
                g2 = s1 - u * tete - n * tete * 0.6
                x0, y0 = min(p[0] for p in pts + [tuple(g1), tuple(g2)]) - 20, min(p[1] for p in pts + [tuple(g1), tuple(g2)]) - 20
                x1, y1 = max(p[0] for p in pts + [tuple(g1), tuple(g2)]) + 20, max(p[1] for p in pts + [tuple(g1), tuple(g2)]) + 20
                loc = lambda p: (p[0] - x0, p[1] - y0)  # noqa: E731
                col = self.coul.get(s.get("couleur", "encre"), self.coul["encre"])
                tr = [{"pts": [loc(p) for p in pts], "ep": ep, "coul": col},
                      {"pts": [loc(g1), loc(s1), loc(g2)], "ep": ep, "coul": col}]
                e.calques = T.depuis_traits(tr, [], x1 - x0, y1 - y0, self.style, self.coul, graine=e.i)
                e.box = (int(x0), int(y0), e.calques.w, e.calques.h)
                mode = "aucune"
            if e.type != "texte" and e.type != "fleche":
                e.box = (e.box[0], e.box[1], e.calques.w, e.calques.h)
            if mode == "aucune" and e.type not in ("photo",):
                e.calques.coul_a = None
            e.fondu_c = (mode == "fondu")
            e.mode_couleur = mode

    # ------------------------------------------------------------ le temps
    def _ideal(self, e):
        """Durée qui donne une main ni trop lente ni trop rapide."""
        if e.type == "texte":
            return min(2.2, max(0.6, 0.055 * len(e.spec["texte"]) + 0.3)) / max(1.0, float(self.d.get("vitesse", 1.0)) ** 0.5)
        if e.type == "fleche":
            return 0.45
        L = e.calques.longueur / self.k
        base = min(4.0, max(1.0, L / 1100))
        if e.calques.a_couleur and e.mode_couleur == "remplit":
            base *= 1.45
        return base * e.spec.get("lenteur", 1.0) / float(self.d.get("vitesse", 1.0))

    def _temps(self):
        avance = 0.15
        # les flèches automatiques se dessinent juste avant la case qu'elles visent
        ordre = [e for e in self.elts if not e.spec.get("_de")]
        fleches = [e for e in self.elts if e.spec.get("_de")]
        departs = {}
        for e in ordre:
            s = e.spec
            if "a" in s:
                departs[e.id] = float(s["a"])
            elif s.get("mot"):
                t = self.temps_du_mot(s["mot"], e.scene)
                if t is None:
                    self.note("✗", f"{e.id} : le mot « {s['mot']} » n'est pas dans le texte de la scène {e.scene + 1}")
                else:
                    departs[e.id] = max(0.0, t - avance)
        prec = None
        for e in ordre:
            if e.id in departs:
                e.t0 = departs[e.id]
            elif prec is None or prec.scene != e.scene:
                a, _ = self.plages[e.scene] if e.scene < len(self.plages) else (0, 0)
                e.t0 = max(0.0, (self.mots[a]["debut"] if a < len(self.mots) else 0.0) - avance)
            else:
                e.t0 = prec.t0 + min(self._ideal(prec), 2.5) + 0.1
            prec = e
        if not self.voix:
            # sans voix : les dessins s'enchaînent à leur rythme, avec un temps de lecture à chaque fin de scène
            t = 0.2
            for k, e in enumerate(ordre):
                if k and e.scene != ordre[k - 1].scene:
                    t += float(self.d.get("pause", 1.0)) + (0.5 if self.affichage in ("successifs", "melange") else 0)
                e.t0 = float(e.spec["a"]) if "a" in e.spec else t
                t = e.t0 + float(e.spec.get("duree", self._ideal(e))) + 0.12
            self.duree_voix = t
        tri = sorted(ordre, key=lambda e: e.t0)
        fin_voix = self.duree_voix
        for k, e in enumerate(tri):
            suivant = tri[k + 1].t0 if k + 1 < len(tri) else max(fin_voix + 0.4, e.t0 + self._ideal(e))
            dispo = suivant - e.t0 - 0.08
            if "duree" in e.spec:
                d = float(e.spec["duree"])
            else:
                d = min(dispo, self._ideal(e) * 1.25)
                d = max(d, min(self._ideal(e), dispo)) if dispo > 0.7 else max(0.7, dispo)
            if dispo < 0.7 and k + 1 < len(tri):
                self.note("⚠", f"{e.id} : seulement {dispo:.1f} s avant le dessin suivant (la main va courir)")
            col = e.calques.a_couleur and e.mode_couleur in ("remplit", "fondu")
            if e.type == "photo":
                e.dt, e.dc = d * 0.4, d * 0.6
                e.fondu_c = e.spec.get("couleur") == "fondu"
            elif col and e.mode_couleur == "remplit":
                e.dt, e.dc = d * 0.62, d * 0.38
            elif col:
                e.dt, e.dc = d * 0.82, max(0.3, d * 0.18)
            else:
                e.dt, e.dc = d, 0.0
        for f in fleches:
            cible = self.par_id[f.spec["_vers"]]
            f.dt = 0.32
            f.t0 = max(0.0, cible.t0 - 0.12)
            cible.t0 += 0.22
            cible.dt = max(0.4, cible.dt - 0.15)
            cible.dc = max(0.0, cible.dc - 0.07) if cible.dc else 0.0
        # pages : on efface la précédente avant la suivante
        if self.affichage in ("successifs", "melange"):
            tr = self.d.get("transition", "efface")
            nb = len(self.d.get("scenes", []))
            for si in range(1, nb):
                nouv = [e for e in self.elts if e.page == si]
                anc = [e for e in self.elts if e.page == si - 1]
                if not nouv or not anc:
                    continue
                t_n = min(e.t0 for e in nouv)
                if tr == "glisse":
                    for e in nouv:
                        e.t0 = max(e.t0, t_n + 0.25)
                    continue
                t_e = max(t_n - 0.5, max(e.fin for e in anc) + 0.15)
                decal = max(0.0, t_e + 0.5 - t_n)
                if decal > 0:
                    for e in nouv:
                        e.t0 += decal
                for e in anc:
                    e.t_efface = t_e
                    e.mode_efface = tr
        fin_dessins = max((e.fin for e in self.elts), default=0)
        self.t_dessins = fin_dessins
        self.recul = self.affichage == "fresque" and self.d.get("recul", True)
        self.duree = max(fin_voix, fin_dessins) + (1.7 if self.recul else 0) + float(self.d.get("fin", 1.5))
        if "duree" in self.d:
            self.duree = max(self.duree, float(self.d["duree"]))

    # ------------------------------------------------------------ caméra
    def _vue_pour(self, bbox, marge=1.45, mini=None):
        x, y, w, h = bbox
        mini = mini or self.CW / 2.6
        vw = max(w * marge, h * marge * W / H, mini)
        vw = min(vw, self.CW)
        vh = vw * H / W
        cx = min(max(x + w / 2, vw / 2), self.CW - vw / 2)
        cy = min(max(y + h / 2, vh / 2), self.CH - vh / 2)
        return (cx, cy, vw)

    def _camera(self):
        tout = (self.CW / 2, self.CH / 2, self.CW)
        self.segs = []  # (ta, tb, vue_a, vue_b)
        cam = self.d.get("camera", "suit" if self.affichage == "fresque" else "fixe")
        if self.affichage == "fresque" and cam != "fixe":
            vue = None
            cible = None
            for e in sorted(self.elts, key=lambda e: e.t0):
                if e.type in ("texte", "fleche") and cible is not None:
                    x, y, w, h = e.box
                    cx0, cy0, cw0, ch0 = cible
                    ux0, uy0 = min(x, cx0), min(y, cy0)
                    ux1, uy1 = max(x + w, cx0 + cw0), max(y + h, cy0 + ch0)
                    bb = (ux0, uy0, ux1 - ux0, uy1 - uy0)
                else:
                    bb = e.box
                    cible = e.box
                v = self._vue_pour(bb, e.spec.get("marge", 1.4))
                if vue is None:
                    self.segs.append((-1.0, 0.0, v, v))
                elif abs(v[0] - vue[0]) + abs(v[1] - vue[1]) + abs(v[2] - vue[2]) > 0.04 * self.CW:
                    ta = max(self.segs[-1][1], e.t0 - 0.55)
                    self.segs.append((ta, max(ta + 0.4, e.t0 + 0.2), vue, v))
                else:
                    v = vue
                vue = v
            if self.recul and vue is not None:
                ta = self.t_dessins + 0.25
                self.segs.append((ta, ta + 1.6, vue, self._vue_pour((0, 0, self.CW, self.CH), 1.0, self.CW)))
        elif self.d.get("transition") == "glisse" and self.affichage in ("successifs", "melange"):
            nb = len(self.d.get("scenes", []))
            vue = (W / 2, H / 2, W)
            self.segs.append((-1.0, 0.0, vue, vue))
            for si in range(1, nb):
                nouv = [e for e in self.elts if e.page == si]
                if not nouv:
                    continue
                t_n = min(e.t0 for e in nouv)
                v = (W / 2, H / 2 + si * H, W)
                self.segs.append((t_n - 0.6, t_n + 0.2, vue, v))
                vue = v
        elif cam == "suit":  # tableau : léger rapprochement sur la case en cours
            vue = (W / 2, H / 2, W)
            self.segs.append((-1.0, 0.0, vue, vue))
            for e in sorted(self.elts, key=lambda e: e.t0):
                if e.type in ("texte", "fleche"):
                    continue
                v = self._vue_pour(e.box, 2.2, W * 0.78)
                v = (v[0] * 0.5 + W / 4, v[1] * 0.5 + H / 4, v[2])
                self.segs.append((e.t0 - 0.4, e.t0 + 0.3, vue, v))
                vue = v
            fin = self.t_dessins + 0.2
            self.segs.append((fin, fin + 1.0, vue, tout))
        if not self.segs:
            self.segs.append((-1.0, 0.0, tout, tout))
        self.respire = self.d.get("respire", 0.03 if self.affichage != "fresque" else 0.0)

    def vue(self, t):
        v = self.segs[0][2]
        for ta, tb, va, vb in self.segs:
            if t < ta:
                break
            if t >= tb:
                v = vb
            else:
                p = lisse((t - ta) / max(tb - ta, 1e-6))
                lw = math.exp(math.log(va[2]) * (1 - p) + math.log(vb[2]) * p)
                v = (va[0] + (vb[0] - va[0]) * p, va[1] + (vb[1] - va[1]) * p, lw)
                break
        if self.respire:
            k = 1 - self.respire * (0.5 + 0.5 * math.sin(t / max(self.duree, 1) * math.pi - math.pi / 2))
            v = (v[0], v[1], v[2] * k)
        return v

    def vers_ecran(self, x, y, t, v=None):
        cx, cy, vw = v or self.vue(t)
        s = W / vw
        return (x - cx) * s + W / 2, (y - cy) * s + H / 2

    # ------------------------------------------------------------ fond
    def _fond(self):
        f = self.coul["fond"]
        base = np.zeros((self.CH, self.CW, 3), np.float32) + np.array(f, np.float32)
        if self.tableau:
            g = T.bruit_doux(self.CW, self.CH, int(180 * self.k), 5)
            g2 = T.bruit_doux(self.CW, self.CH, int(30 * self.k), 9)
            fin = np.random.default_rng(2).random((self.CH, self.CW)).astype(np.float32)
            base += ((g - 0.5) * 22 + (g2 - 0.5) * 8 + (fin - 0.5) * 7)[..., None]
            # traces d'effacement
            tr = T.bruit_doux(self.CW, self.CH, int(260 * self.k), 21)
            base += (np.clip(tr - 0.62, 0, 1) * 40)[..., None]
        elif self.style == "croquis":
            fin = np.random.default_rng(2).random((self.CH, self.CW)).astype(np.float32)
            base -= ((fin - 0.5) * 6)[..., None]
        self.fond_im = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8)).convert("RGBA")

    # ------------------------------------------------------------ la main
    def _main(self):
        m = self.d.get("main", self.st["main"])
        self.main = None
        if m in (None, "aucune", False):
            return
        info = json.load(open(os.path.join(SKILL, "assets", "mains", "mains.json")))
        if m in info:
            src, pointe = os.path.join(SKILL, "assets", "mains", f"{m}.png"), info[m]["pointe"]
        else:
            src = self._chemin(m)
            if not os.path.exists(src):
                sys.exit(f"Main introuvable : {src}")
            pointe = self.d.get("main_pointe")
            if not pointe:
                a = np.asarray(Image.open(src).convert("RGBA"))[..., 3] > 128
                ys, xs = np.nonzero(a)
                k = int(np.argmin(xs + ys))
                pointe = [int(xs[k]) + 4, int(ys[k]) + 4]
        im = Image.open(src).convert("RGBA")
        taille = self.d.get("main_taille", self.st["main_taille"])
        s = taille / im.width
        self.main = im.resize((int(im.width * s), int(im.height * s)), Image.LANCZOS)
        self.pointe = (pointe[0] * s, pointe[1] * s)
        ombre = Image.new("RGBA", self.main.size, (0, 0, 0, 0))
        a = self.main.split()[3].filter(ImageFilter.GaussianBlur(14)).point(lambda v: int(v * (0.32 if self.tableau else 0.2)))
        ombre.putalpha(a)
        self.ombre = ombre
        # intervalles de dessin, dans l'ordre
        self.gestes = []
        for e in self.elts:
            if e.dt > 0:
                self.gestes.append((e.t0, e.t0 + e.dt, e, False))
            if e.dc > 0 and not e.fondu_c and e.calques.a_couleur and len(e.calques.chemin_c):
                self.gestes.append((e.t0 + e.dt, e.t0 + e.dt + e.dc, e, True))
        self.gestes.sort(key=lambda g: g[0])

    def _pointe_geste(self, g, t):
        ta, tb, e, coul = g
        u = min(1.0, max(0.0, (t - ta) / max(tb - ta, 1e-6)))
        x, y = e.calques.pointe(u, coul)
        return self.vers_ecran(e.box[0] + x, e.box[1] + y, t)

    def position_main(self, t):
        """(x, y) de la pointe à l'écran, et si elle dessine."""
        if not self.main or not self.gestes:
            return None, False
        repos = (W + 260, H + 420)
        cour = [g for g in self.gestes if g[0] <= t < g[1]]
        if cour:
            return self._pointe_geste(cour[-1], t), True
        avant = [g for g in self.gestes if g[1] <= t]
        apres = [g for g in self.gestes if g[0] > t]
        pa = self._pointe_geste(avant[-1], avant[-1][1]) if avant else None
        pb = self._pointe_geste(apres[0], apres[0][0]) if apres else None
        ta = avant[-1][1] if avant else None
        tb = apres[0][0] if apres else None
        if pa and pb and tb - ta < 1.1:
            p = lisse((t - ta) / (tb - ta))
            lev = math.sin(p * math.pi) * 40
            return (pa[0] + (pb[0] - pa[0]) * p, pa[1] + (pb[1] - pa[1]) * p - lev), False
        if pa and t - ta < 0.5:
            p = lisse((t - ta) / 0.5)
            return (pa[0] + (repos[0] - pa[0]) * p, pa[1] + (repos[1] - pa[1]) * p), False
        if pb and tb - t < 0.5:
            p = lisse(1 - (tb - t) / 0.5)
            return (repos[0] + (pb[0] - repos[0]) * p, repos[1] + (pb[1] - repos[1]) * p), False
        return None, False

    # ------------------------------------------------------------ sous-titres
    def _groupes(self):
        if hasattr(self, "_gr"):
            return self._gr
        gr, cour = [], []
        for i, m in enumerate(self.mots):
            if not M.norm(m["mot"]) and not cour and gr:  # « ! » seul : on le colle au groupe d'avant
                gr[-1].append(i)
                continue
            cour.append(i)
            txt = " ".join(self.mots[j]["mot"] for j in cour)
            if len(cour) >= 4 or len(txt) >= 22 or m["mot"][-1:] in ".!?:,":
                gr.append(cour)
                cour = []
        if cour:
            gr.append(cour)
        self._gr = gr
        return gr

    def sous_titre(self, t):
        if not self.sous_titres or not self.voix:
            return None
        gr = self._groupes()
        for k, g in enumerate(gr):
            d0 = self.mots[g[0]]["debut"] - 0.05
            f = self.mots[gr[k + 1][0]]["debut"] - 0.05 if k + 1 < len(gr) else self.mots[g[-1]]["fin"] + 0.4
            if d0 <= t < f:
                actif = max([j for j in g if self.mots[j]["debut"] <= t] or [g[0]])
                cle = (k, actif)
                if cle not in self._st_cache:
                    self._st_cache[cle] = self._dessiner_st([self.mots[j]["mot"] for j in g], g.index(actif))
                return self._st_cache[cle]
        return None

    def _dessiner_st(self, mots, actif):
        taille = 58
        while True:
            f = ImageFont.truetype(police("Geist.ttf"), taille)
            try:
                f.set_variation_by_axes([800])
            except Exception:
                pass
            esp = f.getlength(" ")
            lw = [f.getlength(m) for m in mots]
            tot = sum(lw) + esp * (len(mots) - 1)
            if tot < 780 or taille < 40:
                break
            taille -= 4
        sombre = self.tableau
        pw, ph = int(tot + 56), int(taille * 1.55)
        im = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([0, 0, pw - 1, ph - 1], radius=ph // 2, fill=(20, 24, 22, 205) if sombre else (255, 255, 255, 228))
        x = 28
        for k, (m, l) in enumerate(zip(mots, lw)):
            c = self.coul["accent"] if k == actif else ((245, 245, 240) if sombre else self.coul["encre"])
            d.text((x, ph / 2), m, font=f, fill=c + (255,), anchor="lm")
            x += l + esp
        return im

    # ------------------------------------------------------------ une image
    def image(self, t):
        cx, cy, vw = self.vue(t)
        vh = vw * H / W
        x0, y0 = int(round(cx - vw / 2)), int(round(cy - vh / 2))
        bw, bh = int(round(vw)), int(round(vh))
        cadre = self.fond_im.crop((x0, y0, x0 + bw, y0 + bh))
        for e in self.elts:
            ex, ey, ew, eh = e.box
            if ex > x0 + bw or ey > y0 + bh or ex + ew < x0 or ey + eh < y0 or t < e.t0:
                continue
            im = e.etat(t)
            if im is None:
                continue
            dx, dy = ex - x0, ey - y0
            sx, sy = max(0, -dx), max(0, -dy)
            ex1, ey1 = min(ew, bw - dx), min(eh, bh - dy)
            if ex1 <= sx or ey1 <= sy:
                continue
            cadre.alpha_composite(im, dest=(dx + sx, dy + sy), source=(sx, sy, ex1, ey1))
        if (bw, bh) != (W, H):
            cadre = cadre.resize((W, H), Image.BICUBIC if bw < W else Image.LANCZOS if bw > 1.5 * W else Image.BILINEAR)
        pos, _ = self.position_main(t)
        if pos is not None:
            wob = math.sin(t * 7.1) * 2.0
            x = int(pos[0] - self.pointe[0] + wob)
            y = int(pos[1] - self.pointe[1] + math.cos(t * 5.3) * 2.0)
            for im, (ox, oy) in ((self.ombre, (26, 30)), (self.main, (0, 0))):
                X, Y = x + ox, y + oy
                sx, sy = max(0, -X), max(0, -Y)
                ex1, ey1 = min(im.width, W - X), min(im.height, H - Y)
                if ex1 > sx and ey1 > sy:
                    cadre.alpha_composite(im, dest=(X + sx, Y + sy), source=(sx, sy, ex1, ey1))
        st = self.sous_titre(t)
        if st is not None:
            cadre.alpha_composite(st, dest=(int(515 - st.width / 2), int(1395 - st.height / 2)))
        return cadre.convert("RGB")

    def vitesse_main(self, ta, tb):
        """Vitesse médiane de la pointe à l'écran (px/s) entre ta et tb."""
        vs, prec = [], None
        for i in range(int(ta * self.fps) + 1, int(tb * self.fps)):
            pos, dessine = self.position_main(i / self.fps)
            if pos is not None and prec is not None and dessine:
                vs.append(math.hypot(pos[0] - prec[0], pos[1] - prec[1]) * self.fps)
            prec = pos
        return float(np.median(vs)) if vs else 0.0

    def trace(self):
        """Pour le son du trait : à chaque image, la main dessine-t-elle et à quelle vitesse."""
        res, prec = [], None
        for i in range(int(self.duree * self.fps)):
            t = i / self.fps
            pos, dessine = self.position_main(t)
            v = 0.0
            if pos is not None and prec is not None:
                v = math.hypot(pos[0] - prec[0], pos[1] - prec[1]) * self.fps
            res.append([1 if dessine else 0, round(v, 1)])
            prec = pos
        return {"fps": self.fps, "style": self.style, "images": res}


# ---------------------------------------------------------------- rendu vidéo (en parallèle)
_V = None


def _init(chemin):
    global _V
    if _V is None:
        _V = Video(chemin)


def _une(i):
    return _V.image(i / _V.fps).tobytes()


def rendre(chemin, sortie, jusqua=None, qualite="normale", process=None):
    global _V
    _V = Video(chemin)
    v = _V
    fin = min(v.duree, jusqua) if jusqua else v.duree
    n_im = int(round(fin * v.fps))
    os.makedirs(os.path.dirname(os.path.abspath(sortie)), exist_ok=True)
    crf, debit = ("19", "9M") if qualite == "normale" else ("24", "4M")
    cmd = [ffmpeg_exe(), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(v.fps),
           "-i", "-", "-c:v", "libx264", "-preset", "medium", "-crf", crf, "-maxrate", debit, "-bufsize", "18M",
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", sortie]
    ff = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    t_debut = time.time()
    n = process or max(1, min(12, (os.cpu_count() or 2) - 1))
    if n > 1:
        ctx = mp.get_context("fork" if sys.platform != "win32" else "spawn")
        with ctx.Pool(n, initializer=_init, initargs=(chemin,)) as pool:
            for k, b in enumerate(pool.imap(_une, range(n_im), chunksize=3)):
                ff.stdin.write(b)
                if k % (v.fps * 3) == 0:
                    print(f"  {k / v.fps:5.1f} s / {fin:.1f} s", flush=True)
    else:
        for i in range(n_im):
            ff.stdin.write(v.image(i / v.fps).tobytes())
    ff.stdin.close()
    ff.wait()
    calc = time.time() - t_debut
    json.dump(v.trace(), open(os.path.join(os.path.dirname(os.path.abspath(sortie)), "trace.json"), "w"))
    print(f"Vidéo muette : {sortie} ({fin:.1f} s, {os.path.getsize(sortie) / 1e6:.1f} Mo, calcul {calc:.0f} s)")
    return v, calc


# ---------------------------------------------------------------- contrôle
def zones(im):
    im = im.convert("RGBA")
    c = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(c)
    r = (230, 40, 60, 60)
    d.rectangle([0, 0, W, ZONE_HAUT], fill=r)
    d.rectangle([0, ZONE_BAS, W, H], fill=r)
    d.rectangle([ZONE_DROITE, ZONE_DROITE_Y, W, ZONE_BAS], fill=r)
    im.alpha_composite(c)
    return im.convert("RGB")


def vignette(im, legende, w=270):
    h = int(w * im.height / im.width)
    out = Image.new("RGB", (w, h + 34), (34, 34, 38))
    out.paste(im.resize((w, h), Image.LANCZOS), (0, 0))
    f = ImageFont.truetype(police("Geist.ttf"), 18)
    ImageDraw.Draw(out).text((6, h + 7), legende[:40], font=f, fill=(235, 235, 235))
    return out


def planche(v, sortie, moments):
    ims = [vignette(zones(v.image(t)), f"{t:.2f} s {leg}") for t, leg in moments]
    cols = 6
    w, h = ims[0].size
    pl = Image.new("RGB", (cols * (w + 10) + 10, math.ceil(len(ims) / cols) * (h + 10) + 60), (24, 24, 28))
    f = ImageFont.truetype(police("Geist.ttf"), 24)
    ImageDraw.Draw(pl).text((14, 16), f"Planche · {os.path.basename(v.chemin)} · {v.style} · {v.affichage} · {v.duree:.1f} s", font=f, fill=(240, 240, 240))
    for k, im in enumerate(ims):
        pl.paste(im, (10 + (k % cols) * (w + 10), 60 + (k // cols) * (h + 10)))
    os.makedirs(os.path.dirname(os.path.abspath(sortie)), exist_ok=True)
    pl.save(sortie, quality=88)


def verifier(v, dossier):
    pb = list(v.problemes)
    ok = []
    for e in v.elts:
        if e.dt <= 0:
            continue
        vit = v.vitesse_main(e.t0, e.t0 + e.dt)
        lib = f"{e.id} ({e.type}, {e.t0:.1f}→{e.fin:.1f} s)"
        if e.type not in ("texte", "fleche", "photo"):
            if vit > 3200:
                pb.append(("✗", f"{lib} : main trop rapide ({vit:.0f} px/s à l'écran). Simplifier le dessin, le découper en zones ou lui laisser plus de temps"))
            elif vit > 2000:
                pb.append(("⚠", f"{lib} : main rapide ({vit:.0f} px/s)"))
        if e.type == "texte":
            taille = e.taille * W / v.vue(e.fin)[2]
            if taille < 40:
                pb.append(("✗", f"{lib} : texte trop petit à l'écran ({taille:.0f} px, il faut 40 px ou plus)"))
            x0, y0 = v.vers_ecran(e.box[0], e.box[1], e.fin)
            x1, y1 = v.vers_ecran(e.box[0] + e.box[2], e.box[1] + e.box[3], e.fin)
            if 0 <= x0 and x1 <= W and 0 <= y0 and y1 <= H:
                if y0 < ZONE_HAUT or y1 > ZONE_BAS or (x1 > ZONE_DROITE and y1 > ZONE_DROITE_Y):
                    pb.append(("✗", f"{lib} : « {e.spec['texte'][:24]} » touche une zone cachée par TikTok/Reels"))
            elif v.affichage != "fresque":
                pb.append(("✗", f"{lib} : texte coupé par le bord de l'écran"))
        if e.calques.longueur <= 0 and e.type != "photo":
            pb.append(("✗", f"{lib} : aucun trait trouvé (image vide ou trop claire ?)"))
    # trous : rien ne bouge pendant que la voix parle
    gestes = sorted((e.t0, e.fin) for e in v.elts)
    fin_prec = 0.0
    for a, b in gestes:
        if a - fin_prec > 2.5 and a < v.duree_voix:
            pb.append(("⚠", f"rien ne se dessine entre {fin_prec:.1f} et {a:.1f} s"))
        fin_prec = max(fin_prec, b)
    tenue = v.duree - max(v.t_dessins, v.duree_voix)
    (ok if tenue >= 1.0 else pb).append(("✓" if tenue >= 1 else "✗", f"fin tenue {tenue:.1f} s"))
    if not v.tableau and sum(v.coul["fond"]) < 360:
        pb.append(("⚠", "fond sombre : les fonds clairs sont la règle (sauf craie)"))
    if v.main is None and v.d.get("main") not in ("aucune", None, False):
        pb.append(("✗", "main introuvable"))
    ok.append(("✓", f"durée {v.duree:.1f} s · voix {v.duree_voix:.1f} s · temps des mots : {v.tl['source']}"))
    moments = []
    for e in sorted(v.elts, key=lambda e: e.t0):
        if e.type == "fleche":
            continue
        moments.append((e.t0 + e.dt * 0.55, f"{e.id} trace"))
        moments.append((min(v.duree - 0.05, e.fin + 0.02), f"{e.id} fini"))
    moments.append((v.duree - 0.05, "fin"))
    planche(v, os.path.join(dossier, "planche.jpg"), moments[:30])
    print(f"Vérification de {os.path.basename(v.chemin)} ({v.style}, {v.affichage})")
    for niv, msg in ok + pb:
        print(f"  {niv} {msg}")
    print("Textes à l'écran :")
    for e in v.elts:
        if e.type == "texte":
            print(f"  « {e.spec['texte']} » à {e.t0:.1f} s")
    print(f"Planche : {os.path.join(dossier, 'planche.jpg')}")
    return not any(n == "✗" for n, _ in pb)


def catalogue():
    print("Styles :", ", ".join(STYLES), "  (\"tableau\": vert, noir, bleu = n'importe quel style sur un tableau)")
    print("Affichages :", ", ".join(AFFICHAGES))
    print("Éléments : image (src, zones), dessin (sujet, options), texte (texte, role titre), photo (src), fleche (de, vers)")
    print("Clés d'élément : id, mot, a, duree, lenteur, place [x, y, largeur], pres {id, cote}, couleur remplit/fondu/aucune")
    print("Croquis :")
    for k, (_, aide) in croquis.SUJETS.items():
        print(f"  {k:12s} {aide}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video", nargs="?")
    ap.add_argument("--verifier", action="store_true")
    ap.add_argument("--image", type=float)
    ap.add_argument("--essai", action="store_true")
    ap.add_argument("--catalogue", action="store_true")
    ap.add_argument("--qualite", default="normale", choices=["normale", "legere"])
    ap.add_argument("--son-trait", action="store_true", help="ajoute un bruit de feutre très bas (désactivé par défaut)")
    ap.add_argument("--process", type=int)
    a = ap.parse_args()
    if a.catalogue or not a.video:
        catalogue()
        return
    dossier = os.path.dirname(os.path.abspath(a.video))
    ctrl, sortie = os.path.join(dossier, "controle"), os.path.join(dossier, "sortie")
    if a.verifier:
        sys.exit(0 if verifier(Video(a.video), ctrl) else 1)
    if a.image is not None:
        os.makedirs(ctrl, exist_ok=True)
        p = os.path.join(ctrl, f"image-{a.image:g}.png")
        Video(a.video).image(a.image).save(p)
        print(p)
        return
    if a.essai:
        v, calc = rendre(a.video, os.path.join(sortie, "essai.mp4"), jusqua=3.0, process=a.process)
        print(f"Estimation pour {v.duree:.1f} s : environ {calc / 3 * v.duree:.0f} s de calcul")
        return
    v, _ = rendre(a.video, os.path.join(sortie, "muette.mp4"), qualite=a.qualite, process=a.process)
    import son
    son.assembler(os.path.join(sortie, "muette.mp4"), os.path.join(sortie, "trace.json"), v.voix, v.voix_a,
                  os.path.join(sortie, "video.mp4"), trait=a.son_trait or bool(v.d.get("son_trait", False)))


if __name__ == "__main__":
    main()
