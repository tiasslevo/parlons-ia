"""Le tracé : transforme un dessin en calques qui se révèlent dans l'ordre où une main les tracerait.

Trois sources :
- une image (dessin généré sur fond blanc) : les traits foncés sont suivis de proche en proche (le
  trait avance le long de la ligne, pas en balayage) ; la couleur se remplit ensuite par zones ;
- des traits en code (croquis.py) : l'ordre est exactement celui des traits ;
- un texte manuscrit : il s'écrit de gauche à droite.

Chaque source donne un objet Calques : le trait (alpha + couleur), l'ordre d'apparition de chaque
pixel (0 → 1), le chemin de la pointe (pour la main), et la même chose pour la couleur.
Le calcul d'une image est gardé en cache (fichier .trace.npz à côté de l'image).
"""
import hashlib
import math
import os
from collections import deque

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

JAMAIS = 2.0  # ordre des pixels qui n'apparaissent qu'à la fin (poussières)


class Calques:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.trait_a = np.zeros((h, w), np.float32)
        self.trait_rgb = np.zeros((h, w, 3), np.uint8)
        self.ordre = np.full((h, w), JAMAIS, np.float32)
        self.chemin = np.zeros((0, 3), np.float32)       # u, x, y
        self.coul_a = None
        self.coul_rgb = None
        self.ordre_c = None
        self.chemin_c = np.zeros((0, 3), np.float32)
        self.longueur = 0.0                              # longueur du trajet de la pointe (px)
        self.longueur_c = 0.0
        self.nettete = 1500.0   # bord du trait révélé : plus grand = la pointe colle au trait
        self._final = None

    @property
    def a_couleur(self):
        return self.coul_a is not None and float(self.coul_a.max()) > 0.05

    def etat(self, p, q=0.0, efface=0.0, fondu_c=False):
        """Image RGBA (numpy uint8) du dessin : trait révélé jusqu'à p, couleur jusqu'à q."""
        if p >= 1 and (q >= 1 or not self.a_couleur) and efface <= 0:
            return self.final()
        k = self.nettete
        a_t = self.trait_a if p >= 1 else self.trait_a * np.clip((p - self.ordre) * k + 0.5, 0, 1)
        rgb = self.trait_rgb.astype(np.float32)
        out_a = a_t
        out_rgb = rgb
        if self.a_couleur and q > 0:
            if fondu_c:
                a_c = self.coul_a * min(1.0, q)
            elif q >= 1:
                a_c = self.coul_a
            else:
                a_c = self.coul_a * np.clip((q - self.ordre_c) * 40.0, 0, 1)
            out_a = a_c + a_t * (1 - a_c)
            div = np.maximum(out_a, 1e-4)[..., None]
            out_rgb = (self.coul_rgb.astype(np.float32) * a_c[..., None] + rgb * (a_t * (1 - a_c))[..., None]) / div
        if efface > 0:
            out_a = out_a * (1 - np.clip((efface * 1.25 - self.ordre_efface()) * 12, 0, 1))
        return np.dstack([np.clip(out_rgb, 0, 255).astype(np.uint8), (np.clip(out_a, 0, 1) * 255).astype(np.uint8)])

    def final(self):
        if self._final is None:
            a_t = self.trait_a
            rgb = self.trait_rgb.astype(np.float32)
            if self.a_couleur:
                a_c = self.coul_a
                out_a = a_c + a_t * (1 - a_c)
                div = np.maximum(out_a, 1e-4)[..., None]
                rgb = (self.coul_rgb.astype(np.float32) * a_c[..., None] + rgb * (a_t * (1 - a_c))[..., None]) / div
            else:
                out_a = a_t
            self._final = np.dstack([np.clip(rgb, 0, 255).astype(np.uint8), (np.clip(out_a, 0, 1) * 255).astype(np.uint8)])
        return self._final

    def ordre_efface(self):
        if getattr(self, "_oe", None) is None:
            xs = np.linspace(0, 1, self.w, dtype=np.float32)[None, :]
            self._oe = xs * 0.8 + bruit_doux(self.w, self.h, 7, graine=self.w) * 0.2
        return self._oe

    def pointe(self, u, couleur=False):
        """Position de la pointe (x, y dans le calque) à l'avancement u."""
        ch = self.chemin_c if couleur else self.chemin
        if len(ch) == 0:
            return self.w / 2, self.h / 2
        return float(np.interp(u, ch[:, 0], ch[:, 1])), float(np.interp(u, ch[:, 0], ch[:, 2]))


# ---------------------------------------------------------------- outils
def bruit_doux(w, h, cellule=12, graine=0):
    """Bruit lisse 0..1 (pour des bords irréguliers)."""
    rng = np.random.default_rng(graine)
    gw, gh = max(2, w // cellule + 2), max(2, h // cellule + 2)
    g = Image.fromarray((rng.random((gh, gw)) * 255).astype(np.uint8))
    return np.asarray(g.resize((w, h), Image.BICUBIC), np.float32) / 255.0


def grain(w, h, graine=1, fin=0.55):
    """Texture de craie ou de crayon : 1 = plein, ~fin = trou."""
    rng = np.random.default_rng(graine)
    g = rng.random((h, w)).astype(np.float32)
    g2 = bruit_doux(w, h, 3, graine + 7)
    return np.clip(fin + (1 - fin) * (0.55 * g + 0.45 * g2) * 1.6, 0, 1)


def _cle_cache(chemin, *params):
    st = os.stat(chemin)
    h = hashlib.md5(f"{os.path.abspath(chemin)}|{st.st_size}|{st.st_mtime}|{params}".encode()).hexdigest()[:10]
    return h


def _dilater(m, n=1):
    for _ in range(n):
        d = m.copy()
        d[1:, :] |= m[:-1, :]
        d[:-1, :] |= m[1:, :]
        d[:, 1:] |= m[:, :-1]
        d[:, :-1] |= m[:, 1:]
        m = d
    return m


def _bfs(flat, W, depart, etiq, lab, voisins):
    """Parcours en largeur dans le masque (liste plate) depuis depart. Retourne pixels et distances."""
    pix, dist = [depart], [0]
    lab[depart] = etiq
    q = deque([(depart, 0)])
    while q:
        i, d = q.popleft()
        for o in voisins:
            j = i + o
            if flat[j] and lab[j] < 0:
                lab[j] = etiq
                pix.append(j)
                dist.append(d + 1)
                q.append((j, d + 1))
    return pix, dist


def _ordre_masque(masque, cote_max=560, depart=(0.0, 0.0), poids_saut=0.25, mini=4):
    """Ordre de tracé d'un masque de traits. Retourne (ordre plein format, chemin [u,x,y], longueur)."""
    H0, W0 = masque.shape
    f = min(1.0, cote_max / max(H0, W0))
    h, w = max(2, int(H0 * f)), max(2, int(W0 * f))
    petit = np.asarray(Image.fromarray((masque * 255).astype(np.uint8)).resize((w, h), Image.BOX), np.float32) > 40
    petit = _dilater(petit, 1)
    P = np.zeros((h + 2, w + 2), bool)
    P[1:-1, 1:-1] = petit
    W = w + 2
    flat = P.ravel().tolist()
    lab = [-1] * len(flat)
    voisins = (-W - 1, -W, -W + 1, -1, 1, W - 1, W, W + 1)
    comps = []
    for s in np.flatnonzero(P.ravel()).tolist():
        if lab[s] >= 0:
            continue
        pix, _ = _bfs(flat, W, s, len(comps), lab, voisins)
        comps.append(np.array(pix, np.int64))
    ordre_p = np.full((h + 2) * W, -1.0, np.float32)
    grands = [c for c in comps if len(c) >= mini]
    if not grands:
        return np.full((H0, W0), JAMAIS, np.float32), np.zeros((0, 3), np.float32), 0.0
    rng = np.random.default_rng(3)
    echant = []
    for c in grands:
        e = c if len(c) <= 48 else c[rng.choice(len(c), 48, replace=False)]
        echant.append(np.stack([e % W, e // W], 1).astype(np.float32))
    restant = list(range(len(grands)))
    stylo = np.array([depart[0] * f + 1, depart[1] * f + 1], np.float32)
    lab2 = [-1] * len(flat)
    segments = []  # (comp_pix, dist, chemin_local, saut)
    u = 0.0
    morceaux = []
    while restant:
        tous = np.concatenate([echant[k] for k in restant])
        qui = np.concatenate([[k] * len(echant[k]) for k in restant])
        dd = ((tous - stylo) ** 2).sum(1)
        k = int(qui[int(np.argmin(dd))])
        restant.remove(k)
        c = grands[k]
        cx, cy = c % W, c // W
        i0 = int(np.argmin((cx - stylo[0]) ** 2 + (cy - stylo[1]) ** 2))
        saut = math.hypot(cx[i0] - stylo[0], cy[i0] - stylo[1])
        flat_c = [False] * len(flat)
        for j in c.tolist():
            flat_c[j] = True
        pix, dist = _bfs(flat_c, W, int(c[i0]), 0, lab2, voisins)
        pix = np.array(pix, np.int64)
        dist = np.array(dist, np.float32)
        maxd = float(dist.max()) if len(dist) else 0.0
        poids = len(pix) / 3.0 + 1.0  # le temps suit la quantité d'encre, pas le nombre de petits bouts
        u += saut * poids_saut
        # chemin de la pointe : à chaque distance, le pixel du front le plus proche du précédent
        px, py = (pix % W).astype(np.float32), (pix // W).astype(np.float32)
        niveaux, debuts = np.unique(dist, return_index=True)
        fins = list(debuts[1:]) + [len(dist)]
        pts = []
        prec = np.array([px[0], py[0]])
        pas = max(1, len(niveaux) // 400)
        for n_i in range(0, len(niveaux), pas):
            a, b = debuts[n_i], fins[n_i]
            fx, fy = px[a:b], py[a:b]
            j = int(np.argmin((fx - prec[0]) ** 2 + (fy - prec[1]) ** 2))
            prec = np.array([fx[j], fy[j]])
            pts.append((u + (niveaux[n_i] / max(maxd, 1)) * poids, prec[0], prec[1]))
        ordre_p[pix] = u + (dist / max(maxd, 1)) * poids
        morceaux.extend(pts)
        u += poids
        stylo = np.array(pts[-1][1:], np.float32)
    total = max(u, 1e-6)
    ordre_p = np.where(ordre_p >= 0, ordre_p / total, JAMAIS).astype(np.float32)
    ch = np.array(morceaux, np.float32)
    ch[:, 0] /= total
    # lissage léger du chemin, puis retour au plein format
    if len(ch) > 5:
        for col in (1, 2):
            v = ch[:, col]
            ch[:, col] = np.convolve(np.pad(v, 2, mode="edge"), np.ones(5) / 5, mode="valid")
    ch[:, 1] = (ch[:, 1] - 1 + 0.5) / f
    ch[:, 2] = (ch[:, 2] - 1 + 0.5) / f
    longueur = float(np.hypot(np.diff(ch[:, 1]), np.diff(ch[:, 2])).sum()) if len(ch) > 1 else 0.0
    o = ordre_p.reshape(h + 2, W)[1:-1, 1:-1]
    o_plein = np.asarray(Image.fromarray(o, "F").resize((W0, H0), Image.NEAREST), np.float32)
    return o_plein, ch, longueur


def _ordre_couleur(masque, depart=(0, 0), cote_max=360, angle=35):
    """Remplissage de la couleur zone par zone, en balayage oblique, avec la main qui va et vient."""
    H0, W0 = masque.shape
    f = min(1.0, cote_max / max(H0, W0))
    h, w = max(2, int(H0 * f)), max(2, int(W0 * f))
    petit = np.asarray(Image.fromarray((masque * 255).astype(np.uint8)).resize((w, h), Image.BOX), np.float32) > 60
    petit = _dilater(petit, 2)
    P = np.zeros((h + 2, w + 2), bool)
    P[1:-1, 1:-1] = petit
    W = w + 2
    flat = P.ravel().tolist()
    lab = [-1] * len(flat)
    voisins = (-W, -1, 1, W)
    comps = []
    for s in np.flatnonzero(P.ravel()).tolist():
        if lab[s] >= 0:
            continue
        pix, _ = _bfs(flat, W, s, len(comps), lab, voisins)
        if len(pix) >= 12:
            comps.append(np.array(pix, np.int64))
    ordre_p = np.full((h + 2) * W, -1.0, np.float32)
    if not comps:
        return np.full((H0, W0), JAMAIS, np.float32), np.zeros((0, 3), np.float32), 0.0
    ca, sa = math.cos(math.radians(angle)), math.sin(math.radians(angle))
    bruit = bruit_doux(W, h + 2, 6, 11).ravel()
    stylo = np.array([depart[0] * f + 1, depart[1] * f + 1])
    restant = list(range(len(comps)))
    u, pts = 0.0, []
    while restant:
        centres = np.array([[np.mean(comps[k] % W), np.mean(comps[k] // W)] for k in restant])
        k = restant.pop(int(np.argmin(((centres - stylo) ** 2).sum(1))))
        c = comps[k]
        x, y = (c % W).astype(np.float32), (c // W).astype(np.float32)
        s = x * ca + y * sa
        pp = -x * sa + y * ca
        s0, s1 = float(s.min()), float(s.max())
        p0, p1 = float(pp.min()), float(pp.max())
        ls = max(s1 - s0, 1.0)
        poids = math.sqrt(len(c)) * 1.0 + 4
        loc = np.clip((s - s0) / ls * 0.88 + bruit[c] * 0.12, 0, 1)
        ordre_p[c] = u + loc * poids
        passes = max(2, int((s1 - s0) / 7))
        n = passes * 12
        for i in range(n + 1):
            t = i / n
            tri = abs(((t * passes) % 2) - 1)  # va-et-vient
            sv = s0 + t * (s1 - s0)
            pv = p0 + (0.15 + 0.7 * tri) * (p1 - p0)
            pts.append((u + t * poids, sv * ca - pv * sa, sv * sa + pv * ca))
        u += poids
        stylo = np.array(pts[-1][1:])
    total = max(u, 1e-6)
    ordre_p = np.where(ordre_p >= 0, ordre_p / total, JAMAIS).astype(np.float32)
    ch = np.array(pts, np.float32)
    ch[:, 0] /= total
    ch[:, 1] = (ch[:, 1] - 1 + 0.5) / f
    ch[:, 2] = (ch[:, 2] - 1 + 0.5) / f
    longueur = float(np.hypot(np.diff(ch[:, 1]), np.diff(ch[:, 2])).sum()) if len(ch) > 1 else 0.0
    o = ordre_p.reshape(h + 2, W)[1:-1, 1:-1]
    return np.asarray(Image.fromarray(o, "F").resize((W0, H0), Image.NEAREST), np.float32), ch, longueur


# ---------------------------------------------------------------- habillage selon le style
def habiller(c, style, couleurs, graine=0):
    """Applique le rendu du style au trait et à la couleur (craie, crayon…)."""
    encre = np.array(couleurs["encre"][:3], np.float32)
    c.trait_rgb[:] = encre.astype(np.uint8)
    if style == "craie":
        g = grain(c.w, c.h, graine + 1, 0.35)
        c.trait_a = c.trait_a * g
        if c.coul_a is not None:
            craie = np.array([245, 243, 236], np.float32)
            rgb = c.coul_rgb.astype(np.float32)
            c.coul_rgb = np.clip(rgb * 0.55 + craie * 0.45, 0, 255).astype(np.uint8)
            c.coul_a = c.coul_a * grain(c.w, c.h, graine + 5, 0.45) * 0.85
    elif style == "croquis":
        c.trait_a = c.trait_a * grain(c.w, c.h, graine + 2, 0.7) * 0.92
        if c.coul_a is not None:
            c.coul_a = c.coul_a * 0.85
    return c


# ---------------------------------------------------------------- 1. depuis une image
def depuis_image(chemin, largeur, style, couleurs, couleur=True, rect=None, masque_zone=None, cache=True):
    """chemin : dessin sur fond blanc (ou PNG transparent). rect : (x0, y0, x1, y1) en fractions."""
    im = Image.open(chemin)
    if im.mode in ("RGBA", "LA") or "transparency" in im.info:
        im = im.convert("RGBA")
        fond = Image.new("RGBA", im.size, (255, 255, 255, 255))
        fond.alpha_composite(im)
        im = fond
    im = im.convert("RGB")
    if rect:
        W0, H0 = im.size
        im = im.crop((int(rect[0] * W0), int(rect[1] * H0), int(rect[2] * W0), int(rect[3] * H0)))
    hauteur = max(2, int(round(largeur * im.height / im.width)))
    largeur = int(round(largeur))
    im = im.resize((largeur, hauteur), Image.LANCZOS)
    a = np.asarray(im, np.float32)
    if masque_zone is not None:
        mz = np.asarray(Image.fromarray((masque_zone * 255).astype(np.uint8)).resize((largeur, hauteur), Image.NEAREST)) > 127
        a = np.where(mz[..., None], a, 255.0)
    maxc, minc = a.max(2), a.min(2)
    c = Calques(largeur, hauteur)
    c.trait_a = np.clip((175 - maxc) / 115, 0, 1).astype(np.float32)
    cle = _cle_cache(chemin, largeur, rect, None if masque_zone is None else int(masque_zone.sum()), style, couleur) if cache else None
    fcache = os.path.join(os.path.dirname(os.path.abspath(chemin)), ".trace", f"{os.path.basename(chemin)}.{cle}.npz") if cache else None
    if fcache and os.path.exists(fcache):
        z = np.load(fcache)
        c.ordre, c.chemin, c.longueur = z["ordre"], z["chemin"], float(z["longueur"])
        if "ordre_c" in z:
            c.ordre_c, c.chemin_c, c.longueur_c = z["ordre_c"], z["chemin_c"], float(z["longueur_c"])
    else:
        c.ordre, c.chemin, c.longueur = _ordre_masque(c.trait_a > 0.3)
        if couleur:
            mc = (np.clip((246 - minc) / 40, 0, 1) > 0.35) & (c.trait_a < 0.5)
            fin = tuple(c.chemin[-1, 1:]) if len(c.chemin) else (0, 0)
            c.ordre_c, c.chemin_c, c.longueur_c = _ordre_couleur(mc, depart=fin)
        if fcache:
            os.makedirs(os.path.dirname(fcache), exist_ok=True)
            d = {"ordre": c.ordre, "chemin": c.chemin, "longueur": c.longueur}
            if c.ordre_c is not None:
                d.update(ordre_c=c.ordre_c, chemin_c=c.chemin_c, longueur_c=c.longueur_c)
            np.savez_compressed(fcache, **d)
    if couleur:
        c.coul_a = np.clip((248 - minc) / 40, 0, 1).astype(np.float32)
        c.coul_rgb = a.astype(np.uint8)
        if c.ordre_c is None:
            c.ordre_c = np.zeros_like(c.ordre)
        # les pixels foncés restent visibles comme trait ; la couleur garde l'original au final
    return habiller(c, style, couleurs, graine=largeur)


# ---------------------------------------------------------------- 2. depuis des traits en code
def _reechantillonner(pts, pas=3.0):
    pts = np.asarray(pts, np.float32)
    if len(pts) < 2:
        return pts
    seg = np.hypot(*np.diff(pts, axis=0).T)
    L = np.concatenate([[0], np.cumsum(seg)])
    if L[-1] < 1e-3:
        return pts[:1]
    n = max(2, int(L[-1] / pas) + 1)
    s = np.linspace(0, L[-1], n)
    return np.stack([np.interp(s, L, pts[:, 0]), np.interp(s, L, pts[:, 1])], 1)


def depuis_traits(traits, remplissages, w, h, style, couleurs, graine=0):
    """traits : [{"pts": [(x, y)…] en px, "ep": épaisseur, "coul": (r, g, b)}] dans l'ordre du tracé.
    remplissages : [{"poly": [(x, y)…], "coul": (r, g, b)}] posés après le trait."""
    w, h = int(round(w)), int(round(h))
    c = Calques(w, h)
    ss = 2
    big = Image.new("RGBA", (w * ss, h * ss), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)
    longueurs, res = [], []
    for t in traits:
        p = _reechantillonner(t["pts"], 2.5)
        res.append(p)
        longueurs.append(float(np.hypot(*np.diff(p, axis=0).T).sum()) if len(p) > 1 else 1.0)
        col = tuple(int(v) for v in t.get("coul", couleurs["encre"])[:3]) + (255,)
        ep = t.get("ep", 6) * ss
        pts = [(float(x) * ss, float(y) * ss) for x, y in p]
        if len(pts) > 1:
            d.line(pts, fill=col, width=int(round(ep)), joint="curve")
        for x, y in (pts[0], pts[-1]):
            d.ellipse([x - ep / 2, y - ep / 2, x + ep / 2, y + ep / 2], fill=col)
    small = big.resize((w, h), Image.LANCZOS)
    arr = np.asarray(small, np.float32)
    c.trait_a = arr[..., 3] / 255.0
    c.trait_rgb = arr[..., :3].astype(np.uint8)
    # ordre : on avance trait par trait ; un saut de stylo coûte un peu de temps
    u, chemin, bornes = 0.0, [], []
    prec = None
    for p, L in zip(res, longueurs):
        if prec is not None:
            u += math.hypot(p[0][0] - prec[0], p[0][1] - prec[1]) * 0.3
        seg = np.concatenate([[0], np.cumsum(np.hypot(*np.diff(p, axis=0).T))]) if len(p) > 1 else np.zeros(1)
        us = u + seg
        bornes.append(us)
        chemin.extend(zip(us, p[:, 0], p[:, 1]))
        u += max(L, 1.0)
        prec = p[-1]
    total = max(u, 1e-6)
    o = Image.new("F", (w, h), JAMAIS)
    do = ImageDraw.Draw(o)
    for t, p, us in reversed(list(zip(traits, res, bornes))):
        ep = t.get("ep", 6) + 4
        for i in range(len(p) - 1, 0, -1):
            v = float(us[i - 1] / total)
            do.line([tuple(p[i - 1]), tuple(p[i])], fill=v, width=int(round(ep)))
            x, y = p[i - 1]
            do.ellipse([x - ep / 2, y - ep / 2, x + ep / 2, y + ep / 2], fill=v)
        if len(p) == 1:
            x, y = p[0]
            do.ellipse([x - ep / 2, y - ep / 2, x + ep / 2, y + ep / 2], fill=float(us[0] / total))
    c.ordre = np.asarray(o, np.float32).copy()
    ch = np.array(chemin, np.float32)
    ch[:, 0] /= total
    c.chemin = ch
    c.longueur = float(sum(longueurs))
    c.nettete = max(160.0, total / 2.0)  # le trait révélé s'arrête à ~2 px de la pointe
    if remplissages:
        im = Image.new("RGBA", (w * ss, h * ss), (0, 0, 0, 0))
        di = ImageDraw.Draw(im)
        for r in remplissages:
            col = tuple(int(v) for v in r["coul"][:3]) + (255,)
            di.polygon([(x * ss, y * ss) for x, y in r["poly"]], fill=col)
        im = im.resize((w, h), Image.LANCZOS)
        ia = np.asarray(im, np.float32)
        # la couleur passe sous le trait : on garde le trait par-dessus
        a_fill = ia[..., 3] / 255.0
        a_c = a_fill * (1 - c.trait_a) + c.trait_a * a_fill
        rgb = ia[..., :3] * (1 - c.trait_a[..., None]) + c.trait_rgb.astype(np.float32) * c.trait_a[..., None]
        c.coul_a = np.maximum(a_c, 0).astype(np.float32)
        c.coul_rgb = np.clip(rgb, 0, 255).astype(np.uint8)
        fin = tuple(c.chemin[-1, 1:]) if len(c.chemin) else (0, 0)
        c.ordre_c, c.chemin_c, c.longueur_c = _ordre_couleur(a_fill > 0.4, depart=fin)
    habiller(c, style, couleurs, graine)
    if style not in ("craie", "croquis"):
        c.trait_rgb = arr[..., :3].astype(np.uint8)  # garde les traits de couleur (accent)
    elif style == "craie":
        c.trait_rgb = np.clip(arr[..., :3] * 0.35 + np.array([240, 238, 230]) * 0.65, 0, 255).astype(np.uint8)
    return c


# ---------------------------------------------------------------- 3. un texte manuscrit
def depuis_texte(texte, police, taille, couleur, style, couleurs, largeur_max=None, graine=0, interligne=1.05):
    font = ImageFont.truetype(police, int(taille))
    try:
        font.set_variation_by_name("Bold")
    except Exception:
        pass
    lignes = []
    for para in texte.split("\n"):
        mots, cour = para.split(), ""
        for m in mots:
            essai = (cour + " " + m).strip()
            if largeur_max and font.getlength(essai) > largeur_max and cour:
                lignes.append(cour)
                cour = m
            else:
                cour = essai
        lignes.append(cour)
    asc, desc = font.getmetrics()
    lh = int((asc + desc) * interligne)
    lw = [int(font.getlength(l)) for l in lignes]
    w, h = max(lw) + 16, lh * len(lignes) + 12
    im = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(im)
    for i, l in enumerate(lignes):
        d.text(((w - lw[i]) / 2, 6 + i * lh), l, font=font, fill=255)
    c = Calques(w, h)
    c.trait_a = np.asarray(im, np.float32) / 255.0
    col = np.array(couleur[:3], np.uint8)
    xs = np.arange(w, dtype=np.float32)
    o = np.full((h, w), JAMAIS, np.float32)
    n = len(lignes)
    chemin = []
    for i, l in enumerate(lignes):
        y0, y1 = 6 + i * lh, min(h, 6 + (i + 1) * lh)
        x0 = (w - lw[i]) / 2
        loc = np.clip((xs - x0) / max(lw[i], 1), 0, 1)
        o[y0:y1, :] = ((i + loc) / n)[None, :]
        bande = c.trait_a[y0:y1]
        poids = bande.sum(0)
        ys = (bande * np.arange(y0, y1)[:, None]).sum(0) / np.maximum(poids, 1e-3)
        for x in range(int(x0), int(x0 + lw[i]), 6):
            y = ys[x] if poids[x] > 0.5 else y0 + lh * 0.6
            chemin.append(((i + (x - x0) / max(lw[i], 1)) / n, x, y))
    c.ordre = o
    ch = np.array(chemin, np.float32)
    if len(ch) > 5:
        ch[:, 2] = np.convolve(np.pad(ch[:, 2], 2, mode="edge"), np.ones(5) / 5, mode="valid")
    c.chemin = ch
    c.longueur = float(sum(lw)) * 1.6
    c.nettete = max(160.0, float(sum(lw)) / 3.0)
    habiller(c, style, couleurs, graine)
    c.trait_rgb[:] = col
    return c


# ---------------------------------------------------------------- 4. une vraie photo
def depuis_photo(chemin, largeur, style, couleurs, cadre=True, graine=0):
    im = Image.open(chemin).convert("RGB")
    hauteur = int(round(largeur * im.height / im.width))
    largeur = int(round(largeur))
    m = 14
    w, h = largeur + 2 * m, hauteur + 2 * m
    photo = im.resize((largeur, hauteur), Image.LANCZOS)
    traits = []
    if cadre:
        rng = np.random.default_rng(graine)
        j = lambda: float(rng.normal(0, 1.5))  # noqa: E731
        coins = [(m / 2 + j(), m / 2 + j()), (w - m / 2 + j(), m / 2 + j()), (w - m / 2 + j(), h - m / 2 + j()), (m / 2 + j(), h - m / 2 + j())]
        traits = [{"pts": [coins[0], coins[1], coins[2], coins[3], coins[0]], "ep": 6}]
    c = depuis_traits(traits, [], w, h, style, couleurs, graine) if traits else Calques(w, h)
    a = np.zeros((h, w), np.float32)
    a[m:m + hauteur, m:m + largeur] = 1
    rgb = np.zeros((h, w, 3), np.uint8)
    rgb[m:m + hauteur, m:m + largeur] = np.asarray(photo)
    c.coul_a = a
    c.coul_rgb = rgb
    fin = tuple(c.chemin[-1, 1:]) if len(c.chemin) else (0, 0)
    c.ordre_c, c.chemin_c, c.longueur_c = _ordre_couleur(a > 0.5, depart=fin)
    return c
