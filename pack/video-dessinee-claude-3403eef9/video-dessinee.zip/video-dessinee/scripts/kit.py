"""Le kit de style : ce qui rend les vidéos dessinées d'une personne reconnaissables, dans un seul ZIP.

usage :
  python kit.py creer mon-style/ [--sortie kit-mon-style.zip] [--max-px 1600]
  python kit.py lire kit-mon-style.zip [--vers mon-style/]   # ou un dossier (kit décompressé, fichiers d'un Projet)

Dossier du style :
  mon-style/
    style.md       la fiche (modèle : assets/fiche-style.md), avec le bloc JSON "style"
    main/          une main personnalisée (facultatif : sinon une main fournie par le skill)
    dessins/       personnages ou dessins récurrents (images sur fond blanc)
    videos/        les vidéos déjà faites : pas mises dans le kit

Le kit contient : LISEZ-MOI.md, style.md, style.json, main/, dessins/, apercu.jpg.
"""
import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile

from PIL import Image

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
IMAGES = (".png", ".jpg", ".jpeg", ".webp")
LIMITE_APP = 30e6

LISEZ_MOI = """# Kit de style : {nom}

Ce kit garde le style de tes vidéos dessinées (dessin, affichage, couleurs, main, voix, ce qui a plu).

- **Projet Claude** : ajoute `style.md`, `apercu.jpg` et les images de `main/` et `dessins/` dans les
  fichiers du Projet. Ensuite, dans le Projet : « Nouvelle vidéo sur… ».
- **Conversation hors Projet** : joins ce ZIP au premier message : « Voici mon kit, nouvelle vidéo sur… ».
- **Claude Code** : garde le dossier du style et lance Claude Code dedans.

Un seul kit valable à la fois : quand Claude le refait, remplace l'ancien partout.
"""


def bloc_style(texte):
    for m in re.finditer(r"```json\s*(\{.*?\})\s*```", texte, re.S):
        try:
            d = json.loads(m.group(1))
        except json.JSONDecodeError as e:
            sys.exit(f"Le bloc JSON de style.md est invalide : {e}")
        if "style" in d:
            return d["style"]
    sys.exit("style.md n'a pas de bloc ```json {\"style\": …} ``` (modèle : assets/fiche-style.md).")


def slug(t):
    import unicodedata
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", t.lower()).strip("-") or "style"


def images(d):
    if not os.path.isdir(d):
        return []
    return sorted(os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith(IMAGES))


def copier_image(src, dst, max_px):
    im = Image.open(src)
    if max(im.size) > max_px:
        im.thumbnail((max_px, max_px), Image.LANCZOS)
    im.save(dst) if dst.lower().endswith(".png") else im.convert("RGB").save(dst, quality=90)


def vers_video(style, dossier):
    """Les clés de video.json tirées du style."""
    v = {"style": style.get("dessin", "flat"), "affichage": style.get("affichage", "fresque")}
    for k in ("tableau", "couleurs", "main_taille", "sous_titres", "vitesse"):
        if k in style:
            v[k] = style[k]
    m = style.get("main")
    if m:
        perso = images(os.path.join(dossier, "main"))
        v["main"] = os.path.relpath(perso[0], dossier) if perso else m
    return v


def apercu(dossier, style, sortie):
    """Une image du style : un titre, un dessin récurrent (ou un croquis), une légende."""
    import moteur
    dessins = images(os.path.join(dossier, "dessins"))
    v = vers_video(style, dossier)
    v["affichage"] = "successifs"  # l'aperçu tient sur une page
    v["sous_titres"] = False
    elt = {"type": "image", "src": os.path.relpath(dessins[0], dossier)} if dessins else {"type": "dessin", "sujet": "ampoule", "largeur": 0.45}
    v["scenes"] = [{"texte": "Aperçu du style.", "elements": [
        {"type": "texte", "texte": style.get("nom", "Mon style"), "role": "titre"}, elt,
        {"type": "texte", "texte": "une idée, un dessin"}]}]
    p = os.path.join(dossier, "_apercu.json")
    json.dump(v, open(p, "w", encoding="utf-8"), ensure_ascii=False)
    vid = moteur.Video(p)
    t_fin = max(e.fin for e in vid.elts)
    vid.image(t_fin * 0.6).resize((540, 960)).save(os.path.join(dossier, "_a1.png"))
    im2 = vid.image(t_fin + 0.9).resize((540, 960))
    a1 = Image.open(os.path.join(dossier, "_a1.png"))
    pl = Image.new("RGB", (1100, 980), (30, 30, 34))
    pl.paste(a1, (10, 10))
    pl.paste(im2, (550, 10))
    pl.save(sortie, quality=88)
    for f in ("_apercu.json", "_a1.png", "mots.json"):
        if os.path.exists(os.path.join(dossier, f)):
            os.remove(os.path.join(dossier, f))


def creer(a):
    dossier = os.path.abspath(a.dossier)
    fiche = os.path.join(dossier, "style.md")
    if not os.path.exists(fiche):
        sys.exit(f"Pas de style.md dans {dossier} (modèle : assets/fiche-style.md).")
    style = bloc_style(open(fiche, encoding="utf-8").read())
    nom = style.get("nom", os.path.basename(dossier))
    s = slug(nom)
    sortie = a.sortie or os.path.join(os.path.dirname(dossier), f"kit-{s}.zip")
    with tempfile.TemporaryDirectory() as tmp:
        racine = os.path.join(tmp, f"kit-{s}")
        os.makedirs(racine)
        shutil.copy(fiche, os.path.join(racine, "style.md"))
        json.dump({"style": style}, open(os.path.join(racine, "style.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        for sd in ("main", "dessins"):
            fs = images(os.path.join(dossier, sd))
            if fs:
                os.makedirs(os.path.join(racine, sd))
                for f in fs:
                    copier_image(f, os.path.join(racine, sd, os.path.basename(f)), a.max_px)
        apercu(racine, style, os.path.join(racine, "apercu.jpg"))
        open(os.path.join(racine, "LISEZ-MOI.md"), "w", encoding="utf-8").write(LISEZ_MOI.format(nom=nom))
        with zipfile.ZipFile(sortie, "w", zipfile.ZIP_DEFLATED) as z:
            for r, _, fs in os.walk(racine):
                for f in fs:
                    if ".trace" in r:
                        continue
                    p = os.path.join(r, f)
                    z.write(p, os.path.relpath(p, tmp))
    taille = os.path.getsize(sortie)
    print(f"Kit : {sortie} ({taille / 1e6:.1f} Mo)")
    if taille > LIMITE_APP:
        print("  ! plus de 30 Mo (limite de l'app) : relancer avec --max-px 1200")


def lire(a):
    src = os.path.abspath(a.kit)
    tmp = None
    if zipfile.is_zipfile(src):
        tmp = tempfile.mkdtemp()
        with zipfile.ZipFile(src) as z:
            z.extractall(tmp)
        base = tmp
    else:
        base = src
    racines = [r for r, _, fs in os.walk(base) if "style.md" in fs]
    if not racines:
        sys.exit("Pas de style.md dans ce kit.")
    racine = racines[0]
    style = bloc_style(open(os.path.join(racine, "style.md"), encoding="utf-8").read())
    vers = os.path.abspath(a.vers or slug(style.get("nom", "style")))
    os.makedirs(vers, exist_ok=True)
    shutil.copy(os.path.join(racine, "style.md"), vers)
    n = 0
    for sd in ("main", "dessins"):
        d = os.path.join(racine, sd)
        if os.path.isdir(d):
            os.makedirs(os.path.join(vers, sd), exist_ok=True)
            for f in os.listdir(d):
                shutil.copy(os.path.join(d, f), os.path.join(vers, sd, f))
                n += 1
    if not os.path.isdir(os.path.join(racine, "dessins")):  # fichiers d'un Projet posés à plat
        for f in os.listdir(racine):
            if f.lower().endswith(IMAGES) and not f.startswith("apercu"):
                sd = "main" if "main" in f.lower() else "dessins"
                os.makedirs(os.path.join(vers, sd), exist_ok=True)
                shutil.copy(os.path.join(racine, f), os.path.join(vers, sd, f))
                n += 1
    v = vers_video(style, vers)
    json.dump(v, open(os.path.join(vers, "style-video.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"Style « {style.get('nom', '?')} » rangé dans {vers} ({n} images)")
    print(f"Dessin : {v['style']} · affichage : {v['affichage']} · main : {v.get('main', 'celle du style')}")
    print("À recopier en tête de video.json :", json.dumps(v, ensure_ascii=False))
    print("Relire « Ce qui a plu » et « Sujets déjà faits » dans style.md.")


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    c = sp.add_parser("creer")
    c.add_argument("dossier")
    c.add_argument("--sortie")
    c.add_argument("--max-px", type=int, default=1600)
    l_ = sp.add_parser("lire")
    l_.add_argument("kit")
    l_.add_argument("--vers")
    a = ap.parse_args()
    creer(a) if a.cmd == "creer" else lire(a)


if __name__ == "__main__":
    main()
