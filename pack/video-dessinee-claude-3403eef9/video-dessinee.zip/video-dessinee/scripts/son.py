"""Le son : la voix, et en option seulement un bruit de feutre (ou de craie) très bas quand la main dessine.

usage :
  python son.py sortie/muette.mp4 --trace sortie/trace.json [--voix voix.mp3 --voix-a 0.3] [--sortie sortie/video.mp4]
                [--avec-trait] [--musique fond.mp3]

- Le bruit du trait est calculé ici à partir des gestes de la main (trace.json, écrit par moteur.py) :
  souffle filtré, plus fort quand la main va vite, grain plus sec pour la craie. Libre de droits.
- Désactivé par défaut (il agace vite). --avec-trait l'ajoute, environ 34 dB sous la voix.
- La musique (facultative) baisse toute seule quand la voix parle.
- Sortie à -14 LUFS (niveau TikTok/Reels) ; sans voix ni musique, le trait éventuel reste à -36 LUFS.
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from outils import SR, ecrire_wav, ffmpeg_exe, lire_audio, normaliser  # noqa: E402


def passe_bande(x, bas, haut):
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    g = np.clip((f - bas * 0.7) / (bas * 0.3 + 1), 0, 1) * np.clip((haut * 1.3 - f) / (haut * 0.3 + 1), 0, 1)
    return np.fft.irfft(X * g, len(x)).astype(np.float32)


def bruit_trait(trace, duree):
    n = int(duree * SR)
    rng = np.random.default_rng(4)
    style = trace.get("style", "feutre")
    fps = trace["fps"]
    im = np.array(trace["images"], np.float32).reshape(-1, 2)
    if not len(im):
        return np.zeros(n, np.float32)
    t_im = np.arange(len(im)) / fps
    t = np.arange(n) / SR
    pose = np.interp(t, t_im, im[:, 0])
    vit = np.interp(t, t_im, im[:, 1])
    env = pose * (0.35 + 0.65 * np.clip(vit / 900, 0, 1))
    k = int(0.02 * SR)  # attaque et relâche douces
    env = np.convolve(env, np.ones(k) / k, mode="same")
    b = rng.standard_normal(n).astype(np.float32)
    if style == "craie":
        son = passe_bande(b, 1800, 9000) * 0.8
        clics = (rng.random(n) < 0.0009).astype(np.float32) * rng.standard_normal(n).astype(np.float32) * 6
        son += passe_bande(clics, 1500, 7000)
        mod = 0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 11 * t + rng.random() * 6))
    elif style == "croquis":
        son = passe_bande(b, 3000, 11000) * 0.7
        mod = 0.8 + 0.2 * np.sin(2 * np.pi * 7 * t)
    else:
        son = passe_bande(b, 1200, 6500)
        mod = 0.75 + 0.25 * np.sin(2 * np.pi * 9 * t + 1)
    y = son * env * mod
    m = np.abs(y).max() or 1
    return (y / m * 0.25).astype(np.float32)


def duree_video(v):
    import re
    err = subprocess.run([ffmpeg_exe(), "-i", v], capture_output=True, text=True).stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", err)
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def assembler(video, trace, voix, voix_a, sortie, trait=False, musique=None):
    duree = duree_video(video)
    n = int(duree * SR)
    mix = np.zeros(n, np.float32)
    parle = np.zeros(n, np.float32)
    if voix:
        v = lire_audio(voix)
        i0 = int(voix_a * SR)
        v = v[: max(0, n - i0)]
        mix[i0:i0 + len(v)] += v
        a = np.abs(v)
        k = int(0.25 * SR)
        parle[i0:i0 + len(v)] = np.clip(np.convolve(a, np.ones(k) / k, mode="same") * 30, 0, 1)
    if trait and trace and os.path.exists(trace):
        tr = json.load(open(trace))
        b = bruit_trait(tr, duree)
        ref = np.sqrt(np.mean(mix[mix != 0] ** 2)) if voix else 0.1
        rb = np.sqrt(np.mean(b[b != 0] ** 2)) if np.any(b) else 1
        gain = ref / max(rb, 1e-6) * (10 ** (-34 / 20)) if voix else 0.3
        mix += b * gain
    if musique:
        m = lire_audio(musique)
        m = np.tile(m, int(np.ceil(n / max(len(m), 1))))[:n]
        rm = np.sqrt(np.mean(m ** 2)) or 1
        ref = np.sqrt(np.mean(mix ** 2)) or 0.05
        m = m / rm * ref * (10 ** (-14 / 20))
        mix += m * (1 - 0.65 * parle)
    with tempfile.TemporaryDirectory() as tmp:
        brut = os.path.join(tmp, "mix.wav")
        norm = os.path.join(tmp, "norm.wav")
        ecrire_wav(brut, mix)
        normaliser(brut, norm, -14.0 if (voix or musique) else -36.0)  # sans voix ni musique : le trait reste un fond discret
        subprocess.run([ffmpeg_exe(), "-v", "error", "-y", "-i", video, "-i", norm, "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                        "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", sortie], check=True)
    print(f"Vidéo finale : {sortie} ({duree:.1f} s, {os.path.getsize(sortie) / 1e6:.1f} Mo"
          f"{', voix' if voix else ', sans voix'}{', bruit du trait' if trait else ''})")
    return sortie


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--trace")
    ap.add_argument("--voix")
    ap.add_argument("--voix-a", type=float, default=0.3)
    ap.add_argument("--musique")
    ap.add_argument("--avec-trait", action="store_true", help="bruit de feutre très bas (désactivé par défaut)")
    ap.add_argument("--sortie")
    a = ap.parse_args()
    sortie = a.sortie or os.path.join(os.path.dirname(os.path.abspath(a.video)), "video.mp4")
    assembler(a.video, a.trace, a.voix, a.voix_a, sortie, a.avec_trait, a.musique)


if __name__ == "__main__":
    main()
